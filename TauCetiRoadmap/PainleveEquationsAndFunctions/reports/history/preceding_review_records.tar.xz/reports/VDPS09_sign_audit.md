# VDPS09 Hamiltonian extended-form sign audit

Source: Marius van der Put and Masa-Hiko Saito, *Moduli spaces for linear differential equations and the Painlevé equations*, arXiv:0902.1702v5, <https://arxiv.org/pdf/0902.1702v5>.

This audit concerns an internal sign inconsistency in the displayed extended two-form, not the source's derived scalar equation. The original PDF was rendered using PyMuPDF and visually inspected, so the minus sign below is not an OCR/extraction artifact. Evidence: `_research/VDPS09_page42.png`, PDF page index 41, printed p.42.

## Direct check in the PI example

Equations (44), (46), and (47) display

\[
 q'=2p,\qquad p'=3q^2+t,\qquad H=-p^2+q^3+tq,
\]

and the proposed extended form

\[
 \Omega_{\mathrm{printed}}=dp\wedge dq-dH\wedge dt.
\]

At \(q=t=0\), \(p=1\), the time vector is
\(V=\partial_t+2\partial_q\) and \(dH=-2dp\). Hence

\[
 \iota_V\Omega_{\mathrm{printed}}
 =-2dp-2dp=-4dp\ne0.
\]

The compatible form is

\[
 \Omega_{\mathrm{corrected}}=dp\wedge dq+dH\wedge dt.
\]

This annihilates the displayed vector field everywhere because the equations are \(q'=-H_p\), \(p'=H_q\).

## Conversion to the draft's convention

Section 4.1 uses a phase form \(dp\wedge dq/F(q)\) and equations

\[
 q'=-F(q)H_p,\qquad p'=F(q)H_q.
\]

The source's factors are \(F\in\{1,q,q^2,q(q-1)\}\), so they have no explicit time dependence. On the chart where \(F\ne0\), put

\[
 Q=q,\qquad P=\frac p{F(q)},\qquad
 K(Q,P,t)=-H(F(Q)P,Q,t),
\]

where the source argument order is \(H(p,q,t)\). Then

\[
 dQ\wedge dP=-\frac{dp\wedge dq}{F(q)},\qquad
 dQ\wedge dP+dK\wedge dt
 =-\left(\frac{dp\wedge dq}{F(q)}+dH\wedge dt\right).
\]

Multiplying a two-form by −1 does not change its kernel. These coordinates therefore give precisely the draft convention

\[
 \iota_X(dQ\wedge dP)=d_{\mathrm{phase}}K,
 \qquad Q'=K_P,\quad P'=-K_Q.
\]

For PI, \(F=1\), this gives \(K=P^2-Q^3-tQ\). The familiar normalization with coefficients \(q''=6q^2+t\) requires the further explicitly recorded time/phase scaling; the source's displayed equation is \(q''=6q^2+2t\).

The map \((p,q)\mapsto(P,Q)\) here is time independent, so there is no additional generating term. A later time-dependent symplectic coordinate change must be checked through equality of extended forms rather than by this formula alone.

## Recommended use

Keep the draft's internally checked sign convention. Quote the source for its connection presentation, Hamiltonian equations, and scalar elimination after the stated conversion, but explicitly record the corrected extended-form sign. A short coordinate lemma should prove the contraction identity directly; it must not inherit the inconsistent source sign as a premise.
