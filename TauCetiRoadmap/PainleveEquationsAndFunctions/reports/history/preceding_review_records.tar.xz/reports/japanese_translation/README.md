# Japanese translation review archive

The complete Japanese edition is `../../README.ja.md`. The reader-facing review report is `../translation_review_report.ja.md`.

- `review_round1/`: immutable inputs for the full cross-author translation comparison.
- `review_round2/`: immutable corrected inputs for finding closure and focused delta review.
- `reviews/`: translation-author checks, independent findings, and closure records.
- `round1_author_resolutions.json`: immutable author amendment ledger reviewed in round 2. Its historical pending status is superseded by `final_review.json`.
- `appendix_inputs.ja.json` and `appendix_obligations.ja.json`: Japanese translations of the final mathematical plan's input fields and explicit owned proof obligations.
- `validation.json`: coverage and transcription invariants; semantic review is recorded separately.
- `final_review.json`: exact-source binding, final translation hashes, reviewer verdicts and closed findings.
- `history/`: the package report before the Japanese edition was added.

The original English roadmap and structured mathematical plan were not changed. This archive does not claim that the planned mathematical theorems have been proved.

Reassemble the Japanese edition with:

```bash
python3 reports/japanese_translation/build_japanese_edition.py --input reports/japanese_translation/review_round2/artifact --output README.ja.md
```

Verify translation coverage and immutable mathematical sources with:

```bash
python3 reports/japanese_translation/validate_translation.py --root .
```
