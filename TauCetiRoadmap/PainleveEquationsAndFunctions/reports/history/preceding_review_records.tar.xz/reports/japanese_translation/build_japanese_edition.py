#!/usr/bin/env python3
"""Assemble the reviewed translation fragments and translated plan appendices."""
from pathlib import Path
import argparse
import json

p = argparse.ArgumentParser()
p.add_argument('--input', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
names = ['front.ja.md','layers_1_4.ja.md','layers_5_8.ja.md','layers_9_11.ja.md','end.ja.md']
parts = [(a.input/f).read_text().rstrip() for f in names]
inputs = json.loads((a.input/'appendix_inputs.ja.json').read_text())
obligations = json.loads((a.input/'appendix_obligations.ja.json').read_text())
appendix = ['## 付録A：各項目の入力条件と証明範囲','',
    'この付録は、同じ数学レビュー済み版の `design/plan.json` にある44項目の `hypotheses` を日本語で示す。入力として受け取るものと、その項目でこれから構成・証明するものを区別する。各節の本文と合わせて読む。']
for layer in range(1,12):
    appendix += ['',f'### 第{layer}層の入力条件','']
    appendix += ['\n\n'.join(f'- **§{k}**　{v}' for k,v in inputs.items() if k.split('.')[0]==str(layer))]
appendix += ['', '## 付録B：本ロードマップが担う明示的な証明課題','',
    '次の12項目は、構造化計画で明示的に記録された証明課題である。いずれも本ロードマップの担当範囲にあり、必要な結論を仮定へ戻してよいという意味ではない。この一覧だけが未証明事項の全体だという主張でもない。','']
appendix += ['\n\n'.join(f'- **§{k}**　{v}' for k,v in obligations.items())]
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text('\n\n'.join(parts)+'\n\n'+'\n'.join(appendix)+'\n')
print(str(a.output))
