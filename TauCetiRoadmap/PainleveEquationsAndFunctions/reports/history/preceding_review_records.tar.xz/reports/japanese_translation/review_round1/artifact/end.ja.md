## 下流の利用先

今後のランダム行列や可積分確率論の応用では、内在的な相空間と観測量をつなぐ本ロードマップの結果を、RandomMatrices §§8.3–8.5とともに利用できる。その際、Fredholm行列式、Airy端点、およびHastings–McLeod理論の担当範囲は維持する。両方を利用するものは新しい下流の課題であり、既存のRandomMatricesロードマップに本ロードマップへの依存を後から課すものではない。

ほかの利用先として、幾何学的特殊関数や接続公式の比較、不確定特異点を持つ接続のモジュライと指標多様体、および制御された退化の問題がある。これらは、実際に証明された範囲で、水平性・シンプレクティック性・接続・正規化に関する結果を利用する。すべての既約な超越関数の微分代数的分類、代数的特殊解の完全分類、離散・q差分パンルヴェ系、およびクラスターやSakai分類全体に及ぶ構成は、別の拡張である。そのいずれも、上の内在的な微分方程式の構成の前提とはしない。

実施順序は依存グラフに従う。まず既存の幾何学・解析学の基礎と、指定した供給元の拡張を用意し、次に第1～5層を進める。曲面とタウの分枝は、それぞれに明示した前提が整えば進められる。座標比較は関係する分枝に続き、正規化された解析的応用と合流は、その比較を利用する。この順序により、共通の定義と定理が古典的スカラー表示から独立であることを保つ。

## 参考文献

- **I23.** Michi-aki Inaba. *[Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation](https://sigma-journal.com/2023/013/)*. SIGMA 19 (2023), 013, 72 pages. 出版社版、2023年3月22日。参照箇所：Definitions 2.1–2.8; Remark 2.9; Theorems 5.1, 7.5, 8.1, 9.7 and 11.6; equation (6.9); Propositions 6.3, 7.2, 8.2–8.3, 10.7 and 10.10; Definitions 10.1 and 11.4; Corollaries 9.11 and 11.8; equations (8.2), (11.2) and (11.5).

- **IS12.** Michi-aki Inaba; Masa-Hiko Saito. *[Moduli of unramified irregular singular parabolic connections on a smooth projective curve](https://arxiv.org/abs/1203.0084v3)*. Kyoto Journal of Mathematics 53(2) (2013), 433–482. 引用版：arXiv 1203.0084v3（2012年11月22日）。文献キーにはプレプリントの年を残す。参照箇所：Theorem 5.1; Remark 6.3.

- **HEU10.** Viktoria Heu. *[Universal isomonodromic deformations of meromorphic rank 2 connections on curves](https://www.numdam.org/item/AIF_2010__60_2_515_0/)*. Annales de l'Institut Fourier 60(2) (2010), 515–549. NUMDAMで公開された出版本文。誌面pp. 515–549。参照箇所：Theorem 1.1; Definitions 2.3 and 2.10; §2.

- **VDPS09.** Marius van der Put; Masa-Hiko Saito. *[Moduli spaces for linear differential equations and the Painlevé equations](https://arxiv.org/abs/0902.1702v5)*. Annales de l'Institut Fourier 59(7) (2009), 2611–2667. 引用版：arXiv 0902.1702v5（2009年11月12日）。残る内部の不整合は§9.4で指摘する。参照箇所：§2.2, Table 1, preprint pp. 18–19; §3; §4.1 and §§4.3–4.11; equations (12), (17) and (22).

- **IIS06.** Michi-aki Inaba; Katsunori Iwasaki; Masa-Hiko Saito. *[Dynamics of the Sixth Painlevé Equation](https://arxiv.org/abs/math/0501007v2)*. Séminaires et Congrès 14 (2006), 103–167. 引用版：arXiv math/0501007v2（2005年3月6日）。参照箇所：Definitions 2.1–2.2 and 2.11; Lemma 2.12; Definition 3.5; Theorems 4.10–4.12, 5.15–5.16, 7.4, 10.6, 10.10 and 10.13; §§5, 7 and 10.

- **BOA01.** Philip Boalch. *[Symplectic Manifolds and Isomonodromic Deformations](https://arxiv.org/abs/2002.00052v1)*. Advances in Mathematics 163 (2001), 137–205. 引用版：arXiv 2002.00052v1。2001年の論文を著者が2020年に登録した版。参照箇所：§§3–6; Theorems 7.1 and 7.3; §7.

- **BOA14.** P. P. Boalch. *[Geometry and braiding of Stokes data; Fission and wild character varieties](https://arxiv.org/abs/1111.6228v3)*. Annals of Mathematics 179(1) (2014), 301–365. 引用版：arXiv 1111.6228v3（2012年9月22日）。参照箇所：§10, Theorem 10.2; Stokesデータについては§7。

- **BY15.** Philip Boalch; Daisuke Yamakawa. *[Twisted wild character varieties](https://arxiv.org/abs/1512.08091v1)*. arXiv preprint 1512.08091. 引用版：arXiv 1512.08091v1（2015年12月26日）。参照箇所：Remark 3; Definitions 7 and 13; Proposition 19; Theorem 21; Corollary 22.

- **STT02.** Masa-Hiko Saito; Taro Takebe; Hitomi Terajima. *[Deformation of Okamoto–Painlevé pairs and Painlevé equations](https://arxiv.org/abs/math/0006026v2)*. Journal of Algebraic Geometry 11(2) (2002), 311–362. 引用版：arXiv math/0006026v2（2000年9月18日）、3名の共著による論文。参照箇所：Definitions 1.1 and 1.3; Proposition 1.2; Tables 2–3; Theorem 3.1; §6.

- **TER02.** Hitomi Terajima. *[Local cohomology of generalized Okamoto–Painlevé pairs and Painlevé equations](https://arxiv.org/abs/math/0006027v1)*. Japanese Journal of Mathematics, New Series 28(1) (2002), 137–162. 引用版：arXiv math/0006027v1（2000年6月5日）。参照箇所：Theorem 2.1; Proposition 2.1; Conjecture 2.1.

- **ST04.** Masa-Hiko Saito; Hitomi Terajima. *[Nodal curves and Riccati solutions of Painlevé equations](https://arxiv.org/abs/math/0201225v1)*. Journal of Mathematics of Kyoto University 44(3) (2004), 529–568. 引用版：arXiv math/0201225v1（2002年1月23日）。参照箇所：§2.4; Proposition 2.1; Definition 2.3; Remark 2.4; Appendix A.

- **FM19.** Andrea E. V. Ferrari; Lionel Mason. *[Meromorphic Painlevé III transcendents and the Joukowski correspondence](https://arxiv.org/abs/1809.07885v2)*. Journal of Integrable Systems 4(1) (2019), xyz001. 引用版：arXiv 1809.07885v2（2019年1月30日）。参照箇所：§1.1; equation (2).

- **DIL21.** Jan Dereziński; Artur Ishkhanyan; Adam Latosiński. *[From Heun Class Equations to Painlevé Equations](https://sigma-journal.com/2021/056/)*. SIGMA 17 (2021), 056, 59 pages. 出版社版、2021年6月7日。参照箇所：§§5.2–5.3; Appendix B.3.

- **AHT17.** Primitivo B. Acosta-Humánez; Marius van der Put; Jaap Top. *[Isomonodromy for the Degenerate Fifth Painlevé Equation](https://sigma-journal.com/2017/029/)*. SIGMA 13 (2017), 029, 14 pages. 出版社版、2017年5月9日。参照箇所：Introduction; §§2–3.

- **MAL04.** Bernard Malgrange. *[Déformations isomonodromiques, forme de Liouville, fonction τ](https://www.numdam.org/articles/10.5802/aif.2052/)*. Annales de l'Institut Fourier 54(5) (2004), 1371–1392. NUMDAMで公開された出版本文。誌面pp. 1371–1392。参照箇所：§2, printed pp. 1372–1374; Theorem 5.12.

- **BERT10.** Marco Bertola. *[The dependence on the monodromy data of the isomonodromic tau function](https://arxiv.org/abs/0902.4716v2)*. Communications in Mathematical Physics 294 (2010), 539–579. 引用版：arXiv 0902.4716v2（2016年1月20日）。必ずBERT16と併用する。参照箇所：Assumption 3.1; §5.1, Proposition 5.1; Theorem 5.1はBERT16の訂正とともにのみ用いる。

- **BERT16.** Marco Bertola. *[Corrigendum: The dependence on the monodromy data of the isomonodromic tau function](https://arxiv.org/abs/1601.04790v2)*. Communications in Mathematical Physics 381 (2021), 1445–1461. 引用版：arXiv 1601.04790v2（2020年9月19日）。2021年に「Correction to: The Dependence on the Monodromy Data of the Isomonodromic Tau Function」の題で出版された。文献キーには最初のプレプリントの年である2016年を残す。参照箇所：Definition 2.1; Theorems 2.1 and 2.2.

- **BERT17.** Marco Bertola. *[The Malgrange Form and Fredholm Determinants](https://arxiv.org/abs/1703.00046v4)*. SIGMA 13 (2017), 046, 12 pages. 引用版：arXiv 1703.00046v4、SIGMA掲載本文を収録した版。参照箇所：§1; Theorem 2.2; Proposition 2.3; formula (3.6); Theorem 3.3; §3.1.2.

- **ILP18.** A. R. Its; O. Lisovyy; A. Prokhorov. *[Monodromy dependence and connection formulae for isomonodromic tau functions](https://arxiv.org/abs/1604.03082v4)*. Duke Mathematical Journal 167(7) (2018), 1347–1432. 引用版：arXiv 1604.03082v4（2018年10月29日）。参照箇所：§1.4, Theorems A and B, equations (1.13), (1.16)–(1.21), (1.25)–(1.28); Lemma 3.3; Propositions 3.20 and 3.24; §3.9; §§4.3–4.5, especially (4.74)–(4.76); Remark 4.8.

- **DIK08.** P. Deift; A. Its; I. Krasovsky. *[Asymptotics of the Airy-kernel determinant](https://arxiv.org/abs/math/0609451v2)*. Communications in Mathematical Physics 278 (2008), 643–678. 引用版：arXiv math/0609451v2（2007年6月21日）。参照箇所：Theorem 1; equations (2)–(3).

- **HXZ16.** Min Huang; Shuai-Xia Xu; Lun Zhang. *[Location of Poles for the Hastings–McLeod Solution to the Second Painlevé Equation](https://arxiv.org/abs/1410.3338v2)*. Constructive Approximation 43(3) (2016), 463–494. 引用版：arXiv 1410.3338v2（2015年7月9日）。参照箇所：Theorem 2.1.

- **GMR23.** Ilia Gaiur; Marta Mazzocco; Vladimir Rubtsov. *[Isomonodromic Deformations: Confluence, Reduction and Quantisation](https://doi.org/10.1007/s00220-023-04650-8)*. Communications in Mathematical Physics 400 (2023), 1385–1461. 出版社の確定版、2023年3月1日、CC BY 4.0。参照箇所：Theorem 2, pp. 1391–1392, (12)–(15)。これは§11.1の、極の階数を上げる係数についての訂正済み補題とともにのみ用いる。Definitions 3–4 and Theorem 12, §4.2, pp. 1428–1429; brackets (96)–(97); Theorem 13, §4.3, pp. 1435–1436; 分岐を伴わない場合に範囲を限定する明記については§5.1, p. 1441。

- **DLMF.** P. A. Clarkson, *[Painlevé Transcendents, Chapter 32 of the NIST Digital Library of Mathematical Functions](https://dlmf.nist.gov/32)*. Version 1.2.8、2026年9月15日公開。[§32.2](https://dlmf.nist.gov/32.2), equations 32.2.1–32.2.6; [§32.6](https://dlmf.nist.gov/32.6); [§32.7](https://dlmf.nist.gov/32.7); [§32.9](https://dlmf.nist.gov/32.9)、特にequations 32.9.6 and 32.9.12。標準的スカラー表示と正規化の参照先。

