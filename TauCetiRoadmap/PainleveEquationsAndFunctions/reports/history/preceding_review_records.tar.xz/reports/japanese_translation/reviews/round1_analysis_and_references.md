# 日本語版・第1回独立照合：第9～11層、下流利用先、参考文献

## 結果

数学的な誤訳、欠落、量化・適用範囲の変更、数式の転記誤りは **0件**。**P3 の用語精密化を1件**記録する。これは指数パラメータの写像を exponential map と読み違えないための明確化であり、数学的な反例や定理の不成立を指摘するものではない。

レビュー担当：`/root/ja_translate_geometry`。対象の訳文は他担当が作成したものであり、凍結された入力を読んで照合した。訳文ファイルには変更を加えていない。

## 照合範囲と方法

第9～11層の全13目標を、英語正本と段落ごとに照合した。原文・訳文ともに340行、127段落、68箇条書きであり、すべての目標IDが一致する。入力条件の付録13項目は最終版 `design/plan.json` の `hypotheses` と、証明課題の付録3項目（10.2、10.3、11.1）は同じファイルの `owned_proof_obligations` と照合した。下流利用先の全3段落と参考文献全23件を、版、日付、URL、定理・式番号、訂正の扱いまで確認した。

数式記号、引用キー、基礎ライブラリの識別子に脱落はない。ギリシャ文字は原文の全出現を保持しており、訳文で Γ が1回多いのは「Γ は弧長測度を備え」という明示的主語である。文献URLおよび文献キーの順序付き列は一致する。これらの機械的確認に加えて、各段落の仮定・結論・限定条件を読んで確認した。

## 指摘

### JA-R1-ANALYSIS-TERM-01 — P3：exponent map と exponential map の用語上の区別

**位置：** `layers_9_11.ja.md` の §11.1、凍結ファイル251・270・278行。関連箇所は `appendix_inputs.ja.json` の `11.1`。

**原文：** “the meromorphic-in-ε exponent map”、APIの “exponent map”、大域検証族の “exponent map”。

**訳文：** 「ε について有理型の指数写像」「分岐、指数写像を保持して」「端点条件全体、指数写像、安定部分」。

ここで指定するのは、接続の局所指数・留数パラメータの対応写像である。「指数写像」は通常 exponential map の訳語としても使われるため、入力として別の写像を求めているように読める。周囲の形式型・パラメータの文脈から意味は回復でき、式や量化も保存されているので、P3 の明確化とする。

**修正案：** 3箇所を「指数パラメータの写像」に変更する。付録11.1の「行列式・指数・時間の写像」も「行列式・指数パラメータ・時間の写像」とそろえるとよい。

## 重点項目の結果

| 範囲 | 確認した内容 | 結果 |
|---|---|---|
| §9.1–9.2 | 1次ジェットの実際の同型領域、逆運動量、全方程式と係数・時間対応表 | 同値 |
| §9.3–9.5 | 係数境界の被覆、VDPS09の符号訂正、シグマの逆構成の限定、種解と完全分類を主張しない範囲 | 同値 |
| §10.1 | 選択データに解や存在を含めないこと、例外的ファイバーの持ち上げと正規化 | 同値 |
| §10.2 | 各パラメータでのlittle-oとパラメータ一様little-oの区別、重み付きL¹・L²の両方の裾条件、追加1モーメントによる一様O評価 | 同値 |
| §10.2の検証例 | Cauchyクラスと端点の反例、Gaussian移動質量、係数・極限の非零定数 | 同値 |
| §10.3 | PVIおよび斉次PIIの厳密なパラメータ領域、η座標の除外、閉扇形の一様評価、弧積分の次数、+iπ/24 | 同値 |
| §11.1 | §1.3の全primitive条件、行列式の確定特異性、全Takiff係数の符号反転、訂正Laurent係数、トレース非零の除外例 | 同値。用語明確化1件 |
| §11.2 | 参照解のみを入力とし、近似解の存在・退出しないこと・収束を結論とすること、正の余裕、有限共通座標、経路速度 | 同値 |
| §11.3–11.4 | 合流射のデータ依存性、線束・枠比較と収束の順序、零点数と端点定数の追加仮定 | 同値 |
| 付録 | 最終数学版で修正された入力／出力の区別 | 同値 |
| 文献 | 全23件のURL・版・locator・訂正・限定範囲 | 同値 |

## 対象ハッシュ

- `/workspace/scratch/58443e4fc6da/PainleveEquationsAndFunctions/README.md`
  SHA256: `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658`

- `/workspace/scratch/58443e4fc6da/PainleveEquationsAndFunctions/design/plan.json`
  SHA256: `9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4`

- `/workspace/scratch/58443e4fc6da/_ja_translation/review_round1/artifact/layers_9_11.ja.md`
  SHA256: `6cc5013c8611cde195e29983033b7f94dd47f49ffa34068d41bc780e3ce5933e`

- `/workspace/scratch/58443e4fc6da/_ja_translation/review_round1/artifact/end.ja.md`
  SHA256: `5f9e55e2bfd9a415fecf6d43be537fba40e95db3c6f4dfc4eb59b5e1be2c3463`

- `/workspace/scratch/58443e4fc6da/_ja_translation/review_round1/artifact/appendix_inputs.ja.json`
  SHA256: `acc3013338a20487258c8d9800598d6094c9c423e22f2aeb167844c31bd36f76`

- `/workspace/scratch/58443e4fc6da/_ja_translation/review_round1/artifact/appendix_obligations.ja.json`
  SHA256: `fef5ceb7657e60aee392a408a0113b42f8734b65b8d1fad8b92f6bd1703178bd`

## レビューの限界

これは凍結された数学版ドラフトに対する翻訳同値性の照合であり、ロードマップ内の将来の証明課題を新たに証明したという判定ではない。Lean、Workerの実行、および外部への書き込みは対象外とした。
