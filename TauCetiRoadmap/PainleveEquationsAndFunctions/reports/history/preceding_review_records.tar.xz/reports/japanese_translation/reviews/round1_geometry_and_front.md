# 日本語版の数学的翻訳レビュー：第1回、第5〜8層・前書き

## 判定

**修正が必要。P2 指摘 3 件。** 第5〜8層の15目標、前書きと依存契約全体、および付録の第5〜8層の入力条件・証明課題を、英語版 README と構造化計画に照合した。訳文の直接編集はしていない。

担当訳者とは別のレビューとして実施した。数式の記号・符号・係数、量化、仮定と結論、一般的位置と例外的な層の範囲、未証明目標の位置づけを確認した。15目標のすべてで、原文と訳文の段落数・箇条書き数が一致した。以下の指摘以外に、段落の脱落や数学的な範囲の変更は検出しなかった。

## JA-R1-GF-01 — continuation と connection の区別（P2）

原文の continuation が複数箇所で無修飾の「接続」となっている。特に §5.5 の原文見出し **Scalar meromorphic continuation** に対応する「スカラー有理型接続」は、すでに ∇ に対して用いている **meromorphic connection = 有理型接続** と同じ名称になってしまう。この目標は、スカラー接続の構成ではなく、観測量の値の有理型延長を証明するものである。

以下はレビュー対象内の具体的な箇所と修正案である。行番号は今回の凍結入力に対するもの。

| ファイル・位置 | 現在の訳文 | 修正案 |
|---|---|---|
| front.ja.md, 6行、概要 | 共通の接続定理 | 共通の延長定理 |
| front.ja.md, 10行、担当範囲 | 完備な幾何学的接続 | 幾何学的解の完全な延長 |
| front.ja.md, 32行、規約末尾 | 普遍被覆上への接続 | 普遍被覆上への延長 |
| front.ja.md, 108行、構成の読み方 | 共通の接続定理 | 共通の延長定理 |
| layers_5_8.ja.md, 18行、§5.1検証3 | t = 1 を通過するアフィン相空間チャート内での接続 | t = 1 を越えるアフィン相空間チャート内での延長 |
| 同75行、§5.4検証3 | 幾何学的接続の破綻 | 幾何学的な延長の破綻 |
| 同79行、§5.5見出し | スカラー有理型接続 | スカラー解の有理型延長 |
| 同81行、§5.5本文 | 6つのスカラー接続定理 | 6つのスカラー解の延長定理 |
| 同87行、第5層の例 | アフィン座標での脱出と幾何学的接続 | アフィン座標での脱出と幾何学的な延長 |
| 同87行、第5層の例 | 普遍被覆上で完備な接続を持ちながら | 普遍被覆上で完全に延長できながら |
| 同205行、§7.3本文 | その族を接続するために必要な | その族を延長するために必要な |
| 同218行、§7.3検証3 | 時間底空間を周回する接続によって | 時間底空間を周回する解析的延長によって |
| 同293行、§8.3検証1 | その時刻を越えて接続されうる | その時刻を越えて延長されうる |

局所系や束の **connection** は「接続」のままとする。connection formula / connection constant の「接続公式／接続定数」も変更しない。変更対象は解・芽・曲線族の continuation である。

## JA-R1-GF-02 — Barnes G の漸化式の対象（P2）

位置：front.ja.md 68行、AnalyticNumberTheoryPartII の依存契約。

- 原文：canonical Barnes G function, its Weierstrass-product normalization G(1) = 1, gamma recurrence with its pole/zero domains。
- 構造化計画の補足：supplier `barnes` は Canonical Barnes G product, normalization, recurrence, zeros and rigorous sectorial asymptotics を要求する。
- 現在の訳文：極と零点の領域を伴うガンマ関数の漸化式。

原文が要求するのは **Barnes G のガンマ関数を伴う漸化式**である。ガンマ関数自体の漸化式へ対象を変えてはならない。修正案は「極と零点の領域を伴う、Barnes G のガンマ関数を用いた漸化式」、または、直前の Barnes G を受けて「そのガンマ関数を伴う漸化式（極・零点の定義域を含む）」とすることである。

## JA-R1-GF-03 — §8.2 の modification の範囲（P2）

位置：layers_5_8.ja.md 258、260、269行、§8.2。

原文は reference bundle or modification、normalized index-zero complex or modification、および unrestricted bundle modification としている。一方、訳文は「基準束または基本変換」「指数 0 の複体または基本変換」「制限のない束の基本変換」とする。

§7.1 の elementary modifications は基本変換でよいが、§8.2 の補助的 modification にその限定はない。この箇所でも基本変換と訳すと、標識に保持する補助操作や、任意の参照対象変更による零因子の変化についての範囲を狭く読みうる。前書きの基礎契約と付録 8.2 は一般の modification を「改変」として保っており、それらとも不整合になる。

§8.2 の未限定の modification は「改変」「補助的改変」「束の改変」に直すことを提案する。§7.1 の elementary modification の「基本変換」は保持する。

## 指摘に数えない補足

付録B §8.2 の stabilizer descent は「安定化群に関する降下」と訳されている。「安定化群」も stabilizer の用例があるため誤訳とは数えないが、ここは Fredholm 作用素の安定化とは別の群作用の問題である。本文の「固定部分群」に統一すると区別が明瞭になる。

## 維持を確認した重要事項

- §5.2 の F の固有性、各部分水平持上げとの整合性、時間連続・相変数 Lipschitz の仮定、および例外点を含む全初期条件の量化は保持されている。
- §5.3 の基本亜群・モノドロミー作用は、実際の完備な平坦接続から構成する出力であり、入力へ戻されていない。
- §6.2 の全相空間と曲面補集合の同型、§6.3 の基底変換と時間線の比較、§7.2 の追加反射、§8.2 の共鳴・分岐 RHP アダプターは、未証明の構成・証明課題として保持されている。
- §6.3 で第一境界層の1次元空間と局所コホモロジー全体を同一視していない。
- §7.3 で Riccati 曲線と大域的可約接続の同値を主張していない。
- §8.1 の行列式規約、零点重複度と核次元の区別、§8.2 の奇数次数の障害と補助複体、§8.3 の修正された JMU 比較の範囲と符号は保持されている。
- 行列式／Fredholm 構成の広い範囲と、JMU・Hamiltonian 比較の一般的な不分岐・非共鳴範囲は区別されている。
- 前書きの二つの供給元の不足課題は、既存の証明済み定理としては扱われていない。

## 入力の SHA-256

| 入力 | SHA-256 |
|---|---|
| PainleveEquationsAndFunctions/README.md | 387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658 |
| PainleveEquationsAndFunctions/design/plan.json | 9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4 |
| _ja_translation/parts/front.ja.md | dd8179076c89829d5074018533acf9057841485de0f8f050fd2d6b6442b1012f |
| _ja_translation/parts/layers_5_8.ja.md | 1020d2a8a4a98c9ed9eedc1304273e304a16b028f887140b1b2b0b163facd85e |
| _ja_translation/appendix_inputs.ja.json | acc3013338a20487258c8d9800598d6094c9c423e22f2aeb167844c31bd36f76 |
| _ja_translation/appendix_obligations.ja.json | fef5ceb7657e60aee392a408a0113b42f8734b65b8d1fad8b92f6bd1703178bd |

レビュー担当：/root/ja_translate_core。入力は親が凍結した review_round1/artifact と同一ハッシュである。修正後の再照合を別に必要とする。
