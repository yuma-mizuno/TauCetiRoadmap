#!/usr/bin/env python3
"""Check the Japanese edition's coverage and immutable mathematical source.

This verifies structural and transcription invariants only. Semantic equivalence
is assessed by the separately recorded independent translation reviews.
"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import re

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--japanese', type=Path)
parser.add_argument('--inputs', type=Path)
parser.add_argument('--obligations', type=Path)
parser.add_argument('--output', type=Path)
args = parser.parse_args()
root = args.root.resolve()
en_path = root / 'README.md'
ja_path = args.japanese or root / 'README.ja.md'
plan_path = root / 'design/plan.json'
inputs_path = args.inputs or root / 'reports/japanese_translation/appendix_inputs.ja.json'
obligations_path = args.obligations or root / 'reports/japanese_translation/appendix_obligations.ja.json'
en = en_path.read_text()
ja = ja_path.read_text()
plan = json.loads(plan_path.read_text())
inputs = json.loads(inputs_path.read_text())
obligations = json.loads(obligations_path.read_text())
checks = []

def check(name, ok, **detail):
    checks.append({'name':name, 'passed':bool(ok), **detail})

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def sections(text):
    return {m.group(1):m.group(0) for m in re.finditer(
        r'^### (\d+\.\d+) [^\n]+\n[\s\S]*?(?=^### |^## |\Z)', text, re.M)}

def items(block, label, end_label):
    if label not in block:
        return []
    segment = block.split(label,1)[1]
    for end in end_label:
        segment = segment.split(end,1)[0]
    return re.findall(r'^- .+',segment,re.M)

check('English README hash', digest(en_path)=='387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658')
check('Structured mathematical plan hash', digest(plan_path)=='9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4')
check('Source manifest hash', digest(root/'sources.toml')=='4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7')
es, js = sections(en), sections(ja)
ids = [t['id'] for l in plan['layers'] for t in l['targets']]
check('44 target IDs and order', list(es)==ids==list(js), count=len(js))
check('11 layers', re.findall(r'^## 第(\d+)層：',ja,re.M)==[str(i) for i in range(1,12)])
check('44 appendix input contracts', set(inputs)==set(ids), count=len(inputs))
expected_obligations = [x['target'] for x in plan['owned_proof_obligations']]
check('12 owned proof obligations', list(obligations)==expected_obligations, count=len(obligations))
for k in ids:
    e, j = es[k], js[k]
    check(k+' paragraph coverage', len(e.strip().split('\n\n'))==len(j.strip().split('\n\n')))
    check(k+' total bullet coverage', len(re.findall(r'^- ',e,re.M))==len(re.findall(r'^- ',j,re.M)))
    check(k+' table row coverage', len(re.findall(r'^\|',e,re.M))==len(re.findall(r'^\|',j,re.M)))
    check(k+' API law coverage', len(items(e,'**API.**',['**Checks.**','*Needs:*']))==len(items(j,'**構成・法則（API）**',['**検証事項**','*必要な先行結果：*'])))
    check(k+' diagnostic check coverage', len(items(e,'**Checks.**',['*Needs:*']))==len(items(j,'**検証事項**',['*必要な先行結果：*'])))
    check(k+' code identifiers', re.findall(r'`([^`]+)`',e)==re.findall(r'`([^`]+)`',j))
    source_keys = re.findall(r'\*\*([A-Z]+\d*|DLMF)\.\*\*',en)
    used_e = Counter(re.findall(r'\b(?:'+ '|'.join(source_keys)+r')\b',e))
    used_j = Counter(re.findall(r'\b(?:'+ '|'.join(source_keys)+r')\b',j))
    check(k+' citation keys',used_e==used_j)
    e_loc = re.sub(r'\bLayer (\d+) or (\d+)\b',r'§\1 or §\2',e)
    e_loc = re.sub(r'\bLayer (\d+)\b',r'§\1',e_loc)
    j_loc = re.sub(r'第(\d+)層',r'§\1',j)
    check(k+' explicit section locators', Counter(re.findall(r'§+[0-9]+(?:\.[0-9]+)*',e_loc))==Counter(re.findall(r'§+[0-9]+(?:\.[0-9]+)*',j_loc)))
    standalone_math = [p for p in e.split('\n\n') if p.strip() and '=' in p and not re.search(r'[A-Za-z]{3,}',p) and not p.startswith(('-', '|','*','#'))]
    clean = lambda s: re.sub(r'\s+','',s).rstrip(',.。')
    check(k+' standalone formula transcription',all(clean(p) in clean(j) for p in standalone_math),formula_paragraphs=len(standalone_math))
check('23 reference keys', re.findall(r'^- \*\*([A-Z]+\d*|DLMF)\.\*\*',en,re.M)==re.findall(r'^- \*\*([A-Z]+\d*|DLMF)\.\*\*',ja,re.M))
check('Bibliography URLs',re.findall(r'https?://[^)\s]+',en)==re.findall(r'https?://[^)\s]+',ja))
check('Appendix input text included',all(v in ja for v in inputs.values()))
check('Appendix obligation text included',all(v in ja for v in obligations.values()))
check('No duplicated normalization token', '基基底変換' not in ja)
api_count=sum(len(t['api']) for l in plan['layers'] for t in l['targets'])
test_count=sum(len(t['tests']) for l in plan['layers'] for t in l['targets'])
result={'scope':'Japanese translation coverage and exact-source binding; not a proof certificate',
        'checks':len(checks),'failures':[c for c in checks if not c['passed']],
        'targets':len(ids),'api_laws':api_count,'diagnostic_checks':test_count,
        'readme_english_sha256':digest(en_path),'plan_sha256':digest(plan_path),
        'readme_japanese_sha256':digest(ja_path),'details':checks}
if args.output:
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='details'},ensure_ascii=False,indent=2))
raise SystemExit(1 if result['failures'] else 0)
