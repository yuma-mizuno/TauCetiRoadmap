# Core mathematical review — frozen round 1

担当: `/root/math_core_review`。主対象は Layers 1–5。Layers 6–11 は依存循環と証明資源の先取りだけを確認した。Lean・実装可能性・既存形式化の所在は本レビューの判断対象外。過去のレビュー結果は参照していない。親から提示された機械可読計画の疑義は、凍結入力の実フィールドと本文を比較して独立に判定した。

## 判定

**共有 P2 を一件確認した。ID は `MR4-INPUT-OUTPUT`。** `design/plan.json` の `hypotheses` が、実際の入力仮定に同じ target の結論・所有する中間証明課題を混ぜている。README がこれらを既知と仮定している、あるいは README の数学的証明に循環がある、という指摘ではない。数値分類の結論や properness の主要中間補題を「仮定」として読み取れる機械可読表現の不一致である。同種の各フィールドは独立の問題件数にしない。

**README の Layers 1–5 について、今回の検査で確証を得た偽の全称主張・定義上の循環・4.3→5.2 の量化欠落は零件。** ただしこれは全 target の証明を保証する判定ではない。とりわけ §4.4 の全 classical strata に対する相対 RH properness は、引用済み定理の単純な適用としては完了しておらず、本文もその事実を明示している。四つの中間課題からなる証明方針には論理的な道筋があるが、その最難関を証明済みとは扱えない。

凍結入力の SHA-256:

| 入力 | SHA-256 |
|---|---|
| `artifact/README.md` | `b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502` |
| `artifact/sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |
| `artifact/design/plan.json` | `1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10` |

## 確認した finding

### MR4-INPUT-OUTPUT — P2 — hypotheses と所有する証明課題の混在

**対象:** `artifact/design/plan.json` target 1.4、4.4。2.3 にも同じパターンを確認した。

**原文:**

- 1.4 `hypotheses`: “Generic projective leading type; **ten underlying and seventeen ordered profiles** with a label-assignment groupoid; reduced deformation quotient and checked automorphism stabilizers; no assumed time dimension.”
- 4.4 `hypotheses`: “Whole admitted time family; retained exponent lifts; every allowed stable initial point; **uniform lattice boundedness and stable replacement**.”
- 補助的な同型例として 2.3 `hypotheses` に “owned finite-flat auxiliary simple-connection unfolding and logarithmic trace-closedness; smooth integral density argument …” が入っている。

**理由・証拠:** 1.4 の `statement` はまさに formal profiles を分類して ten / seventeen を得ると述べている。4.4 の `statement` は uniform boundedness、構造の延長、stable replacement、gluing を “The required extension is owned here. Develop the proof through four concrete intermediate results” と指定する。さらに同ファイル末尾 `owned_proof_obligations` の target 4.4 はこれらを証明することを義務として登録する。したがって `hypotheses` の読みが、本来の無条件の target を分類結果や compactness の核心を仮定する条件付き target に弱め得る。2.3 の unfolding も本文がここで構成すると明言するもの。

中間補題を証明したうえで主定理の推論に使うこと自体に問題はない。問題は「すでに入力される仮定」「この target 内で作る補題」「最終結論」が同じフィールドに収納され、依存関係・レビュー・機械処理がその区別を回復できないことにある。これを mathematical falsehood または README の循環とは判定しない。

**修正:** `hypotheses` を、その target を始める前に与えられる実際の入力と既に証明された依存先の条件に限定する。1.4 の 10/17 は `conclusions` 等に、4.4 の有界性・置換と 2.3 の unfolding は `proof_obligations` / `construction_steps` に移す。中間補題を先行 target に分割するなら、識別子と依存辺を追加して既証明入力であることを明示する。同種の修正をまとめて一件の整合性修正とする。

**外部文献との関係:** IS12 Theorem 5.1 / Remark 6.3 は 4.4 の全範囲を供給しない。したがって 4.4 の主要補題を入力扱いにすることは、単なる既存定理名の省略では解消できない。一方、README はこの適用範囲を明記している。参照: [IS12 PDF](https://arxiv.org/pdf/1203.0084v3)。

## 重点 1: intrinsic な入力と時間の非循環性

### 定義を結論の隠れた仮定にしていないか

§1.3 の classical class は genus 0、rank 2、構造的 polar degree 4、許容する generic projective irregular local models、正則特異 determinant、縮約した versal formal-data deformation、非空の stable fibers で指定される。時間が一次元であること、解の大域継続、proper RH、六つのスカラー方程式に一致することは定義の条件に入っていない。「非空の stable fiber」は定義域を選ぶ条件として認められ、Painlevé 性を先取りしていない。

structural polar divisor を actual nonzero pole divisor に置き換えると、零留数や apparent strata を消す危険があるが、本文は両者を区別する。logarithmic residue を全 formal Jordan class として凍結すると resonance で不適切になるが、ここでも graded residues と flags の条件を採っている。scalar irregular twist が次数や時間を増やす反例は、classical determinant を regular singular に制限しているため対象外。

### 10 / 17 と時間数を独立に算定

正の構造的 multiplicity の partitions of 4 を調べた。各 irregular multiplicity (m\ge 2\) に許される型は、integer projective slope (m-1\) と half-integer slope (m-3/2\) の二つ。logarithmic part は (m=1\)。これより:

| 極数 | underlying shapes | ordered shapes | 計数理由 |
|---|---:|---:|---|
| 1 | 2 | 2 | partition (4)、二つの slope |
| 2 | 5 | 8 | (1,3) は二型、(2,2) は二型の unordered pair が三通り。ordered では (1,3)/(3,1) が四通り、(2,2) が四通り |
| 3 | 2 | 6 | (2,1,1)、二型と二重極位置三通り |
| 4 | 1 | 1 | (1,1,1,1) |
| 合計 | 10 | 17 | 連続 exponent parameters の点数ではない |

pole positions が (n\)、projective irregular coefficients が \(\sum_i\lceil r_i\rceil\) 個となる generic local model で、曲線座標の三次元作用を除くと
\[
 n+\sum_i\lceil r_i\rceil-3=\sum_i m_i-3=1.
\]

この dimension subtraction には stabilizer の検査が必要であり、本文も明示する。三極以上は標識点で infinitesimal automorphism が消え、二極の場合は残る scaling が非零 irregular leading term に作用する。一極の場合は affine translation と scaling が leading / next coefficient に独立に作用する generic 条件を確認する。有限 stabilizer は marking cover の処理対象である。あらゆる形式座標変更を独立に商にして irregular time を消す反例は、本文の label-preserving **curve-coordinate changes** / 曲線同型としての arrows とは異なる。

[VDPS09 §2.2 / Table 1](https://arxiv.org/pdf/0902.1702v5) を直接確認した。同文献の time dimension を定義に採用せず、本文が structural degree から上の式を証明する順序は適切。[HEU10 Theorem 1.1](https://www.numdam.org/article/AIF_2010__60_2_515_0.pdf) の genus-zero 少数極における曲線 automorphism の注意も、quotient/slice の検査を省けない理由として確認した。

### determinant と intrinsic carrier

odd determinant degree で determinant の平方根が存在しないという攻撃は棄却した。本文は globally trace-subtracted rank-two module を主張せず、End⁰ と PGL carrier を使う。determinant identification を固定した residual scalar automorphism は μ₂ として扱い、Gm と混同していない。determinant の時間 lift の coherence は §1.2 の構成課題であり、無記名の canonical square root を使わない。

## 重点 2: 変形理論、symplecticity、強い isomonodromy

| 対象 | 攻撃した問題 | 判定と残る仕事 |
|---|---|---|
| 2.1 moduli | trivial bundle chart だけを全 phase とする、universal bundle を coarse space 上に無条件に置く | 任意の underlying bundles と bundle-jumping strata を保ち、universal object は étale cover 上に置く。boundedness / finite type / separatedness は構成課題。欠落とは判定せず |
| 2.2 complex | ramification correction を消して常に二項複体とする、∇ の微分を O-linear とする | ramified cone を三次数で保持し、differential は C-linear first-order と明記。termwise coherent duality と hypercohomology の比較を要求している |
| 2.3 dimension | unfixed determinant の一般 genus 公式を固定 determinant にそのまま適用 | 未固定公式と determinant の 2g directions を区別。g=0,r=2,degP=4 は二次元。r=1,g=1 でも未固定二次元と固定零次元の区別に整合 |
| 2.3 closedness | dense generic locus での閉性から非還元基底へ無条件に延長、後段 confluence を先取り | early auxiliary finite-flat unfolding をこの節で所有。smooth integral auxiliary base 上で証明後に base change する順序。Layer11 に依存しない |
| 2.4 exceptional strata | resonance / reducibility / apparent points を便宜的に削除 | 許容 stable strata は残す。irregular leading term の零化は同一 generic local-model stratum の内部とはしていない |
| 3.1 strong extension | ordinary monodromy preserving だけで unique isomonodromy とする、log pole に自由な time poles を許す | 強い integrable extension の pole bounds と kernel lattices の保存を要求する。単なる fiberwise flag 条件ではない |
| 3.2 integrability | 一階 lift の存在のみから flatness と言う | 二パラメータ extension / mixed terms の比較を独立課題として立てる |
| 3.3 total form | flatness だけで Ω が閉じると推論する | symplectic compatibility / total closedness を別に証明する。H はその後の局所表示 |
| 3.4 naturality | stability chamber を変えても全く同じ moduli だとする | 異なる重みの chamber は別問題として区別する |

[I23 Theorem 7.5、§8、Definition 10.1](https://sigma-journal.com/2023/013/sigma23-013.pdf) を照合した。特に (10.1) と Definition 10.1 は、spatial coefficient の pole order m と time coefficient の order m−1、および decoration が定める kernel subsheaves の保存を使う。本文の強い extension はこの構造を再現している。I23 の結果を generic ramified conditions の外まで自動的に適用する記述は見つからなかった。

Hamiltonian の符号も確認した。ω=dq∧dp、i_Xω=d_phaseH なら X=H_p∂q−H_q∂p であり、Ω=dq∧dp+dH∧dt の kernel は ∂t+X を含む。本文の例と一致する。total closedness はこの局所計算を使って存在を循環的に定義せず、上流の trace form と強い extension から証明すべき課題として置かれている。

symplectic closedness の unfolding は本当に補助 moduli の構成と trace-form comparison を要する。simple-connection family の smoothness、central stable locus の同定、generic quasi-isomorphisms は重い証明課題であるが、単に「closedness を仮定する定義」に置き換えられてはいない。

## 重点 3: 全 strata RH と properness の証明経路

### Betti target と transport

§4.1 の decorated analytic groupoid と §4.2 の ordinary affine character quotient は区別される。reducible representation と semisimplification を coarse quotient が区別できないという反例、同じ exponential eigenvalue に異なる exponent lifts が対応する反例、resonance で単一の非閉 Jordan orbit を固定する反例は、本文がすでに防いでいる。

[BOA14 Definition 10.1 / Theorem 10.2](https://arxiv.org/pdf/1111.6228) の family transport の scope と、[BY15 Theorem 21](https://arxiv.org/pdf/1512.08091) の twisted quasi-Hamiltonian 結果を直接区別した。前者の untwisted isotopy を rank-two ramified exponential covering / deck action に適合させる仕事は、後者の theorem を引用するだけでは済まない。本文は §4.2 にその仕事を所有させ、independence / composition / homotopy / quotient descent まで列挙している。したがって適用範囲の偽装とは判定しない。

### generic RH を all-strata RH と誤認していないか

[IS12 Theorem 5.1 / Remark 6.3](https://arxiv.org/pdf/1203.0084v3) を確認した。Theorem 5.1 の analytic isomorphism には generic setup に加えて nonresonance / irreducibility の制限がある。Remark 6.3 は resonant / reducible case の proper surjective bimeromorphic extension を期待として述べる箇所であり、全範囲の既証明定理ではない。README はこれを正しく scope warning として扱う。I23 の foliation theorem を properness と同一視する記述もない。

[IIS06 Theorems 4.10–4.14](https://arxiv.org/pdf/math/0501007v2) は tame PVI の full family properness と安定置換の構想を供給する。その theorem を十個の wild / ramified profiles 全体に適用できると主張してはいない。

### §4.4 の四段階は何を証明しなければならないか

1. **一様 local lattice boundedness。** fixed exponent lifts と compact family of generalized characters のもとで、許容接続と lattice の実際のパラメータが逃げないことが必要。各 fiber ごとの有界性や projective flag fiber だけでは不足する。本文は一様性を要求している。
2. **付加構造の延長。** flag / factorized structure の projective parameter scheme と closed incidence を使う際、underlying connection の有界な family が第一段階で確保されていなければならない。閉性で stability まで保たれるとは本文は言っていない。
3. **stable replacement。** semistable limit の構成、必要な base change / elementary modifications と prescribed determinant・formal type・RH image の両立を証明する必要がある。generic weights による semistable=stable は、semistable replacement 自体を与えない。本文はこの順序を区別している。separatedness は適切な置換が既にある後の一意性に使うもので、存在の代用ではない。
4. **global gluing と analytic properness。** 局所的 replacement を全曲線上で貼り、analytic topology で compact inverse images を得る必要がある。fiberwise properness、pointwise Riemann–Hilbert solvability、valuative-looking limit argument の断片だけでは結論しない。本文の最後の確認条件はこの不足を明示している。

この四段階は、必要な補題が成立すれば properness を得る合理的な経路である。今回は各補題を全 profiles で証明したわけではない。しかし、scope 内の反例や、どのように補題を埋めても結論に到達できない循環は特定できなかった。ロードマップに対し「最難関が未証明だから defect」とするのは不適切。反対に、四つの見出しを書いたことだけで properness を既存文献から検証済みと宣言するのも不適切である。

HEU10 の universal strong deformation による continuation route は別の選択肢であり、properness の証明ではない。time quotient、determinant、local decorations、stability、bundle changes、既構成 h との同一性という adapters は依然必要。本文はこの代替経路を 4.4 の properness を満たしたことにしていない。

## 重点 4: 4.3 から 5.2 への量化範囲

**量化は一致している。** §4.3 は every horizontal trajectory を resonance / reducible / exceptional loci 内も含めて扱い、generic open でしか逆写像を主張しない。§5.2 は proper semiconjugacy の適合を **every partial horizontal lift** に課す。したがって exceptional fiber 上の軌道に適合がないまま dense open から continuation を結論するという欠陥は見つからない。4.3 の全範囲が今後の証明課題であることは本文自身の立場であり、その証明後に使う条件付き依存は循環ではない。

§5.2 の general transfer theorem 自体も確認した。compact path γ に沿う target trajectory の像 K は compact。proper F により F⁻¹(K) は source の compact subset。phase-direction で局所一様 Lipschitz な非自律 ODE と finite-cover による共通延長時間から、有限 endpoint で source lift が消失する可能性を除く。局所一意性が延長を貼り合わせる。target に smooth structure や RH inverse は不要で、π 自身が proper である必要もない。

C¹ path の速度は一般に連続にすぎず、autonomization が C¹ vector field を与えるとは限らない。本文はこの点を正しく扱い、continuous-time / locally uniformly phase-Lipschitz adapter を所有する。piecewise C¹ の finite subdivision を各区間ごとに処理する。flatness が個々の path completeness に必要だという過剰仮定もなく、§5.3 の homotopy invariance の役割と区別する。

[IIS06 Lemma 2.12](https://arxiv.org/pdf/math/0501007v2) の properness による continuation mechanism と整合するが、本文の一般実微分幾何版には明示した局所 ODE hypotheses が必要であり、そこは省略されていない。

## 重点 5: observable と scalar Painlevé 性

§5.4–5.5 は rational function ならすべての trajectory に自動評価できるとは言っていない。rational [x:y] の indeterminacy に入る constant section は明示的に排除し、実際の resolution/lift または direct non-indeterminacy の証明を要求する。P¹-valued morphism が identically infinity の場合も通常の meromorphic function と同一視しない。

時間が complex curve で、holomorphic P¹-valued evaluation が identically infinity でなければ、infinity chart での局所 holomorphic function の零点から有限位数の pole が得られる。この推論は analytic continuation の定義へのすり替えではない。難しいのは classical coordinate observer の admissibility を全 claimed solution strata で証明することであり、それは §5.5 と後段の coordinate comparison に明示的に残る。

完全性が base 上の single-valuedness を意味するという反例も検査した。本文の H=qp/(2t) on C× は一周で (q,p)↦(−q,−p) を与え、universal-cover section と downstairs descent を正しく分ける。deck action に初期点が固定されることが descent の条件である。

## 依存・文献・検査の限界

`plan.json` の 44 targets の `target:` 辺を抽出して DFS を行った。明示的な directed cycle は零、Layers1–5 から Layers6–11 への辺も零。本文を合わせて読み、symplectic closedness に Layer11 の confluence を先取りする経路、properness に Layer6 の compactification や Layer9 の六方程式を先取りする経路は確認しなかった。これは隠れたあらゆる数学的依存が不存在であることの機械的証明ではない。

直接確認した一次資料:

| 資料 | 確認箇所 | 使用した scope |
|---|---|---|
| [I23](https://sigma-journal.com/2023/013/sigma23-013.pdf) | Theorem7.5、§8、§9、(10.1)/Definition10.1 | generic ramified structures、deformation / dimension / strong extension の構造。unrestricted RH properness の供給とはしていない |
| [IS12](https://arxiv.org/pdf/1203.0084v3) | Theorem5.1、Remark6.3–6.5 | generic RH theorem の制限と resonant/reducible extension の位置付け |
| [HEU10](https://www.numdam.org/article/AIF_2010__60_2_515_0.pdf) | Theorem1.1、universal deformation の導入 | strong deformation と curve automorphism / marked-time quotient の注意 |
| [VDPS09](https://arxiv.org/pdf/0902.1702v5) | §2.2/Table1、strong RH の注意 | ten profile shapes と time count の比較。全 global moduli identification を引用だけで済ませない |
| [IIS06](https://arxiv.org/pdf/math/0501007v2) | Lemma2.12、Theorems4.10–4.14 | tame full-family RH properness と compact-containment mechanism |
| [BOA14](https://arxiv.org/pdf/1111.6228) | Definition10.1、Theorem10.2 | admissible untwisted-family transport |
| [BY15](https://arxiv.org/pdf/1512.08091) | Remark3、Theorem21 | exponential covering と twisted quasi-Hamiltonian scope |

このレビューは数学ロードマップとしての判定である。sectorial existence / parameter dependence の全解析証明、ramified transport extension、unfolding family の全構成、全 strata uniform lattice bounds / stable replacement を完成させたものではない。BOA01 の全 proof は今回再現していない。後段 geometry の内容そのものは別担当に委ねた。一次資料の範囲外の新たな主張を「本文が明示的に所有する証明課題」として残すことと、その主張がすでに正しいと証明したことを区別する。

親から canonical の修正完了通知を受けたが、この報告の判定・引用・ハッシュは一貫して凍結 round1 のみを対象とする。修正版の closure 判定はこの報告には含めない。
