# 第1回独立幾何レビュー：Layers 6・7・9

## 判定

凍結 README の担当範囲について、具体的な反例で否定できる数学的主張、または必然的に循環する数学的目標は確認しなかった。**確定指摘は、構造化計画の `hypotheses` が同一ターゲットの成果物を前提に置く一件（P2、`MR4-INPUT-OUTPUT`）への幾何側の裏付けである。** これは README の数学的定理が偽だという指摘ではない。

8境界型の分類と、第一境界時間線の次元1は、曲面側のデータからそれぞれ独立に出せる。古典六方程式との座標比較を先に使う必要はない。一方、全プロファイルの connection moduli と曲面補集合の同型、その同型による時間分布の一致、全変換の指定領域への延長は大きな将来証明である。凍結 README はその点を明示しているので、単に未証明であることを追加の指摘に数えなかった。

この判定はロードマップの全定理を証明したという意味ではない。特に全プロファイルでのコンパクト化、非被約底上の相対比較、全例外チャートの被覆は完成証明を検査できる段階にない。

## 1. 入力、範囲、独立性

対象は以下の凍結3ファイルのみ。過去のレビュー結論を参照せず、canonical ファイルの編集、push、worker実行、Lean・形式化作業はしていない。

| 凍結ファイル | SHA-256 |
|---|---|
| `artifact/README.md` | `b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502` |
| `artifact/sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |
| `artifact/design/plan.json` | `1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10` |

主担当は §§6.1–6.3、7.1–7.3、9.1–9.5。必要な基礎として §§1.3–1.4、2.1–2.4、3.1–3.4、5.4–5.5 を読み、Layer 4 の範囲条件も確認した。Layer 4 の全適切性定理や強変形の解析的構成を独立に証明することは今回の幾何担当の範囲外。

`hypotheses` の入力・出力混同は、レビュー途中で root が提示した現行候補を凍結原本に照合して裁定した。以下の幾何的検査は、その候補や他担当の数学的結論から独立に実施した。

## 2. 確定指摘：MR4-INPUT-OUTPUT（P2）

### 正確な対象と主張

`design/plan.json` の次の `hypotheses[0]`。

- §6.2: “Full-classical compactification with markings/base changes; exact complement and form/distribution comparison; no assumed all-profile global isomorphism.”
- §7.2: “Added marked-surface reflections as well as local connection functors; stated regular/birational domains; full-curve extensions proved.”
- §9.2: “Constructed intrinsic moduli/time charts for ten underlying profiles and all seventeen ordered profiles; label reindexing, parameter maps, nonconstant time covers, inverse jets and omitted loci retained.”

### なぜ問題か

§6.2 が最も明確である。同ターゲットの statement はコンパクト化を構成し、その補集合が全 phase family に一致すること、二形式と時間分布が一致することを証明すると宣言している。API Law2–3 も同じ成果を要求する。ところが `hypotheses` が exact complement と form/distribution comparison を与件として要求すると、構造化計画では主出力を先に受け取ることになる。

§7.2 では、§7.1 の既存の局所 connection functor を入力にすることは正当である。しかし追加の marked-surface reflection の構成と、その指定領域・曲線全体への延長は §7.2 自身の仕事である。`Added ... reflections`、`extensions proved` を一括して前提にしてはならない。

§9.2 は少し区別が必要である。上流で構成した intrinsic moduli や抽象的な時間データを入力にすることは正当である。しかし全17 ordered profile の具体的な座標、係数パラメータ写像、逆 first jet、除外集合の処理は、§9.2 の比較パッケージ自身の成果である。§9.1 の条件付き消去公式だけでは、その全例の具体的存在や被覆は出ない。

### 具体的な証明障害

§6.2 の前提を字義通り採用すれば、

\[
\Psi:M\xrightarrow{\sim}S\setminus D,\qquad
\Psi^*\omega_S=\omega_M,\qquad \Psi_*h_M=h_S
\]

を仮定した上で同じ比較を結論にすることになる。非自明な束のチャート、bundle jumping、例外曲線を構成・被覆しなくても、主要な比較 API を形式上満たせてしまう。この弱化は、README が明示的に禁止する「一般の大域同型を仮定する」経路と衝突する。

VDPS09 の導入は一般の大域比較を予想として述べており、これを既知の前提に昇格させる根拠にはならない。IIS06 の強い比較と Bäcklund 定理は PVI の範囲にあり、全プロファイルの不足を埋めるものでもない。[VDPS09](https://arxiv.org/pdf/0902.1702v5), [IIS06](https://arxiv.org/pdf/math/0501007v2)

### 修正方針

`hypotheses` には既に供給される入力、適用範囲、標識・底変換の許容条件だけを置き、同一ターゲットで構成・証明するものは statement/API/owned obligations に残す。もしこの欄を「作業スコープの要約」の意味で使うのであれば、名前と契約をその意味に変更する必要がある。README の将来定理の記述は、この指摘だけを理由に削る必要はない。

これは他担当の同一 ID の指摘と重複集計しないこと。幾何側で新たな数学的欠陥を一件追加したという扱いは不適切。

## 3. Okamoto対、非ファイバー条件、8境界型

### 3.1 定義の範囲は適切

§6.1 は滑らかな射影的有理曲面、非零有効反標準因子 \(Y=\sum m_iY_i\)、各成分について \(Y\cdot Y_i=0\)、被約支持 \(D\) の SNC 性、加法的 Picard 型、非ファイバー性を保持している。非ファイバー条件は、ある \(n\ge1\) に対して \(nY\) が楕円ファイブレーションのファイバーとなることを排除するもので、単に \(Y\) 自身だけをチェックする条件に弱めていない。

STT02 の定義と分類表を照合した。古い定義における \(\mathbb A^2\) 開集合の追加仮定を D8 に強制する問題も、凍結 README は明示的に避けている。非ファイバー性と \(H^0(S\setminus Y,\mathcal O)=\mathbb C\) の関係は STT02 Proposition 1.3 にあり、代数的正則関数と解析的正則関数を混同する必要はない。[STT02, Definitions 1.1/1.3, Propositions 1.2/1.3, Tables 2–3](https://arxiv.org/pdf/math/0006026)

### 3.2 古典ODEを使わない分類の経路

以下は分類が相互比較から独立であることを確認する計算である。

1. \(Y^2=\sum_i m_i(Y\cdot Y_i)=0\)。有理曲面で \(Y\sim-K_S\) だから \(K_S^2=0\)、\(\rho(S)=10\)。有効因子との交点の性質から \(Y\) は nef である。
2. \(0\to\mathcal O_S(K_S)\to\mathcal O_S\to\mathcal O_Y\to0\) と有理性から \(H^0(\mathcal O_Y)=\mathbb C\)。従って支持は連結である。
3. Hodge index により \(Y^\perp/\mathbb RY\) は負定値で次元8。各成分には随伴公式
   \[
   Y_i^2=2g(Y_i)-2
   \]
   が適用される。種数1の成分は他成分と交わらず、連結性から支持全体になるが、この場合 Picard の恒等成分は楕円曲線部分を持ち、加法的型に反する。従って各成分は \((-2)\)-有理曲線である。
4. 連結交点行列は対角 \(-2\)、非対角非負、正の重複度ベクトルを核に持つ。対応するアフィン型の有限ルート階数は8以下。
5. \(\widetilde A\) の輪は \(\mathbb G_m\) 型を持つので加法的条件で除外される。残る型は
   \[
   \widetilde D_4,\widetilde D_5,\widetilde D_6,\widetilde D_7,
   \widetilde D_8,\widetilde E_6,\widetilde E_7,\widetilde E_8.
   \]

Kodaira の II・III・IV 型も加法的 Picard 型を持つが、尖点・接触・三重点のためここでの SNC 条件を満たさない。したがって「加法型なら8種類」という無条件な主張にはならず、README の SNC 仮定が必要な役割を果たしている。上の議論は STT02 の分類表と一致し、connection の10 presentation や六方程式のリストを入力にしていない。[STT02](https://arxiv.org/pdf/math/0006026)

### 3.3 分類範囲の限界

これは境界交点型の分類であり、任意の2次元非自律系、任意のOkamoto対の標識付き同型類、または全ての connection の局所特異点データを8個に分類したわけではない。D6 に degenerate PV と通常の PIII が現れること、E7 に二つの異なる線形系 presentation が現れることは矛盾ではない。§§6.2、9.2 はこの区別を明記している。

## 4. 第一境界時間線と相対比較

### 4.1 次元1は独立に計算できる

\(F=\Theta_S(-\log D)\)、\(N_D=\mathcal O_S(D)/\mathcal O_S\) とする。TER02 の境界上の完全列は

\[
0\to\nu_*\!\left(\bigoplus_i N_{Y_i/S}\right)
\to F\otimes N_D
\to\Theta_D\otimes N_D\to0
\]

という形で、各 \(N_{Y_i/S}\simeq\mathcal O_{\mathbb P^1}(-2)\) の \(H^0\) は0、\(H^1\) は1次元である。成分 \(Y_i\) 上の節点数を \(t_i\) とすると、右端の正規化上の次数は

\[
(2-t_i)+D\cdot Y_i=(2-t_i)+(-2+t_i)=0.
\]

従って右端の \(H^0\) は \(\mathbb C^r\)。接続写像

\[
\delta:\mathbb C^r\longrightarrow\mathbb C^r
\]

は適切な基底で交点行列により表され、階数は \(r-1\)。よって

\[
\dim H^0(D,F\otimes N_D)=\dim\ker\delta=1.
\]

これは TER02 Theorem 2.1/Proposition 2.1 の経路であり、八つの図それぞれについて古典ODEの係数を計算することを必要としない。[TER02](https://arxiv.org/pdf/math/0006027)

### 4.2 言ってよいことと言ってはいけないこと

この1次元空間の \(H^1_D(S,F)\) への自然な単射と、局所コホモロジー全体が1次元という主張は違う。TER02 は後者を一般には予想として区別し、ST04 の付録も証明範囲に条件がある。§6.3 は第一境界線だけを構成し、全局所コホモロジーの次元1を輸入しないため、この既知の落とし穴を避けている。[TER02, Theorem 2.1/Conjecture 2.1](https://arxiv.org/pdf/math/0006027), [ST04, Appendix](https://arxiv.org/pdf/math/0201225)

また、1次元の線が得られても、時間座標の正規化や非零ベクトルは自動ではない。connection 側の Kodaira–Spencer 方向がこの線に一致し、その持ち上げが既に構成した強変形の分布に一致することは、別途の比較定理である。README は標識、時間の正規化、分布の一致を要求している。

非被約底で fiber dimension が一定だから直ちに局所自由・任意底変換になる、という推論も不可である。例えば \(A=\mathbb C[\varepsilon]/(\varepsilon^2)\) 上の \(A/(\varepsilon)\) の閉ファイバーは1次元でも、\(A\)-平坦ではない。§§6.1/6.3 はこの種類の不足を認識し、相対 Picard、普遍的関数、平坦性、cohomology-and-base-change の実際の仮定を所有する目標としている。これも未証明の大目標ではあるが、偽の一般推論は記載されていない。

## 5. Connection moduli と曲面の比較

§6.2 の難点は八型を数えることではなく、各 profile の全安定 phase family を \(S\setminus D\) に同定し、二形式と分布まで比較することにある。通常の有理チャートだけでは、非自明なベクトル束、bundle jumping、例外曲線、Riccati 成分を含む全補集合は得られない。

ここには実際に大きな証明責任が残る。VDPS09 の導入で一般の比較が予想として扱われることを確認した。一方、IIS06 の PVI では標準座標・位相空間の比較が詳細に与えられ、AHT17 は degenerate PV について強化した monodromy data・parabolic structure を伴う構成を与える。これらの範囲を全プロファイルの一般定理と読み替えることはできない。[VDPS09](https://arxiv.org/pdf/0902.1702v5), [IIS06, §10](https://arxiv.org/pdf/math/0501007v2), [AHT17](https://sigma-journal.com/2017/029/sigma17-029.pdf)

しかし凍結 README は、一般比較を今後構成する、除外チャートの延長と被覆を証明する、PVI 定理を他 profile に移さない、と明記する。また、曲面上に foliation があるだけで完全性を得たり、Layer 4 の適切性を迂回したりしない。従って「その一般定理を引用文献中で見つけられない」ことだけを数学的欠陥に分類しなかった。

## 6. Bäcklund作用とRiccati曲線

### 6.1 局所操作だけで全群を出す問題は避けている

局所 elementary modification、テンソル、双対、標識変更は、その定義域、安定性重み、行列式の次数・指数変化を伴って扱う必要がある。特に elementary modification は次数を1変え、線束テンソルは行列式に平方を掛ける。奇数次数に無条件の半行列式 twist を仮定することはできない。§7.1 はこれを区別している。

IIS06 Remark 7.5 は PVI の中央反射 \(s_0\) を他の単純な gauge transformation と区別する。§7.2 はこれを必須試験として、追加の marked-surface reflection を構成し、§6.2 を介して connection moduli へ比較するルートを指定する。全 affine Weyl 群が §7.1 の局所操作だけから出るとは言っていない。[IIS06, Theorem 7.4, Remark 7.5, Theorem 10.13](https://arxiv.org/pdf/math/0501007v2)

境界ルート図と対称性ルート格子の区別、反射の実際のパラメータ作用、Coxeter 関係、有効因子のある領域、稠密開集合上の有理恒等式から全域の正則自己同型への飛躍を避ける点も明記されている。これらの構成と延長は将来の実証対象であり、完成を確認したわけではない。

### 6.2 Nodal curveからRiccatiへの局所定理は文献の範囲を守る

ST04 Proposition 2.1 は、指定の標識付き族にある内部の \((-2)\)-有理曲線が局所的に変形し、その上の流れが Riccati となることを述べる。大域的な曲線の族には有限被覆やモノドロミーの問題が残る。§7.3 は局所解析的・étale な主張と大域 descent を分けている。[ST04, Proposition 2.1, Remark 2.4, Theorem 3.1](https://arxiv.org/pdf/math/0201225)

\(\mathbb P^1\) の接束の大域切断が次数2以下のベクトル場であることから、相対射影接続の局所式は Riccati になる。ここでも射影接続と大域的 rank-two 線形接続への lift は同じではなく、README は局所 lift または障害の解消を要求する。

次の反例候補は成立しなかった。

- ramified connection の既約性だけから内部 Riccati 曲線が一切ないとは推論できない。共鳴・parabolic/exceptional データとの関係があり、README は FN の E7 presentation をその注意例として扱う。
- 「全ての有理解は invariant Riccati curve に属する」は偽になり得るが、README はその主張をしていない。PII の \(\alpha=0,q=0\) と \(\alpha=-1/2,p=0\) を明確に区別している。
- PI、D7、D8 に Riccati 曲線がないという範囲は ST04 の型別定理と一致する。任意の有理解や任意の還元可能性についての無条件否定に拡張されていない。

## 7. Profile数、時間次元、first-jet、係数境界

### 7.1 10 underlying /17 ordered profilesは独立に数えられる

構造的極次数 \(m\) に対して、\(m=1\) では対数型 \(r=0\)、\(m\ge2\) では generic unramified \(r=m-1\) と generic ramified \(r=m-3/2\) の二択である。\(\sum m_i=4\) の整数分割・組成を数えると次になる。

| 極の個数 | underlying の数 | ordered の数 |
|---:|---:|---:|
| 1 | 2 | 2 |
| 2 | 5 | 8 |
| 3 | 2 | 6 |
| 4 | 1 | 1 |
| 計 | 10 | 17 |

各場合 \(1+\lceil r_i\rceil=m_i\) だから、位置・projective irregular data の次元から曲線座標変更を引く候補次元は

\[
n+\sum_i\lceil r_i\rceil-3=\sum_i m_i-3=1.
\]

これは六方程式の表から逆算した数ではない。ただし単なる数式だけでは不十分で、実際の versal formal-data family、安定化群、標識、正則な slice、行列式の運搬を検査しなければならない。§1.4 はこれらを要求する。任意の曲線を時間として差し込む定義ではない。[VDPS09, §2.2/Table 1](https://arxiv.org/pdf/0902.1702v5)

### 7.2 First-jetは条件付き同値として正しい

\(h=\partial_t+A\partial_q+B\partial_p\) に対して、\(J(t,q,p)=(t,q,A)\) が明記した開集合上で正則同型で、逆 \(p=P(t,q,v)\) を持つなら、

\[
q''=(A_t+A A_q+B A_p)(t,q,P(t,q,q'))
\]

は連鎖律であり、逆も first jet が指定像に入る限り成り立つ。\(A_p\ne0\) は局所条件であって、全域単射性や全 phase chart の被覆にはならない。§9.1 はこの区別を明示している。

rational observer が全解に引き戻せるとも限らない。例えば原点に値を取る定数 section に対して \([x:y]\) は定義されない。§5.4 の morphism/domain/resolution 条件が、この種の抜け道を閉じる。従って first-jet chart 外の例外解や分母ゼロの枝を、分母払いだけで処理することは許されない。

### 7.3 座標・正規化の点検

VDPS09 の元の scalar expression、Hamiltonian/first-order system と、README の辞書を照合した。特に以下を直接計算した。

- PI の \(c^5=2\)、\(T=ct\)、\(Q=c^{-2}q\) は、元の \(q''=6q^2+2t\) を標準形にする。時間だけの変更では係数6を保てない。
- D7 の \(t=T^2,\ Q(T)=Tq(T^2)\) は \((\alpha,\beta,\gamma,\delta)=(4(\theta_\infty+1),-8,4,0)\) を与える。
- D8 の \(t=T^2,\ Q(T)=q(T^2)/T\) は \((8,-8,0,0)\) を与える。
- PIV の \(t=2T,\ Q(T)=2q(2T)\) は \(\alpha=-\theta_\infty-1,\ \beta=-2\theta_0^2\) と整合する。
- FN の変換後の \(U\) について、\(Q=(U'-a)/(2U)\) と \(U=Q'+Q^2+T/2\) から \(Q''=2Q^3+TQ+a-1/2\) が出る。\(U=0,a=0\) では除算不能であることが明示されている。

平方時間の比較は非零時間上の局所双正則写像または被覆として扱われ、同じ穿孔直線の大域座標変更と誤記されていない。[VDPS09, equations (19), (24), (29), (34), (39), (45)](https://arxiv.org/pdf/0902.1702v5)

Hamiltonian の符号も、元の方程式の符号から extended form を再計算する必要がある。§9.4 は source の符号不整合を補正し、\(P=p/F(q),K=-H\) の比較で extended form 全体の負号も保持する。二形式の符号を黙って変える問題としては採用しなかった。PV の印刷された scalar equation と first-order system のずれも、README は訂正式と具体的な数値検査を含めて区別する。

### 7.4 古典係数境界の被覆

PIII の \((\alpha,\beta,\gamma,\delta)\) の全16通りの零・非零パターンを列挙した結果、README の表は次の互いに重ならない4群で全てを覆う。

| 群 | 条件 | パターン数 |
|---|---|---:|
| D6 | \(\gamma\delta\ne0\) | 4 |
| D7 | \(\gamma=0,\ \alpha\delta\ne0\)、または \(\delta=0,\ \beta\gamma\ne0\) | 4 |
| D8 | \(\gamma=\delta=0,\ \alpha\beta\ne0\) | 1 |
| 求積境界 | \(\alpha=\gamma=0\)、または \(\beta=\delta=0\) | 7 |

\(t=aT,q=bQ\) の非零スケーリングは係数を

\[
(\alpha,\beta,\gamma,\delta)
\mapsto(ab\alpha,a\beta/b,a^2b^2\gamma,a^2\delta/b^2)
\]

へ送り、\(q\mapsto1/q\) は \((\alpha,\beta,\gamma,\delta)\mapsto(-\beta,-\alpha,-\delta,-\gamma)\) に対応する。これで非零パターンの正規化を確認でき、零係数への移行を非零 scaling で行ったことにはならない。

求積という判定も単なる呼称ではない。例えば \(\alpha=\gamma=0\)、\(x=\log t,y=q/t\) と置くと、非零領域で

\[
y_x^2=C y^2-2\beta y-\delta
\]

という第一積分に帰着する。全係数0では \(q=C_0e^{\mu\log t}\) であり、一般の \(\mu\) について \(\mathbb C^*\) 上の一価性はない。README は適切な被覆を保持している。

PV は \(\delta\ne0\)、\(\delta=0,\gamma\ne0\)、\(\gamma=\delta=0\) の三分割で尽くされる。最後の群は \(x=\log t\) により自律化し、

\[
q_x^2=(q-1)^2(2\alpha q^2+Cq-2\beta)
\]

という第一積分を持つ。これらの第一積分から二階方程式へ戻る際には、定数枝を元の方程式へ代入して確認する必要がある。第一積分を微分して \(q_x\) で割るだけでは枝を増減させる。この注意は将来の §9.3 の実際の比較証明に必要であり、表自体の欠落を示す反例ではない。

### 7.5 σと例外枝

PI の σ-equation の \(\sigma''\equiv0\) 枝 \(\sigma=at+2a^3\) は、一般には PI phase section を復元しない。PII でも \(c=\alpha+1/2=0,p=0\) の Riccati family は \(\sigma=0\) に潰れる。§9.4 は逆変換の非零条件と、潰れた枝で full phase data を保持する必要を明記している。従って「二階二次の σ-equation の全解が元の Painlevé 解に一意に対応する」という偽命題にはなっていない。

## 8. 証明責任として残るもの

次は重要な未完成箇所だが、今回の凍結 README はそれを目標として所有しており、既知定理として無断で使用していない。

| 目標 | 完成証明に必要なもの | 今回の判定 |
|---|---|---|
| §6.2 全 profile の compactification | 全チャート、重複写像、束の跳躍、例外曲線、全補集合、形式・分布比較 | 大きな将来証明。文献の一般定理としては扱えない |
| §6.3 相対時間線 | 非被約底を含む平坦性・底変換、KS方向、正規化、分布の一致 | 点ごとの次元1計算だけでは不足。本文は追加責任を保持 |
| §7.2 追加反射 | 表面側の構成、実際の作用領域、Coxeter関係、正則延長、connection側への比較 | PVI結果の全profileへの流用は禁止されている |
| §7.3 曲線の大域化 | モノドロミー、有限被覆からのdescent、rank-two lift | 局所結論と大域結論が区別されている |
| §§9.2–9.3 全比較パッケージ | 具体的な momentum、逆jet、各分母・定数枝・例外領域、全係数境界 | 正規化辞書とパターン被覆に明瞭な矛盾は見つからない |

## 9. 一次資料と検査限界

一次資料の本文を browse して、以下の箇所を確認した。文献の主張の範囲と、今回の独立した計算・判断を区別した。

| 資料 | 主に確認した箇所 |
|---|---|
| [STT02](https://arxiv.org/pdf/math/0006026) | 定義1.1/1.3、Proposition1.2/1.3、Tables2–3、D8の定義上の注意 |
| [TER02](https://arxiv.org/pdf/math/0006027) | Theorem2.1、Conjecture2.1、Proposition2.1、境界完全列と交点行列 |
| [ST04](https://arxiv.org/pdf/math/0201225) | Proposition2.1、Remark2.4、Theorem3.1、付録の限定された局所コホモロジー結果 |
| [VDPS09 v5](https://arxiv.org/pdf/0902.1702v5) | 導入の一般比較予想、§2.2/Table1、§4の各profile・scalar/first-order表示 |
| [IIS06 v2](https://arxiv.org/pdf/math/0501007v2) | PVI係数規約、Theorem7.4、Remark7.5、§10、Theorem10.13 |
| [AHT17](https://sigma-journal.com/2017/029/sigma17-029.pdf) | degenerate PVのmoduli、強化monodromy dataと比較範囲 |
| [DIL21](https://sigma-journal.com/2021/056/sigma21-056.pdf) | III/degenerateVの明示的比較と局所モデルの範囲 |

FM19 の指定 PDF は browse で取得できなかったため、その本文を読んだという主張や、その定理だけに依存する断定はしていない。係数境界の今回の判定は、凍結表の有限パターン検査、明示的スケーリング・反転、上の第一積分計算に基づく。

全ての相対構成・解析的適切性・延長定理の証明はこのレビューで完成させていない。したがって「数学的な確定指摘0件」は担当範囲における反例・循環検査の結果であり、全ロードマップの証明保証ではない。構造化計画の一件は、README の数学的妥当性と分離して修正すべきである。
