# Cross-layer mathematical audit

Scope: the frozen round-1 README, plan and sources; mathematical content only. The author read the whole mathematical build and checked the dependency graph independently of the three assigned readers. The resumed review does not run the Worker.

## Accepted finding MR4-INPUT-OUTPUT (P2)

The machine-readable `hypotheses` entries mix actual premises with outputs owned by the very same target. Concrete examples are:

| Target | Original entry in `hypotheses` | Mathematical role in the README |
|---|---|---|
| 1.4 | ten underlying and seventeen ordered profiles | conclusion of the formal-profile classification |
| 4.4 | uniform lattice boundedness and stable replacement | intermediate lemmas to prove before relative properness |
| 6.2 | full-classical compactification; exact complement and form/distribution comparison | the construction and comparison to be established |
| 7.2 | added marked-surface reflections | new generators that the target must construct |
| 9.2 | constructed charts, parameter maps, inverse jets | outputs of scalar comparison |
| 10.3 | uniform HM sectorial Hamiltonian bounds and arc vanishing | supporting analytic estimates owned by this target |

This does not demonstrate a circular definition in the README: that text explicitly owns these proofs. It is a genuine inconsistency in the structured mathematical specification. A consumer reading the hypotheses as premises could wrongly regard the difficult lemma as supplied or the classification as assumed. Core review independently confirmed the first and second examples. The remedy separates actual data and earlier results from same-target construction/proof outputs. It changes 27 entries as one defect pattern, not 27 independent mathematical errors. The separate 10.2 precision amendment also restates its actual hypotheses.

The author change ledger retains every before/after entry. Existing target statements, APIs, dependencies and proof obligations are preserved; 1.4's classification obligation is made explicit in the owned-obligation list.

## Uniform-moment candidate: not counted as a false-statement finding

In 10.2, bounded weighted moments imply a coefficient expansion with a little-o remainder for each fixed parameter. They do not imply a little-o uniform on a noncompact parameter set. The old paragraph did not expressly quantify its little-o uniformly, and 10.3 already separately owned uniform sectorial estimates. The independent analysis reviewer therefore rejected the stronger interpretation as a definite error in the old theorem. This adjudication is retained.

Nevertheless, a useful precision amendment makes both quantifiers explicit and supplies a criterion for the uniform conclusion. The counterexample is a small nilpotent Gaussian jump translated to infinity; it is holomorphic in a connected complex parameter strip, so adding Banach-holomorphic dependence alone does not repair the stronger claim. The amended target requires uniform weighted L¹ and L² tail tightness, or a proved sufficient substitute. The elementary estimate for h = (I+ν)w and the exact geometric-series remainder prove sufficiency. A uniformly bounded additional moment gives the stronger one-power remainder. The new diagnostic and independent proof check are recorded in the analysis review.

## Structural checks and rejected countermodels

1. **Definition does not assume its desired dimensions.** Section 1.3 imposes genus zero, rank two, structural polar degree four, the admitted local structures, regular-singular determinant data and the actual reduced time problem. Neither phase dimension two, time dimension one, a splitting nor continuation is an input field. Profile count and dimension formulas are later conclusions.
2. **No scalar-equation dependency in the intrinsic core.** All 44 targets and 216 internal edges were inspected. The graph is acyclic; no target in Layers 1–8 transitively depends on Layer 9. The first-jet lemma is a conditional comparison after the geometric construction, not a definition of its splitting.
3. **Actual pole vanishing is not structural-degree loss.** At logarithmic points, scalar or zero residues may occur within the structural moduli problem. Irregular leading-term vanishing instead leaves its stipulated generic local stratum. Those two mechanisms must not be conflated; the text distinguishes them.
4. **Completeness is not merely local ODE theory.** The source-to-target proper map traps every partial horizontal lift over the compact transported target path. Compatibility is required at exceptional points and on every partial interval. Thus neither an inverse of coarse RH nor a dense-open compatibility statement is substituted for the theorem.
5. **Full proper RH remains a substantive construction target.** Generic unramified/nonresonant literature does not supply the whole stated family theorem. The roadmap retains lattice bounds, closed incidence extension, stable replacement and analytic gluing as owned obligations. Calling these future proofs does not certify their completion.
6. **Observables do not silently determine all phase data.** An observer has its actual projective/rational domain; an identically infinite value and a trajectory inside indeterminacy are excluded from the usual scalar conclusion. Jet inverses and sigma reconstructions retain their degenerate loci. Geometric solution uniqueness is not used to assert a false scalar inverse.
7. **Surface type is not input identity.** Equal boundary diagrams need not identify decorated connection problems. The first boundary-layer line is not assumed equal to the whole supported-cohomology space. Pair compactification and the comparison of time directions are separate owned constructions.
8. **Tau normalizations carry real additional data.** The determinant section is intrinsic for the specified Fredholm/RHP problem and its proved equivalences. Arbitrary modifications may change its divisor. JMU/Hamiltonian comparison is restricted to its actual generic locus. Neither a scalar Hamiltonian nor an arbitrary reference modification is treated as a canonical global function.
9. **Confluence needs more than a pole diagram.** The input retains determinant and formal coefficients, labels and ramification. Positive-margin finite-chart estimates, matched initial data and a no-exit argument precede solution convergence. Endpoint constants require extra estimates. The text does not infer these conclusions from a formal coefficient limit alone.

## Limit of the verdict

This is an audit of mathematical definitions, theorem targets, proof routes, scope and comparisons. It is not a proof of the 44 future targets. The difficult all-strata RH, full moduli–surface comparison, resonant/ramified RHP adapters and specified uniform confluence/asymptotic estimates remain explicitly owned research/proof work. No additional actionable defect was established by this cross-layer pass beyond MR4-INPUT-OUTPUT.
