# Independent mathematical review — Layers 8, 10, 11

## Verdict

**Confirmed mathematical defects: 0.** I found no false quantified assertion, circular mathematical construction, or presently stated invalid proof implication in the assigned layers of the frozen input. This is a review of the mathematical roadmap, not a claim that its future theorems have been proved. In particular, the broad resonant/ramified RHP construction and intrinsic confluence adapters remain substantial owned proof obligations.

The uniform-moment concern raised during this review is mathematically real **for a stronger, parameter-uniform little-o conclusion**, but I do not count it as a defect of the literal current statement. Section 10.2 does not explicitly assert that its little-o remainder is uniform over the entire parameter domain, while §10.3 explicitly requests separate uniform sectorial remainder estimates. I give a concrete counterexample and a minimal wording improvement below, so this distinction remains reviewable.

## Inputs and method

Read only the frozen mathematical specification:

- `_math_review4/round1/artifact/README.md`;
- `_math_review4/round1/artifact/sources.toml`;
- `_math_review4/round1/artifact/design/plan.json`.

Primary responsibility: §§8.1–8.4, 10.1–10.4, 11.1–11.4, together with the conventions and the dependencies required to interpret their assertions. I did not inspect earlier reviews, execute a worker, inspect Lean implementation, edit canonical inputs, or push anything. I compared the actual `statement`, `hypotheses`, `api`, and `owned_proof_obligations` fields for the relevant targets rather than treating the README alone as the contract.

The checks below distinguish three cases:

1. A stated theorem whose hypotheses demonstrably permit a counterexample.
2. A proof step claimed to follow from insufficient inputs.
3. A named future theorem or adapter the roadmap explicitly undertakes to construct.

Only the first two count as findings. Large proof obligations of the third kind are not silently reclassified as mathematical errors.

## 1. Holomorphic determinant family and global descent

### 1.1 Stabilization construction is a legitimate proof route

The stated local construction is the usual one: choose finite-dimensional `F` so that `(T_s,a): H₀ ⊕ F → H₁` is surjective in a neighborhood. Its kernel `K` has rank `dim F` at Fredholm index zero. The line `det K* ⊗ det F` and the determinant of the projection `K → F` give the local section. Comparison through common stabilizations, with exact-sequence signs fixed, is an actual construction of the line and its section; a curvature form is not being substituted for the integral gluing problem.

The sign convention must be fixed in the exact-sequence comparison, as requested by the explicit finite-dimensional normalization check. For example, with `T_s=s` and auxiliary map `a=1`, the kernel basis `(1,-s)` projects to `-s`; the comparison to `det H₀* ⊗ det H₁` must carry the selected determinant convention. The target explicitly asks for the dual-convention adapter and requires the finite-dimensional result `τ(s)=s`, so this is a sign choice to perform, not an internal contradiction in the contract.

The tests `T_s=s²`, constant invertible `T`, and identically singular index-zero `T` correctly separate line existence, section existence, generic nonvanishing, and divisor multiplicity. No unsupported equation between vanishing order and kernel dimension is asserted.

Primary reference check: Malgrange §2 constructs the determinant extension in its loop-group setting; the roadmap correctly treats the general complex holomorphic Fredholm-family theorem as a separate supplier obligation rather than attributing that general theorem wholesale to Malgrange. [MAL04](https://www.numdam.org/item/10.5802/aif.2052.pdf)

### 1.2 RHP index and bundle modifications are not conflated

For the initial closed-contour model, invertibility of the analytic symbol and zero determinant winding establish Fredholm index zero. They do not establish solvability: partial indices may be nonzero. The roadmap asks for the actual operator, distinguishes invertibility from index zero, permits an identically zero section, and forms a Cartier divisor only on a smooth connected chart with a section that is not identically zero.

The source assumptions were checked directly: BERT17 §1 includes analytic invertible symbols, zero winding, and generic vanishing of all partial indices. The roadmap does not need the source's generic-solvability condition merely to construct its determinant line; it explicitly adds nonidentity-to-zero before asserting a divisor. Its normalized RHP/operator equivalence is therefore scoped coherently. [BERT17, §1](https://sigma-journal.com/2017/046/sigma17-046.pdf)

The degree obstruction is handled correctly. For rank two on `P¹`, `χ(E(k))=d+2k+2`; if `d` is odd, no integer common line twist gives zero Euler characteristic. Section 8.2 explicitly owns an auxiliary index-zero realization and keeps its modification/reference bundle among the markings. It does not claim that arbitrary changes of reference preserve a tau divisor. Comparison by a unit is restricted to proved Fredholm/chain/stable equivalences with everywhere acyclic added complexes.

The stack/coarse-space distinction is also correct: scalar weight zero does not prove triviality of every stabilizer character, and coarse descent is conditional on that proof.

### 1.3 Fredholm trace, divisor, and JMU scope

For a trace-class-norm holomorphic family, the claimed identity

`d log det(I−K) = −Tr((I−K)⁻¹ dK)`

is valid on the invertible locus. Outside the trace-class model, the text asks for the appropriate marked Fredholm adapter and frame comparison. It does not infer a trace-class Fredholm determinant for every bounded Fredholm operator without further work.

BERT10 Assumption 3.1 actually requires distinct simple leading eigenvalues and, at logarithmic poles, eigenvalues distinct modulo integers. The README's general conventions already require distinct leading terms at an unramified irregular point, and §8.3 invokes precisely Assumption 3.1. Thus its shorter phrase “generic ... diagonalizable-leading-term” does not enlarge the comparison locus to repeated semisimple leading eigenvalues. It would be harmless to replace that shorter phrase everywhere by “regular semisimple leading term,” but I did not find an operative repeated-eigenvalue claim. [BERT10, Assumption 3.1](https://arxiv.org/pdf/0902.4716v2)

BERT16 Theorem 2.2 was checked directly: the correction is a locally defined form on monodromy parameters, and the logarithmic differential is `ω_M−θ_V`. The roadmap retains its sign, vertex curvature, lack of a time component in `θ_V`, and the need for factorization/frame corrections. It does not assert that the raw Malgrange form is closed on all time-and-monodromy space. [BERT16, Theorems 2.1–2.2](https://arxiv.org/pdf/1601.04790v2)

Consequently, the broad existence of a marked determinant section is not being used to infer an unspecified ramified/resonant JMU differential. The Hamiltonian identity has the same restricted scope, and the general trace/frame identity remains the object on constructed adapter loci. This is the correct separation.

## 2. Normalized RHP engine and distinguished solutions

### 2.1 Small-norm construction

The `ν` formulation is correct on unbounded contours:

- `C₋w∈L²`;
- multiplication by `w∈L∞` is bounded on `L²`;
- `‖C_w‖≤ρ<1` gives the Neumann inverse;
- `ν=C₋w+C₋(νw)` implies `R₋=I+ν` for `R=I+C((I+ν)w)`;
- Plemelj then gives the required jump.

It avoids the invalid assumption `I∈L²(Γ)`. The converse uniqueness proof is valid in the specified Cauchy-transform class. The roadmap separately requires the endpoint/vertex reconstruction and determinant-removability adapter, so uniqueness is not improperly extended to arbitrary functions with the same almost-everywhere boundary traces.

The two explicit examples are correct:

- On `[0,1]`, the excluded homogeneous correction `e^(−1/z)z⁻¹E₁₂` has squared boundary `L²` norm `e^(−2)/2`, but cannot be reconstructed from its zero jump.
- On the counterclockwise circle, jump `−I₂` has small-norm criterion failure but a normalized solution, so the sufficient criterion is not treated as necessary.

The weighted estimate for `h=w+νw` is correct by Cauchy–Schwarz, and for each fixed parameter, weighted `L¹` integrability gives the stated off-ray asymptotic expansion by dominated convergence. Section 10.2 also explicitly requires additional estimates on the rays, where its angular denominator bound does not apply.

### 2.2 Uniform-moment concern: concrete stronger-statement counterexample

The following stronger statement would be false:

> Uniform boundedness of `(1+|ζ|^m)w_s` in `L¹∩L²`, together with a common small-norm bound, implies a remainder `o(|z|^(−m−1))` uniform over an arbitrary parameter domain.

Take `Γ=R`, `E=E₁₂`, and a sufficiently small nonzero constant `a`. On the connected complex strip

`S={s∈C: Re s>1, |Im s|<δ}`,

let

`w_s(x)=a exp(−(x−s)²)E`.

This is a Banach-holomorphic family into `L¹∩L²∩L∞`, with norms uniformly bounded on the strip. Choosing `|a|e^(δ²)<ρ` gives the common small-norm hypothesis because the standard real-line Cauchy projections have norm one. Also `det(I+w_s)=1` and `E²=0`. Hence the exact solution has `h_s=w_s`: nonlinear products vanish.

For real `s=n`, the leading moment is independent of `n`,

`M₀ = ∫_R w_n(x) dx = a√π E`.

At `z=in`, a direction uniformly separated from both real-line rays,

`n C(w_n)(in) → [a√π/(2πi)]/(1−i)`.

But the proposed first coefficient is `−M₀/(2πi z)`. Thus

`n [ C(w_n)(in) + M₀/(2πi in) ] → [a√π/(2πi)](1−i)/2 ≠ 0`.

The `o(1/z)` remainder is not uniform in `s`; the mass drifts to infinity. This counterexample satisfies holomorphic dependence as well as the small-norm and determinant-one requirements, so Banach holomorphy on a noncompact parameter domain does not repair the uniform statement.

**Why I do not record this as a current defect:** the actual §10.2 says “the dominated-integral remainder `o(...)`,” without quantifying it uniformly in `s`. Its parameter-uniform norm bounds do imply a uniform `O(1/z)` normalization, which is the other claim made there. Section 10.3 separately demands uniform boundary-sector and weighted remainder estimates and gives explicit uniform HM bounds; it does not say those follow from the §10.2 moment membership alone.

A useful precision edit would be:

> “The little-o remainder is for each fixed parameter. It is uniform on parameter families whose weighted `L¹` and `L²` tails are uniformly tight; in particular this holds on compact parameter sets when the family is continuous in the corresponding weighted norms. Entire-domain uniform asymptotics require this added tail condition or a uniformly bounded higher moment.”

A sufficient tail condition is

`sup_s ‖1_{|ζ|>R}(1+|ζ|^m)w_s‖_{L¹∩L²} → 0`.

Together with the uniform `ν` bound, it gives tightness of `(1+|ζ|^m)h_s` in `L¹`. A common weighted moment of order `m+η` for any `η>0` is another sufficient condition. The HM application already has a stronger separately stated uniform target. Reference context: [ILP18, §3.3 and §4.5](https://arxiv.org/pdf/1604.03082v4); the counterexample and tightness calculation above are independent calculations.

### 2.3 Connection-formula parameter restrictions

The PVI restrictions in §10.3 match ILP18 (1.13), (1.17): logarithmic nonresonance, the real-part range of the composite exponents, the nonzero composite exponents, and the four independent-sign nonintegrality sets. The source's branch choices and JMU normalization are retained. The auxiliary formula for `ς` is not totalized at a zero denominator; extension is expressly a separate proof target.

For homogeneous PII, the Stokes cubic, the branch restrictions on `1−s₁s₃` and `iϵs₂`, and `ϵ=sign Re(is₂)` match (1.25). The literal `η` formula requires `s₃≠0`, which the text acknowledges. The example `(i,i,0)` does satisfy the cubic and source genericity restrictions while making the literal quotient undefined; its use as a continuation test is correct. No arbitrary-α or real-axis pole-free conclusion is smuggled into the generic theorem. [ILP18, Theorems A and B](https://arxiv.org/pdf/1604.03082v4)

### 2.4 HM calibration and bridge

The three calibration ingredients are correctly separate: the Airy determinant constant, the specified sector pole-freeness, and uniform sectorial Hamiltonian/arc estimates. I checked HXZ Theorem 2.1 and the sectors in ILP18 (4.74)–(4.76). The source sectors cover the two arcs used here. The claimed explicit bounds are the absolute-value bounds corresponding to the displayed source expansions, with the uniform remainder made an owned target rather than deduced from real-ray asymptotics. [HXZ16, Theorem 2.1](https://arxiv.org/pdf/1410.3338) and [DIK08](https://arxiv.org/pdf/math/0609451)

The arc powers are consistent: an exponential with a simple angular zero integrates to `O(R^(−3/2))`; including the arc-length factor gives `O(R^(−3/2))` on the first arc and `O(R^(−3/4))` on the second. The phase correction `+iπ/24` and absolute factor `exp(χ+iπ/24)` agree with ILP18 (4.76). The uniform estimates, including the boundary rays, still have to be proved by the promised RHP parametrices.

The §10.4 bridge uses the already supplied HM first jet at a regular real time. First-jet inversion plus geometric uniqueness is a valid bridge. It does not re-prove boundary asymptotics from initial values and does not confuse real pole-freeness with complex pole-freeness. In the stated PII chart `p=q′+q²+t/2`, finite real first jets lie in the chart, so regularity at the chosen time is enough for this step.

## 3. Intrinsic confluence, compact paths, and tau limits

### 3.1 Collision data and corrected Laurent lemma

The family records more than a collision divisor: leading orbits, lower coefficients, determinant data, formal conditions, time/exponent maps, and rank-defined regular loci are retained. Mere equality of projective slope is not treated as a primitive endpoint condition. An irregular scalar determinant is explicitly rejected from the primitive class. Ramified adapters are owned constructions; GMR23 §5.1 is correctly restricted to nonramified realizations. [GMR23, §5.1](https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf)

I verified the elementary corrected Laurent calculation. Expanding `C/(z−P)` and subtracting the negative Laurent parts of `CP^j` gives the finite coefficients `D_j(0)+[CP^j]_0`. Since `C=O(ε^(−r−1))` and `P=t₁ε+O(ε²)`, the coefficient of `z^(−r−2)` tends to `t₁^(r+1)W`; the later terms are `O(ε)` on compact subsets away from `z=0`. The `r=1` examples in the text agree with direct rational simplification. The old `O(ε^(−r))` scaling could not create that highest coefficient, as the roadmap observes. [GMR23, printed Theorem 2](https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf)

The three local models with semisimple, nilpotent-but-coupled, and removable leading matrices correctly distinguish the formal types. The ramified calculation after `z=w²`, `g=diag(1,w)` yields leading `2(E₁₂+E₂₁)/w²`; a nonzero matrix pole order alone is not being mistaken for the projective slope.

The negative-to-positive Lie–Poisson adapter by coefficient negation is correct: for linear functions, pulling back by `μ↦−μ` turns the target positive bracket into the source negative bracket. The roadmap requests transport of KKS forms, moment maps, reductions, and Hamiltonian conventions rather than an identity comparison of matrices.

The construction of flat relative complexes and common phase charts is still nontrivial. It is explicitly listed among the obligations, and components lacking verified regular comparison receive no solution-convergence arrow. I did not find a claim that arbitrary formal coefficient convergence automatically supplies such a component.

### 3.2 Compact-path theorem

The hypotheses are sufficient for the asserted ODE theorem: a reference trajectory on a compact piecewise `C¹` path, finitely many common charts, a positive tube margin, uniform field convergence, a common local Lipschitz bound, and convergent initial data. The path velocity is included in the nonautonomous field. The displayed estimate is the standard integral-equation/Grönwall bound. For small error, first exit from a positive-margin tube is impossible; local existence then extends through the finite sequence of chart intervals.

The text explicitly separates the theorem on one fixed compact path from a theorem on a compact time domain requiring controlled path families. It also explicitly separates both from convergence on an unbounded ray or across a fixed singularity. The finite-dimensional manifold/compatible-metric formulation does not add a mathematical obstruction; all relevant images are compact and covered by finitely many charts.

### 3.3 Cascade and tau convergence

The cascade quantifies over verified collision-data comparisons. It does not claim an unspecified finite scalar graph exhausts all degenerations. Matching endpoints by a classical label does not erase the time, parameter, determinant, or first-jet identifications. Iterated limits explicitly require an additional uniform theorem.

For §11.4, once comparison lines/frames exist and the corrected logarithmic forms converge along controlled compact path families, matching the value at a common regular point gives convergence by integration and exponentiation. Off the limiting divisor, the forms themselves must be defined on the comparison domain; this is implicit in the asserted uniform convergence and is not being deduced solely from field convergence.

The alternative trace-norm argument has the right topology and uses a fixed Hilbert space after controlled identifications. It can include zeros. Its separate zero-count conclusion includes a nonvanishing boundary and a nonzero limit, which are exactly the missing safeguards in a naive Hurwitz/Rouché invocation. Endpoint connection constants are kept separate from compact convergence and require uniform sectorial normalization. I found no all-parameter or all-endpoint tau-limit assertion beyond these hypotheses.

## Primary-source retrieval record

Read through the web connector in this fresh review:

| Source | Verified content | Retrieval URL |
|---|---|---|
| MAL04 | §2 determinant-extension setting; Theorem 5.12 has Schlesinger scope | https://www.numdam.org/item/10.5802/aif.2052.pdf |
| BERT10 | Assumption 3.1 simple leading eigenvalues/logarithmic nonresonance | https://arxiv.org/pdf/0902.4716v2 |
| BERT16 | Vertex correction; Theorem 2.2 and `ω_M−θ_V` | https://arxiv.org/pdf/1601.04790v2 |
| BERT17 | Closed-contour hypotheses; index and partial-index distinction; local determinant/frame viewpoint | https://sigma-journal.com/2017/046/sigma17-046.pdf |
| ILP18 | Theorems A/B parameter restrictions, PII normalization, (4.74)–(4.76) sector/arc calibration | https://arxiv.org/pdf/1604.03082v4 |
| HXZ16 | Theorem 2.1; required closed sectors | https://arxiv.org/pdf/1410.3338 |
| DIK08 | Airy determinant source and v2 identification | https://arxiv.org/pdf/math/0609451 |
| GMR23 | Theorem 2 scaling, Theorem 12 negative brackets, §5.1 nonramified scope | https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf |

Some exact versioned PDF URLs failed retrieval. For BERT17 I used the publisher PDF with the cited SIGMA publication header. The unversioned HXZ and DIK PDF responses explicitly printed the cited v2 version/date. These are source inspections, not new byte-provenance certifications of the manifest hashes.

## Limits

I did not attempt complete proofs of the supplier holomorphic determinant theorem, every resonant/ramified RHP adapter, the intrinsic all-strata RH theorem, or every collision-family comparison. The review does not establish those future results. It establishes that the assigned statements, as scoped, do not contain an identified counterexample or invalid implication from the checks performed.

The strongest remaining precision recommendation is to state the pointwise/parameter-uniform little-o distinction in §10.2 explicitly. If the author intends the displayed little-o to be uniform over the entire parameter domain solely from the listed uniform norm bounds, then the drifting Gaussian family above becomes a confirmed finding and the tail-tightness repair is necessary. Under the literal scoped reading and the separate §10.3 uniform target, it is an optional clarification rather than a blocker.
