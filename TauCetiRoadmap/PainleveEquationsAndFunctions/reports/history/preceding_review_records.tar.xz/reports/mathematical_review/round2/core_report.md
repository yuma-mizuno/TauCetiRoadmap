# 独立数学レビュー round 2 — Layers 1–5 と全体の非循環性

## 判定

**P2 が 1 件残る。主要な修正対象 §1.4・§2.3・§4.4 は閉じたが、同種の input/output 混入が §5.3 に残っている。** 重大な数学的反例、新たな誤公式、主要証明課題の削除は、この担当範囲では確認しなかった。これはロードマップの契約を審査した結果であり、計画された定理の証明完了を認定するものではない。

対象は凍結版 `round2/artifact/README.md`、`design/plan.json`、`sources.toml` とする。`round2/snapshot.json` の全 4 ファイルの SHA-256 は実ファイルと一致した。元版は `round1/artifact`、変更台帳は `round1/hypotheses_author_changes.json`。以前の reviewer の findings、判定、点数は読まず、独立に現行の数学的意味を検査した。Lean、worker、push は対象外であり、実行していない。canonical artifact は編集していない。

## 残存 finding

### MR4-INPUT-OUTPUT-5.3 — 同じ節で構成する monodromy action を仮定欄で要求する [P2]

**場所:** `design/plan.json` 1031–1033 行、target `5.3`。対応する README は 459 行と 463–465 行。

statement は endpoint transport を構成し、恒等・逆向き・合成則を証明し、平坦性と局所一意性から経路の endpoint-fixed homotopy 不変性を証明して fundamental-groupoid action を得る、としている。対して hypotheses は次のようになっている。

> Constructed complete flat connection; pointed universal cover of the connected time component; actual monodromy action.

最後の `actual monodromy action` は、この target に先行する単なる生データではない。§5.2 の compact-path lift、§3.2 の平坦性、§5.1 の局所一意性を使って §5.3 が構成・同定すべき具体的な作用である。一般的な fundamental-groupoid interface が supplier にあることと、ここで構成した nonlinear connection の transport がその作用を与えることは異なる。README の 101 行も horizontal-section descent criterion を §5.3 の application としており、473 行もその application を本 roadmap の所有物としている。

したがって hypotheses を文字どおりの入力契約として使うと、holonomy の構成を呼出側へ押し戻した条件付き universal-cover/descent theorem に弱まる。これは今回除去した「同一 target の構成成果を仮定欄へ入れる」不整合の残存例である。§5.2 の継続定理が偽という意味でも、flat complete connection から作用が構成できないという意味でもない。

**最小修正:** hypotheses は「§3.2–§3.3 と §5.1–§5.2 で構成した complete flat connection、連結な time component の基点付き universal cover、初期点」とする。endpoint transport、homotopy invariance、fundamental-groupoid/monodromy action、universal-cover section とその descent criterion はこの target の出力であることを明記する。あるいは transport/action construction と、それを入力に取る descent lemma を順序付きの二つの下位契約に分ける。単に statement から作用の構成義務を消す修正は不適切。

**確信度:** 0.92。数学定理の偽性ではなく、構成ロードマップの入力・出力境界についての P2。

## 主要修正の closure 検査

### §1.4: 10 underlying / 17 ordered profiles と reduced time

現行 hypotheses（plan 229 行）は §1.3 の input、generic projective local types、実際の reduced formal-data deformation problem、保持された pole labels のみを入力とし、profile 数、stabilizer 計算、time dimension を明示的に結論へ戻している。§1.3 の nonempty stable fibers は moduli problem の領域条件であり、time dimension や continuation の仮定ではない。§1.2 の reduced deformation problem の構成も前段の独立 target にある。

独立に degree 4 の ordered compositions を列挙し、part 1 に slope 0、part m≥2 に slope m−1 または m−3/2 を割り当てた。pole 数 1,2,3,4 に対する ordered count は 2,8,6,1、ラベルの順序を忘れた count は 2,5,2,1 となった。全 17 profile で n+Σceil(r_i)−3=1。これはロードマップの数値と整合する。列挙自体は local-model completeness や stabilizer の証明ではないが、README 174–190 行はそれらを依然として要求し、plan の owned proof obligation にも追加されている。VDPS09 §2.2 / Table 1 の ten-family 比較とも照合した。

ラベルの permutation は同一 ordered input 内の label-preserving arrow と混同されていない。scalar irregular determinant directions は classical class から分離され、global half-determinant twist も仮定していない。主要な proof obligation の削除はない。

**closure: pass。**

### §2.3: auxiliary unfolding と relative closedness

現行 hypotheses（plan 405 行）は §§2.1–2.2 の moduli/deformation-complex outputs と正ランク・nonempty stable locus を入力とする。smoothness、obstruction vanishing、finite-flat unfolding、nondegeneracy、closedness は出力である。

README 239–260 行には、元の fixed-distinct-section family を unfolding と同一視しないこと、simple-connection moduli と étale universal-object cover、relative complex/trace form、central stable locus との比較、generic logarithmic/diagonal complexes の二つの quasi-isomorphism、logarithmic trace closedness の直接計算、smooth integral base 上の density descent、後続の nonreduced base change を既証明 identity から行うことが全て残る。Layer 11 はこの早期 unfolding の supplier とされていない。

意味の確認として、relative three-form の generic vanishing を全体へ移す段階は smoothness と integral auxiliary base の後に置かれている。nonreduced base で新たに dense-open vanishing を推論する構成ではない。fixed determinant の genus-positive dimension では 2g directions を比較後に除く条件も保たれている。I23 §8 の unfolding/closedness route と整合する。

**closure: pass。**

### §4.4: 全 classical family の relative properness

現行 hypotheses（plan 886 行）は §4.3 で構成した RH map、actual source strata、exponent lifts、closed character constraints を入力とし、uniform lattice bounds、decoration extension、stable replacement、compact containment、relative properness を仮定しない。

README 400–406 行には四つの中間証明課題が残る。特に、compact character families 上の一様 lattice bound、relative projective parameter space の closed incidence relations、base change/elementary modification を含む semistable replacement、semistable=stable と separatedness による uniqueness、global gluing と analytic topology への適合が明示されている。open stability や projective flag varieties だけでは properness を得られないという制限も保持されている。

§5.2 は一般 transfer lemma の入力として proper F を使うが、classical application のその入力は前段 §4.4 が証明すべきものである。この区別は循環ではない。HEU10 による continuation route を §4.4 の properness の証明と取り違えず、IS12 の generic comparison と I23 の foliation theorem も完全な discharge としていない。実際に IS12 Remark 6.3 はその文献の resonant/reducible properness を期待として述べており、現行版の scope warning は必要である。ここから現在の文献全体で未解決だとは結論しない。

**closure: pass。ただし theorem proof 自体は依然として大きな owned development task。**

## 周辺の数学的意味の検査

- **§§1.1–1.3:** positive rank、determinant identification と residual μ₂ の区別、odd determinant degree、trace-subtracted matrix と globally glued adjoint/PGL connection の区別、structural polar divisor と個別接続の nonzero poles の区別が残る。logarithmic resonance を単一 formal isomorphism class へ固定していない。
- **§§2.1–2.4:** all bundle types と jumping loci が保持され、full ramified cone の degree 2 term と differential-operator complex の扱いが残る。dim=2 の数値は −8+2+8=2。rank-one/general-genus の determinant comparison も別扱いである。
- **§§3.1–3.2:** strong extension の pole filtration、kernel-lattice preservation、integrability は構成する対象の条件である。existence/uniqueness と horizontal splitting を既存入力にしていない。二変数比較による flatness は Stokes theorem より前にあり、analytic characterization を逆に使う循環はない。
- **§3.3:** closed total form は actual connection-specific pairing に対する証明課題として残る。relative closedness と flat splitting だけから自動的に従うとは解釈していない。例えば h=∂t、ω=e^t dq∧dp なら relative ω は閉じていても total Ω は閉じない。現行 target はこの不足分を I23 の実際の integrable-extension construction に即して証明する位置に置いている。
- **§§4.1–4.3:** formal normal form と analytic Stokes theorem を分離し、ramified family transport の deck-equivariant isotopy/descent を own している。ordinary character quotient の非忠実性、exceptional fibers、all-strata horizontal compatibility が保持される。generic inverse を全点の inverse と取り違えない。
- **§5.2:** compact target path の proper preimage 内に lift を閉じ込め、source chart の continuous-time / locally phase-Lipschitz ODE を延長する筋は妥当。C¹ base path を autonomization した場が C¹ とは限らない点への修正も保持されている。対象の singularity や RH の非単射性はこの議論を妨げない。
- **§§5.4–5.5:** rational observer は任意の解に自動的に pull back できるとはせず、non-indeterminacy または resolution/lift を要求する。identically ∞ の除外、finite-order poles、universal-cover continuation と single-valued descent の区別が残る。この observer admissibility は正当な対象の領域条件であり、§5.3 のような「同一節の action construction を事前に供給する」問題とは区別した。

## 変更による義務削除の検査

変更台帳の 27 エントリは全て before/after の実際の hypotheses と一致する。Layers 1–5 では 12 target の hypotheses のみが変わり、statement、api、tests、prerequisites、readme_needs その他のフィールドに変更はない。旧 owned proof obligations の削除・変更は 0 件で、§1.4 と §10.2 の義務が追加されている。この機械検査に加え、上記の通り旧仮定から外された内容が現行 statement/API に実際に残っていることを意味として確認した。

## 全体の非循環性

plan の 44 targets と 216 本の `target:` dependency edges を全て検査した。未解決 target reference は 0、directed cycle は 0。Layers 1–5 の推移的祖先に Layers 6–11 の target は含まれない。特に次の順序が保たれる。

1. §2.3 の supporting unfolding は Layer 11 に依存しない。
2. §§3.1–3.2 の algebraic splitting/flatness は Layer 4 の analytic Stokes interpretation に依存しない。
3. §4.4 の properness → §5.2 の continuation → Layer 9 の scalar displays。
4. §6.2 の compactification は §4.4 を回避するための continuation 証明に使われない。
5. supplied Hastings–McLeod solution から §10.4 の intrinsic bridge への向きであり、RandomMatrices supplier へ逆向き dependency を追加していない。
6. Layer 11 は先行する intrinsic/surface/scalar theory を消費し、finite-flat family を earlier smoothness の仮定へ戻していない。

ただし dependency graph が DAG であることだけでは意味上の入力・出力混入は検出できない。§5.3 の finding がその例である。外部 roadmap の全実装・全証明を読み直していないため、supplier 内部を含む全宇宙の DAG を認証したとは主張しない。二つの named supplier extensions は未完成 gap として明示されている。

## 照合した一次資料

- [I23, SIGMA 19 (2023), 013](https://sigma-journal.com/2023/013/sigma23-013.pdf): §8 の補助 unfolding と closedness、§10 の strong horizontal lift、Corollary 11.8 の total form。現行 proof obligations の配置との限定的な照合。
- [VDPS09, arXiv:0902.1702v5](https://arxiv.org/pdf/0902.1702v5): §2.2 / ten-family table。ordered label count は本レビューで独立に列挙した。
- [IS12, arXiv:1203.0084v3](https://arxiv.org/pdf/1203.0084v3): Remark 6.3 の properness scope、Remark 6.5 の dense chart と whole moduli の区別。

## 限界と次の受入条件

これは Layers 1–5 の構成・定理契約と全体 dependency direction のレビューである。§4.4 の compactness proof、全 profile の surface comparison、analytic sectorial construction 等の完成証明を作成・査読したものではない。他担当の Layers 6–11 の詳細 findings もここでは取り込んでいない。source provenance は proof certificate ではない。

§5.3 の hypotheses から action construction を外し、same-target outputs として明記した新しい凍結版を確認すれば、この担当範囲で見つかった残存 P2 の closure を判断できる。主要三箇所は再び入力へ戻さず、現行の explicit obligations を保持する必要がある。
