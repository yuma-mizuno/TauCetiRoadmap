# MR4 round2：Layers 6・7・9の独立数学レビュー

## 結論

**担当範囲における MR4-INPUT-OUTPUT は解消。新たな P1/P2 の数学的契約不整合は見つからなかった。**

これは修正されたロードマップの入力・先行成果・新しい成果の区別についての結論である。全profileのコンパクト化、大域補集合同型、反射の延長、あるいはRHのpropernessの証明が完成した、という判定ではない。これらは引き続き明示的な構成・証明課題である。

旧レビューの「0件」という判断は用いていない。round1/artifactとround2/artifact、および著者のhypotheses変更台帳を比較し、担当全targetの本文、API、例外、依存関係を読んだ。canonicalファイルは編集していない。Lean、Worker、pushは対象外であり実行していない。

## 固定した対象

| File | SHA-256 |
|---|---|
| `README.md` | `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658` |
| `design/plan.json` | `5d01eec8f10d5f3b8ae670920ca9fb4bdc814401d0ea8117a6e8c13c5ba79519` |
| `sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |

対象は `_math_review4/round2/artifact`。上記はround2/snapshot.jsonに一致する。具体的な機械可読記録は `geometry_findings.json`、構造・列挙の証拠は `geometry_audit_evidence.json`。

## 修正箇所の評価

| Target | 正当な入力・先行成果 | なお当該targetが構成・証明するもの | 保持された制限 |
|---|---|---|---|
| 6.2 | Layers 1–3の完全なphase family、内在的形式・splitting、6.1のpair framework、許されたmarking/base change | compactification、8境界型、**完全な**開補集合との同型、形式・分布の比較 | exceptional曲線、bundle-jumpingを含む非自明束のchart、overlapとcoverage。同じD₆型だけでは同型を得ない。 |
| 6.3 | 6.1–6.2のnonfibered additive pair family、Layer 3のsplitting | 第一境界層のrank 1、局所cohomologyへの単射、局所自由base change、KS/time同定 | full local-cohomologyとの等号は仮定しない。非被約baseでのfiber次元一定だけから自由性を推論しない。 |
| 7.1 | 既存のdecorated connection、局所不変商、指定line connection/duality/relabeling | 変更後のdeterminant・exponent・stable域・strong-extension比較 | weight chamber、実際の許容領域、逆操作に必要なflagを保持。 |
| 7.2 | 7.1のfunctor、Layers 2–3のpairing/splitting、6.2のmarked比較 | 追加のmarked-pair反射、regular/birational域、horizontal/symplectic延長、関係式 | PVI中央反射を局所整数shiftで得たことにしない。dense openの有理恒等式から全域automorphismへ飛躍しない。 |
| 7.3 | 初期fiberの内部rational −2曲線、許容されたsemiuniversal pair変形、6.3のtime比較 | 曲線の局所継続、不変性、projective linearization | 外部parameterを固定したtime方向。local/étale/finite base change、monodromy descent、rank-two lift障害、全曲線上のregular延長。 |
| 9.2 | 1.4で先行して得たprofile分類、内在的moduli・splitting・形式・継続 | 具体的chart、parameter/time写像、momentum逆、全overlap/coverage | 10 underlyingと17 ordered、8境界型を混同しない。square-timeは非零域/cover上。FNのU=0例外、各分母と省略locusを保持。 |
| 9.4 | 既存の幾何変換、determinant変分、coordinate比較 | source-sign補正、Hamiltonian/sigma/linear-system比較 | sigma逆の非退化、PIのspurious branch、PIIの真の不変locus上のphase情報喪失を明記。 |
| 9.5 | 9.2のPI/PII比較、first-jet lemma、許された幾何変換 | 指定Hamiltonian、momentum inverse、seed恒等式 | α=−1/2のRiccati、pole chart、実際の変換域、特殊解の非完全分類。 |

主要証拠：plan.jsonのhypothesesは1248, 1314, 1382, 1445, 1505, 1915, 2015, 2044行。本文はREADME §§6.2–6.3, 7.1–7.3, 9.2–9.5。6.2、6.3、7.2のowned_proof_obligationsもplan.json 2942, 2948, 2954行に残る。

変更差分の機械比較では、担当範囲で変更された8 targetの変更fieldはすべて`hypotheses`だけだった。statement、API、checks、prerequisites、source_scopeは不変である。READMEの担当部分もround1から変更されていない。したがって修正の際に例外や構成責任を本文から削った形跡はない。

## 隠れた循環と大域性

1. **6.2は8型分類から同型を仮定していない。** 実際のcompactification、overlap、全chart、全補集合比較を要求し、VDPS09導入部の全profile比較を既存定理として使わないことを明記している。D₆を共有する異なるformal pole data、D₈のaffine-plane条件、省略exceptional曲線の各反例も残る。9.2の表は出力の索引であり、moduliを8個の名前で定義していない。

2. **継続定理は表面比較から独立。** 宣言された全prerequisite graphはacyclic。5.5の推移的前提に6.*, 7.*, 9.*はなく、6.2・6.3・7.2・7.3の推移的前提に9.*もない。README §§6.2–6.3もコンパクト化やscalar Painlevé propertyで§4.4を代用しないと明記している。グラフ検査は形式的依存に限定されるが、対応する本文にも逆流は認めなかった。

3. **追加反射は先行構成に偽装されていない。** 7.2は6.2の完成したmarked比較を使える一方、追加反射自体と延長・関係式は新しい出力である。対象間の自然同型・parameter写像・domainが必要なので、同じ境界図へ戻っただけでは反射平方の証明にならない。

4. **9.1のjet-isomorphism仮説は正当。** 抽象的chain-rule/逆写像補題の仮説であり、9.2が具体的な各profileについてこれを構成・検証する責任は消えていない。A_p≠0を任意領域での大域逆に置き換えない条件も保たれる。

5. **9.2から9.4への参照を検討した。** source correctionの説明位置への前方参照はある。しかし必要な修正は直接の微分と2-form恒等式であり、9.2自身もcompatible systemから再導出せよと要求する。9.4全体を使って9.2を証明する必要はない。実装時にはこの独立な代数補題を使い、9.4全体を逆輸入しない必要がある。現行文章を数学的循環とは判定しない。

## 独立した短い計算

### FN/P34とPII

U≠0上でV=U′、a²=θ₀²とし、

`U″ = V²/(2U) + 2U² − TU − a²/(2U)`, `Q=(V−a)/(2U)`

を代入すると、直接

`Q′ = U − T/2 − Q²`

を得る。さらにV=2UQ+aを使えば

`Q″ = 2Q³ + TQ + a − 1/2`。

従ってREADMEの逆 `U=Q′+Q²+T/2` とparameter α=a−1/2は整合する。U=0,a=0では除算による逆は存在しないので、保持された例外は数学的に必要である。

### Hamiltonianとsigma

PIIのHから

`q′=p−q²−t/2`, `p′=2qp+α+1/2`

を得て、消去により`q″=2q³+tq+α`。全微分でH′=−p/2、H″=2qH′−(α+1/2)/2となるため、READMEのsigma逆はH′≠0上で正しい。α=−1/2,p=0では異なるq初期値のRiccati軌道がH≡0へ潰れる。これは単なる見かけの分母ではない。

PI sigma式を微分すると `2σ″(σ‴+6σ′²+t)=0`。σ″が恒等的に0でなければ解析的延長でPIを再構成する。一方、除外枝はσ=at+2a³であり、q=−aは開time域上でPIを満たさない。READMEの非退化条件は削除できない。

source formについてはF=F(q), Q=q, P=p/F(q), K=−H(F(Q)P,Q,t)から

`dQ∧dP+dK∧dt = −(dp∧dq/F+dH∧dt)`

を直接得る。sourceのHamiltonian符号をそのまま輸入しない規則と整合する。

PII seedはα=0で(q,p)=(0,t/2)、α=1で(q,p)=(−1/t,2/t²+t/2)が両Hamilton方程式を満たす。後者のt=0除外は必要である。

### PVI反射と係数境界

κ₀↦−κ₀、κⱼ↦κⱼ+κ₀により `2κ₀+Σκⱼ` は `−2κ₀+Σκⱼ+4κ₀`となって不変。反射を2回行えば全parameterを回収する。この計算はparameter作用だけの確認であり、全phase域のregular延長を証明したものではない。

9.3のPIII係数4個について16通りの零/非零パターンを全列挙し、D₆/D₇/D₈/elementaryのどれにも入らないものがないことを確認した。これは分類表の被覆だけを検査し、scaling/inversionの幾何学的比較やquadratureの完全な証明を代替しない。

## 原典確認と限界

TER02 Theorem 2.1とConjecture 2.1について、[J-STAGE掲載の本文索引](https://www.jstage.jst.go.jp/article/math1924/28/1/28_1_137/_pdf)を今回取得した。第一境界寄与の次元1と、全局所cohomologyとの等号が別の主張であることを確認した。直接PDF取得はtimeoutだったため、新しいbyte検証とはしていない。

ST04 Proposition 2.1の[論文本文掲載](https://www.researchgate.net/publication/2101207_Nodal_curves_and_Riccati_solutions_of_Painlev'e_equations)では、外部parameter α₀を固定しtimeの局所近傍で曲線を延ばす主張を確認した。READMEのglobal conventionがθ固定であることと合わせ、7.3は全parameter方向に−2曲線がpersistするという誤った主張をしていない。arXiv PDF取得はDisabledErrorであり、この本文確認をpinされたPDFの新しい認証とはしていない。

全source-specific dictionaryを今回すべてpinされたPDFから再導出したわけではない。sources.tomlはround1とbyte同一で、既存の「certified」もロードマップの定理の証明書ではない。2つのPython環境でsymbolic libraryが利用できなかったため、記録した式の確認は上記の手計算であり、成功したsymbolic testと称していない。

**残る構成・証明責任は広く重いが、現行文面はそれを仮説に移して隠してはいない。** 特に6.2と7.2の全域比較・延長、6.3のfamily base change、9.2の実際のchart/coverageは、今後の数学的証明で個別に満たす必要がある。
