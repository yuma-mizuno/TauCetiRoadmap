# Round 2 independent mathematical re-review — Layers 8, 10, 11

## Closure

**Unresolved mathematical findings: 0. Proposed further corrections: none.**

The hypothesis cleanup preserves the actual construction/proof obligations in the assigned domain. The added §10.2 uniformity hypothesis is sufficient; its extra-moment estimate is correct; and its holomorphic Gaussian counterexample has the correct nonzero limiting constant and sign. The original moment wording was treated as a precision issue, not retrospectively counted as a false-statement finding.

This closes the assigned review of the immutable round-2 mathematical specification. It does not certify that the roadmap's future mathematical theorems have been proved.

## Exact reviewed input

Directory: `/workspace/scratch/58443e4fc6da/_math_review4/round2/artifact`.

| File | SHA-256 independently checked |
|---|---|
| `README.md` | `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658` |
| `design/plan.json` | `5d01eec8f10d5f3b8ae670920ca9fb4bdc814401d0ea8117a6e8c13c5ba79519` |
| `sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |
| `metadata.toml` | `b50aa2bc22ec2d67eaaff1124873e26fcf41a6b052574bc2989ebaa36f067a81` |

Comparison baseline: the original immutable `_math_review4/round1/artifact`.

Reviewed author ledgers: `round1/hypotheses_author_changes.json` and `round1/uniform_moment_author_clarification.json`. The final checks below were bound to the frozen round-2 bytes, not merely to the live canonical directory or the ledgers.

No canonical file was edited, no worker was executed, and no push or other remote mutation was performed. The review concerns mathematics, not Lean implementation.

## 1. Exact scope of the changes

Within the assigned domain:

- `8.1`, `8.2`, `10.3`, `11.1`, `11.2`, `11.3`, and `11.4` changed **only** their structured `hypotheses` fields.
- `10.2` changed its `statement`, `hypotheses`, and `tests` to distinguish fixed-parameter from uniform remainder claims and to add the Gaussian check.
- `8.3`, `8.4`, `10.1`, and `10.4` were unchanged.
- All pre-existing `owned_proof_obligations` entries remain exactly present. The entries for `1.4` and `10.2` were added.
- The supplier and named-gap lists are unchanged.
- The README's only change from round 1 is the §10.2 precision amendment and new check.

Consequently, there is no silent deletion of an existing construction, restriction, correction term, comparison domain, or proof path hidden behind the edited summary fields.

## 2. Proof check of the uniform remainder amendment

### 2.1 Uniform bounds and tail transfer

Write

\[
W_m(\zeta)=1+|\zeta|^m,\qquad h_s=w_s+\nu_sw_s.
\]

The common small-norm gap and boundedness of the fixed contour operator give

\[
\|\nu_s\|_2\leq\frac{\|C_-\|\,\|w_s\|_2}{1-\rho}.
\]

Thus a uniform bound on the listed weighted norms gives a finite constant

\[
N=\sup_s\|\nu_s\|_2.
\]

For every tail cutoff \(R\), Hölder's inequality gives exactly the estimate needed by the new text:

\[
\|\mathbf1_{|\zeta|>R}W_mh_s\|_1
\leq
\|\mathbf1_{|\zeta|>R}W_mw_s\|_1
+N\,\|\mathbf1_{|\zeta|>R}W_mw_s\|_2.
\]

Therefore the two added weighted-tail conditions on \(w_s\) imply uniform weighted \(L^1\)-tail tightness of \(h_s\). No tail bound on \(\nu_s\) itself is required. This validates the exact transfer asserted in the amendment.

The same estimate without the indicator gives a uniform weighted \(L^1\) bound for \(h_s\). In particular, on the separated sectors, the zeroth moment gives the claimed uniform \(I+O(1/z)\) normalization even without uniform tail tightness.

### 2.2 Exact geometric-series remainder

Let the contour adapter give, for sufficiently large \(z\) in the stated closed sector,

\[
|\zeta-z|\geq c\bigl(|\zeta|+|z|\bigr)
\]

with \(c>0\) independent of the parameter. The finite expansion is

\[
\frac1{\zeta-z}
=-\sum_{j=0}^{m}\frac{\zeta^j}{z^{j+1}}
+\frac{\zeta^{m+1}}{z^{m+1}(\zeta-z)}.
\]

Thus the remainder after the terms through \(z^{-m-1}\) is

\[
\mathcal E_{m,s}(z)
=\frac1{2\pi i\,z^{m+1}}
  \int_\Gamma\frac{\zeta^{m+1}h_s(\zeta)}{\zeta-z}\,d\zeta.
\]

After multiplication by \(|z|^{m+1}\), its norm is controlled by the integral of

\[
|\zeta|^m\|h_s(\zeta)\|
\frac{|\zeta|}{|\zeta-z|}.
\]

For fixed \(s\), the last factor tends to zero pointwise and is bounded by \(c^{-1}\), so the original fixed-parameter little-o follows from weighted integrability.

For a uniform statement, split at a fixed \(R\). The contribution of \(|\zeta|\leq R\) is bounded by a constant times \(R/|z|\) times the uniform weighted norm. The remaining contribution is bounded by a constant times the uniform weighted tail. Choosing \(R\) first and then \(|z|\) proves

\[
\sup_s |z|^{m+1}\|\mathcal E_{m,s}(z)\|\longrightarrow0.
\]

This is precisely the amendment's claimed uniform conclusion.

### 2.3 Both stated alternatives are sufficient

**Compact parameter set.** Norm-continuous dependence into weighted \(L^1\cap L^2\) has a compact image. A finite norm-net of that image, followed by tail control for its finitely many members, gives the required uniform tails. The earlier common small-norm gap remains an input. No unjustified dominated-convergence step over a noncompact parameter set is used.

**One additional weighted moment.** Interpreting this as uniform bounds for \(W_{m+1}w_s\) in \(L^1\cap L^2\), the same Hölder estimate gives a uniform bound for \(\int |\zeta|^{m+1}\|h_s\|\). Using \(|\zeta-z|\geq c|z|\) directly in the exact remainder yields

\[
\sup_s\|\mathcal E_{m,s}(z)\|
\leq C |z|^{-m-2}.
\]

The new uniform big-O order is therefore correct.

These controls apply on the separated sectors where the contour denominator estimate holds. The amended text retains the separate need for estimates on the rays and for the actual endpoint/sectorial application. It does not use the tail argument to discard boundary-ray behavior.

## 3. Exact check of the Gaussian example

Let \(E=E_{12}\), \(a>0\), and

\[
w_s(x)=a e^{-(x-s)^2}E,
\qquad \operatorname{Re}s>1,\quad|\operatorname{Im}s|<\delta.
\]

For \(s=u+iv\),

\[
|e^{-(x-s)^2}|=e^{v^2}e^{-(x-u)^2}.
\]

Hence, with the usual matrix norm \(\|E\|=1\),

\[
\|w_s\|_1=a e^{v^2}\sqrt\pi,\qquad
\|w_s\|_2=a e^{v^2}(\pi/2)^{1/4},\qquad
\|w_s\|_\infty=a e^{v^2}.
\]

The norms are uniformly bounded on the strip. Differentiation with respect to \(s\) multiplies the Gaussian by a polynomial, so it gives a holomorphic family in each of these Banach spaces. On the oriented real line, \(C_-\) is a signed orthogonal Fourier projection and has norm one. Thus \(a e^{\delta^2}<1\) supplies a common norm gap.

Since \(E^2=0\), \(\det(I+w_s)=1\), and \(\nu_s=C_-w_s\) satisfies the small-norm equation with \(\nu_sw_s=0\). Therefore the exact density is \(h_s=w_s\), as claimed.

The Gaussian integral, including its complex translate, gives

\[
M_0=\int_{\mathbb R}w_s(x)\,dx=a\sqrt\pi E.
\]

At real \(s=n\), substitute \(x=n+u\):

\[
nC(w_n)(in)
=\frac a{2\pi i}\int_{\mathbb R}
\frac{e^{-u^2}}{1-i+u/n}\,du\,E
\longrightarrow
\frac{a\sqrt\pi}{2\pi i(1-i)}E.
\]

The reciprocal denominator has modulus at most one, so this limit is justified by ordinary dominated convergence. Adding the asserted coefficient correction gives

\[
\begin{aligned}
\lim_{n\to\infty}n\left(C(w_n)(in)+\frac{M_0}{2\pi i\,in}\right)
&=\frac{a\sqrt\pi}{2\pi i}
  \left(\frac1{1-i}+\frac1i\right)E\\
&=\frac{a\sqrt\pi}{2\pi i}\frac{1-i}{2}E\ne0.
\end{aligned}
\]

This is the exact constant and sign printed in the amendment. The points \(z=in\) stay in a direction separated from the contour. The counterexample therefore demonstrates failure of parameter-uniform little-o within the stated off-ray region, rather than exploiting a boundary-ray exception. Its translated mass violates the newly added uniform tail condition.

## 4. Proof-obligation retention after hypothesis cleanup

| Target | Legitimate input after cleanup | Construction/proof obligation retained |
|---|---|---|
| 8.1 | Holomorphic complex Fredholm family of index zero; determinant convention | Stabilizations, refinement/cocycle comparisons, line/section, finite-dimensional normalization, base change, bundle-valued extension. The named supplier gap is unchanged. |
| 8.2 | Decorated family, analytic reconstruction, and selected RHP marking/reference data | Fredholm realization and index-zero normalization; odd-degree modification issue; resonant/ramified adapters; proved comparison equivalences; stabilizer test for coarse descent. |
| 10.2 | Inputs of the general small-norm lemma, with specified Cauchy class | The geometric application still must construct the contour/Plemelj/reconstruction adapter, prove endpoint and determinant removability, and now prove the stated uniform remainder control when needed. |
| 10.3 | Precisely restricted monodromy loci, branches/normalizations, supplied HM object/Fredholm identity, earlier analytic interfaces | Endpoint formulas; Barnes-function domains; continuation through auxiliary-coordinate exclusions; DIK/HXZ estimates; uniform HM sectorial Hamiltonian bounds and arc calibration. |
| 11.1 | Specified geometric collision datum, actual endpoint conditions, and separated boundary data | Invariant groupoid/domain construction, Poisson sign/reduction comparison, corrected Laurent lemma, common phase charts, endpoint adapters, and horizontal-field limit. |
| 11.2 | Existing reference trajectory, positive-margin common charts, uniform fields/Lipschitz bound, matched initial data | Existence of approximating trajectories on the whole path, no-exit argument, finite-chart continuation, and uniform convergence. The reference trajectory is a legitimate comparison input, not the output trajectory. |
| 11.3 | Verified earlier geometric arrows and the actual hypotheses of the compact-path theorem | Scaled scalar equations, parameter/time/jet comparisons, omitted-chart coverage, and composition with additional uniformity for exchanged limits. |
| 11.4 | Admitted collision family with determinant/RHP realizations and a regular normalization point | Line/frame/Hilbert-space comparisons are constructed before applying the scalar convergence lemma. Corrected-form or trace-norm convergence remains a genuine analytic hypothesis; zero-count and endpoint results keep their additional conditions. |

The seven hypothesis-only changes leave their full statement/API/tests/Needs unchanged. In particular, the edits have not turned “construct index zero,” “construct common charts,” or “compare determinant lines” into optional follow-up work, nor have they strengthened the convergence conclusions by deleting the actual analytic hypotheses.

## 5. Retained conclusions from the full original review

The unchanged parts of the assigned domain retain the mathematical safeguards checked in round 1:

- The determinant line exists independently of generic nonvanishing. Its Cartier divisor requires nonidentity-to-zero; arbitrary reference modifications are not declared unit-equivalent.
- JMU/Hamiltonian comparisons retain their generic unramified, simple-leading-spectrum, logarithmically nonresonant scope. The BERT16 vertex correction is retained. Broader determinant/Fredholm statements do not imply an unspecified ramified JMU identity.
- The small-norm uniqueness class still excludes endpoint homogeneous terms. The determinant-one and meromorphic-connection recovery arguments remain separate proof obligations.
- The ILP18 connection formulas keep their precise PVI/homogeneous-PII parameter and branch restrictions. HM calibration still requires complex-sector and boundary-ray information beyond real pole-freeness.
- Geometric confluence still distinguishes formal coefficient limits, verified common-chart field limits, matched initial data, compact-path convergence, tau normalization, and endpoint constants.

Primary-source verification performed in the original independent review remains applicable because these source-dependent claims did not change:

- [MAL04, §2 and Theorem 5.12](https://www.numdam.org/item/10.5802/aif.2052.pdf).
- [BERT10, Assumption 3.1](https://arxiv.org/pdf/0902.4716v2), [BERT16, Theorems 2.1–2.2](https://arxiv.org/pdf/1601.04790v2), and [BERT17](https://sigma-journal.com/2017/046/sigma17-046.pdf).
- [ILP18, Theorems A/B and (4.74)–(4.76)](https://arxiv.org/pdf/1604.03082v4), [HXZ16, Theorem 2.1](https://arxiv.org/pdf/1410.3338), and [DIK08](https://arxiv.org/pdf/math/0609451).
- [GMR23, Theorem 2, Theorem 12, and §5.1](https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf).

The fresh calculations in §§2–3 of this report, rather than an appeal to a source's generality, establish the correctness of the new precision amendment.

## Limits and final classification

This review does not provide the missing proofs of all resonant/ramified Fredholm adapters, all-strata Riemann–Hilbert properness, the general holomorphic determinant supplier, or every intrinsic collision comparison. Those remain expressly owned mathematical work. No such future obligation was removed by the reviewed edits.

**Final classification for the assigned frozen input: no unresolved finding; no further mathematical edit requested.**
