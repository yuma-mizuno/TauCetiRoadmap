# Round 3 独立数学レビュー — core 5.3 closure

## 判定

**Clear。未解決 finding は 0 件。** Round 2 の残存 P2 `MR4-INPUT-OUTPUT-5.3` は、Round 3 の凍結版で閉鎖されたと判定する。完全な平坦接続から実際の非線形 monodromy action を構成する義務が、呼出側の仮定へ移されていた問題は解消している。構成、ホモトピー不変性、被覆上の切断、descent の義務を弱める変更もない。

この判定の対象は、5.3 の変更差分、その前後の transport/action/section/descent 契約、および Layers 1–5 の hypotheses に残る同型の入出力混同である。ロードマップ全体の定理が既に証明されたという判定ではない。Round 2 で確認済みの変更されていない数学を全面的に再検証することはしていない。

## 対象と差分固定

読んだ資料は、凍結された Round 2 / Round 3 の `artifact/README.md`、`artifact/design/plan.json`、`artifact/sources.toml`、`artifact/metadata.toml`、Round 3 の `snapshot.json`、および `round2/author_resolution_5_3.json`。Lean 実装・worker 実行・push は対象外であり、canonical ファイルは編集していない。

全 artifact の SHA-256 は Round 3 snapshot と一致した。README、sources、metadata は Round 2 と byte-for-byte 同一。plan の構造差分は次の二つだけである。

| JSON path | 変更 | 内容 |
|---|---|---|
| `$.layers[4].targets[2].hypotheses[0]` | 置換 | 5.3 の実際の monodromy action を入力から除き、構成する出力として明記 |
| `$.owned_proof_obligations[11]` | 追加 | 5.3 の transport/action 構成と section/descent 適用の所有義務 |

author resolution ledger の before / after は、それぞれ凍結版の hypotheses と完全一致する。既存の 11 個の owned proof obligation は順序・内容とも変わらず、5.3 が 12 個目として追加された。5.3 を含む全 target の statement、API、checks、prerequisites その他の field は、この hypotheses 以外すべて不変である。

## 5.3 の入出力を意味で検査した結果

### 本当の入力

修正後は、3.2–3.3 と 5.1–5.2 で構成・証明する完全な平坦接続、pointed universal cover を備えた連結な admitted time component、初期点を入力にしている。

3.2 が平坦性、3.3 が実際の接続による fiber symplectic form の保存、5.1 が局所水平切断の存在・一意性および局所解析性、5.2 が各 compact piecewise C¹ path に沿う大域的な一意的水平 lift を所有する。これらはすべて 5.3 の先行 target であり、5.3 の結論を受け取らない。pointed universal cover と初期点は構成のデータであって、monodromy が既に構成されていることや初期点がその固定点であることを要求していない。

### 出力が残っていること

修正後の hypotheses は、endpoint transport、homotopy invariance、actual fundamental-groupoid/monodromy action、universal-cover sections、descent criterion を「ここで構成・証明する」と明示する。追加された owned obligation も、実際の完全な平坦接続から作用を構成し、その後に切断とdescentを扱う順序を明示している。

これは単なる否定文の追加だけではない。変更されていない statement と API は、以下の数学的順序を引き続き所有している。

1. 5.2 の一意的 path lift の終点を用いて endpoint map を定義する。局所一意性から恒等路、逆路、連結に関する法則を証明する。
2. 3.2 の平坦性と 5.1 の局所水平積構造を用い、端点を固定したホモトピーに対する不変性を証明する。これによって実際の fundamental groupoid action、したがって基点 fiber 上の monodromy action を構成する。
3. 基点からの path class で表した被覆点に、その path に沿う初期点の輸送を対応させる。前段のホモトピー不変性で well-definedness、局所理論で水平性・解析性を得て、被覆へ引き戻した phase family の大域水平切断を構成する。
4. deck equivariance を比較し、その切断が元の time base に降りることと、初期点が全 loop monodromy に固定されることの同値を証明する。固定点条件は descent の判定結果であり、被覆上の切断を構成する入力ではない。
5. 3.3 の既に構成された symplectic preservation を用い、実際の action が fiber symplectic forms を保存することを証明する。

この記述は契約の依存関係を検査するための説明であり、上の各証明義務をこのレビューが実装・完了したという意味ではない。参照箇所は plan の target 3.2、3.3、5.1、5.2、5.3、および README の同名節である。

### generic interface と実際の action の区別

README の UniversalCovers 供給契約は、covering carrier と lifting/fundamental-group interface を供給し、水平切断の descent を 5.3 の適用としている。これは当該非線形接続の実際の action を供給したことにはならない。今回の修正はこの区別を明示し、5.3 の prerequisites に循環的な action supplier を追加していない。

また 4.2 の complete transport は Betti 側の対象であり、5.2 の proper semiconjugacy に対する正当な先行入力である。それが source phase family 上の endpoint transport/action を無証明で供給する、と読み替える変更はない。

### 出力・適用範囲の弱体化がないこと

5.3 の statement、API、checks は完全に保持されている。例外的な初期点を含む逆路則、非自明な monodromy の例、被覆上で完全でも元の base へは降りない例が残っている。初期点を monodromy の固定点に限定する仮定は追加されていない。作用の symplecticity、pullback/input-isomorphism との比較、切断の一意性も落ちていない。

README の例で、B = ℂ×、H = qp/(2t) から得る輸送は、一周で (q,p) を (−q,−p) に移し、二周で恒等となる。初期値を固定するのは原点だけという区別は保持されている。これは action を自明と仮定する修正や、descent を完全性に置き換える修正がなされていないことを確かめる、本文内の具体的なチェックである。

## Layers 1–5 の同型残存確認

21 target の hypotheses をそれぞれの statement と prerequisites に照合した。新たな同一 target の出力の仮定化は検出しなかった。判定は単語の有無ではなく、その対象が定義域の条件なのか、先行 target の出力なのか、当該 target の結論なのかを区別して行った。

| 対象 | 入出力を区別して確認した点 |
|---|---|
| 1.1–1.4 | curve/local data と admitted domain は入力。groupoid/naturality、time comparison、10/17 分類、stabilizer 計算、一次元 reduced time は出力。1.3 の非空性は入力 class の定義域条件である。 |
| 2.1–2.4 | moduli 構成、deformation complex、smoothness、auxiliary unfolding、pairing の非退化・閉性はそれぞれの所有出力。2.4 の allowed strata は固定 local conditions が許す対象の範囲を示し、その存在・保存を同項自身の入力として供給するものとは読まない。 |
| 3.1–3.4 | 3.1 の pole/kernel/integrability 条件は求める extension のクラスであり存在仮定ではない。3.2 の平坦性は出力。3.3 の symplectic form と flat splitting は 2.3、3.1–3.2 の出力。3.4 の presentation isomorphism は比較するデータ。 |
| 4.1–4.4 | 4.1 の有限 ramification とその deck action は local input presentation であり、5.3 の非線形 monodromy とは異なる。4.2 の ramified isotopy/descent/complete transport、4.3 の全 source での compatibility、4.4 の lattice bounds/replacement/properness は所有出力のまま。 |
| 5.1–5.2 | local germ の存在・一意性は 5.1 の出力。5.2 の target transport と proper map は一般転送定理の入力であり、具体的適用では 4.2–4.4 から得る。ODE/chart-extension adapter は自ら証明する。 |
| 5.3 | 上述の修正により actual action を構成する義務と、その action による descent 判定が順序づけられた。 |
| 5.4–5.5 | observer の非不定性・not-identically-infinity は scalar meromorphic object を呼ぶための admissibility。5.5 の大域水平切断は 5.3 の先行出力。各 observer の claimed stratum で admissibility を証明する義務は 5.5 に保持されている。 |

依存辺は Round 2 とすべて同一である。補助的に現凍結版の graph を再計算して 44 target、216 本の内部辺、循環 0 を確認した。構造上の DAG だけを、上記の意味上の区別の代用にはしていない。

## 限界と引継ぎ

修正されたのは数学的な構成契約である。5.3 の transport/action と section/descent は今後証明する所有義務として明示された。4.4 の全族 properness、uniform lattice bounds、stable replacement などの大きな内部証明課題も変更されず残る。これらを未証明の入力へ隠す残存は今回の範囲で検出しなかったが、このレビューはそれらの証明そのものを供給していない。

今回、新しい外部一次資料調査は行っていない。変更が内部契約の二箇所に限定され、必要な比較対象の本文は提供 artifact 内にあるため、Round 2 の数学・資料調査を全面的にやり直すことはしていない。未変更の全命題の真偽や各 supplier の実装状況に、新たな包括的保証を与えない。

**引継ぎ結果：`MR4-INPUT-OUTPUT-5.3` は closed。今回の scope で unresolved finding はなし。**

## 凍結版 SHA-256

| ファイル | SHA-256 |
|---|---|
| `artifact/README.md` | `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658` |
| `artifact/design/plan.json` | `9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4` |
| `artifact/sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |
| `artifact/metadata.toml` | `b50aa2bc22ec2d67eaaff1124873e26fcf41a6b052574bc2989ebaa36f067a81` |
| `snapshot.json` | `e769743c9c40d30cc7f9288d052323de26bcb5a8c798fe0748f40882f6b63a74` |
| `round2/author_resolution_5_3.json` | `479062d081c8f1c0293e32fb98a871b1287bd821d91e2cbea68d4191834e21ff` |
