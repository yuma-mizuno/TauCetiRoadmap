# MR4 round3：geometry担当の限定差分・scope確認

## 結論

**round2で得たLayers 6・7・9の判定を、下記round3の固定bytesへ引き継げる。今回の限定レビューの未解決findingは0件。**

5.3の修正は、実際の非線形モノドロミー作用を入力として要求していた不整合を解消している。完全平坦接続から輸送・作用を構成し、その後に普遍被覆上のsectionとdescentへ適用する順序が明示された。後続のLayer 9が消費する結論や適用域は変更されていない。

この記録は限定差分の独立評価と、変更されていない前回レビューの適用継続である。原典確認や座標計算を繰り返した完全な別レビューとは数えない。

## 固定した最終候補

| File | SHA-256 |
|---|---|
| `README.md` | `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658` |
| `design/plan.json` | `9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4` |
| `sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |

対象は `_math_review4/round3/artifact`。すべてround3/snapshot.jsonと一致する。

## 正確な差分

構造比較により、round2→round3のplan.jsonの差分は次の2か所だけである。

1. **5.3のhypotheses[0]を変更**（plan.json 1033行）。従前の「actual monodromy action」を仮説から外し、3.2–3.3・5.1–5.2で先行して構成された完全平坦接続、pointed universal coverを備えた連結time component、および初期点を入力としている。endpoint transport、homotopy invariance、実際のfundamental-groupoid/monodromy action、universal-cover sectionとdescent criterionはここで構成・証明することを明記した。
2. **5.3のowned_proof_obligationを1項目追加**（plan.json 2984行）。既存11項目はすべて保持し、輸送・作用の構成を先に、section/descentへの適用を後に置いている。

この2差分をround2のplanへ適用するとround3のplan全体と一致する。README.mdとsources.tomlはbyte同一である。

## Layers 6・7・9への影響

6.1–6.3、7.1–7.3、9.1–9.5の**全target recordが同一**である。hypothesesだけでなくstatement・API・tests・prerequisites・Needs・source scopeまで変更されていない。全targetのprerequisitesも同一で、宣言された依存グラフは引き続きacyclicである。

ここで「先行結果も一切変更されていない」とは述べない。**5.3は9.1–9.5の推移的前提**であり、その仮説は今回変更されている。しかし、担当targetの前提のうち他のrecordはすべて同一で、5.3自身のstatement・API・tests・prerequisites・Needs・source scopeも不変である。変更は出力を先取りした仮説を除き、その出力の構成責任を明確化するものなので、Layer 9の既存の利用を弱めない。

したがって前回確認した、6.2の全補集合・全chart比較、6.3のfamily base change、7.2の追加反射と実際のregular延長、7.3のlocal/base-change域、9.2の具体的chart・jet逆・coverage、9.4–9.5の例外域に関する判定を維持する。同じ8境界型を根拠に大域同型を仮定する変更もない。

## 5.3の数学的順序

README §§5.2–5.3と修正後hypothesesを合わせると、証明する順序は明確である。

- 5.1の局所存在・一意性と5.2の完全なcompact-path liftから、各初期点の唯一の水平liftの終点をendpoint transportとして定義する。
- 一意性によりidentity・reversal・concatenationを証明し、3.2のflatnessからendpointを固定したhomotopyに対する不変性を証明する。これにより初めてfundamental groupoidとmonodromyの作用を得る。
- pointed universal cover上で、初期点からの経路類を使って水平sectionを構成する。元のtime baseへのdescentは、その初期点が構成されたmonodromy作用で固定される条件と同値であることを証明する。
- 3.3の水平輸送による形式の保存を用いて、その作用がfiber symplectic formsを保存することを示す。

作用を既知の入力として要求する段階はない。5.2のproper比較mapの逆を選んで作用を定義する飛躍もなく、exceptional fiberの点は一意な水平liftを使って扱う。5.2の「全ての許容parameter・初期点・compact piecewise C¹ path」という量化は不変である。

README 471–473行付近の非自明monodromy例とdescentの反例も保持されており、完全性だけから元のbase上の単一値sectionを結論する誤りは導入されていない。一般のtransportやcoveringのinterfaceを使うことと、この実際の非線形phase-space上の作用を構成することは、新しいowned obligationにより区別されている。

## 前回記録との結び付け

- `_math_review4/round2/geometry_report.md` — SHA-256 `a76c36b4719ba5deca68dbc4a0536304c049b5c04ed3048f7bce64f70e487205`
- `_math_review4/round2/geometry_findings.json` — SHA-256 `d8ba0f977381ce0afcc274914220f6195dd66ca12272830bc4b1985d63716f96`
- `_math_review4/round2/geometry_audit_evidence.json` — SHA-256 `8d60def3ca4f08cfaaaa754efcb7d90f5ce8e3257daa4ee2e10509e9fce7d460`

前回の数式確認・原典scope確認とその限界は、この記録により取り消さない。今回は指定された差分だけを再検討した。新しい原典取得や座標計算の成功は主張しない。

**closureはロードマップの入力・出力と責任分担についてであり、数学的構成が完成したことの証明ではない。** 5.3の実際の輸送・作用、6.2の全profile比較、7.2の追加反射と延長、6.3のbase change、9.2のchart/coverageは、引き続き担当targetの本来の構成・証明課題である。canonical編集、Lean、Worker、pushは行っていない。
