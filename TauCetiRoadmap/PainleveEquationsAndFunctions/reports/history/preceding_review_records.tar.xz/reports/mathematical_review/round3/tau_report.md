# Round 3 final delta closure — determinant/tau, RHP and confluence

## Verdict

**Unresolved mathematical findings: 0. New findings from the round-2 → round-3 delta: 0. Further corrections proposed: none.**

The independent mathematical verdict recorded in the round-1 and round-2 tau reviews carries to the exact round-3 bytes identified below. The final change removes the actual monodromy action from the input list of §5.3 and explicitly retains its construction as an owned proof obligation. The statement, dependencies, APIs and checks of that target remain intact. Every reviewed target and qualification in Layers 8, 10 and 11 is unchanged from round 2.

This is a narrow final delta review. The substantive primary-source and mathematical checks were performed in the preceding independent reviews; they were not needlessly repeated. The verdict concerns consistency and proof obligations of a mathematical roadmap, not a claim that its planned theorems have already been established.

## 1. Immutable input and byte binding

Final input directory: `/workspace/scratch/58443e4fc6da/_math_review4/round3/artifact`.

| File | Independently checked SHA-256 | Relation to round 2 |
|---|---|---|
| `README.md` | `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658` | Byte-identical |
| `design/plan.json` | `9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4` | Exactly the two structured differences below |
| `sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` | Byte-identical |
| `metadata.toml` | `b50aa2bc22ec2d67eaaff1124873e26fcf41a6b052574bc2989ebaa36f067a81` | Byte-identical |

The baseline was the frozen round-2 artifact, whose plan hash is `5d01eec8f10d5f3b8ae670920ca9fb4bdc814401d0ea8117a6e8c13c5ba79519`. A complete recursive comparison of the parsed plans found precisely the following two changes, with no other added, removed or modified value.

## 2. Complete mathematical delta

### 2.1 §5.3 hypothesis replacement

JSON pointer: `/layers/4/targets/2/hypotheses/0`.

Old:

> Constructed complete flat connection; pointed universal cover of the connected time component; actual monodromy action.

New:

> The complete flat connection constructed in 3.2–3.3 and 5.1–5.2, a connected admitted time component with a pointed universal cover, and an initial point. Endpoint transport, homotopy invariance, the actual fundamental-groupoid/monodromy action, universal-cover sections and their descent criterion are constructed and proved here; no such action is supplied as an input.

### 2.2 Explicit owned obligation added

JSON pointer: `/owned_proof_obligations/11`.

```json
{
  "target": "5.3",
  "owner": "PainleveEquationsAndFunctions",
  "obligation": "Construct endpoint transport and its homotopy-invariant fundamental-groupoid/monodromy action from the actual complete flat connection, then construct universal-cover sections and prove the descent criterion. The nonlinear action is not an assumed supplier output.",
  "status": "owned transport/action construction followed by its section/descent application"
}
```

All eleven existing entries of `owned_proof_obligations` were preserved exactly and in their original order. The new entry was appended.

## 3. Why the §5.3 correction preserves the mathematical work

The revised premises identify the already constructed complete flat connection, its admitted connected base and pointed universal cover, and the initial point. They no longer import the very action that §5.3 is required to construct. The unchanged statement still requires endpoint transport, the identity/reversal/concatenation laws, homotopy invariance relative endpoints, the fundamental-groupoid action, the unique universal-cover horizontal section through each initial point, the exact fixed-point criterion for descent, and preservation of the fiber symplectic forms.

The construction order remains mathematically coherent: complete horizontal lifting provides the endpoint maps; local uniqueness gives their inverse and concatenation laws; flatness and the local uniqueness argument supply homotopy invariance; the resulting transport action produces the universal-cover section and its deck-equivariance/descent criterion. Preservation of the fiber symplectic forms remains a conclusion to be obtained using the earlier symplectic-connection results. The added obligation reinforces the earlier statement rather than weakening it to an application of an assumed action.

No prerequisite, API or check was deleted. In particular, the existing Hamiltonian example on the punctured time plane remains: `H=qp/(2t)` gives monodromy `(q,p) ↦ (−q,−p)`, two loops give the identity, and only the origin is fixed by the one-loop action. Its role still distinguishes existence on the universal cover from descent to the base. The corrected summary does not turn completeness into a claim of single-valued descent.

This also preserves the continuation infrastructure used by the reviewed RHP/analytic bridge targets. No new hypothesis that would restrict an already reviewed comparison, and no new assertion that would enlarge it, was introduced.

## 4. Assigned domain unchanged

The exhaustive comparison, rather than a selected keyword scan, confirms that every target object in Layers 8, 10 and 11 is identical to its round-2 counterpart. Their dependencies and the relevant global supplier/gap declarations are likewise unchanged. The README containing their full mathematical qualifications is byte-identical.

Consequently the following conclusions of the independent prior review remain applicable:

- **Layer 8:** determinant lines, their sections and local scalar representatives remain distinct; index zero is not identified with solvability; the normalized modification/reference construction, actual transition comparisons, stabilizer/descent qualifications and nonidentically-zero divisor restrictions remain owned and scoped. The corrected Malgrange/JMU comparison is still restricted to its stated domains, with vertex-curvature correction accounted for.
- **Layer 10:** prescribed RHP solution spaces, the small-norm operator hypotheses and geometric reconstruction obligations remain explicit. The §10.2 amendment still distinguishes fixed-parameter little-o from uniform little-o, imposes weighted-tail control for the latter, and keeps the compact-parameter and extra-moment sufficient alternatives. The exact holomorphic Gaussian example and its nonzero limit remain the already verified round-2 text. Hastings–McLeod identification, sectorial Hamiltonian bounds and the generic connection-formula/continuation domains have not been enlarged.
- **Layer 11:** the corrected Laurent scaling, geometric lift and ramified/slope qualifications, compact-path ODE convergence, determinant-line/frame comparisons, normalized tau convergence and the extra endpoint estimates remain explicit obligations. No unconditional confluence or uniform endpoint theorem was introduced.

The detailed proofs of the weighted-tail transfer and uniform Cauchy remainder, the exact Gaussian limit, and the comparison of prior hypothesis cleanups are recorded in `../round2/tau_report.md`. The independent source and counterexample audit is recorded in `../round1/tau_report.md`.

## 5. Evidence provenance and limits

The source audit carried into this closure includes the primary publications below; no new source claim was needed to approve the narrow delta.

| Reviewed subject | Primary source previously inspected |
|---|---|
| Malgrange determinant construction and its scope | [Malgrange 2004](https://www.numdam.org/item/10.5802/aif.2052.pdf) |
| Variational hypotheses and vertex correction | [Bertola 2010](https://arxiv.org/pdf/0902.4716v2), [Bertola corrigendum](https://arxiv.org/pdf/1601.04790v2) |
| Fredholm determinant/RHP restrictions | [Bertola 2017](https://sigma-journal.com/2017/046/sigma17-046.pdf) |
| Generic connection formulas and HM calibration | [Its–Lisovyy–Prokhorov](https://arxiv.org/pdf/1604.03082v4) |
| HM pole-free sectors | [Huang–Xu–Zhang](https://arxiv.org/pdf/1410.3338) |
| Airy determinant constant | [Deift–Its–Krasovsky](https://arxiv.org/pdf/math/0609451) |
| Intrinsic confluence and required correction of Laurent scaling | [Gaiur–Mazzocco–Rubtsov](https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf) |

This delta closure does not replace the separate core/geometry reviewers' assessments of their domains. It checks that the sole relevant dependency correction preserves the construction required by the domains assigned here, and that their previously reviewed mathematical content is unchanged. Large future constructions continue to be future constructions; their size alone is not classified as a false statement or circular proof.

No canonical file was edited, no worker was executed, and no push was performed. `tau_findings.json` is the empty array because no unresolved mathematical defect was established in this assigned review.
