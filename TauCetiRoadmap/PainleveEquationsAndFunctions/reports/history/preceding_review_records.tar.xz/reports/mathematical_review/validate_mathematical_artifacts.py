"""Check mathematical-artifact consistency; this does not prove the mathematics."""
from pathlib import Path
import hashlib, json, re, sys, tomllib

pkg=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[2]
output=Path(sys.argv[2]) if len(sys.argv)>2 else pkg/'reports/mathematical_review/validation.json'
readme=(pkg/'README.md').read_text()
plan=json.loads((pkg/'design/plan.json').read_text())
manifest=tomllib.loads((pkg/'sources.toml').read_text())
targets={t['id']:t for layer in plan['layers'] for t in layer['targets']}
sources={s['id'] for s in manifest['source']}
checks=[]
def check(name,ok,detail=None):
    checks.append({'name':name,'passed':bool(ok),**({'detail':detail} if detail is not None else {})})
def norm(text):return ' '.join(text.split())
check('canonical_and_design_README_identical',readme==(pkg/'design/README.md').read_text())
sections={}
for match in re.finditer(r'^### (\d+\.\d+) ([^\n]+)\n(.*?)(?=^### |^## |\Z)',readme,re.M|re.S):
    tid,title,body=match.groups()
    prose=[];api=[];tests=[];mode=None;needs=None
    for line in body.splitlines():
        if line=='**API.**':mode='api';continue
        if line=='**Checks.**':mode='tests';continue
        if line.startswith('*Needs:* '):needs=line[len('*Needs:* '):];continue
        if line.startswith('- ') and mode in ('api','tests'):
            (api if mode=='api' else tests).append(line[2:]);continue
        prose.append(line)
    sections[tid]={'title':title,'statement':norm('\n'.join(prose)),'api':api,'tests':tests,'needs':needs}
check('44_targets_in_11_layers',len(targets)==44 and len(plan['layers'])==11)
check('README_plan_target_ids',list(sections)==list(targets))
for tid,t in targets.items():
    s=sections[tid]
    check(tid+':title',t['title']==s['title'])
    check(tid+':statement',norm(t['statement'])==s['statement'])
    check(tid+':api',[norm(x['statement']) for x in t['api']]==[norm(x) for x in s['api']])
    check(tid+':tests',[norm(x['statement']) for x in t['tests']]==[norm(x) for x in s['tests']])
    check(tid+':needs',norm(t.get('readme_needs',''))==norm(s['needs'] or ''))
    check(tid+':source',t['locator']['source'] in sources)
edges={tid:[p[7:] for p in t['prerequisites'] if p.startswith('target:')] for tid,t in targets.items()}
check('all_internal_dependencies_exist',all(x in targets for es in edges.values() for x in es))
visiting=set();seen=set();cycles=[]
def visit(tid):
    if tid in visiting:cycles.append(tid);return
    if tid in seen:return
    visiting.add(tid)
    for dep in edges[tid]:
        if dep in targets:visit(dep)
    visiting.remove(tid);seen.add(tid)
for tid in targets:visit(tid)
check('acyclic_dependency_graph',not cycles,cycles)
def ancestors(tid):
    result=set();todo=list(edges[tid])
    while todo:
        dep=todo.pop()
        if dep in result:continue
        result.add(dep);todo.extend(edges.get(dep,[]))
    return result
back={tid:sorted(x for x in ancestors(tid) if x.startswith('9.')) for tid in targets if int(tid.split('.')[0])<9}
back={tid:xs for tid,xs in back.items() if xs}
check('Layers_1_to_8_do_not_use_Layer_9',not back,back)
counts={'layers':len(plan['layers']),'targets':len(targets),'api_laws':sum(len(t['api']) for t in targets.values()),'diagnostic_checks':sum(len(t['tests']) for t in targets.values()),'internal_edges':sum(map(len,edges.values())),'sources':len(sources)}
hashes={rel:hashlib.sha256((pkg/rel).read_bytes()).hexdigest() for rel in ['README.md','design/README.md','design/plan.json','sources.toml','metadata.toml']}
result={'scope':'Mathematical-artifact text and dependency consistency only; no theorem-proof claim and no Lean audit. Source PDFs were not all rehashed in this resumed review.','counts':counts,'files':hashes,'checks':checks,'failures':[x['name'] for x in checks if not x['passed']]}
output.parent.mkdir(parents=True,exist_ok=True)
output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'checks':len(checks),'failures':result['failures']},ensure_ascii=False,indent=2))
sys.exit(bool(result['failures']))
