"""Verify frozen mathematical review bytes and their canonical-file binding."""
from pathlib import Path
import hashlib,json,sys

base=Path(__file__).resolve().parent
pkg=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else base.parents[1]
failures=[];snapshots={}
for directory in sorted(p for p in base.glob('round[0-9]*') if p.is_dir()):
    manifest=json.loads((directory/'snapshot.json').read_text())
    snapshots[directory.name]=manifest['files']
    for rel,expected in manifest['files'].items():
        path=directory/'artifact'/rel
        actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual!=expected:failures.append(str(path))
final_path=base/'final_review.json'
if not final_path.is_file():
    failures.append('missing final_review.json')
else:
    final=json.loads(final_path.read_text())
    last=snapshots.get(final['final_round'],{})
    for rel,expected in final['canonical_files'].items():
        path=pkg/rel
        actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual!=expected:failures.append('canonical/'+rel)
        frozen_rel='README.md' if rel=='design/README.md' else rel
        if last.get(frozen_rel)!=expected:failures.append('final-round-binding/'+rel)
    for name in ['core','geometry','tau']:
        path=base/final['final_round']/(name+'_findings.json')
        record=json.loads(path.read_text()) if path.is_file() else None
        findings=record if isinstance(record,list) else (record.get('unresolved_findings') if isinstance(record,dict) else None)
        if findings!=[]:
            failures.append('unclosed-final-findings/'+name)
print(json.dumps({'scope':'Frozen bytes, final canonical binding and recorded findings only; not theorem verification or Lean audit.','snapshot_files':{k:len(v) for k,v in snapshots.items()},'failures':failures},indent=2))
sys.exit(bool(failures))
