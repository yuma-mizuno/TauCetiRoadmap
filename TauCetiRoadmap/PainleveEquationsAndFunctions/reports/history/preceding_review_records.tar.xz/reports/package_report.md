# Current package: reusable intrinsic mathematics

This unpublished mathematical draft contains 77 targets, 214 API laws and 257 diagnostics across six plans: the original 44-target Painlevé application, four independent general frameworks with 29 targets, and the four-target FiveLogarithmicPoints consumer. All old target IDs and original 129 diagnostics are retained. General proof ownership and concrete application obligations are separated.

## Entry points

| Path | Role |
|---|---|
| `REUSABILITY.md`, `REUSABILITY.ja.md` | Design, theorem boundaries, independent consumer and proposed ownership |
| `README.md`, `README.ja.md` | Updated classical application; design mirrors are byte-identical |
| `frameworks/*/README.md`, `README.ja.md`, `plan.json` | Actual independently reviewable mathematical contracts |
| `applications/FiveLogarithmicPoints/` | Explicit two-time/four-phase second consumer |
| `design/reuse_registry.json`, `reuse_graph.json` | Cross-package registry and expanded directed prerequisite graph |
| `reports/reusability/migration.json` | All 44 original IDs and moved general proof ownership |
| `reports/reusability/review_report.ja.md` | Current three-round review and closure |
| `reports/reusability/translation_review.ja.md` | Current bilingual scope and verification |
| `reports/reusability/resolution_ledger.json` | Original findings and independent closure references |
| `sources.toml` | 24 sources with exact scope and preserved provenance |

## Current verification

Run from the package root:

```bash
python3 reports/reusability/validate_reusability.py
python3 reports/reusability/verify_snapshots.py
```

The structural result is 2303 checks, zero failures, with 77 vertices and 321 internal prerequisite edges. Generic closure excludes applications; the five-point closure excludes Painlevé; intrinsic classical Layers 1–8 exclude scalar Layer 9. Snapshot verification has 95 checks with zero failures. These are text/graph/byte checks, not theorem verification.

The independent review closes all assigned findings for the 23 final frozen mathematical files. General proofs and difficult concrete geometric adapters remain explicit future obligations. The modules specify proposed upstream destinations and do not claim upstream acceptance.

## Historical material

`reports/strict_review/`, `reports/mathematical_review/`, `reports/japanese_translation/`, their older top-level reports, and the preserved implementation artifacts describe their own frozen versions. Use the two scripts above for the current package. Older scripts with fixed hashes must be run only against their matching historical inputs, not against the current root. The pre-revision canonical source and old entry reports are preserved under `reports/reusability/history/`.

Worker execution, provider jobs, push, issue, PR and publication have not occurred. Historical Lean records are preserved and were not used as an active gate. Source PDFs, extracted articles, repository checkouts and runtime helpers are not shipped. The final package is a reviewable draft, not blanket authorization to copy every historical file into a future content repository.
