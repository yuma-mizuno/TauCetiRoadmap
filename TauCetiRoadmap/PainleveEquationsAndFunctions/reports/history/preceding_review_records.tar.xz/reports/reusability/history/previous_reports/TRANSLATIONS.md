# ロードマップの言語別入口

- [日本語版：内在的パンルヴェ方程式と関数](README.ja.md)
- [English: intrinsic Painlevé equations and functions](README.md)
- [日本語版の翻訳・数学照合レビュー](reports/translation_review_report.ja.md)
- [数学内容そのもののレビュー記録](reports/mathematical_review_report.ja.md)

日本語版は数学レビュー後の英語正本の全文訳である。11層・44項目の番号、数式、文献、検証事項、依存関係を維持し、構造化計画の入力条件と明示的証明課題を付録に収録した。英語正本と構造化計画は変更していない。

状態は未公開ドラフトであり、将来の証明課題を含む。翻訳レビューの完了は、記載した全数学定理の証明完了を意味しない。
