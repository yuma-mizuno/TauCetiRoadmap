# Painlevé ロードマップ：数学内容の再レビュー

2026-11-05。対象は未公開ドラフト `PainleveEquationsAndFunctions`。ユーザーの指示に従い、今回の判定対象を数学的な定義、定理の仮定と結論、証明経路、文献の適用範囲、座標表示との比較に限定した。

## 判定

**数学内容の再レビューと修正を完了し、最終固定版で未解決の指摘は0件となった。** 初巡の統合 P2 一件を修正し、第2巡で見つかった同種の残存 P2 一件も修正した。第2巡はそのまま合格扱いにせず、第3巡で §5.3 の解消、同種問題の残存、変更されていない幾何・解析部分への影響を再確認した。§10.2 の一様性の追記は、元の固定パラメータの命題を偽と数えず、独立に検証した精密化として扱う。これを数学内容のレビュー済みドラフトとして確定する。

Worker 自体は起動していない。push、issue、PR、公開処理は行っていない。以下の「証明目標」は将来証明する内容であり、このレビューによって一般定理の証明が完了したことにはならない。

## 1. 今回確認した全体構造

古典 differential Painlevé の入力は、種数0の曲線、階数2の束、次数4の構造的極因子、指定された regular-singular determinant connection、許容される局所形式構造、安定性と marking のデータである。入力の同型と基底変換も保持する。時間空間は、その形式データの実際の reduced versal deformation から構成する。

この定義には、時間が1次元であること、位相空間が2次元であること、isomonodromic splitting の存在、RH properness、Painlevé property を入れない。これらは後の結論である。ラベルを忘れた10 profile とラベル付き17 profile も分類の出力であり、入力を十種類から選ぶ定義にはしない。

安定接続のモジュライと変形複体から相対シンプレクティック形式を構成し、時間方向の強い可積分拡張から水平分布を構成する。解はその水平切断の芽であり、指定された observable を評価して初めて通常の scalar function を得る。

全44項目・216本の内部依存を再点検した。循環はなく、Layers 1–8 から Layer 9 の古典式比較への推移的依存もない。これは機械的な辺の検査に加え、各章の証明経路を読んで確認した範囲の判定である。入力条件と表現式との境界は本文 §§1.1–1.4、§§3.1–3.4、§§5.1–5.5、§9.1 に明示されている。

## 2. 確定した問題と、再レビューで見つかった残存箇所

**初巡の統合指摘: MR4-INPUT-OUTPUT、重大度 P2。** 本文は正しく「構成・証明する」と書いている一方、構造化計画 `design/plan.json` の `hypotheses` 欄に、同じ項目でこれから得る結果が並んでいた。

| 項目 | 仮定のように書かれていた内容 | 正しい役割 |
|---|---|---|
| §1.4 | 10 underlying / 17 ordered profiles | 形式型分類の結論 |
| §2.3 | 補助的 unfolding と閉性に必要な構成 | 同項目で先に証明する中間結果 |
| §4.4 | 一様 lattice boundedness と stable replacement | RH properness のために証明すべき補題 |
| §5.3（第2巡で発見） | actual monodromy action | 完全な平坦接続から構成する具体的な作用 |
| §6.2 | 全コンパクト化、補集合全体の同型、形式・分布の一致 | この比較定理の主要な出力 |
| §7.2 | 追加の marked-pair reflections と延長 | 構成すべき変換と、その延長定理 |
| §9.2 | 具体的なチャート、parameter map、逆 first jet | 古典表示比較の出力 |
| §10.3 | HM の一様扇形評価と大円弧積分の消失 | 接続定数の校正のために証明する解析的評価 |

本文そのものを循環した定義と判定したのではない。構造化された仮定だけを読むと、難しい中間定理が既に供給されていると誤認できる不整合である。独立した core と geometry の担当が、実際のフィールドと本文を照合して同じ問題を確認した。

初巡では同じ問題がある27項目の仮定欄を整理した。その後、独立した修正後レビューで §5.3 に残っていた同種の混入を P2 `MR4-INPUT-OUTPUT-5.3` として発見した。完全な平坦接続から構成するはずの actual monodromy action が、まだ入力に残っていた。これも修正し、輸送、ホモトピー不変性、実際の作用、普遍被覆上の切断、降下条件を、順に構成・証明する出力として保持した。入力・出力の問題として修正した仮定欄は計28項目となる。§10.2 の仮定欄も、後述する一様性の追記と併せて更新した。入力データ、厳密に先行する結果、当該項目の新たな出力を区別し、既存の statement、API、依存先、所有する証明課題を保った。分類と一様漸近評価の証明責任も明示的な一覧に加えた。28件の別々の欠陥としては数えていない。記録上は、初巡の統合 P2 一件と、第2巡で見つけた同じ問題型の残存 P2 一件である。

初巡の変更前後の全文は `mathematical_review/round1/hypotheses_author_changes.json`、§5.3 の追加修正は `mathematical_review/round2/author_resolution_5_3.json` に保存している。第2巡を合格扱いにせず、再度固定した第3巡で最終的な解消を確認した。

## 3. 一様漸近展開：反例で量化を明確にした

これは、元の文の確定した偽命題としては数えない。元の §10.2 の little-o を各固定パラメータについて読むなら正しく、§10.3 は既に別途一様扇形評価を要求していた。独立解析レビューもこの読みを採用した。そのうえで、一様な結論へ誤用できないよう本文を強化した。

### 固定パラメータと一様性の差

RHP の residual jump を (I+w_s)、Cauchy 解を (R_s=I+C(h_s))、(h_s=(I+\nu_s)w_s) とする。各 (s) で

\[
(1+|\zeta|^m)w_s\in L^1\cap L^2
\]

なら、輪郭の無限遠の ray から離れた閉扇形で、対応する係数展開と固定 (s) の (o(|z|^{-m-1})) を示せる。これらのノルムがパラメータ全体で有界でも、非コンパクトなパラメータ集合上の一様 little-o は自動ではない。

### 正則に依存する具体的な反例

\[
\Gamma=\mathbb R,\qquad
w_s(x)=a e^{-(x-s)^2}E_{12},\qquad
\Re s>1,\quad |\Im s|<\delta,
\]

とし、(a>0) を (a e^{\delta^2}<1) となるよう取る。これは Banach 空間値で正則な small-jump family であり、零次の (L^1,L^2,L^\infty) ノルムは一様に有界、(det(I+w_s)=1) である。(E_{12}^2=0) により、正確に (h_s=w_s) となる。

零次モーメントは (M_0=a\sqrt\pi E_{12}) で一定だが、(s=n,z=in) とすると

\[
n\left(C(w_n)(in)+\frac{M_0}{2\pi i\,in}\right)
\longrightarrow
\frac{a\sqrt\pi}{2\pi i}\frac{1-i}{2}E_{12}\ne0.
\]

従って一様な (o(1/z)) は成り立たない。質量が輪郭上で無限遠へ移動していることが原因であり、正則依存だけでは防げない。

### 追加した十分条件と証明

一様 little-o を主張するパラメータ集合では、(W_m=1+|\zeta|^m) として

\[
\sup_s\|\mathbf1_{|\zeta|>R}W_mw_s\|_1\to0,
\qquad
\sup_s\|\mathbf1_{|\zeta|>R}W_mw_s\|_2\to0
\]

を証明する。共通 small-norm gap から (sup_s\|\nu_s\|_2<\infty) が得られ、

\[
\|\mathbf1_{|\zeta|>R}W_mh_s\|_1
\le
\|\mathbf1_{|\zeta|>R}W_mw_s\|_1
+\|\nu_s\|_2\,
\|\mathbf1_{|\zeta|>R}W_mw_s\|_2
\]

によって (h_s) の重み付き tail も一様に小さくなる。幾何級数の正確な剰余を、有界な部分と tail に分ければ一様 little-o が従う。

十分条件として、重み付きノルムで連続な族をコンパクトなパラメータ集合に制限する方法と、さらに一次数高いモーメントを一様に抑える方法も記した。後者は一様 (O(|z|^{-m-2})) を与える。§10.3 の扇形評価と §11.4 の端点での極限には、実際に使うパラメータ集合上での評価が必要である。

## 4. 重要な反例候補に対する判定

### 4.1 時間の定義と次元

§1.3 は時間の次元を定義に入れていない。§1.4 で、許容される projective Katz invariant と構造的極次数から、座標変更の作用・安定化群・marking を調べて次数4の場合の一次元時間を導く。10型と17型の計数も独立に再計算し、一致を確認した。rank、構造的極次数、実際の非零な極の次数は区別されている。[VDPS09, §2.2, Table 1; I23, §§2–4, Theorem 7.5.]

### 4.2 全点での幾何学的継続

§4.3 は共鳴・可約・例外 locus を含む水平軌道との適合を要求する。§5.2 は、すべての部分的な水平持ち上げについて、proper な写像がそれを完全な target transport に写すことを仮定する。コンパクトな target path の逆像に軌道を閉じ込め、局所 ODE の存在・一意性と有限個のチャートで延長する。generic open 上の適合だけを全体へ流用する構造にはなっていない。

一方、§4.4 の全 strata・族としての proper RH は、大きな証明課題として残る。IS12 Theorem 5.1 は generic/nonresonant/irreducible な範囲の比較であり、Remark 6.3 の期待される properness を、そのまま全許容クラスの既証明定理と扱えない。引用の射程と、ロードマップが所有する拡張証明を分けた。[IS12, Theorem 5.1, Remark 6.3; IIS06, Lemma 2.12.]

### 4.3 表面側の分類と時間線

8個の加法型境界は、反標準性、交点条件、加法型、SNC という表面側の条件から分類する。古典 ODE や全 profile の connection–surface 同型を、その分類の前提にしない。

また、第一境界層

\[
L=H^0\!\left(D,\Theta_S(-\log D)\otimes N_D\right)
\]

の次元1と、局所コホモロジー全体の次元1を区別する。前者の交点行列による計算を用い、後者との無条件の等号は仮定しない。族での局所自由性・底変換と、connection 側の時間分布との一致は、別の比較定理として残す。[STT02, Proposition 1.2; TER02, Theorem 2.1, Proposition 2.1, Conjecture 2.1.]

### 4.4 scalar comparison と失われるデータ

一般の first-jet map は局所同型であるだけでは大域同型にならない。本文は実際に逆を持つ領域を指定する。平方時間の変換には被覆を使い、FN の (U=0) 枝や sigma に写すと失われる Riccati family の phase data を保持する。PIII の16通りの係数の零・非零パターンは D6 が4、D7 が4、D8 が1、求積境界が7で尽くされる。分母を払うだけで新しい解を追加しない。

### 4.5 τ、漸近解析、合流

determinant section と JMU/Hamiltonian 公式の適用範囲を分ける。補助的な reference bundle の任意の変更は零因子を変え得るので、証明済みの同値に対してだけ unit による比較を行う。HM の実軸の情報だけから複素扇形の評価を推論しない。

合流では、極の重複度だけでなく leading orbit、下位係数、determinant、時間・指数・label・ramified descent を記録する。解の存在、共通領域からの非脱出、初期値に整合する収束を証明した後で、古典的なスケーリングを比較する。コンパクト経路上の収束から端点の接続定数までを自動で導かない。

## 5. ロードマップが引き続き所有する主要な証明課題

| 項目 | 完了条件となる数学的内容 |
|---|---|
| §2.3 | 補助的な有限平坦 unfolding、変形複体と trace 形式の比較、閉性の特殊化 |
| §§4.2–4.4 | 分岐 Stokes データの族としての輸送、全点の水平適合、全許容 strata での相対 properness |
| §§6.2–6.3 | 全位相空間を含む compactification/complement 比較、族の底変換、時間分布の一致 |
| §7.2 | 局所修正だけでは得られない追加反射、その正則な定義域と関係式・延長 |
| §8.2 | 共鳴・分岐を含む指定された index-zero RHP realization と許される descent |
| §§10.2–10.3 | 端点の Cauchy reconstruction、正確な一様性条件、指定した接続公式と HM 校正の扇形評価 |
| §§11.1–11.4 | 実際の衝突データからの位相・時間比較、共通チャートでの場の収束、正規化された τ の極限 |

これらを「仮定」として済ませて先へ進むロードマップにはしていない。各項目でどの入力から何を構成・証明するかを、本文と計画の両方に残している。将来の一般定理の真偽・証明完成と、今回の設計レビューの完了は区別する。

## 6. 記録と再現可能性

初回3巡の記録は `strict_review/` に保持し、今回の数学レビューを `mathematical_review/` に分離した。今回の各巡には、固定した README・plan・sources・metadata、SHA-256、担当別報告、指摘一覧、変更前後の台帳を保存する。

本文と plan の全44項目について、statement、API、診断例、Needs の一致を検査した。現在の規模は11層、44項目、115個の API 法則、129個の診断例、216本の内部依存であり、数学文書の整合性検査270件を通過した。これは数値と対応関係の検査であり、129個の一般定理の証明ではない。

今回の出典点検は、担当領域の一次資料と問題箇所の適用範囲に対して行った。以前の22 PDF のバイトハッシュ全件検査を、今回新しく実行したとは表示しない。`sources.toml` の既存 provenance は保持した。

レビュアーは利用可能な同じモデル系列内の独立セッションである。Worker の異なるモデル系列という条件を満たしたとは表示しない。

## 参照資料

- [I23: Inaba, factorized ramified connections](https://sigma-journal.com/2023/013/) — 変形複体、symplectic structure、strong extension と global foliation。
- [VDPS09: van der Put–Saito, moduli and Painlevé equations](https://arxiv.org/abs/0902.1702v5) — 10 underlying profiles と表示比較。
- [IS12: Inaba–Saito, unramified irregular parabolic connections](https://arxiv.org/abs/1203.0084v3) — Theorem 5.1 と Remark 6.3 の適用範囲。
- [IIS06: Dynamics of the Sixth Painlevé Equation](https://arxiv.org/abs/math/0501007v2) — 幾何学的 Painlevé property の共通機構と PVI 比較。
- [STT02: Deformation of Okamoto–Painlevé pairs](https://arxiv.org/abs/math/0006026v2) — 表面側の分類・変形。
- [TER02: Local cohomology of generalized Okamoto–Painlevé pairs](https://arxiv.org/abs/math/0006027v1) — 第一境界層と局所コホモロジー全体の区別。
- [ILP18: Monodromy dependence and connection formulae](https://arxiv.org/abs/1604.03082v4) — 適用範囲を指定した τ 接続公式と具体的 RHP 解析。

残りの一次資料と正確な節・定理番号は、本文 References、`sources.toml`、担当別レビューに記載した。

## 最終固定版

| ファイル | SHA-256 |
|---|---|
| README.md | `387c929984ac0d8aee1f3ad3fa1fd507f42984728595c6efeb08146e84d23658` |
| design/plan.json | `9c7aa0339590c7f6c151f65941ee29ff9b5548096709dce1baf7dc743cff78e4` |
| sources.toml | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |
