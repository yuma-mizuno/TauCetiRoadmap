# Framework: algebraic confluence and finite-algebra Poisson geometry

**Status.** Draft mathematical proof targets extracted from the general portions of the earlier Painlevé target 11.1. This specification does not declare the proofs complete and modifies no upstream roadmap.

**Purpose.** Isolate two reusable results. The first is linear Laurent algebra with an elementary analytic convergence consequence for arbitrary finite-dimensional coefficients. The second constructs a relative dual Poisson structure from a finite locally free algebra. They require no Painlevé equation, primitive endpoint condition, phase dimension, asymptotic solution, or moduli quotient.

## Contracts and ownership

| Contract | Input → output | Proposed owner |
| --- | --- | --- |
| 1.1 | Vector-valued Laurent germs and principal-part cancellation → exact rational identity, limiting coefficients and compact-uniform convergence | FormalLaurentPuiseux, proposed parametric principal-part extension |
| 1.2 | Finite locally free commutative algebra A → relative Poisson structure on (gl_n ⊗ A)∨, base change and all-coefficient sign transport | LieGroupoidsPoisson, proposed complex relative finite-algebra extension |

The two targets are independent. A collision of connections may use both, but neither general theorem takes the collision’s geometric conclusions as hypotheses. A divisor or coefficient presentation produces comparison lemmas; it does not define the general Poisson object. The determinant, formal type, relative orbit conditions, reduction existence and horizontal-connection limit remain obligations of a consuming application.

Consumers use `framework:AlgebraicConfluence/1.1` and `framework:AlgebraicConfluence/1.2`. The `proposed_owner` field records distinct proposed upstream owners; this extraction does not create a duplicate permanent owner or assert that those additions have already been made.

## Layer 1: general algebraic contracts


### 1.1 Finite principal-part cancellation with vector-valued coefficients

Let V be an arbitrary finite-dimensional complex vector space and r ≥ 0 an integer. Work with convergent meromorphic germs at ε = 0. Let P(ε) = t₁ε + ⋯ + tᵣ₊₁εʳ⁺¹ + O(εʳ⁺²), with t₁ ≠ 0; let C(ε) be V-valued with a pole of order at most r + 1, and write W for its ε⁻ʳ⁻¹ coefficient; and let D_j(ε) be holomorphic V-valued germs for 0 ≤ j ≤ r. For a Laurent germ f, write [f]_<0, [f]₀ and [f]_≥0 for its negative part, constant coefficient and nonnegative part. Define B_j = −[CPʲ]_<0 + D_j and

A_ε(z) = Σⱼ₌₀ʳ B_j(ε)/zʲ⁺¹ + C(ε)/(z − P(ε)).

Prove the exact finite identity

A_ε(z) = Σⱼ₌₀ʳ (D_j(ε) + [C(ε)P(ε)ʲ]_≥0)/zʲ⁺¹ + C(ε)P(ε)ʳ⁺¹/[zʳ⁺¹(z − P(ε))].

This identity uses only scalar multiplication on V. Prove that C(ε)P(ε)ʳ⁺¹ tends to t₁ʳ⁺¹W and that, on every compact subset of ℂ \ {0}, A_ε converges uniformly to Σⱼ₌₀ʳ (D_j(0) + [CPʲ]₀)/zʲ⁺¹ + t₁ʳ⁺¹W/zʳ⁺². After shrinking the ε disk, the denominator on a fixed compact set K is bounded below by |z − P(ε)| ≥ dist(K,0)/2. Thus a finite rational remainder proves uniform convergence; no exchange with an uncontrolled infinite series is needed. Prove naturality under complex-linear maps V → V′. For an invertible parameter substitution ε = φ(η), transport C, P and B_j by composition and define D′_j = B_j ∘ φ + [(C ∘ φ)(P ∘ φ)ʲ]_<0; prove that D′_j is holomorphic and gives the same rational family and limiting coefficients. Principal-part projection itself does not commute with a nonlinear substitution: the holomorphic D_j must receive this correction. The transformed leading coefficients satisfy (t′₁)ʳ⁺¹W′ = t₁ʳ⁺¹W. A change of the z-coordinate is a separate comparison of the rational expression, not an identification of its individual coefficients without transformation.

The coefficient t₁ʳ⁺¹W is nonzero exactly when W is nonzero. In that case the limiting V-valued rational function has a pole of order r + 2 at z = 0. For V = M_n(ℂ) this is a statement about matrix pole order, and supplies no projective Katz slope or formal normal form. If instead C = O(ε⁻ʳ), then CPʳ⁺¹ = O(ε), so the purported new highest coefficient is zero. This is the index/scaling correction needed before the printed pole-raising assertion in GMR23, Theorem 2, pp. 1391–1392, (12)–(15) can be used. The corrected lemma is proved here rather than treating that printed statement as a premise. Whether an application’s time-dependent coefficient basis agrees with its actual Laurent coefficients must be checked in that application.

**API.**

- Construct the principal-part cancellation for arbitrary finite-dimensional coefficient spaces and prove the exact finite rational identity.
- Compute all limiting coefficients and prove uniform convergence on each compact set avoiding the collision point.
- Prove compatibility with linear coefficient maps and invertible parameter substitution, including the necessary holomorphic correction to D_j.
- Distinguish the nonzero highest matrix pole coefficient from formal slope, and exhibit the loss of that coefficient under the insufficient C = O(ε⁻ʳ) scaling.

**Checks.**

- At r = 1, C = W/ε², P = t₁ε + t₂ε², B₀ = −W/ε² and B₁ = −t₁W/ε give the limit t₂W/z² + t₁²W/z³. For t₁ = 1, t₂ = 0, the entire expression equals W/[z²(z − ε)]. By contrast C = W/ε, B₀ = −W/ε, B₁ = W and P = ε give 2W/z² in the limit, with zero triple-pole coefficient.
- At r = 0, C = W/ε, P = t₁ε and B₀ = −W/ε + D₀ give the limit D₀(0)/z + t₁W/z²; the formula must cover this smallest collision.
- If W = 0, the highest coefficient vanishes. The theorem does not assert a pole of order r + 2 or preserve a nonzero-leading formal stratum in that case.
- Applying a linear functional V → ℂ before or after cancellation gives the same scalar formula. Choosing V = M_n(ℂ) changes no coefficient index and introduces no matrix commutator into this lemma.
- For r = 0, C = 1/ε, P = ε, B₀ = −1/ε and D₀ = 0, substitute ε = η + cη². Then [C ∘ φ]₀ = −c and D′₀(0) = c, so the limiting simple-pole coefficient remains zero. Setting D′₀ = D₀ ∘ φ without correction would give the wrong coefficient −c.

*Needs:* FormalLaurentPuiseux §L1–L7’s Laurent operations and parameter substitution, extended coefficientwise to finite-dimensional vector spaces; convergence of meromorphic germs and the displayed elementary denominator estimate. The corrected lemma is an output and GMR23’s printed pole-raising statement is not an input.

### 1.2 Relative dual Poisson structures for finite locally free algebras

Let B be a complex algebraic or complex analytic base, A a finite locally free commutative O_B-algebra, and n ≥ 1. Form the locally free Lie algebra L = gl_n(O_B) ⊗ A with [X ⊗ a, Y ⊗ b] = [X,Y] ⊗ ab. On the relative dual vector bundle L∨, define the positive linear Poisson bracket intrinsically by {ℓ_X,ℓ_Y}₊ = ℓ_[X,Y], where ℓ_X(ν) = ν(X); extend by the biderivation rule. Construct the corresponding algebraic or holomorphic relative Poisson tensor, prove Jacobi and prove compatibility with base change. The structure is relative to B and makes no assertion about a Poisson bracket in the base directions. Define the negative convention by {f,g}₋ = −{f,g}₊.

Prove that fiber negation N(ν) = −ν is a Poisson isomorphism from the negative to the positive convention: {N*f,N*g}₋ = N*{f,g}₊. This negates every linear coefficient, including every degree in a Takiff-coordinate presentation; an identity map of coefficient matrices is not the comparison. Construct the relative group of units GL_n(A) and its coadjoint action, and prove equivariance of N. On an already specified smooth coadjoint-orbit locus, compare the paired KKS conventions ω_±,ν(ad*_Xν,ad*_Yν) = ±ν([X,Y]) and prove N*ω₊ = ω₋. For H₊ ∘ N = H₋, prove the corresponding Hamiltonian-vector-field transport using the recorded paired convention. Transport an already supplied compatible moment-map and regular-reduction datum through this equivariant comparison, with its sign convention recorded. The output is compatibility where that datum exists, not existence of arbitrary quotients, flatness of relative orbits, or smoothness of a reduction locus.

Retain the actual dual carrier. The trace pairing identifies L∨ with gl_n(O_B) ⊗ A∨; it does not identify A∨ with A. If the application supplies a finite flat Cartier divisor P in a smooth relative curve, write p: P → B and construct A∨ ≅ p_*ω_P/B with A = p_*O_P, where ω_P/B ≅ ω_C/B(P)|_P is the relative dualizing module. Prove the resulting perfect residue pairing with A. In a local polynomial presentation A = O_B[z]/(Q(z)), with Q monic of degree m, the coordinate lemma identifies the dualizing generator with dz/Q and the Frobenius functional λ_Q(f) with the coefficient of zᵐ⁻¹ in the representative of degree less than m. Equivalently λ_Q(f) is the sum of the residues of f(z)dz/Q(z) at the divisor. Prove perfectness, base change and compatibility with changes of such presentations, transporting the differential generator as well as coefficients. A general finite locally free A need not admit such a Frobenius identification; its intrinsic dual Poisson structure does not require one.

On a split fiber A ≅ ∏_i ℂ the Lie algebra and bracket split accordingly. On a local fiber A ≅ ℂ[z]/zᵐ, prove the Takiff-coordinate formula [Xzⁱ,Yzʲ] = [X,Y]zⁱ⁺ʲ for i + j < m and zero for i + j ≥ m, together with the corresponding dual linear Poisson formula. These are coordinate lemmas for the intrinsic finite-algebra construction. For the source comparison in GMR23, brackets (96)–(97), the negative convention is transported by fiber negation; a connection convention dY/dz = A_source Y versus ∇ = d + A_ours additionally requires A_ours = −A_source, with its residue and exponent coefficients transformed consistently. GMR23 Definitions 3–4 and Theorem 12, §4.2, are models on their stated domains, not a proof that every local-condition orbit or collision reduction is flat or regular.

**API.**

- Construct the relative dual linear Poisson structure from multiplication in A, and prove Jacobi, functoriality under algebra isomorphisms and base change.
- Construct fiber negation as an equivariant Poisson isomorphism and transport the paired KKS, Hamiltonian and already verified reduction conventions.
- Keep A∨ as the dual carrier and prove the residue/Frobenius coordinate comparison only with its specified curve or polynomial input.
- Derive split and truncated-algebra coordinate formulas, including every Takiff degree and the full source-to-supplier sign map.

**Checks.**

- For O_Δ[z]/(z(z − ε)), ε ≠ 0 gives the product of two point algebras, while ε = 0 gives ℂ[z]/z². The central nilpotent class of z is part of the comparison.
- With X = E₁₂, Y = E₂₁ and ν_source = diag(1,−1)/2, the source linear Poisson bracket is −1. At ν_ours = −ν_source the positive supplier bracket is also −1; pullback under fiber negation agrees, while identity comparison gives +1. For a Takiff algebra the bracket is zero when the sum of the two degrees exceeds the truncation degree.
- For Q(z) = z(z − ε) and f = a + bz, λ_Q(f) = b. When ε ≠ 0 this equals [f(ε) − f(0)]/ε; at ε = 0 it is the coefficient of the surviving nilpotent class z. The dualizing pairing persists although the separated-point expression contains 1/ε.
- For A = ℂ[x,y]/(x,y)², every functional λ gives a degenerate pairing (a,b) ↦ λ(ab): a nonzero element of span{x,y} in the kernel of λ pairs to zero with all A. Thus a general finite locally free algebra cannot be identified with its dual by an unstated Frobenius functional, while the dual Poisson construction still applies.
- The fiber-negation map is not evidence that a chosen orbit family is flat or that a desired complex symplectic quotient exists. Those are separate hypotheses or construction targets of the application.

*Needs:* LieGroupoidsPoisson §G4.6A supplies the underlying linear-bracket/sign pattern; the complex relative finite-algebra construction, base-change proof and sign adapter are proved here. Use finite locally free dual/vector-bundle foundations and, for the optional residue comparison, curve dualizing modules and residues. Any orbit or reduction comparison retains its separately verified geometric hypotheses.

## Source and scope

The existing [GMR23 record](../../sources.toml) retains its source key and provenance. Relevant locators in [GMR23](https://doi.org/10.1007/s00220-023-04650-8) are Theorem 2, (12)–(15), with the explicit correction in 1.1; §4.2, Definitions 3–4 and Theorem 12; and brackets (96)–(97). The source’s §5.1 restriction to nonramified Painlevé realizations is a limitation of those applications, not a restriction on either elementary general contract above. No source theorem is used to infer arbitrary orbit flatness, reduction existence or primitive endpoint admissibility.
