# AlgebraicConfluence 独立数学レビュー

## 判定

**Pass。要修正事項は検出しなかった。** 対象は凍結された一般目標 1.1、1.2 と日英 README、`plan.json` である。この判定はロードマップの数学的な契約、仮定、依存境界に対するもので、今後記述すべき一般定理の証明を完成済みと認定するものではない。

レビュー担当は `/root/reuse_moduli_author`。MeromorphicConnectionModuli の著者であり、今回の AlgebraicConfluence の著者ではない。manifest の SHA-256 を 3 ファイルすべてで照合し、凍結された本文は編集していない。重大度 critical / high / medium / low はすべて 0 件。

## 1.1：有限主部の相殺

有限恒等式

\[
\frac{C}{z-P}
=\sum_{j=0}^{r}\frac{CP^j}{z^{j+1}}
+\frac{CP^{r+1}}{z^{r+1}(z-P)}
\]

へ (B_j=-[CP^j]_{<0}+D_j) を代入すれば、目標の恒等式が得られる。無限級数の項別極限も、(V) の積も使わない。したがって任意の有限次元複素ベクトル空間を係数にでき、複素線形写像による自然性も同じ恒等式に帰着する。

(C) の極の位数が高々 (r+1)、(P=t_1\epsilon+O(\epsilon^2)) なので、

\[
CP^{r+1}\longrightarrow t_1^{r+1}W.
\]

(K\Subset\mathbb C\setminus\{0\}) では、十分小さいパラメータに対して (|z-P(\epsilon)|\geq\operatorname{dist}(K,0)/2)。残りの係数は正則芽であるから、表示された有限剰余の評価だけで (K) 上の一様収束が従う。(W\ne0) のときの極の位数 (r+2) と、(C=O(\epsilon^{-r})) のときの最高次係数の消失は、いずれもこの式で直接確認できる。低次の Laurent 項が最高次の非零係数を相殺することはない。

### 非線形パラメータ変更

(F=CP^j=F_-+F_+)、(F_-=[F]_{<0}) とおく。可逆芽 (epsilon=\phi(\eta)) について、

\[
D'_j
=B_j\circ\phi+[F\circ\phi]_{<0}
=D_j\circ\phi-[F_-\circ\phi]_{\ge0}.
\]

右辺は正則であり、

\[
D'_j(0)+[F\circ\phi]_0=D_j(0)+[F]_0
\]

となる。したがって本文の補正は必要かつ十分である。単なる (D_j\circ\phi) への置換では不十分、という警告は正しい。

(\phi(\eta)=a\eta+O(\eta^2)) なら (t'_1=at_1)、(W'=a^{-r-1}W) なので、最高次係数 ((t'_1)^{r+1}W'=t_1^{r+1}W) も保存される。指定された反例 (C=1/\epsilon)、(\phi=\eta+c\eta^2) では ([C\circ\phi]_0=-c)、(D'_0(0)=c) となり、単純極の係数は確かに 0 のままである。

本文の (r=0)、(r=1)、スケーリング不足の全計算例を別々に確認した。とくに (C=W/\epsilon)、(B_0=-W/\epsilon)、(B_1=W)、(P=\epsilon) では二重極の係数が (2W)、三重極の係数が 0 であり、チェックの値は正しい。

この一般定理から得るものを (V)-値有理関数の極の位数に限定し、Katz slope、形式型、接続の moduli の極限を別問題としている点も適切である。時間依存の係数基底と実際の Laurent 係数との比較は、応用側の証明義務として残っている。

## 1.2：有限局所自由代数の双対 Poisson 構造

### 相対構成と基底変換

(L=\mathfrak{gl}_n(\mathcal O_B)\otimes A) の括弧は、行列の Jacobi 恒等式と (A) の可換結合律から Jacobi 恒等式を満たす。その双対上の線形 Poisson tensor は (\mathcal O_B)-双線形の構造定数から構成できる。したがって相対方向の tensor と任意の基底変換との整合性を証明する目標として仮定は十分である。基底方向の Poisson 構造を暗黙に導入していない。

ここでは入力が有限局所自由な **(\mathcal O_B)-代数そのもの** なので、非被約基底の nilpotent も入力に保持されている。幾何学的点上の作用素族だけでは非被約構造が指定されない解析目標 1.1 の問題とは異なり、この代数目標の基底を被約に制限する理由はない。代数的対称代数上の構成と、正則ベクトル束上の正則 Poisson tensor の構成は、ともにこの一般目標の出力として明示されている。

### (A^\vee) と residue 表示

行列の trace pairing は完全だが、これだけで (A^\vee\simeq A) とはならない。本文が

\[
L^\vee\simeq\mathfrak{gl}_n\otimes A^\vee
\]

を実際の carrier として保持していることを確認した。有限平坦 Cartier 因子 (P\subset C) を追加した場合だけ、有限平坦双対性と adjunction

\[
A^\vee\simeq p_*\omega_{P/B},\qquad
\omega_{P/B}\simeq\omega_{C/B}(P)|_P
\]

を証明して residue 表示へ移る。この境界は正しい。

局所表示 (A=\mathcal O_B[z]/(Q))、(Q) monic、次数 (m) では、代表元の (z^{m-1}) 係数を取る汎関数 (\lambda_Q) が (dz/Q) に対応する。基底 (1,z,\dots,z^{m-1}) での乗法 pairing は反対角の値が 1、その手前が 0 であり、行列式は (\pm1)。したがって被約でない因子や基底でも完全性が保たれる。monic division による係数抽出は基底変換とも可換する。座標を変えるときに係数だけでなく微分の生成元を運ぶ、という条件も必要であり、本文に含まれている。

(Q=z(z-\epsilon))、(f=a+bz) では (\lambda_Q(f)=b)。分離した二点での表示 ((f(\epsilon)-f(0))/\epsilon) が (epsilon=0) で特異に見えても、内在的な pairing は正則で完全なままである。対照的に (A=\mathbb C[x,y]/(x,y)^2) では、任意の (\lambda) に対して (\operatorname{span}(x,y)\cap\ker\lambda) に非零元 (u) があり、(\lambda(uv)=0) がすべての (v) について成り立つ。一般有限局所自由代数に Frobenius 同型を仮定してはいけない、という反例は有効である。

### 符号、KKS、Hamiltonian、reduction

線形関数上で (N^*\ell_X=-\ell_X) なので、

\[
\{N^*\ell_X,N^*\ell_Y\}_-
=-\ell_{[X,Y]}
=N^*\{\ell_X,\ell_Y\}_+.
\]

従って fiber negation は負の convention から正の convention への Poisson 同型になる。これは Takiff のすべての次数を一斉に符号反転する写像であり、係数の恒等写像ではない。

また (dN(\operatorname{ad}^*_X\nu)=\operatorname{ad}^*_X(-\nu)) だから、本文の paired KKS convention に対して

\[
(N^*\omega_+)_\nu(\operatorname{ad}^*_X\nu,
\operatorname{ad}^*_Y\nu)
=(-\nu)([X,Y])
=(\omega_-)_\nu(\operatorname{ad}^*_X\nu,
\operatorname{ad}^*_Y\nu).
\]

Hamiltonian の (H_+\circ N=H_-) による移送もこの同型から従う。例えば (\iota_{X^\#}\omega=d\mu_X) を採れば、正の coadjoint orbit の moment map は (\nu)、負のものは (-\nu) であり、(\mu_+\circ N=\mu_-) と整合する。本文は paired convention を記録することを要求しており、独立した符号を混在させていない。

KKS と reduction の主張は、既に指定され、必要な条件が検証された滑らかな orbit/reduction datum に限定されている。相対 orbit の次元一定性、平坦性、複素商の存在、正則 reduction の滑らかさは、この符号比較からは得られない。本文はそれらを明示的に応用側へ残しているので、無条件の一般化は検出しなかった。相対 KKS family を使う個別応用は、必要な相対滑らかさ・一定 rank の条件をその datum として検証する必要がある。

## 一次文献との比較

[Gaiur–Mazzocco–Rubtsov, publisher PDF](https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf) の Theorem 2（印刷 pp. 1391–1392、(12)–(15)）、その証明（印刷 pp. 1429–1430）、§4.2 の Definitions 3–4 と Theorem 12、括弧 (96)–(97)、§5.1 を確認した。

印刷された極の位数上昇のスケーリングをそのまま入力定理にすると、有限恒等式の最高次係数と一致しない。今回の 1.1 は必要な (C) の次数を修正し、自分の一般定理として証明する設計にしている。また (96)–(97) の負の構造定数は、1.2 の fiber negation による比較と一致する。§5.1 の例は階数 2 の非分岐設定であり、任意の分岐型や任意の reduction の定理として輸入されていない。

既存の実 smooth Poisson 理論から複素相対定理を無条件に引用する箇所もない。一般複素相対構成、基底変換、双対性・residue adapter は、このロードマップが所有する証明課題として明示されている。

## 日英・plan・依存関係

英語の statement、API 文、各チェック、Needs と `plan.json` の一致を機械的に照合した。日本語版では両目標の仮定、式、全符号、API、チェック、source scope を英語と比較し、意味の差を検出しなかった。1.1 と 1.2 は互いを必要とせず、Painlevé の分類や応用目標への依存もない。

## 残る証明作業とレビュー上の欠陥の区別

次は依然として実施すべき証明作業だが、ロードマップに既に明示されているため、今回の要修正事項には数えない。

- 1.1 の有限恒等式、係数極限、コンパクト一様評価、パラメータ変更の補正を、再利用可能な証明として記述する。
- 1.2 の相対 Poisson tensor、Jacobi、基底変換、fiber negation と paired KKS/Hamiltonian の整合を構成する。
- residue adapter で有限平坦双対性、Cartier adjunction、完全 pairing、表示変更との整合を証明する。
- 応用側で形式型、実際の係数基底、相対 orbit の条件、商の存在、水平流の極限を検証する。

このレビューはこの二つの一般契約に限られ、最後の応用上の課題や root の confluence adapter の正当性まで代わりに認定するものではない。
