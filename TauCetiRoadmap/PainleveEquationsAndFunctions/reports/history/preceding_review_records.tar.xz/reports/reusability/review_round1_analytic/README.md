# Framework: analytic RHPs and determinant convergence

**Status.** Draft mathematical proof targets. The constructions and proofs below are not declared complete. This is a reusable supplier specification extracted from the earlier Painlevé roadmap §§8.1, 10.2 and 11.4. It changes no upstream repository or ownership assignment.

**Purpose.** Separate general analytic theorems from their geometric and special-function applications. The inputs are operator families, contour packages, jump matrices, weighted estimates, holomorphic line comparisons and trace-class estimates. None of the six contracts requires a Painlevé equation, a rank-two formal profile, a phase-space dimension, a selected asymptotic branch, or a collision of meromorphic connections.

## Reuse and ownership

| Contract | General input and output | Proposed owner |
| --- | --- | --- |
| 1.1 | Index-zero holomorphic Fredholm family → determinant line, canonical section and naturality | HeegaardFloerPartII, proposed F0.0C |
| 1.2 | Contour geometry → Cauchy operators, solution class and reconstruction criteria | OperatorTheory, proposed analytic RHP extension |
| 1.3 | Cauchy package and uniform norm gap → unique residual solution and estimates | OperatorTheory, proposed analytic RHP extension |
| 1.4 | Weighted moments and tail control → coefficients and precisely quantified uniform asymptotics | OperatorTheory, proposed analytic RHP extension |
| 1.5 | Compared line sections, corrected one-forms and normalization → local uniform scalar convergence | ComplexKahlerGeometry, proposed normalized-section convergence target |
| 1.6 | Trace-norm holomorphic operator convergence → determinant convergence and conditional local zero counts | OperatorTheory adapter consuming RandomMatrices §8.3 |

The local dependency chain is 1.2 → 1.3 → 1.4. Targets 1.1, 1.5 and 1.6 have their own foundational inputs; 1.5 and 1.6 are independent convergence routes. The generic trace-class determinant stays with RandomMatrices §8.3, and the complex holomorphic Fredholm determinant line stays with proposed HeegaardFloerPartII F0.0C. Existing real orientation lines, matrix-symbol Toeplitz index results and trace-class determinants are not silently substituted for one another.

Applications must verify their own adapters: the contour and endpoint bounds of a parametrix, the actual operator-family or trace-class realization, line and frame comparisons, meromorphic-connection reconstruction, and any JMU/Hamiltonian comparison. The general theorems consume the precisely stated analytic data. Special-function conclusions do not enter their prerequisites.

In `plan.json`, `target:1.3` refers to this module. A consumer imports a contract as `framework:AnalyticRHPAndDeterminants/1.3`. `proposed_owner` is a prospective mathematical ownership assignment; it is not a claim that an upstream target has been implemented or modified.

## Layer 1: general analytic contracts


### 1.1 Holomorphic determinant lines for index-zero Fredholm families

Construct the complex holomorphic extension of the reusable determinant-line theory whose proposed owner is HeegaardFloerPartII, F0.0C. The existing real stabilization and orientation construction is a supplier of its algebraic comparison pattern, not a proof of this holomorphic extension. For a holomorphic family T_s: H₀ → H₁ of bounded complex Fredholm operators of index zero on a finite-dimensional complex analytic base S, initially with fixed complex Hilbert spaces, construct a holomorphic line L_T and its canonical determinant section τ_T. Use the convention L_T,s = det(ker T_s)* ⊗ det(coker T_s), dual to the real orientation-line convention. Construct the line even when the dimensions of kernel and cokernel jump. (MAL04, §2, printed pp. 1372–1374, gives the determinant-extension model; BERT17, §1, gives an RHP application within its stated symbol class.)

Locally choose a finite-dimensional complex space F and a: F → H₁ such that (T_s,a): H₀ ⊕ F → H₁ is surjective. Prove that K = ker(T,a) is a holomorphic vector bundle of rank dim F, using a local bounded splitting and holomorphic inversion. Set L_F = det K* ⊗ det F and τ_F = det(K → F), where K → F is the projection. Construct comparison maps under adding stabilizing summands and then through common refinements; prove their cocycle and section-compatibility laws before gluing. Fix the exact-sequence sign convention by requiring that a finite-dimensional family has its ordinary determinant in the standard determinant frame. Prove independence of all stabilization choices, holomorphic base change and naturality under isomorphisms of operator families. Use these same comparison laws to extend from fixed Hilbert spaces to holomorphic Hilbert bundles with specified local trivializations.

Identify τ_T(s) ≠ 0 exactly with invertibility of T_s. Existence of L_T does not imply that τ_T is generically nonzero, nor that it defines an effective divisor without additional hypotheses. Closedness of a proposed curvature two-form does not supply an integral transition cocycle. This target expands the previously named complex-holomorphic-determinant-family gap into the stabilization, gluing and naturality proof obligations themselves; the gap is not a prerequisite. Applications pull back this one construction and separately establish any RHP realization or logarithmic-derivative formula.

**API.**

- Construct the stabilization kernel bundles, determinant lines and canonical sections with the declared dual convention and finite-dimensional sign calibration.
- Prove refinement compatibility, the cocycle law, stabilization independence and holomorphic base change.
- Prove naturality under operator-family isomorphisms and glue the Hilbert-bundle version through its specified trivializations.
- Identify the section’s nonvanishing locus with the invertible-operator locus without assuming generic nonvanishing or a divisor.

**Checks.**

- For T_s: ℂ → ℂ, z ↦ sz, the standard frames give τ(s) = s, fixing the dual convention.
- For T_s(z) = s²z, the zero has order two although dim ker T₀ = 1; no unconditional equality between vanishing order and kernel dimension is supplied.
- An everywhere invertible constant family has nonvanishing determinant section; an identically singular index-zero family may have an identically zero section without invalidating its line.
- Two finite-dimensional stabilizations must give the same section after comparison through a common refinement, and a third stabilization must not change that comparison.

*Needs:* Complex bounded-Fredholm theory, local bounded splittings and holomorphic inversion; finite-dimensional determinant/exact-sequence carriers; HeegaardFloer §2.2/F0.0’s real comparison pattern; ComplexComparisonPartII’s holomorphic bundle and gluing interfaces. This target supplies the proposed HeegaardFloerPartII F0.0C extension and does not assume its formerly named gap.

### 1.2 Contour packages and the Cauchy-transform solution class

Construct a reusable contour package for finite oriented unions of compact C¹,α arcs, closed C¹,α curves, and noncompact arcs that are straight rays outside a compact set, where 0 < α ≤ 1. Require regular parametrizations and only finitely many endpoints and transverse vertices. Fix arc-length measure and the complex line element dζ, and require that distinct branches meet only at the specified vertices. Prove the bounded L² Cauchy boundary operators C₊, C₋ and the Plemelj relation C₊ − C₋ = id, together with the analytic Cauchy transform C(h)(z) = (2πi)⁻¹∫_Γ h(ζ)/(ζ − z)dζ and its boundary reconstruction on the stated class. The proofs must include the local cross-branch estimates at vertices and the convergence and decay of the integral on unbounded rays. A more general contour can be admitted only after supplying these same contracts. Pointwise endpoints have zero arc-length measure, but that fact removes none of the local analytic obligations there.

For a finite matrix size, define a normalized Cauchy-class residual solution by R = I + C(h), h ∈ L²(Γ), with h = R₊ − R₋ almost everywhere and with the normalization at infinity justified by the contour package and any additional moment hypotheses. The L² floor gives decay on sectors separated from the unbounded rays; a claimed I + O(1/z) normalization requires the L¹ control of §1.4. No extra homogeneous term at an endpoint or vertex is allowed. Prove that h is recovered uniquely from the jump. This specifies an analytic solution class rather than merely L² boundary traces.

Also formulate and prove a candidate-reconstruction criterion using the Cauchy formula on excised domains: control the large boundary and require the small-circle integrals about every endpoint and vertex to tend to zero. The local hypotheses in that criterion must imply this disappearance, not merely assert that the candidate has L² traces. Applications with local parametrices supply those bounds for their transformed candidates. State a separate determinant-removability criterion: when det R has matching boundary values, extends across the open arcs and all endpoints and vertices, and tends to one at infinity, the resulting entire scalar function is one by Liouville’s theorem. The jump identity det(I + w) = 1 alone does not verify this criterion.

**API.**

- Construct the Cauchy transform and bounded boundary operators with Plemelj and the declared contour-dependent bounds.
- Define the normalized Cauchy-transform class, recover its density from the jump and record the precise normalization supplied by its moment assumptions.
- Prove reconstruction of a candidate from its jump under explicit large-boundary and endpoint/vertex small-circle estimates.
- Export determinant-one and matrix-invertibility conclusions only after the scalar determinant extension and infinity normalization have been verified.

**Checks.**

- Identity jump gives h = 0 and R = I in this class. On Γ = [0,1], the competing matrix I + exp(−1/z)z⁻¹E₁₂ has the same identity jump and normalization and has L² boundary correction with squared norm e⁻²/2, but an essential endpoint singularity. It is excluded by Cauchy reconstruction: h = R₊ − R₋ = 0 cannot reconstruct its nonzero correction.
- On an unbounded contour, I need not lie in L²(Γ). The normalized class is the affine class I + C(L²), not a demand that its matrix boundary value itself belong to L².
- The determinant of a jump being one supplies matching determinant traces; endpoint and vertex removability and the normalization at infinity remain separate obligations.
- A residual analytic matrix reconstructed from an arbitrary admissible jump is not thereby a meromorphic connection with prescribed polar data; that reconstruction belongs to the application.

*Needs:* Complex L² and bounded-operator foundations; Fourier–Plancherel and the real-line Hilbert transform; Schur estimates; the Cauchy formula and Liouville’s theorem. The contour boundedness, Plemelj, reconstruction and endpoint criteria are proved here as a proposed OperatorTheory extension; no Painlevé or meromorphic-connection reconstruction is a prerequisite.

### 1.3 A quantitative small-norm RHP theorem

Fix a proved contour package from §1.2 and a finite matrix size. For a residual jump J_s = I + w_s with w_s ∈ L²(Γ) ∩ L∞(Γ), define C_w f = C₋(fw) on L². Assume a common bound ‖C_w‖ ≤ ρ < 1 on the stated parameter set. If an invertible-jump RHP is intended, additionally require J_s to be invertible almost everywhere; in the determinant-one specialization require det J_s = 1 almost everywhere. These algebraic jump assumptions do not replace the operator norm gap or the determinant-removability criterion.

Solve ν = C₋w + C_wν by ν = (id − C_w)⁻¹C₋w, using the Neumann series, and set μ = I + ν, h = μw and R = I + C(h). Prove h ∈ L², R₋ = μ and R₊ = R₋(I + w). Conversely, an admissible Cauchy-class solution yields that same equation for ν and is therefore unique in the specified class. The construction uses ν ∈ L² and never assumes that I or μ is in L² on an unbounded contour. State the basic quantitative bounds ‖(id − C_w)⁻¹‖ ≤ (1 − ρ)⁻¹ and ‖ν‖₂ ≤ ‖C₋w‖₂/(1 − ρ), and derive continuous and Banach-holomorphic parameter dependence from the resolvent identity when w depends in L² ∩ L∞. Weighted coefficient asymptotics are exported only through §1.4.

The operator construction produces a matrix-valued analytic boundary-jump solution. A determinant-one and everywhere invertible matrix solution additionally uses the determinant extension and normalization criterion of §1.2; det J = 1 alone is not a proof of det R = 1. A problem outside the small-norm domain may still be solvable: it needs a different inverse, a vanishing lemma, or another separately verified argument. Nor does an arbitrary small L² jump specify a meromorphic connection with designated singularities. Undoing a geometric parametrix reduction and identifying the resulting connection and its horizontal variation are downstream application tasks. (ILP18, §3.3, Lemma 3.3 is a concrete application; the general norm-gap theorem and its hypotheses are owned here.)

**API.**

- Construct the inverse of id − C_w, the density ν, the jump density h and the unique solution R in the prescribed Cauchy class.
- Prove the quantitative inverse and error bounds and continuous or Banach-holomorphic dependence in the stated jump norms.
- Use the separate determinant-removability criterion to obtain determinant one and matrix invertibility on precisely the verified locus.
- Allow alternative invertibility arguments outside the norm-gap domain without inferring nonsolvability from failure of the small-norm criterion.

**Checks.**

- For w = 0 the construction gives ν = h = 0 and R = I, in agreement with the Cauchy-class uniqueness statement.
- The estimate ‖ν‖₂ ≤ ‖C₋w‖₂/(1 − ρ) records the necessary loss as ρ approaches one; it does not provide a uniform estimate at ρ = 1.
- Failure of the small-norm hypothesis does not prove nonsolvability. On a counterclockwise unit circle the constant jump −I₂ has w = −2I₂ and ‖C_w‖ = 2, yet the solution R_out = I₂, R_in = −I₂ is in the Cauchy class, with h = −2I₂ and determinant one.
- The Neumann-series solution theorem has no prerequisite involving phase-space dimension, a formal connection profile, monodromy selection, or reconstruction of a meromorphic connection.

*Needs:* §1.2’s verified Cauchy operators and solution class; bounded-operator Neumann series, the resolvent identity and Banach-holomorphic inversion. A geometric reconstruction or a specific asymptotic model is a consumer, not a supplier, of this theorem.

### 1.4 Weighted moments, coefficient expansions and uniform tails

For the family constructed in §1.3, fix an integer m ≥ 0 and write W_m(ζ) = 1 + |ζ|ᵐ. Require W_m w_s ∈ L¹(Γ) ∩ L²(Γ). The identities h_s = w_s + ν_s w_s and Hölder’s inequality give ‖W_m h_s‖₁ ≤ ‖W_m w_s‖₁ + ‖ν_s‖₂‖W_m w_s‖₂. Thus the common small-norm gap and uniform bounds for the displayed weighted norms imply a uniform weighted L¹ bound for h_s. Let a closed angular sector at infinity satisfy the proved contour estimate |ζ − z| ≥ c(|ζ| + |z|) for every ζ ∈ Γ and all sufficiently large z in that sector, with c > 0 independent of the claimed parameters.

For each fixed parameter, prove R_s(z) = I − (2πi)⁻¹Σ_{j=0}^m z⁻ʲ⁻¹∫_Γ ζʲh_s(ζ)dζ + o(|z|⁻ᵐ⁻¹). In particular, the coefficient of z⁻ʲ⁻¹ is −(2πi)⁻¹∫_Γ ζʲh_s(ζ)dζ, with this sign. The exact remainder is (2πi)⁻¹z⁻ᵐ⁻¹∫_Γ ζᵐ⁺¹h_s(ζ)/(ζ − z)dζ. Dominated convergence proves the little-o at a fixed parameter, but uniform weighted norm bounds alone do not make it uniform on a noncompact parameter set. Those bounds do imply uniform R_s = I + O(1/z) in the specified separated sectors. Claims on the rays themselves require additional local sectorial estimates.

For a parameter-uniform little-o, additionally prove weighted-tail tightness: as A → ∞, both sup_s ‖1_{|ζ|>A}W_m w_s‖₁ and sup_s ‖1_{|ζ|>A}W_m w_s‖₂ tend to zero. The same weighted L¹ tail property follows for h_s from the preceding inequality applied on the tail and the uniform ‖ν_s‖₂ bound. Split the exact remainder into a fixed bounded part and its tail: the former tends to zero uniformly and the latter is uniformly small. Sufficient alternatives are a compact parameter set with norm-continuous dependence in both weighted spaces, or uniform bounds for one additional weighted moment. The latter gives the stronger uniform O(|z|⁻ᵐ⁻²) remainder by the same denominator estimate. Every downstream endpoint, collision or asymptotic-normalization argument must verify these controls on its actual parameter set; pointwise dominated convergence is not such a verification.

**API.**

- Transfer weighted moments and weighted-tail tightness from w_s to h_s with the explicit L¹/L² estimate.
- Compute each coefficient at infinity, with its sign, and the exact remainder on a sector with a proved denominator bound.
- Distinguish pointwise little-o, uniform big-O and uniform little-o, exporting the last only with uniform tail control.
- Prove the compact-parameter and extra-moment sufficient criteria, including the stronger next-order big-O from one extra moment.

**Checks.**

- On Γ = ℝ, let w_s(x) = a exp(−(x − s)²)E₁₂ with Re s > 1 and |Im s| < δ, choosing a > 0 so small that a exp(δ²) < 1. This is a Banach-holomorphic small-jump family with uniformly bounded zeroth L¹/L²/L∞ moments, determinant one and exact density h_s = w_s because E₁₂² = 0. Its zeroth moment is M₀ = a√π E₁₂. At s = n and z = in, n(C(w_n)(in) + M₀/(2πi·in)) tends to (a√π/(2πi))((1 − i)/2)E₁₂ ≠ 0. Thus a pointwise o(1/z) remainder need not be parameter-uniform; the translated mass fails the uniform tail condition.
- For the translated Gaussian counterexample, the limiting scalar factor is 1/(1 − i) − i = (1 − i)/2. The coefficient sign and the constant a√π/(2πi) must be retained together.
- On a compact parameter set, continuity in the weighted L¹ and L² norms makes the family uniformly tight in both weighted tails; boundedness alone on a noncompact set does not.
- A uniform (m + 1)-st weighted moment gives an O(|z|⁻ᵐ⁻²) remainder on the same separated sector, while a claim along a contour ray still needs its own local estimate.

*Needs:* §1.3’s density and uniform norm-gap bounds; the contour denominator estimate; weighted L¹/L² inequalities and tail compactness. No particular connection, Painlevé branch, asymptotic parametrix or collision model is a prerequisite.

### 1.5 Normalized section convergence from logarithmic one-forms

Prove a convergence lemma for arbitrary holomorphic line sections, independently of any determinant or differential-equation origin. Let Ω be a common connected simply connected complex domain with a fixed point s₀. Supply holomorphic line bundles L_ε, sections σ_ε, comparison isomorphisms Φ_ε: L_ε → L₀, a nowhere-zero holomorphic frame e of L₀ on Ω, and specified nowhere-zero holomorphic normalization factors c_ε. Write Φ_ε(c_εσ_ε) = f_ε e, including ε = 0, and restrict to a domain where all the f_ε under consideration and f₀ are nowhere zero. Existence of these comparisons and a common nonvanishing domain is input, not a consequence of an unspecified degeneration. Normalization factors may remove divergent factors; their parameter derivatives and the chosen frame must be included in the actual corrected one-forms α_ε = d log f_ε.

For every compact K ⊂ Ω, choose piecewise smooth paths γ_s from s₀ to s ∈ K, contained in a common compact K′ ⊂ Ω and with uniformly bounded lengths in a fixed local metric. Assume f_ε(s₀) → f₀(s₀) ≠ 0 and sup_{s∈K}|∫_{γ_s}(α_ε − α₀)| → 0. Uniform convergence of the one-forms on each such K′ is a sufficient condition. Prove f_ε(s)/f₀(s) = [f_ε(s₀)/f₀(s₀)] exp(∫_{γ_s}(α_ε − α₀)) and hence locally uniform convergence f_ε → f₀. Prove independence of path using the logarithmic-derivative identity; alternatively, closed holomorphic one-forms on the simply connected domain and one nonzero base-point value construct their unique nowhere-zero scalar representatives by exponentiating primitives.

This lemma requires neither a Fredholm realization nor the targets on connections, asymptotic parametrices or collision geometry. Such applications must first construct the line/frame comparisons and prove that their proposed variational forms really equal the displayed logarithmic derivatives. In particular, using a JMU or Hamiltonian expression requires its own proved comparison and does not automatically extend it to a resonant or ramified endpoint. BERT17, Proposition 2.3, formula (3.6), Theorem 3.3 and §3.1.2, and BERT16, Theorem 2.2 on its comparison locus, concern those possible inputs rather than a universal identification. This proof concerns a common nonvanishing domain. Across zeros, use a separate holomorphic representative and, where available, the determinant convergence route of §1.6. Endpoint connection constants and nonlinear Stokes limits require additional uniform sectorial estimates and compatible asymptotic normalization.

**API.**

- Express compared and normalized line sections in one specified frame, including all scalar factors in the actual logarithmic derivative.
- Prove the exponential integral identity and locally uniform scalar convergence from base-point normalization and compact-path estimates.
- Construct nowhere-zero representatives from closed holomorphic one-forms and one nonzero base-point value on a simply connected domain.
- Retain separate obligations for comparison formulas, passage through zeros, and endpoint or connection-constant limits.

**Checks.**

- Multiplying τ_ε by an uncontrolled ε-dependent nonzero constant leaves d log τ_ε unchanged but can destroy convergence; the base-point normalization is essential.
- For τ_ε(z) = z − ε, scalar determinants converge across the zero, while their logarithmic derivatives do not converge uniformly in a neighborhood of it.
- Convergence on every fixed compact time interval does not give a uniform endpoint asymptotic estimate, so it cannot alone determine the limiting connection constant.
- A change of line frame or a parameter-dependent normalization factor changes the logarithmic one-form by its actual logarithmic derivative; the comparison must include this correction before applying the convergence estimate.

*Needs:* Holomorphic line bundles, explicit line/frame comparisons and primitives of closed holomorphic one-forms; the displayed compact-path estimates and normalized base-point values. Neither a Fredholm determinant family nor an admitted collision is required by the general lemma.

### 1.6 Trace-norm determinant convergence and local zero counts

Use the generic trace-class determinant and its trace-norm continuity from RandomMatrices §8.3, within that supplier’s actual operator scope. On one fixed complex Hilbert space H, let K_ε(s) be trace-class operators, holomorphic in trace norm on a common complex domain Ω, and suppose K_ε → K₀ in trace norm uniformly on every compact subset of Ω. Prove that D_ε(s) = det_H(id − K_ε(s)) is holomorphic and converges to D₀ locally uniformly. Uniform bounds of the trace norms on a compact set together with the supplier’s determinant-continuity bound give the required uniform estimate. This is a theorem about scalar holomorphic representatives and can include their zeros; it does not integrate logarithmic derivatives across a zero.

For operators initially acting on different Hilbert spaces H_ε, supply specified bounded complex-linear isomorphisms U_ε: H_ε → H with bounded inverses, transport K_ε by conjugation, and prove the trace-norm convergence of these transported operators. Moving-contour parametrizations, orientation and measure factors must be included in the identification; pointwise convergence of untransported kernels is not the trace-norm hypothesis. If the scalar determinant is to represent a preassigned line section, the application must prove that realization and control any multiplying nonzero scalar factor. This target neither repeats the generic determinant construction nor assumes that every RHP admits this trace-class representation.

For the zero-count consequence, specialize to one complex variable and a bounded domain D with piecewise smooth boundary and compact closure in a common holomorphy domain. Require D₀ to be nonzero on ∂D and not identically zero. Prove that, for sufficiently small ε, D_ε and D₀ have the same number of zeros in D counted with multiplicity, using uniform convergence on the boundary and Rouché’s theorem. Localize this assertion to small disjoint domains around isolated limiting zeros; do not infer an unrestricted global zero-count statement. Endpoint connection constants and nonlinear Stokes limits still require uniform endpoint or sectorial estimates and compatible asymptotic normalization. Convergence on all fixed compact subsets supplies neither condition.

**API.**

- Export holomorphic determinant convergence from compact-uniform trace-norm convergence on a specified fixed Hilbert space.
- Transport varying Hilbert spaces through explicit identifications and record the contour, measure and scalar-normalization obligations required by an application.
- Prove eventual equality of local zero counts with multiplicity under the stated one-variable boundary hypotheses.
- Keep convergence through zeros distinct from logarithmic-derivative convergence and from endpoint or Stokes-constant limits.

**Checks.**

- On H = ℂ take K_ε(z) = 1 − z + ε. Then K_ε converges in trace norm and D_ε(z) = z − ε converges as a holomorphic determinant across the zero, while d log D_ε = dz/(z − ε) does not converge uniformly near that zero.
- The constant family D_ε ≡ ε converges uniformly to the identically zero function; the limiting nonvanishing-boundary hypothesis fails, so no zero-count conclusion follows.
- A moving-contour kernel formula must include the parametrization and measure factors in the transported operator before a trace-norm estimate is a statement about one fixed Hilbert space.
- Convergence on every fixed compact time interval does not give a uniform endpoint asymptotic estimate, so it cannot alone determine the limiting connection constant.

*Needs:* RandomMatrices §8.3’s generic trace-class determinant and trace-norm continuity; OperatorTheory’s complex trace-class carrier; holomorphic-function theory and Rouché’s theorem. No Fredholm-line degeneration, geometric collision, small-norm RHP or Painlevé selection is a prerequisite.

## Source scope and inherited safeguards

The stable source keys and byte-provenance records remain in the parent [sources.toml](../../sources.toml). The source models are [MAL04](https://www.numdam.org/articles/10.5802/aif.2052/), [BERT17](https://arxiv.org/abs/1703.00046v4), corrected [BERT16](https://arxiv.org/abs/1601.04790v2), and [ILP18](https://arxiv.org/abs/1604.03082v4), at the locators stated above. These references are not asserted to prove the entire general contract.

All three original determinant-family checks are retained in 1.1. The endpoint ghost, the noncompact-contour L² issue, the separate determinant-removability obligation, the ρ = 1 loss and the solvable non-small jump are retained in 1.2–1.3. The translated Gaussian, including its exact sign and constant, and the uniform-tail and extra-moment distinctions are retained in 1.4. The normalization-constant, moving-Hilbert-space, zero and endpoint caveats are retained in 1.5–1.6. A connection reconstruction theorem or a collision comparison is a downstream adapter, not an implicit assumption of any generic analytic result.
