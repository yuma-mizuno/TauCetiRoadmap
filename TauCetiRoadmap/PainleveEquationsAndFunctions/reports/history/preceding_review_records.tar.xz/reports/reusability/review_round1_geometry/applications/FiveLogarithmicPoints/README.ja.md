# FiveLogarithmicPoints：五つの対数極

> **展開した第二の利用例・数学ドラフト。** 各項目は明示的構成・具体例を備えた証明目標であり、一般枠組みのすべての証明が完了したという宣言ではない。[English](README.md)。

この適用は、実際の証明再利用を検査する。許容入力の構造的次数は 5、時間基底の次元は 2、相ファイバーの次元は 4 である。一般の構成・延長・降下には古典的適用と同じ証明を用い、パンルヴェの目標は前提にしない。

## 1.1 五つの対数極と空でない安定入力

順序付き五点をもつ種数 0 の曲線をとる。最初の三点を 0、1、∞ に送る一意な正規化の後、時間基底は B = {(t₁,t₂) ∈ ℂ² : t₁,t₂ ∉ {0,1}, t₁ ≠ t₂} と表示される。したがって dim B = 2 は標識曲線の商から得る結論であり、B の座標はその商の表示である。階数 2、構造的因子 P = a₁+⋯+a₅、同定を指定した行列式 (O,d) とその自明な強い時間移送、順序付き留数対 (1/4,−1/4)、(1/4,−1/4)、(1/6,−1/6)、(1/6,−1/6)、(1/4,−1/4) をもつ完全対数的旗を用いる。i=1,…,5 に対して重み αᵢ,₁ = i/100、αᵢ,₂ = i/100 + 2ⁱ⁻¹/1000 を選ぶ。十個はすべて異なり、0<αᵢ,₁<αᵢ,₂<1 である。階数 1 の安定性の壁では 2deg F + Σᵢ εᵢ2ⁱ⁻¹/1000 = 0（εᵢ=±1）が必要になるが、符号和の分子は奇数で絶対値は 31/1000 以下なので成立しない。したがって、この数値データでは安定と半安定が一致する。これらを MeromorphicConnectionModuli §§1.1–1.2 の入力とする。古典的な次数 4 の条件を課さない。

相空間の点を仮定せず、すべての配置について非空性を証明する。γ₁⋯γ₅ = 1 を満たす生成元に対し、D = diag(i,−i)、J = [[0,1],[−1,0]]、K = diag(exp(πi/3),exp(−πi/3))、(M₁,…,M₅) = (D,J,K,K⁻¹,(DJ)⁻¹) とする。積は I であり、各局所スペクトルは相異なる。D と J に共通不変直線がないため、この表現は既約である。exp(−2πiλ) に対応する指定した対数と、必要なら標準拡張からの局所対数格子の変更を用いた確定特異対応により、各標識曲線上に指定した留数・旗をもつ対数接続が得られる。ここで用いるのはモノドロミーの既約性であり、留数行列に定数の共通固有直線がないという条件ではない。

トレース留数は零で、行列式モノドロミーは自明である。したがって行列式の対数接続は、ℙ¹ 上の極をもたない平坦線束接続へ延び、(O,d) と同型になる。その同定を選ぶ。不変な真部分束がないので、選んだ重みについて安定である。追加の確認として、各極で一つずつ留数を選んだ和は [3(σ₁+σ₂+σ₅)+2(σ₃+σ₄)]/12、σᵢ ∈ {−1,1} と書ける。分子は奇数なので整数にはならない。これも留数・次数関係によって階数 1 の不変部分接続を排除する。B 全体でファイバーが非空であることを証明し、B 上の大域的標識付き対象を仮定しない。

**入力条件**

- ℙ¹ 上の順序付き相異なる五点、指定した階数・対数留数・行列式の同定・一般の重みを用いる。時間の商の二次元性と安定ファイバーの非空性は出力である。

**構成・法則（API）**

- `fivePointAdmittedInputLaw1` — 標識曲線の実際の商を B と同定し、その固定された衝突判別集合を確認する。
- `fivePointAdmittedInputLaw2` — 既約モノドロミーの具体例、その指定対数による拡張、行列式の同定を構成する。
- `fivePointAdmittedInputLaw3` — 階数 2 の基礎束を自明と仮定せず、安定ファイバーの非空性を確認する。

**検証事項**

- `fivePointAdmittedInputCheck1` — 積 D J K K⁻¹ (DJ)⁻¹ は厳密に I である。D の固有直線は座標軸であり、J はそれらを入れ替える。
- `fivePointAdmittedInputCheck2` — 留数差は 1/2 または 1/3 で非共鳴である。符号付き和の分子は奇数で、整数となる場合をすべて排除する。
- `fivePointAdmittedInputCheck3` — 五極を四極に置き換えると時間次元は 2 から 1 へ変わり、単なるチャート変更ではない。
- `fivePointAdmittedInputCheck4` — 留数行列に定数の共通固有直線がないことだけでは、微分加群の既約性の証拠にならない。

**Needs:** framework:MeromorphicConnectionModuli/1.1; framework:MeromorphicConnectionModuli/1.2; roadmap:ComplexComparisonPartII §C5.6 regular-singular correspondence, with chosen-logarithm lattice comparison.

**文献と証明範囲：** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 1.2 相空間四次元の平坦シンプレクティック力学系の構成

§1.1 で確認した入力に MeromorphicConnectionModuli §3.4 を適用する。その出力は、許容される次数 0 の束の型をすべて保持した全安定相空間族 π: M → B、相対トレース・シンプレクティック形式 ω、および構成された正則平坦分裂 h である。種数 0 における行列式固定との比較を確認する。一般次元公式は 2·2²(0−1)+2+2(2−1)·5 = 4 を与え、この場合に行列式を固定して除かれる方向は 2g = 0 である。滑らかさとシンプレクティック性は構成の出力であり、入力の項目にしない。モジュライ構成が ω の実際の保存を証明した後で、NonlinearConnections §1.6 により閉じた全二形式を得る。可換な二つの水平時間方向は内在的に存在し、Garnier のスカラー公式や Hamilton 座標を用いない。

**入力条件**

- 1.1 の確認済み入力と非空性を用いる。相空間・分裂・シンプレクティック形式を入力として与えない。

**構成・法則（API）**

- `fivePointConstructedDynamicsLaw1` — 一般構成の許容条件と行列式比較を確認する。
- `fivePointConstructedDynamicsLaw2` — 同じ非線形接続対象、相対次元 4、閉じた全形式を提供する。
- `fivePointConstructedDynamicsLaw3` — 引戻しと表示の比較を同定し、時間次元 2 を保持する。

**検証事項**

- `fivePointConstructedDynamicsCheck1` — ファイバー次元は −8+2+10=4 で、2 ではない。deg P=5 を古典的な予算に置き換えない。
- `fivePointConstructedDynamicsCheck2` — 平坦性だけでは e^{t₁}ω を保存しない。実際の保存定理を適用しなければならない。
- `fivePointConstructedDynamicsCheck3` — 大域的モジュライ族を、自明束上の行列チャートで置き換えない。

**Needs:** target:1.1; framework:MeromorphicConnectionModuli/3.4; framework:NonlinearConnections/1.6.

**文献と証明範囲：** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 1.3 確認された固有 RH 比較

この対数モジュライ問題に、I13 Theorem 2.2 に基づく MeromorphicConnectionModuli §§4.1–4.2 を用いる。g=0、r=2、n=5、rn−2r−2 = 4 > 0、および一般の安定性重みを確認する。階数 1 の行列式比較と、実際の粗モジュライ・gerbe の比較を用いて、構成した行列式固定モジュライを I13 の族の同じ行列式ファイバーと同定する。指数パラメータの写像 λ ↦ exp(−2πiλ) とのファイバー積で留数パラメータを保持した、標識付き指標族を用いる。固有性は、この実際の族の写像についての定理であり、証明した Cartesian な基底変換比較から受け取る。§1.1 の仮定にはせず、葉層の存在からも推測しない。

同 §4.1 の完備な Betti 経路移送を用い、§1.2 の強い分裂がすべての部分水平持ち上げをこの移送へ送ることを証明する。源と標的の比較には許容された全モジュライを用い、選んだ束のチャートへ制限しない。ここで利用するのは確定特異な定理である。一般の不確定特異点の固有性や、古典的パンルヴェの延長定理は取り込まない。

**入力条件**

- 1.1–1.2 の実際の対数入力と構成された接続、確認した I13 の数値範囲、行列式・標識の比較を用いる。固有性と部分持ち上げとの両立性は、一般定理を通じて確認する結論である。

**構成・法則（API）**

- `fivePointProperRhLaw1` — 行列式固定後の正確な I13 モジュライと、指数パラメータを保持する Betti 標的を同定する。
- `fivePointProperRhLaw2` — 証明された Cartesian 比較による固有性と、全点での水平両立性を確認する。

**検証事項**

- `fivePointProperRhCheck1` — この場合は 2·5−4−2=4>0 である。種数・階数・極数の不等式を確認せず原典の定理を適用しない。
- `fivePointProperRhCheck2` — 対数を忘れて指数値だけを保持すると、固有性の主張を失う。
- `fivePointProperRhCheck3` — RH の固有性は π: M→B の固有性を意味しない。

**Needs:** target:1.1; target:1.2; framework:MeromorphicConnectionModuli/4.1; framework:MeromorphicConnectionModuli/4.2.

**文献と証明範囲：** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 1.4 完備移送の再利用とその正確な範囲

§1.3 に NonlinearConnections §1.4 を適用し、B 内の任意のコンパクトな区分的 C¹ 経路に対し、各ファイバーのすべての点を通る一意な水平持ち上げを得る。同枠組みの §1.3 から正則な局所芽、§1.5 から基本亜群の作用と基点付き普遍被覆上の大域水平切断、§1.6 からシンプレクティック保存を得る。作用と切断は構成された平坦接続の出力であり、その非線形モノドロミー作用で初期点が固定される場合に、ちょうど B へ降下する。

これは、古典的族に使うものと同じ一般の延長・降下の証明の、実際の第二の利用例である。推移的な依存閉包に、PainleveEquationsAndFunctions の目標、形式プロファイルの列挙、加法型曲面分類、スカラーのパンルヴェ公式を含めてはならない。直接の import だけでなく、展開したグラフでこの条件を検査する。

相ファイバー二次元の場合のスカラー第一ジェット定理を、この四次元ファイバーに適用しない。また、二次元基底上で一変数の極の主張をしない。正則な時間曲線 C→B と、引戻しが定義され非恒等的無限大条件を満たす許容観測量を別途与えた場合には、基底変換と NonlinearConnections §1.7 を用いて、その曲線上での有理型評価を得る。将来の Garnier 座標辞書は下流の比較であり、ここの目標の前提にはしない。

**入力条件**

- 1.2–1.3 の構成済み平坦シンプレクティック接続と確認済み固有半共役を用いる。曲線上の観測量についての追加結論には、指定した曲線と許容性のデータも必要である。

**構成・法則（API）**

- `fivePointCompleteTransportLaw1` — 時間二次元・相空間四次元の族に、同じ完備性と亜群作用の定理を適用する。
- `fivePointCompleteTransportLaw2` — 古典的適用への推移的依存がないことを確認する。
- `fivePointCompleteTransportLaw3` — 追加仮定をすべて付した、一変数の観測量引戻しを述べる。

**検証事項**

- `fivePointCompleteTransportCheck1` — 展開した前提グラフは、次数 4 の定義を含むすべてのパンルヴェ目標を除外する。
- `fivePointCompleteTransportCheck2` — 完備移送でもモノドロミーは非自明になりうる。普遍被覆上の切断が降下するとは限らない。
- `fivePointCompleteTransportCheck3` — 時間曲線に制限しても相ファイバーは四次元で、スカラー第一ジェットのファイバーは二次元である。スカラー第一ジェット同型をそのまま主張できない。

**Needs:** target:1.2; target:1.3; framework:NonlinearConnections/1.3; framework:NonlinearConnections/1.4; framework:NonlinearConnections/1.5; framework:NonlinearConnections/1.6; framework:NonlinearConnections/1.7.

**文献と証明範囲：** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 文献

- **I13:** Michi-aki Inaba, *Moduli of parabolic connections on a curve and Riemann–Hilbert correspondence*, [arXiv:math/0602004v2](https://arxiv.org/abs/math/0602004v2), Theorems 2.1–2.2; journal publication J. Algebraic Geom. 22 (2013), 407–480.
- **I23:** Michi-aki Inaba, [*Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation*](https://sigma-journal.com/2023/013/), SIGMA 19 (2023), 013.
