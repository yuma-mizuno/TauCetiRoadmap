# MeromorphicConnectionModuli

> **Independent mathematical framework — draft.** This is a proposed upstream owner, with its own inputs, twelve theorem/construction targets and output contracts. It is not an alias for a specialized phase space. Statements below are proof targets; review completion does not claim that their mathematical proofs have all been supplied. The English target statements, hypotheses, APIs, tests and Needs entries are synchronized with `plan.json`. [日本語版](README.ja.md).

## What is reusable

The construction takes decorated meromorphic-connection data and produces a moduli family together with its **constructed** flat symplectic nonlinear time connection. A consumer supplies admission data and then uses one theorem, §3.4. Genus zero, rank two, structural polar degree four, one time variable, a named scalar equation and a classified surface are absent from the general hypotheses.

| Input the consumer must provide | Output constructed by this framework |
| --- | --- |
| An admitted curve, polar divisor and local decorations | The stack and rigidified stable moduli on all permitted bundle types |
| A genuine admitted time family and stability chamber | The actual horizontal splitting, flatness and pullback comparisons |
| Determinant mode and its verified conditions | Correct determinant-fiber comparison and dimension theorem |
| Nonemptiness evidence for a claimed full base | A surjective holomorphic nonlinear-connection carrier on that base |
| No scalar equation or Hamiltonian is required | Relative symplectic form, its preservation and the closed total form |

The local scope is deliberately exact: logarithmic full-flag conditions, generic unramified irregular conditions, and the generic totally ramified factorized conditions specified in §1.1. A new local singularity class requires an admission/construction theorem before it can use this export. Logarithmic resonance is retained through flags and lattices. Nonempty fibers, global fixed-determinant transport and positive-genus fixed-determinant smoothness have separate verification obligations.

## Dependency and ownership boundary

The geometric construction uses `NonlinearConnections/1.1` (carrier, morphisms and pullbacks) and `NonlinearConnections/1.6` (generic differential-form calculus). The optional logarithmic branch also uses `NonlinearConnections/1.3` for local horizontal sections. They do not supply the geometric horizontal splitting or preservation of its trace form: §§3.1–3.2 prove those properties for this construction. Foundational inputs are standard curve/bundle, stack/moduli, coherent-cohomology, formal local algebra and complex-geometry interfaces listed in the structured plan. No specialized consumer is an upstream prerequisite.

The main owned extensions beyond a source formula are the intrinsic presentation groupoid, certified determinant transport, the full trace-free/trace comparison including ramified relations, early finite-flat unfolding, and coherent comparison maps. In particular, removing a scalar stabilizer is not the same as removing the 2g-dimensional determinant deformation space.

## Common consumer certificate

A consumer identifies its local models and verifies the open generic conditions; specifies its actual time family and markings; chooses unfixed determinant or verifies the fixed determinant and its rank-one time transport; chooses a valid stability chamber; and provides nonemptiness evidence wherever it claims a surjective family. It then invokes §3.4. Completeness, proper Riemann–Hilbert comparison, scalar observables, distinguished solutions and classification results are further consumer obligations.

The five-logarithmic-point rank-two problem on ℙ¹ is a decisive reuse check: when nonempty with compatible fixed determinant, the construction gives phase dimension four over a two-dimensional configuration base. This checks mathematical scope beyond relative dimension two; its explicit existence certificate belongs to the separate consumer. The optional §§4.1–4.2 branch additionally supplies a proper logarithmic Riemann–Hilbert semiconjugacy in the exact I13 range. The same consumer can then apply the general continuation theorem of NonlinearConnections §1.4, without any five-point-specific compactness theorem.

## Layer 1: Admitted geometric inputs and time problems

### 1.1 Admitted decorated connection data

Define a groupoid fibered over complex bases whose objects are smooth proper connected curve families, a nonempty ordered set of disjoint marked sections, a structural polar divisor P = Σ mᵢaᵢ, an integer rank r ≥ 1 and degree d, and the local data below. Construct both the unfixed-determinant problem, with all local trace polar data prescribed, and its fiber over a specified compatible line connection (L,∇L); in the latter an isomorphism det(E,∇) ≅ (L,∇L) is part of the object. A connection is a locally free sheaf on the entire curve with a relative meromorphic connection and the chosen decorations, not merely a matrix on a trivial-bundle chart. Morphisms are actual compatible bundle isomorphisms.

The initial admitted domain consists precisely of the local models in I23 §§2–5: logarithmic poles m=1 with full flags and specified graded residues, including resonant and repeated residues; generic unramified poles m≥2 with full filtrations on ma and pairwise distinct leading eigenvalues; and totally ramified generic poles of rank r≥2, m≥2, with wʳ=z and ν(w)=Σₖ₌₀ʳ⁻¹νₖ(z)wᵏ, where ν₀=Σⱼ₌₀ᵐ⁻¹a₀ⱼzʲdz/zᵐ, νₖ=Σⱼ₌₀ᵐ⁻²aₖⱼzʲdz/zᵐ for k≥1, and a₁₀ is invertible. For the last model construct the finite-level factorized ramified structures, their relations and equivalence with the formal model. Roots and formal coordinates are presentations with descent arrows. Mixed blocks, arbitrary slopes, leading-eigenvalue collisions and vanishing a₁₀ require separate extensions of this admitted domain.

Choose rational stability weights in a chamber with stable = semistable whenever that chamber is used; stability tests ∇-invariant proper subbundles. Establish Cartesian pullback with coherent isomorphisms. The initial domain is a source-supported scope for a reusable theory, not a list of classical scalar equations.

**Hypotheses**

- Complex smooth proper connected curve families; r≥1, d∈ℤ; nonempty disjoint marked sections with structural multiplicities; the three explicitly admitted local models; a chosen weight chamber.
- The determinant-fixed mode additionally includes the line connection and its determinant identification, with matching trace polar data and residue/degree relation.

**API**

- `admittedConnectionDataLaw1` — Construct restrictions, pullbacks, composition and inverse of arrows, with the associator and identity laws.
- `admittedConnectionDataLaw2` — Identify the underlying formal differential module, the induced connection on End⁰(E) of rank r² − 1, and the associated PGLᵣ connection. These latter two are the invariant adjoint/projective outputs. The local matrix A − tr(A)I/r represents the projective connection in a frame; it is not a canonically glued rank-r differential module on E. No square root of the determinant line is chosen.
- `admittedConnectionDataLaw3` — Compare equivalent local presentations by ramified descent, keeping parabolic flags and logarithmic lattices.
- `admittedConnectionDataLaw4` — Express determinant compatibility by an isomorphism of line connections; derive the residue/degree equation in a chosen local convention.

**Tests and falsification cases**

- `admittedConnectionDataCheck1` (non-example) — On E = O ⊕ O(−1), the determinant has odd degree; a putative global half-determinant twist does not exist. The carrier must still allow this bundle when the prescribed determinant matches it.
- `admittedConnectionDataCheck2` (compatibility) — Two logarithmic residues with the same repeated eigenvalue, one scalar and one nonzero Jordan block, are not identified by specifying the eigenvalues. Their allowed parabolic objects and monodromy differ.
- `admittedConnectionDataCheck3` (non-example) — Changing the root w to −w in a rank-two ramified chart changes the displayed branches but gives an equivalent descended object; forgetting the descent arrow fails this check.
- `admittedConnectionDataCheck4` (compatibility) — With I23's ramified convention, a rank-two ramified point contributes 2c + 1/2 to the residue/degree relation. Replacing it by 2c changes that relation by 1/2.
- `admittedConnectionDataCheck5` (computation) — Rank zero is rejected before slope stability or the dimension formula is applied. At r = 1 the adjoint bundle End⁰(E) has rank zero, without changing the required positive rank of E.
- `admittedConnectionDataCheck6` (computation) — For A = 0 and frame change g = diag(z,1), g⁻¹dg = diag(1,0)dz/z; subtracting half its trace gives diag(1/2,−1/2)dz/z. The scalar discrepancy prevents gluing a rank-two trace-subtracted connection on E, while the induced End⁰(E) and PGL₂ connections glue.

**Prerequisites:** Foundational inputs only.

**Needs:** Standard algebraic curve and bundle families, formal differential modules, finite ramification and descent, stacks, and parabolic stability. The intrinsic local-data groupoid and all comparison maps are constructed here.

**Source scope and owned proof:** I23, Definitions 2.1, 2.2, 2.4, 2.7–2.8; Definition 3.1, Proposition 3.3, Corollaries 4.3–4.4 and §5. Coordinate-independent packaging and 2-coherent descent are owned proof obligations, not assertions that I23 already proves that packaging.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 1.2 Admitted time families and determinant transport

Construct the deformation groupoid of the curve, marked poles and admitted irregular polar coefficients, keeping logarithmic residues and formal residue exponents fixed. Start from a smooth atlas of the pointed-curve stack with the finite coordinate jets and open coefficient conditions of I23 §5. Build the coordinate-change arrows and descent, rather than assuming a coarse curve moduli space has no automorphisms. Let B be a smooth complex chart, marking cover, or base change of this admitted time problem whose new base is smooth. The coefficient discriminants and collisions removed from B are fixed by input data. A topological marking of the punctured family is constructed locally and compared on overlaps; an arbitrary topological deformation is not declared an allowed time family.

In unfixed-determinant mode no determinant section is selected. In fixed-determinant mode require a certified strong rank-one transport of the specified determinant: a compatible integrable total line connection, with the induced trace polar data and fixed residues. Construct this rank-one transport locally on a marked contractible time chart by extending the fixed rank-one local system and gluing the prescribed logarithmic lattices and polar primitives; verify its restriction to the initial determinant, polar bound, and cocycle laws. The logarithmic genus-zero case must also have an explicit dlog construction. Global fixed-determinant output requires actual gluing data for these local transports, or a supplied line connection with the same verified properties. A freely varying family of determinant connections is not accepted on the strength of the residue condition alone. This rank-one construction is an owned preliminary result, independent of the rank-r horizontal splitting of §3.1.

Separate external exponent parameters from these time directions. Strong isomonodromy will preserve transported analytic data under admitted variation of irregular type; it does not mean that the irregular coefficients in a fixed coordinate are frozen. No analytic Stokes classification is a premise of the algebraic construction.

**Hypotheses**

- The decorated local data of 1.1 with fixed residue exponents; curve, polar-coefficient and marking variations obtained from the stated admitted time groupoid.
- For fixed determinant, the rank-one transport certificate constructed here or supplied with its verified pole, integrability, initial-value and gluing conditions.

**API**

- `admittedTimeDeformationLaw1` — Separate tangent directions along the admitted time base B from variation in the external residue/exponent parameter θ, and compare the pullback tangent sequence.
- `admittedTimeDeformationLaw2` — Construct marking changes and local time reparametrizations with their coherence laws.
- `admittedTimeDeformationLaw3` — Identify the collision and vanishing-leading-term discriminant from the input, independently of initial conditions.
- `admittedTimeDeformationLaw4` — Construct and certify local rank-one determinant transports, including the genus-zero logarithmic dlog model, and state the exact gluing datum required for global fixed-determinant output.

**Tests and falsification cases**

- `admittedTimeDeformationCheck1` (computation) — Five ordered logarithmic points on ℙ¹ have two time moduli after quotient by PGL₂: 5 − 3 = 2; their configuration is independent of initial conditions.
- `admittedTimeDeformationCheck2` (computation) — A change τ = 2t multiplies the displayed horizontal generator by 1/2; retaining its coefficient unchanged gives a different parametrized system.
- `admittedTimeDeformationCheck3` (non-example) — Two solutions with different movable pole sets use the same Bθ. A base that deletes one solution's poles fails this requirement.
- `admittedTimeDeformationCheck4` (non-example) — On a fixed positive-genus curve, changing a line connection by tη with nonzero holomorphic η generally changes a period and hence its rank-one monodromy. Fixed residues alone cannot certify a strong determinant transport.

**Prerequisites:** `target:1.1`

**Needs:** §1.1; smooth atlases of pointed-curve stacks, jet bundles, local topological trivializations of smooth punctured-curve families, and rank-one logarithm/exponential gluing. This target owns the rank-one transport comparison.

**Source scope and owned proof:** I23 §5 constructs the curve/jet/coefficient time scheme and §§10–11 use it. The general determinant-transport and coordinate-descent interfaces are additional owned obligations; they cannot be replaced by a claim that every determinant family admits a lift.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

## Layer 2: Moduli, deformation theory and relative symplectic form

### 2.1 Stable moduli on all bundle types

Construct the stack of stable objects of §1.1 over the admitted time problem §1.2, its scalar rigidification and its relative coarse moduli space. Use bounded parameter spaces of filtered bundles and impose the connection and factorized-structure relations. Prove the moduli universal property, separatedness and finite type, with quasi-projectivity in the source-supported setting. Work with all permitted bundle types. A matrix presentation covers only its actual locus. Construct an étale universal-object cover and descend all subsequent tensors; do not assume a universal vector bundle on the coarse space.

In unfixed-determinant mode the stable scalar inertia is Gm. With a specified determinant identification it is μr; determinant fixing and rigidification are different operations. Construct the determinant morphism and the comparison with the moduli problem having specified determinant, reserving the smoothness and relative dimension calculation for §2.3. Establish the needed coarse-space base-change comparison through these local gerbe presentations. Nonemptiness is an additional consumer assertion, not a theorem for every numerical input. Locally empty moduli are retained; the family becomes a surjective analytic submersion only after restricting B to its open nonempty-fiber locus.

**Hypotheses**

- The numerical and admitted local data of 1.1 and the time family of 1.2; a fixed stability chamber; all bundle types. No nonemptiness assumption is imposed on the construction.

**API**

- `stableDecoratedModuliLaw1` — Identify geometric points and families up to the appropriate arrows, with an explicit coarse-map universal property.
- `stableDecoratedModuliLaw2` — Prove restriction and admissible base-change comparisons, including determinant fibers.
- `stableDecoratedModuliLaw3` — Compare framed charts with their actual moduli loci. Fixed splitting-type strata on ℙ¹ are locally closed; the balanced locus is open, including the trivial-bundle locus in degree zero. Prove each inclusion and closure comparison, and record the complement of every chart used.
- `stableDecoratedModuliLaw4` — For a change of weights, identify the actual common stable locus and the resulting comparison there; do not export an automatic global isomorphism.

**Tests and falsification cases**

- `stableDecoratedModuliCheck1` (non-example) — A stable object may have scalar automorphisms before rigidification. A set-valued quotient that claims all stabilizers were trivial fails this example.
- `stableDecoratedModuliCheck2` (characterisation) — A family can leave a trivial-bundle chart by bundle jumping while remaining in the moduli space. Its phase path is not declared singular for that reason.
- `stableDecoratedModuliCheck3` (computation) — In the extension family 0 → O(−1) → E_t → O(1) → 0, E₀ = O(−1) ⊕ O(1) while E_t = O ⊕ O for t ≠ 0. The two splitting strata pull back to {0} and its complement in A¹; the first is not open. The full connection moduli must retain such bundle jumps on the permitted connection locus.
- `stableDecoratedModuliCheck4` (characterisation) — An admitted totally ramified generic local model is irreducible as a formal differential module, hence a global connection containing it has no proper ∇-invariant subbundle and is stable for every weight (I23 Remark 2.9). This assertion is not exported to arbitrary ramified blocks.

**Prerequisites:** `target:1.1`, `target:1.2`

**Needs:** §§1.1–1.2; boundedness, Quot constructions, geometric invariant theory, scalar rigidification and étale descent. Smoothness, dimension and symplecticity are not inputs.

**Source scope and owned proof:** I23 Theorem 5.1 and §§7–10; fixed-determinant and coarse-base-change comparisons are explicitly constructed extensions of the displayed moduli problem.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 2.2 The differential-operator deformation complex and trace pairing

Construct the deformation complex from infinitesimal endomorphisms preserving the local structures, permitted variations of the connection, and all relations of the factorized ramified structures. Begin with the two-term connection complex G•. In the ramified case retain the full cone F• = Cone(G• → S•ram[1])[−1], including degrees 0, 1 and 2, both differentials and the local factorization terms. A two-term replacement requires a proved quasi-isomorphism. Identify infinitesimal automorphisms, tangent vectors and obstruction classes by hypercohomology and construct the trace/Serre-duality pairing.

The commutator with ∇ is a ℂ-linear first-order differential operator and is generally not O-linear. Work with sheaves of ℂ-vector spaces, coherent underlying terms, Čech totalization and the actual termwise duality calculation; do not silently place this differential in D(QCoh). Prove presentation and cover independence by chain maps and quasi-isomorphisms. Construct the trace morphism to the determinant deformation complex and its trace-free fiber, with signs and local factorization compatibility. This target supplies the comparison maps; §2.3 must prove the resulting smooth determinant-map and dimension statements. Scalar gauge automorphisms and genuine infinitesimal determinant variation are separate directions.

**Hypotheses**

- The stable moduli problem of 2.1 with the admitted filtrations and factorized ramified relations; either unfixed determinant or its specified fiber. The complex and pairing are outputs.

**API**

- `decoratedDeformationComplexLaw1` — Give the differential, local compatibility equations and the map from an infinitesimal family to its cocycle.
- `decoratedDeformationComplexLaw2` — Prove gauge-change and coboundary compatibility in both directions.
- `decoratedDeformationComplexLaw3` — Construct the trace-free/determinant decomposition and the dual complex with its signs.
- `decoratedDeformationComplexLaw4` — Prove naturality of the pairing under input isomorphisms and admissible base change.

**Tests and falsification cases**

- `decoratedDeformationComplexCheck1` (compatibility) — An infinitesimal gauge change by u changes a connection representative by the commutator differential of u; its tangent class is zero.
- `decoratedDeformationComplexCheck2` (characterisation) — Without determinant identification stable scalar automorphisms have a one-dimensional infinitesimal direction. Fixing the identification removes that direction in characteristic zero, although finite μr remains until rigidification; this does not remove the 2g determinant deformation directions by itself.
- `decoratedDeformationComplexCheck3` (computation) — With ω = dq ∧ dp, the ordered tangent pair (∂q, ∂p) has pairing +1 and the reversed pair −1; a reversed trace convention must be corrected before transport formulas are used.

**Prerequisites:** `target:2.1`

**Needs:** §2.1; Čech hypercohomology, coherent cohomology, Serre duality and infinitesimal deformation theory. The differential-operator adapter, complete ramified cone and trace-free comparison are owned here.

**Source scope and owned proof:** I23 §6, (6.9), Proposition 6.3 and §7, Proposition 7.2. The fixed-determinant fiber and its compatible trace-free complex are explicit owned comparisons.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 2.3 Smoothness, dimension and the determinant fiber

Use §2.2 to prove obstruction vanishing and smoothness of the stable moduli family in the admitted domain. Identify its relative tangent bundle by first hypercohomology. For unfixed determinant and a nonempty stable fiber, derive dim M_b = 2r²(g−1)+2+r(r−1)deg P. The local trace polar parts are fixed in this formula.

For the fixed-determinant export, construct the determinant moduli of line connections with those trace polar parts, locally an affine bundle of rank g over Picᵈ(C_b), and prove that its tangent complex is the regular de Rham complex O_C → Ω¹_C. Over ℂ, build a compatible trace map and scalar section using 1/r at the full deformation-complex level, including ramified relations. Prove the induced determinant map is smooth on the stated stable locus, with surjective tangent map onto a 2g-dimensional determinant tangent space. Identify the specified-determinant coarse family with the relevant fiber after its gerbe comparison. Only then deduce dim M_b^det = 2(r²−1)(g−1)+r(r−1)deg P. Prove that the trace pairing splits orthogonally into the trace-free and scalar directions and is nondegenerate on the fixed-determinant tangent space. Rank-one fixed-determinant fibers are zero-dimensional.

The determinant comparison, including deformation functor, smoothness and orthogonality, is a separately owned proof obligation. No positive-genus fixed-determinant dimension or symplectic export is marked available until it is discharged. This restriction changes neither the unfixed-determinant source theorem nor the genus-zero dimension agreement.

**Hypotheses**

- The moduli construction of 2.1 and actual complex and trace pairing of 2.2; the admitted local models over ℂ.
- Dimension assertions concern nonempty stable fibers. The fixed-determinant conclusion additionally requires the determinant-map comparison proved in this target.

**API**

- `smoothModuliAndDeterminantFiberLaw1` — Identify the relative tangent sheaf and prove base-change compatibility for tangent and obstruction calculations.
- `smoothModuliAndDeterminantFiberLaw2` — Construct the determinant deformation map, its scalar section and the trace-free fiber, including all local compatibility equations.
- `smoothModuliAndDeterminantFiberLaw3` — Prove smoothness and orthogonal trace decomposition before subtracting 2g determinant directions.
- `smoothModuliAndDeterminantFiberLaw4` — Return separate unfixed- and fixed-determinant dimension theorems with their exact hypotheses.

**Tests and falsification cases**

- `smoothModuliAndDeterminantFiberCheck1` (computation) — Genus zero, rank two and degree four give −8 + 2 + 8 = 2; structural degree five instead gives 4.
- `smoothModuliAndDeterminantFiberCheck2` (non-example) — Fixing the determinant in positive genus removes 2g directions when the determinant-map comparison applies; the genus-zero coincidence cannot be exported unchanged.
- `smoothModuliAndDeterminantFiberCheck3` (computation) — At r = 1 and g = 1 the unfixed-determinant formula gives 2, and fixing the entire line connection gives 0. The rank-zero input that would incorrectly give 2 is outside the domain.
- `smoothModuliAndDeterminantFiberCheck4` (computation) — For g=1, r=2 and deg P=1, the unfixed formula gives 4 and the fixed-determinant formula gives 2 whenever the corresponding stable fiber is nonempty and the comparison holds; removing only the scalar stabilizer would miss this difference.

**Prerequisites:** `target:2.1`, `target:2.2`

**Needs:** §§2.1–2.2; infinitesimal smoothness, Riemann–Roch, Picard varieties and rank-one de Rham cohomology. The determinant-map comparison is not imported from a genus-zero calculation.

**Source scope and owned proof:** I23 Theorem 7.5 and its determinant-obstruction argument; fixed-determinant smoothness, full cone splitting and orthogonality are owned extensions with a separate completion gate.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 2.4 Early finite-flat unfolding and the closed symplectic form

Construct the relative trace two-form on the moduli family, descend it from the universal-object cover and prove nondegeneracy using §2.2 and §2.3. Prove closedness by the following auxiliary construction here, before any limiting-system or confluence application. Over a smooth integral auxiliary base H, replace the fixed polar divisor by the finite-flat divisors of I23 §8. At a ramified point use ∏ⱼ₌₁ᵐ⁻¹(z−hʳqⱼ)(z−hʳ), with qⱼ distinct, nonzero and different from 1. Construct the moduli algebraic space of simple connections with the unfolded factorized local structures, an étale universal-object cover, the relative deformation complex and trace form. Reapply the boundedness and deformation arguments to this new family; it is not covered merely by §1.1's disjoint marked sections.

Prove smoothness over H and identify the original stable moduli, complex and form with the appropriate open part of the central fiber. On the dense open parameter set with generic separated poles, construct both quasi-isomorphisms from the diagonal deformation complex to the unfolded complex and the logarithmic parabolic complex, respecting trace forms. Prove closedness of the logarithmic trace form by the Čech cup-product/trace calculation and gauge descent and transfer it through these two comparisons. The relative sheaf of three-forms on this smooth family over an integral base is locally free, and restriction to the indicated dense open detects zero. Deduce d_relative ω=0 on the whole family, restrict to the central stable locus and descend. A later nonreduced base change uses this proved identity; density on a nonreduced base is not a substitute.

The fixed-determinant result is the pullback of this closed form to the determinant fiber, with nondegeneracy supplied only after §2.3's orthogonality comparison. No scalar Hamiltonian or classification of phase surfaces enters this construction.

**Hypotheses**

- §§2.1–2.3 in the admitted domain. Smoothness, the auxiliary simple-connection family, generic comparison maps and closedness are outputs.
- For the fixed-determinant symplectic export, the determinant-fiber comparison and nondegeneracy gate in 2.3.

**API**

- `closedRelativeTraceFormLaw1` — Construct the finite-flat unfolding, the moduli of simple connections and the universal-object cover, and identify their central fibers.
- `closedRelativeTraceFormLaw2` — Construct both diagonal-complex comparison maps and prove compatibility with the trace pairing.
- `closedRelativeTraceFormLaw3` — Prove nondegeneracy and closedness independently, including descent and later base-change compatibility.

**Tests and falsification cases**

- `closedRelativeTraceFormCheck1` (characterisation) — A skew pairing which vanishes identically is closed but is not symplectic; nondegeneracy must follow from the actual duality computation.
- `closedRelativeTraceFormCheck2` (computation) — For r = 2, local order 2 and q₁ = 2, the unfolding equation is (z − 2h²)(z − h²). Its fiber at h = 0 is z² and at h = 1 is (z − 2)(z − 1); modulo h² it is again z². Check the central and pulled-back complexes and forms, rather than identifying this family with fixed distinct sections.
- `closedRelativeTraceFormCheck3` (dependency check) — Delete all later applications and every scalar equation: the finite-flat unfolding, its two generic comparison maps and the closedness proof must still be stated and constructible here.

**Prerequisites:** `target:2.1`, `target:2.2`, `target:2.3`

**Needs:** §§2.1–2.3; relative differential forms, trace cup products, descent, and zero detection on a smooth family over an integral base. This target constructs the finite-flat unfolding and does not depend on a downstream confluence theorem.

**Source scope and owned proof:** I23 Theorem 8.1, Propositions 8.2–8.3 and the complex preceding (8.2). The roadmap keeps every construction needed by that unfolding proof in this upstream framework.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

## Layer 3: Strong nonlinear connection and coherent general construction

### 3.1 Strong integrable extensions and the actual horizontal splitting

For a time tangent at a moduli point, construct a strong integrable extension of the universal connection over the corresponding dual-number deformation. On the moving total curve X let D be the sum of the marked relative Cartier divisors with coefficient one, formed on the smooth ambient family before pullback to the infinitesimal base. The allowed total-form pole filtration is Ω¹_X(log D) ⊗ O_X(P−D), relative to any fixed auxiliary base. Require integrability and preservation of the kernel lattices attached to the local filtrations, namely kernels of E → E|_{mᵢaᵢ}/Fᵢ,k with the relevant structural thickening and the additional factorized relations. Preserving flags separately on each fiber is insufficient. Prove the coordinate lemma that, in a moving polar coordinate z, the allowed forms are generated by dz/zᵐ and dε/zᵐ⁻¹; the time coefficient is regular at a logarithmic point.

Prove existence and uniqueness up to the specified isomorphism restricting to the identity on the central fiber, within this strong extension class. Glue the local lifts and descend from the universal-object cover. Construct the actual O-linear splitting h:π*TB→TM and prove dπ∘h=id. In fixed-determinant mode prove that taking determinant of the constructed extension agrees with the certified rank-one transport of §1.2, so that h is tangent to the moving determinant fiber. This is a comparison theorem, not a claim that an arbitrary determinant section is preserved. Existence of h, integrability and preservation of the trace form are not input axioms.

**Hypotheses**

- The admitted time and moduli constructions of §§1.1–2.3 and a time tangent vector. The total pole filtration and kernel-lattice relations specify the class of extensions being constructed.
- For fixed determinant, §1.2 supplies the verified rank-one time transport and §2.3 supplies the determinant-fiber comparison.

**API**

- `strongHorizontalSplittingLaw1` — Construct the lift from a time tangent and prove additivity and O-linearity.
- `strongHorizontalSplittingLaw2` — Prove restriction, base-change and input-isomorphism naturality of the lift.
- `strongHorizontalSplittingLaw3` — Compare lifts computed with different local coordinates, formal diagonalizations and universal-object covers.
- `strongHorizontalSplittingLaw4` — Identify the induced horizontal subbundle and its projection isomorphism to π*TB.
- `strongHorizontalSplittingLaw5` — Prove determinant functoriality of the strong extension and tangency to a certified moving determinant fiber.

**Tests and falsification cases**

- `strongHorizontalSplittingCheck1` (characterisation) — A zero time tangent lifts to zero; adding an arbitrary vertical vector would violate uniqueness of the integrable extension.
- `strongHorizontalSplittingCheck2` (compatibility) — Rescaling the time tangent by 2 rescales its lift by 2, while changing the time coordinate to 2t rescales the normalized generator by 1/2.
- `strongHorizontalSplittingCheck3` (non-example) — The zero map cannot be a splitting over a nonzero time tangent because dπ ∘ 0 = 0 ≠ id.
- `strongHorizontalSplittingCheck4` (non-example) — At m=1 a proposed time term dε/z lies outside the allowed total-form module in a moving polar coordinate; fiberwise flag preservation cannot repair that violation.

**Prerequisites:** `target:1.1`, `target:1.2`, `target:2.1`, `target:2.2`, `target:2.3`, `framework:NonlinearConnections/1.1`

**Needs:** §§1.1–2.3; infinitesimal local lifting, formal factorized-structure comparison and descent. NonlinearConnections §1.1 supplies only the abstract carrier and morphism language.

**Source scope and owned proof:** I23 Definition 10.1, (10.1), Lemmas 10.3–10.6, Propositions 10.7/10.10 and (11.2); determinant compatibility and intrinsic pole-filtration comparison are owned proof obligations.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 3.2 Flatness, trace-form preservation and the closed total form

Compare the two-parameter strong extensions and their mixed infinitesimal term to prove h([v,w])=[h(v),h(w)]. Prove that holomorphic integral sections carry the corresponding strong integrable total connections. This bracket calculation uses the algebraic extension comparison, not a global Riemann–Hilbert theorem.

Use the actual trace cocycles and strong-extension comparison to prove that the constructed horizontal variation preserves the relative symplectic form ω. Flatness of an arbitrary splitting alone would not imply that assertion. Define Ω(v,w)=ω(v−h(dπv),w−h(dπw)), prove dΩ=0 and ker Ω=im h, and deduce preservation of ω by local horizontal transport. The generic differential-form equivalence in NonlinearConnections §1.6 can organize this final calculation, but it cannot supply trace-form preservation as an unproved premise. In a one-dimensional time chart, only after a symplectic trivialization and local exactness have been supplied, derive Ω=dq∧dp+dH∧dt in relative dimension two, and the analogous sum in higher even dimension. Scalar Hamiltonians are local primitives attached to charts.

**Hypotheses**

- The actual strong splitting of 3.1 and the relative symplectic form of 2.4, with the determinant gate where applicable. Flatness and preservation of that form are outputs.

**API**

- `flatSymplecticIsomonodromyLaw1` — Compute the mixed two-parameter extension term and obtain the bracket identity and flat horizontal distribution.
- `flatSymplecticIsomonodromyLaw2` — Recover the relative form by vertical restriction and the horizontal distribution as the kernel.
- `flatSymplecticIsomonodromyLaw3` — Prove admissible base-change naturality for the relative form, the actual splitting and the closed total form.
- `flatSymplecticIsomonodromyLaw4` — Compare two Hamiltonian potentials in a fixed chart: their difference is constant along connected phase fibers.
- `flatSymplecticIsomonodromyLaw5` — State the extra generator term for a time-dependent symplectic change of coordinates through equality of the extended two-forms.

**Tests and falsification cases**

- `flatSymplecticIsomonodromyCheck1` (non-example) — For H = p²/2, contraction with ∂t + p∂q annihilates dq ∧ dp + p dp ∧ dt; using the opposite sign does not.
- `flatSymplecticIsomonodromyCheck2` (compatibility) — H and H + t² give the same vertical vector field and extended two-form, but different scalar functions.
- `flatSymplecticIsomonodromyCheck3` (non-example) — On a symplectic fiber, Ω has no nonzero vertical kernel vector; degenerating ω to zero would fail this characterization.
- `flatSymplecticIsomonodromyCheck4` (non-example) — On ℂ²×ℂ with ω=dq∧dp, h(∂t)=∂t+q∂q is flat because the base has dimension one, but its flow scales ω. This fails the trace-form preservation obligation.

**Prerequisites:** `target:2.2`, `target:2.4`, `target:3.1`, `framework:NonlinearConnections/1.6`

**Needs:** §§2.2, 2.4 and 3.1; two-parameter infinitesimal extensions, trace variation and differential-form calculus. NonlinearConnections §1.6 is used only after the actual preservation identity has been proved.

**Source scope and owned proof:** I23 Theorem 11.6, Definition 11.4 and Corollary 11.8. The flatness proof and the trace-form variation are separate obligations.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 3.3 Naturality and coherent change of presentation

For isomorphic admitted decorated time problems construct compatible isomorphisms of their stacks, rigidifications and phase families, preserving the trace pairing, ω, h and Ω. Cover finite-jet coordinate changes, formal frame changes, ramified root changes with descent data, universal-object covers and compatible rank-one determinant transports. Construct the pullback comparison for a holomorphic map f:B′→B between smooth complex bases and prove that the resulting horizontal vector at (b′,m) is (v′,h_m(df(v′))). The corresponding algebraic stack pullback remains meaningful for general test bases, but analytic submersion statements require a smooth complex base.

Record the natural comparison isomorphisms for identity and composite base changes, the associativity pentagon, the identity triangles and compatibility with 2-isomorphic presentation arrows. On the rigidified phase spaces these descend to the required equalities/cocycle laws. Thus the construction is pseudofunctorial before rigidification and functorial up to the specified canonical comparisons afterward. Changes of determinant, weights, labels or formal local type that are not isomorphisms of the input remain genuine parameter changes or correspondences on stated domains. A time-dependent gauge matrix changes a formula but the compatible object and its transported tensors remain identified.

**Hypotheses**

- Isomorphisms of the same admitted decorated time problem and base maps preserving its specified data; the constructions of §§1.1–3.2.
- Analytic output is over smooth complex bases; coarse-space comparisons use the scalar-gerbe descent from 2.1. Non-isomorphic parameter changes are not included among presentation arrows.

**API**

- `coherentModuliNaturalityLaw1` — Give the stack-level comparison 1-isomorphisms and their coherent 2-isomorphisms; descend the corresponding phase-space comparisons.
- `coherentModuliNaturalityLaw2` — Prove equality of pullback splitting and forms with the outputs constructed after base change.
- `coherentModuliNaturalityLaw3` — Preserve source and target maps of the NonlinearConnections morphisms and specify the exact domains of all parameter correspondences.

**Tests and falsification cases**

- `coherentModuliNaturalityCheck1` (compatibility) — For f:B′→B and g:B″→B′, compare direct (f∘g)* construction with g*f* and check the three-composition pentagon rather than choosing unrelated identifications.
- `coherentModuliNaturalityCheck2` (non-example) — A weight wall crossing changes the stable locus and is not a presentation isomorphism unless an actual common stable domain has been specified.
- `coherentModuliNaturalityCheck3` (compatibility) — The base map t=s² pulls h(∂t) back to h′(∂s)=(∂s,2s h(∂t)); at s=0 the horizontal vector still projects to ∂s, so the base map need not be a local isomorphism.

**Prerequisites:** `target:1.1`, `target:1.2`, `target:2.1`, `target:2.2`, `target:2.4`, `target:3.1`, `target:3.2`, `framework:NonlinearConnections/1.1`

**Needs:** §§1.1–3.2 and the generic pullback carrier of NonlinearConnections §1.1; uniqueness of strong extensions and tensor descent. The coherence data are constructed here.

**Source scope and owned proof:** I23 Propositions 10.7 and 10.10 supply uniqueness used by the comparison. Full intrinsic base-change/2-coherence is an owned theorem target, not a quotation from a coordinate formula.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 3.4 General construction theorem and reusable export

Assemble §§1.1–3.3 into a construction from each admitted decorated time problem to its rigidified stable phase family and, over the open nonempty-fiber part of a smooth analytic time base, a holomorphic flat symplectic nonlinear connection (π:M→B,h,ω) in NonlinearConnections §§1.1 and 1.6, together with its closed total form Ω. The inputs contain curve and local connection data, a stability chamber and the determinant mode; they do not contain h, a scalar differential equation or a classification of surfaces. The result applies in arbitrary genus and admitted rank/polar degree for unfixed determinant; fixed-determinant export requires the separately proved comparison in §2.3 and the certified time transport in §1.2.

Give a single consumer certificate listing local-model admission, the actual time base, determinant verification, weight choice and nonemptiness evidence. Return the geometric carrier, the constructed tensors, dimension theorem at its exact scope, naturality and coherent pullback laws. A consumer proves only these admission conditions and its further specialized results. In particular neither relative dimension two nor one-dimensional time belongs to this construction theorem. Completeness, proper Riemann–Hilbert comparison, chosen observables, scalarization and distinguished solutions require their own downstream hypotheses and proofs. The export consists of explicit theorem interfaces with named proof owners; this roadmap does not certify that all those proofs have already been completed.

**Hypotheses**

- The admitted geometric input and time problem of 1.1–1.2; stable construction of 2.1–2.4 and the actual h, flatness and naturality from 3.1–3.3.
- Restrict to the open nonempty-fiber time locus for a surjective nonlinear-connection carrier; a consumer must provide nonemptiness if its whole proposed base is claimed.
- Fixed-determinant export additionally passes the independent determinant-fiber and rank-one transport gates.

**API**

- `meromorphicModuliToNonlinearConnectionLaw1` — Export a construction theorem, not an alias for a specialized phase space: its conclusion supplies π, h, ω, Ω and all their laws from the admitted geometric input.
- `meromorphicModuliToNonlinearConnectionLaw2` — Supply the common consumer certificate and distinguish construction, nonemptiness and completeness obligations.
- `meromorphicModuliToNonlinearConnectionLaw3` — Prove reuse under base change and presentation equivalence through 3.3, without rerunning a case classification.

**Tests and falsification cases**

- `meromorphicModuliToNonlinearConnectionCheck1` (dependency check) — Removing every specialized consumer, every relative-dimension-two selection and every classical equation leaves the input/output statement and all local prerequisites intact.
- `meromorphicModuliToNonlinearConnectionCheck2` (computation) — Five logarithmic points on ℙ¹ in rank two, fixed determinant and a nonempty stable locus give relative dimension 4 and a two-dimensional configuration base; the construction theorem must accept that input.
- `meromorphicModuliToNonlinearConnectionCheck3` (non-example) — A tuple of arbitrary formal singularities is not admitted merely because its dimension formula happens to be positive; each local model and determinant/time certificate must be verified.
- `meromorphicModuliToNonlinearConnectionCheck4` (non-example) — A holomorphic flat symplectic connection can have incomplete horizontal curves; this export alone cannot justify global continuation of all initial conditions.

**Prerequisites:** `target:1.1`, `target:1.2`, `target:2.1`, `target:2.2`, `target:2.3`, `target:2.4`, `target:3.1`, `target:3.2`, `target:3.3`, `framework:NonlinearConnections/1.1`, `framework:NonlinearConnections/1.6`

**Needs:** Exactly §§1.1–3.3 and the stated generic NonlinearConnections interfaces. No specialized consumer or scalar-equation comparison is a prerequisite.

**Source scope and owned proof:** This assembly and its consumer contract are the roadmap’s mathematical design. I23 supplies the admitted unfixed-determinant construction model; all added determinant/coherence gates remain explicitly owned.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

## Layer 4: Optional logarithmic Riemann–Hilbert and properness branch

### 4.1 Marked logarithmic Betti family and the full Riemann–Hilbert map

For the logarithmic subproblem of §1.1, construct the topologically marked family of representation varieties of the punctured curves, their affine conjugacy quotients and the prescribed-local-character subfamilies. Keep the residue-exponent parameter λ on the de Rham side and the exponential characteristic-polynomial parameter a=rh(λ) on the Betti side. Repeat the bounded construction of §2.1 over the simultaneous residue parameter space Λ, and prove its comparison with the I13 family; the horizontal splitting is relative to fixed λ, so varying λ is not a time direction. On a marking cover the Betti family is identified by transport with a fixed character variety times the time base. This gives complete transport along all admissible time paths even when the character variety is singular; no smooth Betti tangent bundle is required.

Construct the holomorphic Riemann–Hilbert map from the entire stable logarithmic parabolic moduli of §2.1, including allowed reducible and resonant objects and all bundle types. Define it through the local system of horizontal sections and its conjugacy-quotient class, and prove descent from the universal-object cover. Identify this logarithmic moduli problem, its weights and residue ordering with the exact moduli functor used by I13; a matrix-chart comparison is insufficient. Prove that the actual strong splitting of §3.1 is semiconjugate to the marked Betti transport at every point, using the total integrable extension with its logarithmic lattices and the analytic dependence of local solutions. Prove local horizontal-lift existence independently of Riemann–Hilbert invertibility. At resonant or reducible points the map may have positive-dimensional fibers and is not replaced by an inverse map.

For a certified determinant transport, show that taking determinant of monodromy agrees with the rank-one Riemann–Hilbert map and that the prescribed determinant is a transported Betti section. Export the Hausdorff locally compact marked target and the full semiconjugacy as inputs to NonlinearConnections §1.4, without asserting properness until §4.2 or deducing source completeness here.

**Hypotheses**

- The logarithmic local subproblem of 1.1, the admitted pointed-curve time problem and fixed residue exponents of 1.2, and the actual stable moduli and strong connection of 3.4.
- A topological marking cover of the punctured-curve family. Fixed-determinant conclusions require the verified determinant transport. The Betti target is allowed to be singular.

**API**

- `regularSingularRiemannHilbertSemiconjugacyLaw1` — Construct the marked affine Betti target with its complete path transport and state the retained residue/character parameter map.
- `regularSingularRiemannHilbertSemiconjugacyLaw2` — Prove the all-points Riemann–Hilbert semiconjugacy for the actual strong source splitting, including the map on singular target strata.
- `regularSingularRiemannHilbertSemiconjugacyLaw3` — Identify the full logarithmic moduli functor with I13 and prove compatibility with determinant, presentation change and analytic base change.

**Tests and falsification cases**

- `regularSingularRiemannHilbertSemiconjugacyCheck1` (non-example) — An open subset where Riemann–Hilbert is an isomorphism does not include all stable resonant or reducible objects. The semiconjugacy statement must be checked on their actual moduli points.
- `regularSingularRiemannHilbertSemiconjugacyCheck2` (compatibility) — Two residue parameters differing by allowed integer shifts can have the same local monodromy eigenvalues; retain λ rather than identifying the de Rham families over the a-parameter.
- `regularSingularRiemannHilbertSemiconjugacyCheck3` (compatibility) — A singular affine character variety is still a Hausdorff locally compact analytic space with complete marked transport; requiring a nonsingular target would discard exactly the strata needed by the proper-map continuation argument.

**Prerequisites:** `target:1.1`, `target:1.2`, `target:2.1`, `target:3.1`, `target:3.2`, `target:3.3`, `target:3.4`, `framework:NonlinearConnections/1.3`

**Needs:** §§1.1–3.4 restricted to logarithmic data; representation varieties and affine conjugacy quotients, analytic horizontal sections, marked fundamental groups and regular-singular correspondence. NonlinearConnections §1.3 supplies local horizontal sections for the already constructed source connection.

**Source scope and owned proof:** I13 §2 (the marked Riemann–Hilbert map), §6 and §8 (isomonodromic deformation). Full comparison of its moduli functor and strong splitting with this framework, including exceptional strata and determinant compatibility, is explicitly owned.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

### 4.2 Family properness in the exact logarithmic source scope

For the full stable logarithmic parabolic moduli problem identified in §4.1, prove family properness of the marked Riemann–Hilbert map to the character family pulled back along the residue map rh:Λ_r^(n)(d)→A_r^(n). Use the complete exponent target (Rep_r(C,marked points)×_T T̃)×_{A_r^(n)}Λ_r^(n)(d), not only the generic smooth character locus. The exact source range is rank r≥2, n≥1, generic weights with stable=semistable, and rn−2r−2>0 when g=0, n>1 when g=1, n≥1 when g≥2. The residue space satisfies d+Σᵢⱼλⱼ^(i)=0. Prove the properness statement for families and its analytic base-change stability; properness of individual fibers alone is not the required result. The source theorem also supplies surjectivity and bimeromorphicity in this range, after the exact functor comparison.

For fixed determinant, construct the commutative determinant square on the de Rham and Betti moduli, prove the rank-one regular-singular Riemann–Hilbert isomorphism with the prescribed trace residues and logarithmic lattice, and identify the specified-determinant coarse moduli with the actual Cartesian inverse image of the corresponding determinant Betti section. Include the scalar-gerbe comparison: choosing a determinant identification must not silently change the coarse fiber. The section is transported only after the certificate of §1.2 and comparison of §4.1. Deduce fixed-determinant family properness by proper analytic base change along this proved square. This comparison is required even in genus zero; the simplification there must be proved.

Export the proper semiconjugacy certificate consisting of §§4.1–4.2. A consumer then invokes NonlinearConnections §1.4 with its own source and time domain to deduce complete horizontal continuation. Do not reprove that general continuation theorem here or extend this properness assertion to arbitrary irregular data.

**Hypotheses**

- The entire logarithmic moduli problem and Riemann–Hilbert map of 4.1, identified with I13; r≥2, n≥1 and fixed genus, degree and residue data with d+Σᵢⱼλⱼ^(i)=0.
- Generic weights satisfying stable=semistable; g=0 requires rn−2r−2>0; g=1 requires n>1; g≥2 requires n≥1.
- Fixed-determinant restriction additionally requires the proved Cartesian determinant comparison, rank-one regular-singular correspondence and certified transported determinant section.

**API**

- `regularSingularFamilyPropernessLaw1` — Identify the full parameterized target and prove properness after pullback along any admitted analytic time/exponent base change.
- `regularSingularFamilyPropernessLaw2` — Construct and prove the Cartesian determinant comparison on coarse moduli, including rank-one Riemann–Hilbert and scalar identification issues.
- `regularSingularFamilyPropernessLaw3` — Return a proper semiconjugacy certificate for a separate application of the general continuation theorem.

**Tests and falsification cases**

- `regularSingularFamilyPropernessCheck1` (computation) — For g=0,r=2,n=5, rn−2r−2=4>0, so the numerical source condition holds. A genuine nonemptiness certificate and the determinant comparison remain necessary for the full fixed-determinant application.
- `regularSingularFamilyPropernessCheck2` (non-example) — For g=0,r=2,n=3, rn−2r−2=0; this target cannot cite I13 Theorem 2.2 as supplying its properness theorem.
- `regularSingularFamilyPropernessCheck3` (non-example) — Deleting an exceptional fiber from the source may destroy properness even though the generic Riemann–Hilbert map is an isomorphism; keep the full stable moduli source.
- `regularSingularFamilyPropernessCheck4` (dependency check) — The five-point application uses the same NonlinearConnections §1.4 as any other proper semiconjugacy consumer; no separate five-point compactness theorem is added here.

**Prerequisites:** `target:1.1`, `target:1.2`, `target:2.1`, `target:2.3`, `target:3.3`, `target:3.4`, `target:4.1`

**Needs:** §4.1 and the exact full stable parabolic moduli functor; I13 family properness at its stated scope, rank-one regular-singular correspondence, coarse determinant-fiber comparison and proper analytic base change.

**Source scope and owned proof:** I13 Theorem 2.2 (including every numerical hypothesis), Remark 2.3(1), §6 and §8. Comparison with this framework and the fixed-determinant Cartesian square are owned proofs. No irregular properness result is inferred.

**Proposed owner:** TauCetiRoadmap.MeromorphicConnectionModuli (proposed; this draft does not install an upstream roadmap)

## Explicit mathematical completion gates

- `M-local-presentation-descent` — Build intrinsic input groupoids and coordinate/root changes with coherent descent, without treating I23 coordinate formulas as the definition.
- `M-determinant-time` — Construct and verify rank-one strong determinant transport on the stated local charts; global fixed-determinant output requires actual gluing. Prove determinant compatibility of the rank-r lift.
- `M-determinant-fiber` — Compare full ramified deformation cone with the regular determinant de Rham complex; prove scalar splitting, smooth determinant map, 2g removal and orthogonal nondegeneracy before exporting positive-genus fixed-determinant symplecticity.
- `M-early-unfolding` — Construct the finite-flat auxiliary family and both generic-fiber comparison maps upstream of every confluence application.
- `M-strong-lift` — Prove existence/uniqueness inside the total-pole and kernel-lattice extension class, mixed-term flatness and actual trace-form preservation.
- `M-coherent-export` — Prove canonical pullback/presentation comparisons, 2-coherence and the general construction theorem independently of all specialized consumers.
- `M-regular-RH-proper` — Identify the entire logarithmic moduli functor with I13, prove all-points strong-splitting semiconjugacy, exact family properness and the Cartesian fixed-determinant restriction. Source completeness belongs to the generic NonlinearConnections theorem, applied downstream.

## Primary sources and exact use

- **I23** — [Michi-aki Inaba, Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation, SIGMA 19 (2023), 013](https://sigma-journal.com/2023/013/); [PDF](https://sigma-journal.com/2023/013/sigma23-013.pdf). §§2–5; §6 (6.9), Proposition 6.3; §7 Proposition 7.2, Theorem 7.5; §8 Theorem 8.1, Propositions 8.2–8.3; §10 Definition 10.1, (10.1), Propositions 10.7/10.10; §11 Definition 11.4, Theorem 11.6, Corollary 11.8.
- **I13** — [Michi-aki Inaba, Moduli of parabolic connections on a curve and Riemann–Hilbert correspondence, Journal of Algebraic Geometry 22 (2013), 407–480](https://arxiv.org/abs/math/0602004); [PDF](https://arxiv.org/pdf/math/0602004). Definitions 1.1 and 2.2; Theorems 2.1–2.2; §6; regular-singular reconstruction and surjectivity.

I13 supplies the optional logarithmic §§4.1–4.2 branch and supports logarithmic-consumer nonemptiness; it is not a prerequisite for the general irregular construction of §3.4. No unrestricted extension beyond the admitted I23 local models is claimed.
