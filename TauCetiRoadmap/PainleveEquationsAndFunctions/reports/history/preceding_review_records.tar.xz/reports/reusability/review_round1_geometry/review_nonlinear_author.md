# Independent mathematical review: geometry and second consumer

**Reviewer:** /root/reuse_nonlinear_author  
**Decision:** request changes before accepting the reusable bilingual contract.  
**Findings:** P1 = 0, P2 = 2, P3 = 2.

This reviewer authored NonlinearConnections, and did not author the three reviewed target sets. The review concerns the accuracy and possible completion of the roadmap statements. Planned proofs are not treated as errors merely because they have not yet been carried out.

## Frozen scope and hashes

The frozen snapshot is review_round1_geometry. Its manifest SHA-256 is:

`3f3a82a770ca24c024141023fb2562df9eed34d5261e695d69cbf0adc2ca01f3`

All nine file hashes match the manifest. No reviewed source file was modified. The exact file hashes and primary-source hashes are recorded in [review_nonlinear_author.json](review_nonlinear_author.json).

The review covers all 12 MeromorphicConnectionModuli targets, all four FiveLogarithmicPoints targets, and the 21 root targets in Layers 1–5, in their English/Japanese README and structured-plan forms. It also inspects the root introductory supplier/ownership contracts and the corresponding Japanese input/obligation appendices. Root performs the expanded global DAG check separately; this review does not certify that graph. It does not review the author's own NonlinearConnections module or the independent analytic module.

## P2 findings requiring correction

### GEO-N-01 — The old supplier paragraphs still assign extracted generic proofs to the root

The root targets 2.1–2.3 now correctly import the general stable moduli construction, deformation complex and symplectic construction. The introductory supplier prose still says that Layer 2 supplies the connection functor, equations, boundedness and deformation complex, and that the scalar gerbe and tensor descent are “application theorems here.” The Japanese version repeats these assignments.

This leaves two stated owners for the same general work. Update both supplier sections so MeromorphicConnectionModuli 2.1–2.4 owns the general bounded construction, scalar-gerbe comparison, complex and tensor descent. Root Layer 2 should own the classical admission, determinant/central-fiber and framed-chart comparisons. This is a reuse-contract correction; the new target bodies already largely make the right distinction.

**Acceptance:** the introductions, supplier prose and structured ownership fields name the same general proof owner.

### GEO-N-02 — Japanese §1.2 confuses a smooth new base with a smooth base-change map

MeromorphicConnectionModuli 1.2 admits a base change whose **new base is smooth**. The Japanese phrase 「または滑らかな基底変換とする」 naturally admits the narrower reading that the **map** is smooth. Its own target 3.3 accepts the ramified map \(t=s^2\), including \(s=0\), which is not a smooth morphism there.

Replace the phrase with an explicit statement that arbitrary holomorphic base changes are permitted when the new base is a smooth complex manifold. The map need not be smooth, étale or locally invertible. Keep the distinction from general algebraic test bases used for stack pullback.

**Acceptance:** Japanese 1.2, English 1.2 and the \(t=s^2\) check have the same domain.

## P3 precision findings

### GEO-N-03 — Name the carrier receiving separatedness

MeromorphicConnectionModuli 2.1 lists the stack, rigidification and coarse space, then asks for “separatedness and finite type.” The intended statement is viable for the coarse/rigidified phase family. It should say so explicitly. The unfixed-determinant stable stack retains \(\mathbb G_m\) inertia, and its diagonal cannot be proper: its fiber at an object is the nonproper group \(\mathbb G_m\).

This is a request to disambiguate the exported property, not a rejection of the coarse moduli theorem.

### GEO-N-04 — State the marking-cover-to-configuration-base adapter

I13's proper family and the formula in M 4.2 are on the marking cover. FiveLogarithmicPoints 1.4 concludes completeness for paths in the original configuration base \(B\). The present “marking comparison” can support a valid proof, but the adapter should be explicit.

One sufficient route is to lift a compact \(B\)-path to a chosen marking cover, apply NonlinearConnections 1.4 to the pulled-back connection and proper comparison, project the horizontal lift back to \(M\), and prove marking-independence by uniqueness and deck compatibility. Alternatively, descend the character family and RH map and prove properness locally on the base. Then construct the endpoint action on \(B\).

## Mathematical checks that passed

The central reusable construction has a viable, noncircular shape. The input consists of curve/local/time/determinant/stability data. The stack, deformation complex, splitting, flatness and forms are constructed in successive targets; the general export does not hide all conclusions in an assumed record.

The positive-genus determinant comparison is properly isolated. The regular determinant de Rham complex, full ramified-complex trace/scalar splitting, smooth determinant map and orthogonal nondegeneracy are named proof obligations. Subtracting \(2g\) from the unfixed formula gives the stated fixed-determinant formula. The genus-zero agreement is not exported without these gates.

Relative closedness and total closedness are distinct. M 2.4 owns the early finite-flat unfolding and both generic comparison maps. M 3.2 proves actual trace-form preservation before applying the generic total-form criterion; it explicitly rejects flatness alone as sufficient.

The strong extension class retains the total pole module, the moving-coordinate time bound \(m-1\), kernel lattices and the factorized relations. Merely preserving fiberwise flags is correctly insufficient. The determinant transport is constructed separately and compared with the rank-\(r\) lift.

The admitted irregular domain stays within the three stated I23 models. In particular, the totally ramified model retains \(a_{10}\ne0\); mixed blocks, arbitrary slopes and vanishing leading terms require separate extensions.

I checked the local primary-source text of I13 Theorem 2.2. It really is a family properness theorem with the residue-exponent fiber product, and it has the numerical restrictions recorded in M 4.2. Rank-one regular-singular comparison is supported by Remark 2.3(1); the family and Cartesian determinant comparisons remain properly owned proof obligations. I23 Theorems 5.1 and 7.5 and Corollary 11.8 also agree with the scopes used here.

### Independent five-point computations

The specified representation satisfies
\[
DJK K^{-1}(DJ)^{-1}=I,
\]
and every matrix has determinant one. The two eigenlines of \(D\) are the coordinate axes and \(J\) exchanges them, so the representation is irreducible. The prescribed logarithms match the eigenvalues after ordering their eigenlines. The statement explicitly retains the logarithmic lattice changes needed to obtain those residues.

The ten weights are distinct and lie in \((0,1)\). Their 32 signed differences have minimum absolute value \(1/1000\) and maximum \(31/1000\), so no expression \(2\deg F+\sum\varepsilon_i2^{i-1}/1000\) vanishes. The possible sums of one chosen residue at each pole are
\[
\left\{\pm\frac{13}{12},\ \pm\frac34,\ \pm\frac7{12},\
\pm\frac5{12},\ \pm\frac14,\ \pm\frac1{12}\right\};
\]
none is an integer. The independent invariant-line exclusion is correct.

The time dimension is \(5-3=2\), the phase dimension is \(-8+2+10=4\), and the I13 inequality is \(2\cdot5-4-2=4>0\). These are verified outputs/conditions, not assumptions that the construction is already a flat symplectic system. The second consumer really invokes the same proper-transfer, groupoid and symplectic interfaces. It also correctly refuses to assert a scalar first-jet isomorphism on four-dimensional fibers or one-variable isolated-pole results on the two-dimensional base.

## Bilingual and structural comparison

The 12 M targets and four five-point targets match their English plan statement/API/check/Needs entries. All root Layer 1–5 mathematical entries are represented. Root 1.4 places its final statement paragraph after its Checks block, so a contiguous-substring check reports a layout mismatch; the paragraph is present and no mathematical content is missing.

The reviewed Japanese statements preserve the determinant, strong-pole, total-form, properness and five-point requirements, subject to GEO-N-02. The root Japanese input and proof-obligation appendices have been updated to the new target bodies.

Root 1–3 and 5 correctly act as imports and specialization checks in their substantive target statements. Root 4 distinguishes the imported logarithmic branch from the retained scoped classical irregular/Stokes and properness extension. Those remaining proof-development targets are not rejected simply because they are planned.

## Review limit

This is an assessment of the mathematical contracts and their reuse, not a completed proof of the moduli construction or the remaining irregular properness theorem. The P2 findings must be corrected and the changed contract rereviewed before this review is closed.


