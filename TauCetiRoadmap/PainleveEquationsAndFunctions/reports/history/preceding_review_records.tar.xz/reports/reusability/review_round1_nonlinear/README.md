# Nonlinear connections, transport, observations and comparison

**Status: mathematical draft.** This module contains nine construction and proof targets. Completion of the roadmap text does not mean that these theorems have already been proved or added to an upstream library. Every named upstream owner is a **proposed destination**.

This is a reusable dependency unit with its own [plan](plan.json) and [Japanese version](README.ja.md). Its mathematical prerequisites contain no Painlevé target, rank-two condition, degree-four condition, classical scalar equation, or Riemann–Hilbert comparison. A geometric application constructs its own phase family, splitting and any auxiliary forms or comparison maps, then invokes only the general results whose hypotheses it has proved. The module retains actual objects, arrows, pullbacks and comparison isomorphisms.

## What is reusable

| Target | Independently exported result | Additional input a consumer must prove |
|---|---|---|
| 1.1 | Nonlinear connection objects, arrows, curvature and base change | An actual submersion and tangent splitting |
| 1.2 | Local path lifts and compact extension | Continuous time dependence and local uniform phase Lipschitz bounds |
| 1.3 | Holomorphic horizontal germs and parameter dependence | A holomorphic splitting and flatness in the time directions |
| 1.4 | Completeness transferred by proper semiconjugacy | A proper map and compatibility with every partial lift at every point |
| 1.5 | Fundamental-groupoid action, universal-cover sections and descent | Flatness and path completeness, obtained by any valid proof |
| 1.6 | Closed-total-form criterion and symplectic transport | Fiberwise closedness and nondegeneracy, then the stated preservation or closedness hypothesis |
| 1.7 | Admissible evaluation and scalar descent | An actual admissible observation on a complex curve |
| 1.8 | Intrinsic first-jet scalarization | An observation and a proved local jet isomorphism |
| 1.9 | Finite-chart convergence with existence and no exit | Common domains, positive margins, uniform field bounds and matched initial data |

The dependency graph deliberately does not route scalarization through symplectic geometry or global continuation. Likewise, the proper-semiconjugacy theorem does not require flatness, while fundamental-groupoid transport does. Meromorphic evaluation can be used for any holomorphic map from a curve, without first proving completeness of a connection. Compact-path convergence does not depend on a collision or confluence construction; that construction is responsible for verifying its common-domain hypotheses.

## Regularity and proof boundary

The real $C^1$ branch is used for individual horizontal path lifting. Curvature, differential-form identities and the smooth flat-product theorem use smooth real data. The complex branch uses holomorphic data on finite-dimensional complex manifolds. No statement silently extends these constructions to singular, nonreduced or infinite-dimensional bases.

A consumer may legitimately supply a connection already proved complete to target:1.5. That is different from defining every connection to contain a proof of completeness. Targets 1.1–1.3 construct the carrier and local solution theory, and target:1.4 gives one sufficient theorem for completeness. Similarly, target:1.6 accepts an independently constructed relative form and proves the relation between flatness, preservation and total closedness; it does not manufacture an application’s relative form by an assumption.

The previously named gap holomorphic-horizontal-lifts is expanded into the analytic proof obligations of target:1.3. Neither that target nor any other prerequisite points back to the gap. All nine targets are mathematical obligations, with concrete checks that can falsify an overbroad statement.

## Layer 1: reusable finite-dimensional nonlinear geometry

### 1.1 Ehresmann connections, actual arrows and base change

Let $\pi:M\to B$ be a smooth submersion between finite-dimensional Hausdorff second-countable smooth manifolds without boundary. A real nonlinear connection is a $C^1$ vector-bundle splitting $h:\pi^*TB\to TM$ with $d\pi\circ h=\mathrm{id}$. The holomorphic version uses complex manifolds, a holomorphic submersion and a holomorphic splitting. Surjectivity and properness of $\pi$ are not part of the definition. Whenever curvature, differential forms or smooth Frobenius theory are used below, strengthen the real splitting to smooth; the $C^1$ branch is retained for individual path lifting.

Define an arrow $(F,f):(M\to B,h)\to(N\to C,k)$ by actual smooth maps, or holomorphic maps in the holomorphic category, satisfying $\rho F=f\pi$ and $dF\circ h=k\circ df$. Composition and identities are the actual compositions and identities of these maps. An isomorphism retains its inverse and compatibility, rather than identifying the objects in a quotient set.

For a smooth or holomorphic map $u:B'\to B$, construct the fiber product $M'=B'\times_BM$, its projection $\pi':M'\to B'$ and the pullback splitting $h'_{(b',m)}(v)=(v,h_m(du(v)))$. Prove its tangent-space membership, splitting identity, functoriality on arrows and the canonical coherence isomorphisms for repeated base change. Construct the horizontal and vertical subbundles and, on the smooth or holomorphic branch, the vertical curvature $K_h(X,Y)=[hX,hY]-h[X,Y]$. Flatness means $K_h=0$. Neither horizontal solution operators, completeness, nor a symplectic form is an input to this construction.

**Hypotheses.**

- Finite-dimensional Hausdorff second-countable manifolds without boundary, a smooth submersion and a C¹ splitting; or finite-dimensional complex manifolds, a holomorphic submersion and a holomorphic splitting.
- For curvature and differential-form assertions, the real splitting is smooth. Base changes and arrows have the regularity of their chosen category.

**API.**

- Construct the category of actual connection-preserving arrows, its isomorphisms, and the horizontal–vertical splitting of the tangent bundle.
- Construct pullback connections along arbitrary smooth or holomorphic base maps and prove identity, composition and Cartesian comparison laws with their actual comparison maps.
- Prove tensoriality of $K_h$ and its naturality under connection isomorphisms and pullback; define flatness independently of completeness and symplecticity.

**Checks.**

- The zero map $\pi^*TB\to TM$ fails the splitting identity when $TB\ne0$; the product splitting on $B\times X\to B$ passes it.
- Under the noncritical time change $\tau=2t$, the vector field normalized to project to $\partial_\tau$ is one half of the vector field normalized to project to $\partial_t$.
- A fiber product connection can be defined along a ramified time map; this alone asserts neither completeness nor invertibility of its first-jet observation map.

*Needs:* SmoothBundlesConnections §B1.5/B5 for bundle splittings and smooth connection carriers; ComplexKahlerGeometry §K1/K3.0/K4/K7.1 for the holomorphic manifold and differential floor. This target owns the nonlinear arrows, pullback construction and coherence laws.

**Dependency references.** `roadmap:SmoothBundlesConnections §B1.5/B5`; `roadmap:ComplexKahlerGeometry §K1/K3.0/K4/K7.1`.

**Source scope.** Generic geometric construction. The old horizontal-lift gap is not an input here. No classical family or comparison morphism is needed.

**Proposed owner.** SmoothBundlesConnectionsPartII (proposed nonlinear-connection carrier and base-change extension); ComplexKahlerGeometry (proposed holomorphic carrier adapter)

### 1.2 Local horizontal lifting and continuous-time compact extension

Prove the local existence–uniqueness theorem for $y'=F(t,y)$ on finite-dimensional coordinate domains when $F$ is continuous in time and locally uniformly Lipschitz in the phase variable. The local constants are uniform on a sufficiently small closed time–phase box. In submersion coordinates $\pi(z,y)=z$, a $C^1$ base path $\gamma$ turns a $C^1$ splitting into the equation $y'=A(\gamma(t),y)\gamma'(t)$. Construct its local solution by the integral-equation contraction argument, prove uniqueness and restriction, and glue coordinate solutions to the unique maximal horizontal lift through each initial point. For a path with finitely many $C^1$ pieces, concatenate lifts at its breakpoints.

Prove the compact-extension lemma: a horizontal lift defined up to a finite endpoint of a base path extends through that endpoint if its image is contained in a compact subset of $M$. Use finitely many submersion charts near the compact set, uniform local existence intervals, accumulation and uniqueness to obtain the endpoint value and extension. A cluster point alone is not asserted to be the limit without this local uniqueness argument. The resulting lemma is available for ordinary nonautonomous ODEs in the same coordinate form.

The velocity of a $C^1$ path is merely continuous. The autonomized field $(1,F(t,y))$ therefore need not be $C^1$. The proof must use the stated continuous-time theorem, or a proved reduction to it, rather than import a smooth-vector-field theorem with unmet hypotheses. Continuous dependence on initial data is established under these hypotheses; stronger smooth or holomorphic dependence is claimed only with its additional regularity, and holomorphic horizontal sections are constructed in target:1.3. No complete-lift operator is assumed.

**Hypotheses.**

- A connection from target:1.1 and a compact-interval base path with finitely many C¹ pieces.
- For the analytic chart lemma: a continuous-time finite-dimensional ODE locally uniformly Lipschitz in its phase variable on its open domain.
- For compact extension: a finite endpoint at which the base path is defined, and a single compact subset containing the partial lift.

**API.**

- Prove the continuous-time Picard–Lindelöf chart theorem and the continuous initial-data dependence needed for local lifting.
- Construct unique maximal horizontal lifts, with restriction, reversal where defined, and concatenation across finitely many C¹ pieces.
- Prove that containment of a partial lift in one compact subset forces extension through a finite endpoint, using the actual nonautonomous regularity.

**Checks.**

- For the product splitting, the fiber coordinate is constant along every horizontal lift.
- The equation $y'=y^2$, $y(0)=1$ has $y(t)=1/(1-t)$: its local solution does not extend in the affine phase line through $t=1$; compact containment fails.
- The path $\gamma(s)=|s-1/2|^{3/2}$ is $C^1$, but $\gamma'$ is not $C^1$ at $1/2$. Its horizontal-lift equation remains an admissible continuous-time ODE; a $C^1$ autonomization cannot be assumed.

*Needs:* Local target:1.1; DifferentialGeometry §Layers 0–1 and Layer 3/3.5 for finite-dimensional charts and the differential calculus floor. The continuous-time Picard–Lindelöf, compact-extension and chart-gluing adapters are proof obligations of this target, not unverified imports.

**Dependency references.** `target:1.1`; `roadmap:DifferentialGeometry §Layers 0–1 and Layer 3/3.5`.

**Source scope.** Generic ODE construction and continuation proof. This is the analytic content required by later properness and no-exit arguments; no Riemann–Hilbert map is used.

**Proposed owner.** DifferentialGeometry (proposed continuous-time ODE and compact-extension extension); SmoothBundlesConnectionsPartII (proposed horizontal-lift adapter)

### 1.3 Holomorphic horizontal germs and parameter dependence

For a holomorphic submersion with a flat holomorphic splitting, construct the unique germ of holomorphic section $s$ through each $x_0\in M_{b_0}$ satisfying $\pi s=\mathrm{id}$, $s(b_0)=x_0$ and $ds=h$. Prove the local existence theorem with joint holomorphic dependence on the initial point and on auxiliary parameters when the submersion and splitting vary holomorphically in compatible finite-dimensional complex-manifold parameter charts. No assertion over singular or nonreduced parameter bases is implicit.

The proof target includes the complex ODE theorem with holomorphic parameter dependence: construct a convergent Picard iteration on a common polydisc, use uniform convergence to prove holomorphy, and prove uniqueness. In local base coordinates, flatness makes the horizontal coordinate vector fields commute. Prove the commuting-flow identity and compose the local flows to obtain local product charts and horizontal sections; prove their uniqueness and compatibility on connected overlaps. The resulting germ–initial-value correspondence is natural under actual connection isomorphisms and compatible base changes. It is local, and contains no global continuation assertion.

This is the explicit mathematical replacement of the previous gap named holomorphic-horizontal-lifts. The gap itself is not a prerequisite, and no theorem about horizontal germs is stored as unexplained input data. Over a one-dimensional complex base, flatness of the holomorphic horizontal line distribution is automatic; in higher base dimension it is a genuine hypothesis.

**Hypotheses.**

- Finite-dimensional complex manifolds, a holomorphic submersion and a flat holomorphic splitting.
- For joint parameter dependence: a compatible local holomorphic family in finite-dimensional complex-manifold parameter charts, with flatness in the time directions.
- An initial point in the fiber of the chosen base point; conclusions hold after shrinking around it.

**API.**

- Prove local complex ODE existence, uniqueness and joint holomorphic initial-value and parameter dependence on common polydiscs.
- Construct commuting horizontal flows and local holomorphic product charts from the proved flatness of the splitting.
- Construct the natural bijection between initial points and local horizontal section germs, and prove uniqueness and overlap compatibility.

**Checks.**

- For the product splitting, the horizontal section through $(b_0,x_0)$ is $b\mapsto(b,x_0)$. The constant map $b\mapsto(b_0,x_0)$ is not a section on a nontrivial base.
- On $\mathbb C^2_{s,t}\times\mathbb C_y$, take $h\partial_s=\partial_s$ and $h\partial_t=\partial_t+s\partial_y$. A horizontal section would satisfy $y_s=0,\ y_t=s$, contradicting equality of mixed derivatives; flatness cannot be dropped.
- A theorem over a smooth parameter polydisc does not by itself provide a horizontal section over a singular or nonreduced base.

*Needs:* Local target:1.1 and target:1.2; ComplexKahlerGeometry §K1/K3.0/K4/K7.1 for complex differential and holomorphic convergence tools. The complex ODE, commuting-flow and holomorphic horizontal-germ constructions are owned here. There is no dependency on gap:holomorphic-horizontal-lifts.

**Dependency references.** `target:1.1`; `target:1.2`; `roadmap:ComplexKahlerGeometry §K1/K3.0/K4/K7.1`.

**Source scope.** An explicit generic analytic proof target replacing a formerly external gap. Specialized isomonodromic horizontal-section results are examples, not proof prerequisites.

**Proposed owner.** SmoothBundlesConnectionsPartII (proposed holomorphic horizontal-lift target H1); ComplexKahlerGeometry (proposed holomorphic ODE and flow adapter)

### 1.4 Completeness transferred by a proper semiconjugacy

Let $(M\to B,h)$ be a real connection from target:1.1. Let $p:R\to B$ be any continuous map of topological spaces carrying specified complete continuous transport: for every piecewise $C^1$ path $\gamma:[a,b]\to B$ with finitely many pieces and every $r_0\in R_{\gamma(a)}$, a continuous trajectory $\beta_{\gamma,r_0}:[a,b]\to R$ lies over $\gamma$, starts at $r_0$, and satisfies restriction and concatenation laws. The target need not be a manifold. Let $F:M\to R$ be continuous over $B$ and proper in the explicit sense that inverse images of compact subsets are compact.

Assume compatibility at every source point: every partial horizontal lift $x$ of $\gamma$ with initial point $x_0$ satisfies $F(x(t))=\beta_{\gamma,F(x_0)}(t)$ throughout its domain. Prove that every such base path has a unique horizontal lift on its entire compact interval through every initial point of $M_{\gamma(a)}$. Flatness is not needed for this completeness theorem.

Indeed, the complete target trajectory has compact image $K=\beta_{\gamma,F(x_0)}([a,b])$. Every partial lift is trapped in $F^{-1}(K)$; target:1.2 extends it through each finite endpoint, and local uniqueness glues the extensions. This proof uses properness of $F$, not properness of the phase projection $M\to B$. It does not use an inverse, injectivity or surjectivity of $F$. In particular, a nontrivial compact exceptional fiber is retained in full: the initial point in that fiber matters, and transport is not defined by choosing a preimage of the target trajectory.

For a holomorphic source splitting, apply the real theorem to its underlying real manifolds. Holomorphic local sections and homotopy invariance require the additional flatness and analytic results stated in their own targets. Compatibility only on a dense open subset, or properness only away from exceptional points, does not meet the hypotheses.

**Hypotheses.**

- A finite-dimensional C¹ Ehresmann splitting as in target:1.1; local existence and compact extension are supplied by target:1.2.
- A continuous target over B with specified complete continuous trajectories for all compact piecewise C¹ base paths, including restriction and concatenation laws.
- A continuous map F over B whose inverse image of every compact set is compact.
- Semiconjugacy for every partial horizontal lift through every source point, including exceptional points.

**API.**

- Construct the unique full horizontal lift of each compact piecewise $C^1$ base path through every source initial point from the proper semiconjugacy hypotheses.
- Prove completeness without choosing an inverse to F, and retain distinct initial points in every compact exceptional fiber.
- Apply the theorem to the underlying real geometry of a holomorphic splitting, without asserting flatness or holomorphic global sections from properness alone.

**Checks.**

- Take $M=\mathbb C_t\times\mathbb C_y$, $h\partial_t=\partial_t+y^2\partial_y$, $R=B=\mathbb C_t$ and $F=\pi$. The target transport is complete and the semiconjugacy holds, but $F$ is not proper. The lift through $y(0)=1$ has $y(1/2)=2$, $y(3/4)=4$ and no finite value at $t=1$.
- For a product connection and the identity comparison with its own constant-fiber transport, the theorem returns the constant fiber coordinate.
- If a proper comparison contracts an exceptional curve, the proof uses the compact inverse image of the target trajectory and local uniqueness at each point of that curve; replacing the fiber by one arbitrarily selected preimage fails the required initial-value statement.
- The $C^1$ path $\gamma(s)=|s-1/2|^{3/2}$ is permitted. Its merely continuous velocity is handled by target:1.2; an unproved $C^1$ autonomization is not an admissible shortcut.

*Needs:* Local target:1.1 and target:1.2. Compactness of continuous images and inverse images under the stated properness hypothesis are the only target-space topology used. No Riemann–Hilbert theorem, classical profile or properness of the phase projection is a prerequisite.

**Dependency references.** `target:1.1`; `target:1.2`.

**Source scope.** The proof mechanism is abstracted from the nonlinear connection and geometric continuation viewpoint exemplified by IIS06, Definitions 2.1–2.2 and Lemma 2.12. Its generic continuous-target formulation and exact hypotheses are proved in this module; those specialized results do not supply a universal proper comparison.

**Proposed owner.** SmoothBundlesConnectionsPartII (proposed proper-semiconjugacy completeness theorem), using the proposed DifferentialGeometry continuous-time extension

### 1.5 Fundamental-groupoid transport, universal covers and descent

Let a smooth real or holomorphic connection be flat and complete for all compact piecewise $C^1$ paths. Completeness is a hypothesis to be proved by the producer of the connection, by target:1.4 or another valid argument. From unique horizontal lifting construct endpoint maps $T_\gamma:M_{\gamma(a)}\to M_{\gamma(b)}$, with identity, reversal and concatenation laws. If $\gamma_1$ is traversed before $\gamma_2$, use the convention $T_{\gamma_2*\gamma_1}=T_{\gamma_2}\circ T_{\gamma_1}$.

Prove invariance under endpoint-fixed homotopy. Use local flat product charts, a finite subdivision of a compact homotopy, and uniqueness on overlaps; include the smooth approximation or subdivision step relating continuous homotopies to the piecewise smooth representatives. This constructs an action of the fundamental groupoid of $B$. Endpoint maps are diffeomorphisms in the smooth case and biholomorphisms in the holomorphic case. Symplectic preservation is not inferred here.

For connected $B$, a chosen $b_0$ and a pointed universal cover $p:\widetilde B\to B$, construct for each $x_0\in M_{b_0}$ a global horizontal section of the pulled-back family $\widetilde B\times_BM\to\widetilde B$. Prove it is smooth, or holomorphic in the holomorphic case, by the local product theorem. It descends to a section on $B$ if and only if $x_0$ is fixed by every actual monodromy map $T_\ell$ for based loops $\ell$. Thus the universal-cover solution and its descent obstruction are separate outputs. Pullback and connection-isomorphism naturality are proved using actual maps, including all exceptional points of a supplied phase space.

**Hypotheses.**

- A smooth real or holomorphic flat connection from target:1.1, with completeness for every compact piecewise C¹ base path established by its producer.
- For the universal-cover statement: a connected base with a chosen base point and pointed universal cover. Finite-dimensional manifolds meet the usual local covering hypotheses.
- No symplectic form or Riemann–Hilbert comparison is required.

**API.**

- Construct endpoint transport, prove concatenation, reversal and homotopy invariance, and obtain a fundamental-groupoid action by actual fiber isomorphisms.
- Construct the unique global horizontal section on the pulled-back family over the pointed universal cover through each initial point.
- Prove that the horizontal section descends to the original base exactly when its initial point is fixed by the full monodromy action.

**Checks.**

- A loop followed by its reverse acts as the identity on every initial point, including a point on an exceptional fiber of any separately supplied comparison.
- On $\mathbb C_t^\times\times\mathbb C^2_{q,p}$, the connection $q'=q/(2t),\ p'=-p/(2t)$ is complete and flat. One positive loop sends $(q,p)$ to $(-q,-p)$; two loops act identically. Exactly $(0,0)$ is fixed by every loop, although every initial point has a horizontal section on the universal cover.
- On $\mathbb C^2_{s,t}\times\mathbb C^2_{q,p}$, set $h\partial_s=\partial_s+\partial_q$ and $h\partial_t=\partial_t+q\partial_p$. This connection is complete but has curvature $\partial_p$. A rectangular loop with side increments $a,b$ translates $p$ by $ab$, so completeness without flatness does not give homotopy invariance.

*Needs:* Local target:1.1, target:1.2 and target:1.3; UniversalCovers §completed covering and lifting interface; SmoothBundlesConnections §B1.5/B5 for the smooth flat-product floor. target:1.4 is one optional producer of the completeness hypothesis, not a prerequisite of this theorem.

**Dependency references.** `target:1.1`; `target:1.2`; `target:1.3`; `roadmap:UniversalCovers §completed covering and lifting interface`; `roadmap:SmoothBundlesConnections §B1.5/B5`.

**Source scope.** Generic flat-connection and covering theory. The geometric monodromy viewpoint in IIS06 and the symplectic isomonodromy setting of BOA01 are downstream applications; no claim of symplecticity follows without target:1.6's hypotheses.

**Proposed owner.** SmoothBundlesConnectionsPartII (proposed complete nonlinear transport and descent targets), with the existing UniversalCovers interface

### 1.6 Symplectic preservation and the closed total two-form

Let $V=\ker d\pi$ for a smooth real or holomorphic submersion, let $h$ be a smooth or holomorphic splitting, and let $\omega$ be a smooth or holomorphic relative two-form on $V$ that is nondegenerate and closed on every fiber. These properties of $\omega$ must be proved by its producer. Define $v^V=v-h(d\pi v)$ and the actual total two-form $\Omega(v,w)=\omega(v^V,w^V)$. Prove that $\ker\Omega=\operatorname{im}h$.

For a base vector field $X$ and vertical fields $U,V$, define
$$
(D^h_X\omega)(U,V)=hX\bigl(\omega(U,V)\bigr)-\omega([hX,U],V)-\omega(U,[hX,V]).
$$
Compute all components of $d\Omega$: on three vertical vectors it is $d_V\omega$; on $(hX,U,V)$ it is $D^h_X\omega(U,V)$; on $(hX,hY,U)$ it is $-\omega(K_h(X,Y),U)$; on three horizontal vectors it is zero. Deduce, using vertical nondegeneracy, the equivalence
$$
d\Omega=0 \quad\Longleftrightarrow\quad K_h=0\ \text{and}\ D^h\omega=0.
$$
Prove separately that the locally defined parallel transport preserves the relative forms if and only if $D^h\omega=0$. Thus flatness and preservation are distinct conditions. With completeness, target:1.5 then yields symplectic global transport; completeness is not needed for the local criterion.

Under the proved horizontal-preservation condition $D^h\omega=0$, only for a one-dimensional time base, and after a local symplectic trivialization with the required local phase exactness, derive a Hamiltonian potential for $h\partial_t=\partial_t+X_H$ from $\iota_{X_H}\omega=d_{\rm phase}H$. In Darboux coordinates the intrinsic total form has the coordinate display $\Omega=\sum_i dq_i\wedge dp_i+dH\wedge dt$. Prove the time-only ambiguity in $H$ on connected phase charts and the transformation law under time-dependent symplectic coordinates by comparing the actual total forms. Do not use the one-time formula unchanged in several time variables, where horizontal–horizontal components require their own analysis.

**Hypotheses.**

- A smooth real or holomorphic submersion and a splitting of the same regularity.
- A relative two-form proved fiberwise closed and vertically nondegenerate; flatness and horizontal preservation are conclusions of the criterion only when total closedness is separately established.
- For the Hamiltonian coordinate lemma: horizontal preservation, a one-dimensional time chart, a local symplectic trivialization and local exactness of the resulting closed phase one-form.

**API.**

- Construct the total form from the vertical projection and prove its kernel identity and naturality.
- Prove the component formulas and the equivalence $d\Omega=0\iff(K_h=0\ \text{and}\ D^h\omega=0)$ under the stated fiberwise hypotheses.
- Prove the equivalence between infinitesimal horizontal preservation and symplecticity of all local parallel-transport maps.
- Derive the one-time Hamiltonian display, time-only ambiguity and time-dependent coordinate transformation law from the intrinsic total form.

**Checks.**

- On $\mathbb C_t\times\mathbb C^2_{q,p}$ take the product flat splitting and $\omega=e^t\,dq\wedge dp$. The associated $\Omega$ satisfies $d\Omega=e^t\,dt\wedge dq\wedge dp\ne0$; flatness alone does not imply symplectic preservation or total closedness.
- For $H=p^2/2$, contraction of $\partial_t+p\partial_q$ with $dq\wedge dp+p\,dp\wedge dt$ is zero, checking the sign in the Hamiltonian display.
- The potentials $H$ and $H+t^2$ give the same total two-form because $d(t^2)\wedge dt=0$.
- The relative zero form is closed but vertically degenerate; its total extension has full tangent kernel, so the kernel and curvature conclusions require nondegeneracy.

*Needs:* Local target:1.1 and target:1.2; ComplexKahlerGeometry §K1/K3.0/K4/K7.1 for relative forms, exterior differentiation and local symplectic calculus. Global transport, when desired, is a separate application of target:1.5 after completeness has been proved.

**Dependency references.** `target:1.1`; `target:1.2`; `roadmap:ComplexKahlerGeometry §K1/K3.0/K4/K7.1`.

**Source scope.** Generic tensor and differential-form proof. I23 Definition 11.4 and Corollary 11.8 and BOA01 §7 provide specialized geometric constructions and comparisons, not a theorem that flatness alone preserves an arbitrary relative form.

**Proposed owner.** SmoothBundlesConnectionsPartII (proposed symplectic nonlinear-connection criterion); ComplexKahlerGeometry (proposed total-form and local Hamiltonian comparison)

### 1.7 Admissible observations and meromorphic evaluation on curves

Let $S$ be a connected one-dimensional complex manifold and let $s:S\to M$ be a holomorphic map. Define admissible observation data by an actual holomorphic $\mathbb P^1$-valued map on a neighborhood of $s(S)$, or by meromorphic or rational presentation data for which evaluation along $s$ is proved to have a well-defined holomorphic $\mathbb P^1$-valued continuation. This is a marked observation; its domain and any comparison maps are retained.

Construct that continuation in the following elementary admissible case: local numerator–denominator presentations restrict along $s$ to holomorphic pairs that are not both identically zero. Remove their common vanishing order at each point of the curve, and prove the resulting local $\mathbb P^1$-maps agree on overlaps. Alternatively, if a resolution $\widehat M\to M$, a holomorphic observation $\widehat Q:\widehat M\to\mathbb P^1$ and a holomorphic lift $\widehat s$ are supplied, evaluation is $\widehat Q\widehat s$. Its independence of choices must be proved by comparison on a dense domain, or the lift must remain part of the observation marking. In particular, a curve wholly contained in an indeterminacy locus has no canonical rational evaluation merely because some lift exists.

If the evaluated map is not identically $\infty$, prove that it defines a meromorphic function on $S$. At a point with value $\infty$, its reciprocal is a holomorphic germ with a zero of finite order; the identity theorem excludes infinite order. Thus poles are isolated and of finite order. The curve hypothesis is essential to this formulation: higher-dimensional bases have polar divisors and possible indeterminacy, not a theorem of isolated poles.

Apply this local statement to horizontal germs from target:1.3 and, when separately supplied, to the universal-cover sections from target:1.5. For a universal cover, prove that the scalar observation descends exactly when the evaluated function is invariant under every deck transformation. A monodromy-fixed geometric initial point is sufficient, but not necessary, for scalar descent. Prove naturality under actual compatible observation maps, base changes and resolved comparisons on their stated domains.

**Hypotheses.**

- A connected complex curve S, a holomorphic map s into a complex phase manifold, and admissible marked observation data on its image.
- For local ratio construction: the restricted numerator and denominator are not both identically zero; comparisons on overlaps are part of the presentation to be proved compatible.
- For evaluation through a resolution: an actual holomorphic lift and observation, with independence proved or the lift retained as marking.
- For an ordinary meromorphic function: evaluation is not identically infinity. For scalar descent: a specified covering and its actual deck action.

**API.**

- Construct admissible evaluation by actual maps, one-variable cancellation of local ratios, or specified resolved lifts, and prove the claimed comparison independence.
- Prove finite-order isolated poles for a non-identically-infinite admissible evaluation on a complex curve.
- Prove that an observed function descends if and only if it is deck invariant; distinguish this from descent of the full geometric section.

**Checks.**

- The constant $\mathbb P^1$-valued map $Q\equiv\infty$ is allowed as a map but is excluded from the ordinary-meromorphic-function conclusion.
- For the rational observation $Q=[x:y]$ on $\mathbb C^2$ and the constant curve $s\equiv(0,0)$, both restricted coordinates vanish identically. Different directional lifts to the blowup have different values; no unmarked scalar value is defined.
- The observation $1/t$ on a punctured disc extends as a $\mathbb P^1$-map with reciprocal $t$ at the origin, giving one pole of order one.
- For the sign-monodromy example $q'=q/(2t),\ p'=-p/(2t)$ over $\mathbb C^\times$, the observation $q^2$ descends to the base even when the geometric section with nonzero initial data does not. Scalar descent cannot be characterized only by a fixed initial point.

*Needs:* Local target:1.1 for compatibility with phase maps; ComplexCurveModuli §D0/D2.0 and ComplexKahlerGeometry §K1/K3.0/K4/K7.1 for one-variable holomorphic and meromorphic calculus. Horizontal sections from target:1.3 or target:1.5 are optional supplied inputs to this general evaluation theorem, not prerequisites.

**Dependency references.** `target:1.1`; `roadmap:ComplexCurveModuli §D0/D2.0`; `roadmap:ComplexKahlerGeometry §K1/K3.0/K4/K7.1`.

**Source scope.** Generic complex-curve evaluation and descent. IIS06's geometric definition of solution and VDPS09's scalar coordinates motivate applications; arbitrary rational observations do not automatically satisfy admissibility.

**Proposed owner.** ComplexCurveModuli (proposed meromorphic evaluation lemma); SmoothBundlesConnectionsPartII (proposed marked observations of horizontal sections)

### 1.8 Intrinsic first jets and local scalarization

Let $B$ be a complex time curve, let $\rho:E\to B$ be a holomorphic submersion of relative dimension one, and let $(M\to B,h)$ be a holomorphic nonlinear connection. Construct the first-jet bundle $J^1(E/B)$ intrinsically: its fiber over $e\in E_b$ is the affine space of complex-linear splittings $j:T_bB\to T_eE$ of $d\rho_e$. Construct its holomorphic transition maps and prove that these splittings correspond to first jets of local holomorphic sections of $E\to B$.

An observation $Q:M\to E$ over $B$ defines
$$
J_Q(x)=\bigl(Q(x),dQ_x\circ h_x\bigr)\in J^1(E/B).
$$
On an explicitly specified open $U\subset M$, assume and verify that $J_Q:U\to V$ is a biholomorphism onto an open $V\subset J^1(E/B)$. Transport the splitting to $V$ and prove its contact compatibility: along its horizontal curves, the jet coordinate is the derivative of the observed section. This constructs the corresponding second-order dynamics. Prove a bijection between horizontal section germs in $U$ and observation-section germs whose first jets lie in $V$ and solve that dynamics. The inverse uses the actual inverse of $J_Q$; it is not supplied by dimensional counting or by formal elimination.

As a downstream coordinate lemma choose $(t,q,p)$ on $U$, write $h\partial_t=\partial_t+A(t,q,p)\partial_q+B(t,q,p)\partial_p$, and suppose the jet map $(t,q,p)\mapsto(t,q,A(t,q,p))$ has the specified inverse $p=P(t,q,v)$. Then the intrinsic second-order dynamics has the display
$$
q''=\bigl(A_t+A A_q+B A_p\bigr)\bigl(t,q,P(t,q,q')\bigr).
$$
Prove naturality under actual connection and observation-bundle isomorphisms, and under noncritical time changes. Arbitrary ramified base change still defines the pullback connection of target:1.1, but need not preserve this jet-isomorphism hypothesis. The theorem assumes no symplectic structure, no completeness, no meromorphic continuation property and no named scalar equation.

**Hypotheses.**

- A holomorphic nonlinear connection over a complex curve, a holomorphic observation bundle E→B of relative dimension one, and an actual observation Q over B.
- An explicitly specified open domain on which the constructed first-jet map is proved biholomorphic onto an open subset of the first-jet bundle.
- For coordinate formulae: the displayed chart and actual inverse P. For naturality of the scalarized chart under a time change: its derivative is nonzero.

**API.**

- Construct the affine first-jet bundle, its holomorphic transition maps, its identification with section jets and the intrinsic observation jet map.
- Transport the connection across a proved jet isomorphism, establish the contact condition and prove the local solution-germ correspondence with its actual inverse.
- Derive the scalar second-order display by the chain rule and prove its naturality on the stated noncritical coordinate domains.

**Checks.**

- When $A=p$, the jet inverse is $p=q'$ and the second-order equation is $q''=B(t,q,q')$.
- If $A$ is independent of $p$, the jet map loses the momentum variable and has no open-set inverse in a two-dimensional phase chart.
- For $A=p^2$, the jet map has separate local inverse branches away from $p=0$ but no automatic global inverse; at $p=0$ its differential loses rank.
- Clearing denominators in a scalar display does not create a solution in a phase chart where the observation or jet inverse is undefined; the original domain is retained.
- Under $\tau=t^2$ at $t=0$, the time derivative vanishes. Pullback connections still exist, but the noncritical time-change comparison of scalar jets does not apply.

*Needs:* Local target:1.1; ComplexKahlerGeometry §K1/K3.0/K4/K7.1 and DifferentialGeometry §Layers 0–1 and Layer 3/3.5 for holomorphic tangent bundles, affine-bundle gluing, the chain rule and local inverse calculus. Neither symplectic target:1.6 nor meromorphic-observation target:1.7 is a prerequisite.

**Dependency references.** `target:1.1`; `roadmap:ComplexKahlerGeometry §K1/K3.0/K4/K7.1`; `roadmap:DifferentialGeometry §Layers 0–1 and Layer 3/3.5`.

**Source scope.** Generic first-jet construction and chain-rule proof. VDPS09 §4.1 and its displayed classical systems are downstream examples of the coordinate lemma, not assumptions or a definition of the scalarized dynamics.

**Proposed owner.** DifferentialGeometry (proposed intrinsic first-jet construction and scalarization); ComplexKahlerGeometry (proposed holomorphic jet adapter)

### 1.9 Finite-chart solution convergence and a no-exit argument

Let $I=[a,b]$ be compact, let $M$ be a fixed finite-dimensional smooth manifold, and let $F_\varepsilon(t,\cdot)$ be actual time-dependent tangent fields on common domains, for parameters $\varepsilon$ near $0$ in a metric parameter space. Fields are continuous in time and locally uniformly Lipschitz in phase. If phase spaces vary, the application must first supply actual common identifications and verify these hypotheses for the transported fields. Let $x_0:I\to M$ be an existing solution for $F_0$.

Assume a finite subdivision $a=a_0<\cdots<a_N=b$ and common phase charts such that, in each chart, the closed tube $\{(t,y):t\in I_j,\ \|y-x_{0,j}(t)\|\le r_j\}$, with a fixed $r_j>0$, is compactly contained in a larger common time–phase domain. Thus the reference graph has the explicit positive margin $r_j$ from the lateral boundary of its tube. Choose compact overlap neighborhoods in which the chart transitions and their derivatives are controlled. On each fixed tube suppose $F_\varepsilon\to F_0$ uniformly and the phase Lipschitz constants $L_j$ can be chosen independent of sufficiently small $\varepsilon$. The matched initial points $x_\varepsilon(a)$ converge to $x_0(a)$. Existence on all of $I$, confinement to the tube cover and uniform convergence of the approximate solutions are conclusions, not hypotheses.

Construct local approximate solutions using target:1.2. Until the first possible exit from the $j$th tube, prove the Grönwall estimate
$$
\sup_{t\in I_j}\|x_\varepsilon(t)-x_0(t)\|
\leq \bigl(\|x_\varepsilon(a_j)-x_0(a_j)\|+\ell_j\delta_{\varepsilon,j}\bigr)e^{L_j\ell_j},
\qquad
\ell_j=a_{j+1}-a_j,\quad
\delta_{\varepsilon,j}=\sup_{\text{tube}_j}\|F_\varepsilon-F_0\|.
$$
Here the supremum is first taken over the common interval before exit; after excluding exit it holds over $I_j$. Choose $\varepsilon$ so that this bound is smaller than the prescribed margin. A first exit is then impossible, and compact extension gives the entire segment. Transfer the endpoint estimate through the controlled chart overlap and induct over the finitely many segments. This yields uniform convergence on $I$ in any compatible metric on a compact neighborhood of the reference graph. Do not assert a single unchanged Lipschitz constant across arbitrary coordinate transitions.

For horizontal lifts, the pulled-back vector field contains $\gamma'(t)$; a $C^1$ base path gives a continuous-time ODE and is covered by target:1.2. Holomorphic phase fields uniformly bounded on larger common complex neighborhoods supply uniform phase Lipschitz constants on smaller tubes by Cauchy estimates. Convergence of coefficients without common domains, a no-exit margin and matched initial data is insufficient. Uniformity over a family of time paths or a compact time domain requires additional uniform path and chart controls. Fixed compact-path convergence asserts neither convergence on unbounded rays nor convergence through excluded singular endpoints.

**Hypotheses.**

- A fixed finite-dimensional manifold, or verified common identifications supplied by the application, and continuous-time locally phase-Lipschitz tangent fields on common domains.
- An existing reference solution on a compact interval, a finite common chart subdivision, fixed closed radius-r_j tubes compactly contained in common time–phase domains with r_j>0, and controlled compact overlap neighborhoods.
- Uniform field convergence on those tubes and phase Lipschitz constants uniform for sufficiently small parameters.
- Matched initial data converging to the reference initial point. No global approximate solution or prior no-exit conclusion is assumed.

**API.**

- Prove the until-exit segmentwise Grönwall estimate with explicit interval lengths, field errors and incoming initial errors.
- Exclude first exits using the positive margins, extend each solution segment by compact extension, and transfer errors through finitely many controlled chart transitions.
- Deduce existence on the entire compact interval and uniform convergence; state the additional uniform controls required before quantifying over families of paths or time domains.

**Checks.**

- On $I=[0,2]$, take $F_n=1/(n+1)$, $F_0=0$ and common initial value $0$. Then $x_n(t)=t/(n+1)$ and $\sup_I|x_n-x_0|=2/(n+1)$, agreeing with the estimate.
- Even for identical zero fields, initial values $x_n(0)=(-1)^n$ do not converge; coefficient convergence alone does not imply solution convergence.
- Convergence of coefficients on one chart does not control a trajectory after it leaves that chart; the common tubes and positive no-exit margins cannot be omitted.
- The solutions $x_n(t)=t/(n+1)$ converge uniformly on every fixed compact interval but not uniformly for $t\in[0,\infty)$. The compact-path conclusion does not contain an unbounded-ray assertion.

*Needs:* Local target:1.2; DifferentialGeometry §Layers 0–1 and Layer 3/3.5 for charts, norms and integral estimates; ComplexKahlerGeometry §K1/K3.0/K4/K7.1 for the optional Cauchy-estimate route to uniform phase Lipschitz bounds. The Grönwall, finite-chart and no-exit adapters are proved here. No collision, confluence, proper-comparison or Painlevé target is a prerequisite.

**Dependency references.** `target:1.2`; `roadmap:DifferentialGeometry §Layers 0–1 and Layer 3/3.5`; `roadmap:ComplexKahlerGeometry §K1/K3.0/K4/K7.1`.

**Source scope.** Generic finite-dimensional continuous-dependence theorem with an explicit finite-chart no-exit proof. A geometric degeneration must independently construct the common identifications and verify the hypotheses; coefficient limits alone are not that construction.

**Proposed owner.** DifferentialGeometry (proposed parameter-dependent finite-chart ODE convergence and no-exit target); SmoothBundlesConnectionsPartII (proposed horizontal-lift application)

## Source orientation and ownership

The proofs of the general assertions are the obligations above. The following primary sources explain important downstream geometric settings; their specialized scope must not be silently enlarged.

- **IIS06:** Inaba, Iwasaki and Saito, [Dynamics of the Sixth Painlevé Equation](https://arxiv.org/abs/math/0501007v2), Definitions 2.1–2.2 and Lemma 2.12 for nonlinear connections and continuation; later sections for its specific geometric application.
- **I23:** Inaba, [Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation](https://sigma-journal.com/2023/013/), Definition 11.4 and Corollary 11.8 for the constructed total form in the stated moduli setting.
- **BOA01:** Boalch, [Symplectic Manifolds and Isomonodromic Deformations](https://arxiv.org/abs/2002.00052v1), §7 for the isomonodromic symplectic setting under its hypotheses.
- **VDPS09:** van der Put and Saito, [Moduli spaces for linear differential equations and the Painlevé equations](https://arxiv.org/abs/0902.1702v5), §4.1 for displayed first-order systems and downstream scalar comparisons. This module does not import their displayed coefficients as intrinsic definitions.

The module’s proposed upstream ownership is recorded target by target in plan.json. No upstream roadmap was edited by creating these files. A future extraction may change the physical location of a target, while preserving its mathematical hypotheses, dependency edges and exported comparison laws.

