# 独立数学レビュー：NonlinearConnections 第1ラウンド

**判定：再利用する契約の精密化を要する。** 九つの一般定理の数学的本体に critical/high の誤りは見つからなかった。medium の適用範囲修正2件と、日本語の論理量化の明確化1件を修正した後で最終受理する。証明そのものが完成したという判定ではない。

レビュー対象は凍結した英語版、日本語版、plan.json であり、manifest の全SHA-256と一致することを確認した。元ファイルは変更していない。英語statement・仮定・API・検証事項・NeedsとJSONの一致、内部参照の解決、非循環性、Painlevé適用や自身のgapへの依存がないことも確認した。

## N-R1：1.5を呼ぶ際の平坦性を保持する（medium）

1.6の局所保存判定は平坦性を仮定せず正しい。一方、statementとNeedsの「完備性を加えれば1.5」という任意追加の結論では、1.5が要求する平坦性を省略している。**平坦性と完備性をともに証明した後で1.5を用いる**と英日・JSONに明記する必要がある。

反例として、既存1.5の例 $h\partial_s=\partial_s+\partial_q$, $h\partial_t=\partial_t+q\partial_p$ は $\omega=dq\wedge dp$ も保存する。全てのコンパクト経路で完備だが曲率は $\partial_p$ であり、長方形ループは $p$ を $ab$ だけ動かす。したがって保存性と完備性だけから基本亜群の作用を得ることはできない。局所保存判定自体に不要な平坦性を付け加えるのではなく、大域の1.5適用の条件に保持する。

## N-R2：deck不変性の降下判定に被覆の範囲を保持する（medium）

1.7の本文は普遍被覆上で述べており正しい。しかし仮定欄は単に「指定した被覆」、APIは無条件にdeck不変性との同値と読める。普遍被覆を仮定/APIにも明記する。正規被覆まで拡張するなら、deck群が各ファイバー上推移的に作用することを明示して証明する。

任意の被覆では結論は誤る。$p(z)=z^3-3z$ は $\mathbb C\setminus\{-2,-1,1,2\}$ から $\mathbb C\setminus\{-2,2\}$ への連結3枚被覆である。二つの局所モノドロミーは異なる互換で $S_3$ を生成し、deck群は自明になる。$f(z)=z$ はdeck不変だが、$p^{-1}(0)=\{0,\sqrt3,-\sqrt3\}$ 上で異なる値を持つので降下しない。本文の普遍被覆条件はこの問題を回避している。

幾何学的切断が降下しなくても $q^2$ が降下する既存の例は維持する。これはscalar descentがphase descentより弱いことを正しく検証している。

## N-R3：日本語の「not both」の量化を明確にする（low）

1.7の「両方が恒等的には零でない」は、各関数がそれぞれ非零であるという強い条件にも読める。意図は「少なくとも一方が恒等的に零ではない」である。$(0,1)$ と $(1,0)$ はどちらも許容された定値 $\mathbb P^1$ 写像を与える。statementと仮定欄の両方を明確にする。共通の孤立零点は約分の対象なので、各点で同時に零にならないという条件へ強めてはならない。

## 各目標の数学的確認

| 目標 | 結果と確認内容 |
| --- | --- |
| 1.1 | pass — C¹ path-lifting branch is separated from smooth curvature/form assertions; arrows and base changes are actual maps with the correct pullback splitting. Neither completeness nor properness is in the definition. |
| 1.2 | pass — The time variable is only continuous, with uniform local phase Lipschitz control. Compact extension uses local uniqueness and a compact containment hypothesis, not a cluster point alone. The C¹-path counterexample rules out unjustified C¹ autonomization. |
| 1.3 | pass — Holomorphic local ODE and parameter-dependence proof obligations are explicit; flatness yields commuting flows. Smooth parameter charts are distinguished from singular/nonreduced parameter bases. |
| 1.4 | pass — Continuous image of the target path is compact and proper inverse image traps every partial source lift. No inverse of the comparison, no source projection properness, no target smoothness, and no deletion of exceptional points are used. |
| 1.5 | pass — The statement retains both flatness and completeness, actual path transport, continuous-homotopy comparison, universal-cover holomorphy, and the full monodromy fixed-point condition for phase descent. |
| 1.6 | pass core theorem; revise optional export — All four dΩ components have the correct signs, vertical nondegeneracy gives the asserted equivalence, and the one-time Hamiltonian sign passes H=p²/2. The optional target 1.5 invocation must retain flatness (N-R1). |
| 1.7 | pass main theorem; revise contract scope and Japanese quantifier — Curve cancellation and finite-order poles are valid with the stated exclusions; resolved-lift marking prevents indeterminacy ambiguity. The main universal-cover scalar-descent theorem is correct and weaker than geometric descent. The exported covering hypothesis and API must retain its scope (N-R2); Japanese quantifier should be explicit (N-R3). |
| 1.8 | pass — The jet carrier is intrinsic and scalarization requires an actual local biholomorphism. The coordinate formula follows by differentiating q′=A and using its proved inverse. Ramified time change is correctly separated from noncritical jet naturality. |
| 1.9 | pass — Fixed compact tubes and positive margins precede Grönwall; existence and no-exit are conclusions. Incoming errors are transferred through controlled chart changes, and local Lipschitz constants are allowed to change. Fixed compact-path convergence is not exported to rays or endpoints. |

## 閉鎖条件

N-R1とN-R2の条件を英語・日本語・JSONに揃え、N-R3の量化を明確にした差分を再確認する。局所定理の前提を不必要に強めたり、普遍被覆上でのスカラー降下を幾何学的切断の降下と同一視したりしない。全件閉鎖後に、このモジュールのロードマップ契約を受理できる。

## 凍結版の識別

| ファイル | SHA-256 |
| --- | --- |
| README.md | `8b02e0ae9538eb05b5079234251944754c8b8ca7ef18bbda6dc7dd69557d0d7a` |
| README.ja.md | `83d949277224565603637e3df7301d9f279c6475f986a32eff54a2abf11bc5a2` |
| plan.json | `71d816823b19215ace7e44bf908e917236904735975e8254a903f96a7c043c12` |
