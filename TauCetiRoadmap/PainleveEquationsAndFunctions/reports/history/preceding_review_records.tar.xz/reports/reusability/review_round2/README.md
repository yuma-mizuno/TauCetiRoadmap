# Roadmap: intrinsic Painlevé equations and functions

**Summary.** Construct Painlevé dynamics from moduli of meromorphic connections, and construct Painlevé functions from the horizontal sections of that dynamics. The input consists of a curve, a structural polar divisor, a determinant connection, local formal moduli conditions, and stability and marking data. The phase space, its symplectic form, and its horizontal distribution are constructed from this input. A common continuation theorem precedes every classical scalar equation. The ten underlying rank-two formal profiles, their labelled realizations, their eight additive surface types, and the six classical differential equations are comparison results. The theory includes resonant parameters, allowed reducible connections, ramified irregular singularities, special invariant loci, tau sections, normalized analytic solutions, and confluence. Elementary coefficient degenerations are covered by a separate boundary comparison. JMU/Hamiltonian comparisons of tau sections have the precise generic scope stated in Layer 8; the determinant construction itself has the broader marked-RHP scope specified there.

## Reusable proof packages and independent consumers

This revision treats reusability as an acceptance condition: a general proof must have its own mathematical inputs, outputs, laws, counterexamples and owner, and its dependency closure must contain no Painlevé application target. The companion files are part of this draft, not merely suggestions to write another roadmap later.

| Package | Construction or theorem | Independent consumers |
|---|---|---|
| [NonlinearConnections](frameworks/NonlinearConnections/README.md) | General nonlinear connections, local lifts, proper transfer, monodromy/descent, symplectic form, observers, intrinsic jets, compact-path limits | This roadmap; FiveLogarithmicPoints; other smooth/holomorphic connection problems |
| [MeromorphicConnectionModuli](frameworks/MeromorphicConnectionModuli/README.md) | Admitted decorated moduli → coherent flat symplectic nonlinear connection; regular-singular RH branch | Degree-four classical input; five logarithmic points; admitted higher-rank/genus data |
| [AnalyticRHPAndDeterminants](frameworks/AnalyticRHPAndDeterminants/README.md) | Complex Fredholm determinant, Cauchy-class RHP, uniform moments/tails, normalized limits | This roadmap; independent operator and RHP problems |
| [AlgebraicConfluence](frameworks/AlgebraicConfluence/README.md) | Vector-valued principal-part cancellation and relative dual Lie–Poisson structures | This roadmap; other pole-collision and finite-algebra problems |
| [FiveLogarithmicPoints](applications/FiveLogarithmicPoints/README.md) | A second worked consumer with two-dimensional time and four-dimensional phase fibers | Uses the first two packages without importing a Painlevé target |

The general framework is not an axiom saying that an arbitrary connection is complete, nor an unrestricted moduli theorem. Each theorem retains its exact hypotheses. General existence/flatness/symplecticity are constructed in the moduli package; completeness requires a separately proved proper semiconjugacy. The classical degree-four restriction occurs only in §1.3. Coordinate equations remain downstream comparisons in Layer 9. See [REUSABILITY.md](REUSABILITY.md) for the ownership and proof-reuse contract and [the Japanese version](REUSABILITY.ja.md).

The structured graph is a local draft extension with explicit framework references. No claim is made that the official Worker has accepted this extended graph or that the proposed upstream targets have already been implemented. Historical Lean records are retained only as dated evidence and are outside this mathematical revision.

## Scope and ownership

The reusable constructions and the Painlevé application have separate proof targets and dependency graphs. NonlinearConnections owns general nonlinear-connection, continuation, jet and convergence theorems. MeromorphicConnectionModuli constructs those objects from its admitted geometric input, with a separately scoped regular-singular RH branch. AnalyticRHPAndDeterminants owns the general determinant and RHP analysis; AlgebraicConfluence owns the finite-algebra and pole-cancellation lemmas. This roadmap owns the classical restriction and its hypothesis checks, formal-profile classification, the remaining classical irregular/Stokes and proper-RH extension, observable and surface comparisons, transformations, and the analytic and confluence application adapters. It consumes the same underlying objects and theorems; it does not define parallel carriers. General proof ownership, proposed Tau Ceti destinations and migration of the earlier targets are recorded in REUSABILITY.md and design/reuse_registry.json.

The generic formal connection and formal gauge language is supplied by FormalConnectionsOpers F2–F3. Finite-ramification normal forms are consumed directly from PadicDifferentialEquationsAndRigidCohomology §RD.6.52a. The word “formal” in those contracts does not supply an analytic Stokes classification or a global isomonodromic deformation. SchemeAndStackFoundations supplies stacks, deformation foundations and Quot/Hilbert constructions. AlgebraicModuliForArithmeticGeometry supplies rigidification and general representability criteria. ComplexComparisonPartII supplies complex analytic spaces, coherent analytification and its stated regular-singular comparisons. SmoothBundlesConnections supplies general smooth connections and transport; DifferentialGeometry supplies local and maximal flows. Their mathematical objects are used through adapters, not recreated under Painlevé-specific names.

RandomMatrices §8.5 owns Hastings–McLeod existence and uniqueness, real pole-freeness, and its Fredholm/Tracy–Widom identities. Section 10.4 here owns only the bridge from that scalar solution to an intrinsic horizontal section. RandomMatrices is a supplier of that bridge; it is not made to depend on this roadmap. The trace-class determinant required by the tau branch is consumed from RandomMatrices §8.3 at its stated operator generality. New applications using both theories are downstream consumers of both.

Difference and q-difference Painlevé dynamics, a general Sakai classification of discrete systems, cluster realizations, arbitrary-rank wild nonabelian Hodge theory, a classification of every algebraic special solution, and numerical connection constants for every asymptotic regime have different scope. They are not prerequisites of the differential theory specified here. Rational and classical-function solutions included here are the explicit families obtained from the geometric reductions and transformations of Layers 7 and 9; no completeness classification of all such solutions is asserted.

## Conventions

Work over ℂ. Curves are smooth connected projective curves, with a finite nonempty ordered set of pairwise distinct marked points. The general rank is an integer r ≥ 1; slope stability is defined on this positive-rank domain. A ramified local condition also satisfies the rank and local-order restrictions of its stated formal model. The classical subcategory has genus zero and rank two. Write P = Σ mᵢaᵢ for the structural polar divisor; it bounds the poles and records the local moduli problem. It is not the divisor of nonzero poles of each individual connection. Apparent singularities and scalar residues at a marked point are allowed when the local conditions allow them. The auxiliary unfolding in §2.3 and the collision data of §11.1 use separately constructed finite-flat divisors; their special fibers need not consist of distinct marked sections.

An object is a vector bundle E on the whole curve, a meromorphic connection ∇: E → E ⊗ Ω¹(P), an isomorphism of its determinant connection with the specified line connection, and the local structures below. All relevant bundle splitting types are retained. The general input permits a meromorphic determinant; the classical complexity subcategory uses a regular-singular determinant with fixed residues and its compatible moving-curve transport. This still allows odd determinant degree. At a logarithmic point prescribe residue eigenvalues and a compatible filtration; do not freeze one complete formal isomorphism class at resonant parameters. At an unramified irregular point use a generic distinct-leading-term formal condition. At a ramified point use the generic factorized ramified condition, with ramified descent. Leading coefficients required to be nonzero remain nonzero within a fixed irregular stratum. Their vanishing belongs to Layer 11.

Weights are denoted w, avoiding confusion with the classical scalar coefficient α. Use generic stability weights for which semistability equals stability on the specified numerical data. Stability concerns ∇-invariant subbundles. Changing a weight chamber is a wall-crossing problem, not an auxiliary-choice invariance. Isomorphisms preserve the determinant identification, labels and prescribed local structures. Retain these arrows before rigidification or passage to a coarse moduli space. For a stable rank-two object with determinant identification fixed, the residual scalar group is μ₂, not the full multiplicative group; fixing the determinant and rigidifying this remaining group are different operations.

Write Θ for fixed external residue/exponent parameters and Bθ for an admitted marked time base with θ ∈ Θ fixed. Write πθ: Mθ → Bθ for the phase family. The distinction between fixed parameters and time directions is part of the deformation problem. For the convention ∇ = d + A, a logarithmic residue λ has monodromy eigenvalue exp(−2πiλ); sources using d − A or exponent θ = −λ have exp(2πiθ). Retain the actual logarithm parameters in the fiber product defining the comparison target: forgetting them is not a proper map.

The horizontal splitting is h: π*TB → TM with dπ ∘ h = id. Its image is the invariant dynamics. A vector field representing it requires a chosen time vector. A local solution is a holomorphic section s of π satisfying ds(v) = h(v), with a specified initial point. Paths are compact piecewise C¹ paths in the fixed admitted base. The base is never punctured further according to the poles of a selected solution.

Use ω = dq ∧ dp and ι_Xω = d_phase H in a Hamiltonian chart. Thus q′ = H_p and p′ = −H_q. The extended form is Ω = dq ∧ dp + dH ∧ dt, whose kernel contains ∂t + X. Under τ = f(t) the normalized horizontal generator scales by dt/dτ. A scalar Hamiltonian is local and can change by a time-only function or by the generator of a time-dependent symplectic coordinate change.

“Painlevé function” first means a geometric horizontal section or its germ. A scalar function is the evaluation of a specified admissible observable, with a time coordinate and normalization. An everywhere defined map to ℙ¹ may give the constant value ∞; the usual meromorphic-function conclusion excludes that case. Universal-cover continuation and single-valued descent to B are different conclusions.

## Exact supplier contracts

### Existing mathematical foundations

Use the existing mathematical carriers for manifolds, tangent and vector bundles, sheaves, schemes, complexes, groupoids, proper maps and bounded operators. Generic connection, deformation and determinant constructions extend these objects through the precise supplier contracts below. Historical implementation and declaration audits are retained with their frozen review versions; they are not prerequisites or completion gates for this mathematical revision.

### From TauCetiRoadmap.SchemeAndStackFoundations

Consume §1.18 for stacks and 2-fiber products, §1.23 for the stated moduli interfaces, §§4.2–4.6 for infinitesimal deformation and obstruction foundations, and §4.14 for the Noetherian projective Quot/Hilbert and Hom/Isom constructions. Use §§2.2, 2.6 and 2.7 for Čech/coherent cohomology and cohomology with supports, §2.20 for relative duality and the coherent Serre pairing, and §3.3 for vector-bundle degrees and curve Riemann–Roch. For Layer 6 use §3.4's divisor/Picard groups, §4.11's modifications and strict transforms, §4.17's normal-crossing divisors, and §§5.9–5.10's surface intersection pairing, adjunction and numerical lattice theory. The logarithmic deformation and boundary-Picard calculations specific to these pairs are constructed in §6.1. MeromorphicConnectionModuli owns the particular connection functor, its equations, boundedness and deformation complex; Layer 2 here verifies their classical specialization. A generic representability criterion does not itself construct this moduli space.

### From TauCetiRoadmap.AlgebraicModuliForArithmeticGeometry

Consume §5.1 for rigidification and §7.1 for the stated Artin representability criteria; use §8's framed deformation/versality machinery only after checking its hypotheses on the connection deformation complex. The scalar-gerbe and tensor-descent constructions are owned by MeromorphicConnectionModuli §§2.1–2.4. Layer 2 here verifies the classical restriction of that same construction.

### From TauCetiRoadmap.FormalConnectionsOpers

Consume F2.1–F2.4 for algebraic sheaf connections and the stated analytic horizontal-trivialization comparison in its regular setting, and F3 for formal gauge groupoids. F6.2 concerns cyclic vectors and the flag/oper equivalence, and is not the finite-ramification normal-form supplier. F8's formal oper isomonodromy groupoid does not provide the analytic time connection of Layer 3.

### From TauCetiRoadmap.PadicDifferentialEquationsAndRigidCohomology

Consume §RD.6.52a only in its characteristic-zero Laurent-series formal-normal-form and descent scope. Layer 1 specializes it to complex rank-two local moduli conditions. No p-adic analytic theorem is used as a complex sectorial theorem.

### From TauCetiRoadmap.ComplexComparisonPartII and ComplexCurveModuli

Consume ComplexComparisonPartII C−1.1 for the generic complex analytic-space carrier, coherent analytic quotients, gluing, fiber products and scheme analytification; C0 for the corresponding coherent-module language. Use C5.6 only for its regular-singular Riemann–Hilbert scope. ComplexCurveModuli D2.0 supplies the native-manifold/analytic-space adapter and D0 the stated genus-zero family comparisons. Neither supplies a ramified Stokes theorem. MeromorphicConnectionModuli owns the general meromorphic moduli and regular-singular comparison. This application owns the remaining classical irregular descent and its analytic comparisons. For the boundary Picard carrier in §6.1, use ComplexComparisonPartII C3.2d.2 and C3.2f.1–2 after proving their proper-flat and universal-functions hypotheses; smooth geometrically integral curve representability does not cover a nonreduced Y.

### From TauCetiRoadmap.JacobianChallenge

Consume Layer C's proper coherent direct-image, cohomology-and-base-change and constant-rank comparison at their actual hypotheses, including the Grauert-style locally free base-change conclusion. In §6.3 verify these hypotheses for the boundary-line family. Do not replace arbitrary base change by the flat-base-change statement alone.

### From TauCetiRoadmap.AnalyticNumberTheoryPartII

Consume §§4.3 and 4.3a for the canonical Barnes G function, its Weierstrass-product normalization G(1) = 1, gamma recurrence with its pole/zero domains, zero multiplicities and sectorial logarithmic asymptotics with remainder. These are used only in §10.3's explicit connection constants. This proposed supplier is not an assertion that a Barnes G carrier is already present in Mathlib.

### From TauCetiRoadmap.SmoothBundlesConnections and DifferentialGeometry

Consume SmoothBundlesConnections B1.5 for Ehresmann splittings and its proper-submersion theorem, B5 for the transport/flat-bundle/fundamental-group interfaces, and DifferentialGeometry Layer 3, including §3.5, for local, maximal and time-dependent smooth flows. The projection Mθ → Bθ is not assumed proper; the proper map used in Layer 5 is the Riemann–Hilbert comparison.

The explicit proof target NonlinearConnections §1.3, proposed for SmoothBundlesConnectionsPartII H1, provides: an integrable holomorphic Ehresmann splitting of a submersion between finite-dimensional complex manifolds has unique local holomorphic horizontal sections through every point, jointly holomorphic in initial data and auxiliary holomorphic parameters.

This is a specified complex extension of the smooth transport supplier, placed before the solution layer; it is not asserted to be a theorem already written in B1.5. Its proof is owned by NonlinearConnections §1.3, using complex local ODE existence and parameter dependence, with the multivariable compatibility supplied by integrability.

### From TauCetiRoadmap.RandomMatrices

Consume §8.3's trace-class Fredholm determinant construction and identities for the determinant branch after establishing that the operators here satisfy that contract. Consume §8.5's scalar Hastings–McLeod existence/uniqueness and real pole-freeness only in §10.4. The determinant line of a family of general index-zero Fredholm operators, its descent, and its relation to Riemann–Hilbert solvability are separate constructions in Layer 8.

### From TauCetiRoadmap.HeegaardFloer and OperatorTheory

Consume HeegaardFloer §2.2/F0.0 for its real Fredholm determinant-line stabilization, exact-sequence comparison and pullback laws; its real bundle is not a holomorphic complex line. Consume OperatorTheory/ToeplitzOperators T3 for the complex matrix-symbol Fredholm/index theorem, and OperatorTheory/OperatorIdeals OI-B23/OI-B30 for the relevant operator-ideal and trace-class carrier. The operators attached to connection data, their index-zero normalization, their canonical section and their marking comparisons are application constructions in Layer 8.

The explicit proof target AnalyticRHPAndDeterminants §1.1, proposed for HeegaardFloerPartII F0.0C, provides: a holomorphic family of complex index-zero Fredholm operators has a holomorphic determinant line and canonical section constructed through finite-dimensional stabilizations, with comparison isomorphisms satisfying refinement, cocycle and holomorphic base-change laws.

This proposed complex extension of F0.0 is developed in the independent analytic framework before the §8.1 binding; a real determinant line or an arbitrary closed two-form does not discharge it.

### From TauCetiRoadmap.ComplexKahlerGeometry and AlgebraicVectorBundles

Consume ComplexKahlerGeometry K1's complex inverse/implicit-function comparison, K3.0's holomorphic calculus, K4's holomorphic connection, gauge, tensor, pullback and curvature interfaces, and K7.1's projective-space charts. Use AlgebraicVectorBundles L0A–L0C/L1A–L1B for locally free sheaves, duals, determinants and geometric bundle carriers. MeromorphicConnectionModuli supplies the meromorphic/formal adapters and relative complex symplectic constructions on those same carriers, with the specified poles. Layers 1–3 here verify their classical restriction; no complex theorem is inferred from a merely real symplectic statement.

### From TauCetiRoadmap.FormalLaurentPuiseux

Consume L1–L7 for scalar Laurent/Puiseux fields, substitution, derivations, residues and finite ramification/descent. Formal connection normal forms still come from the separate connection suppliers. AlgebraicConfluence §1.1 specifies the reusable finite-dimensional-coefficient principal-part cancellation and its parameter-change law. Scalar formal series alone supply neither this family theorem nor sectorial summation or analytic Stokes data.

### From TauCetiRoadmap.LieGroupoidsPoisson and SymplecticGeometry

Consume LieGroupoidsPoisson G4.6A's positive smooth real Lie–Poisson bracket, with {ℓξ,ℓη} = ℓ[ξ,η], and SymplecticGeometry/HamiltonianReduction R2–R3's smooth real coadjoint/KKS and regular free/proper reduction constructions only for the underlying smooth comparison. AlgebraicConfluence §1.2 constructs the complex relative dual Lie–Poisson structure and its residue and sign comparisons. Section 11.1 here constructs the actual orbit/reduction and family comparisons on their verified loci. A real reduction theorem is not silently promoted to a complex existence theorem.

### From TauCetiRoadmap.UniversalCovers

Consume the completed roadmap's covering-space carrier and lifting/fundamental-group interface. The horizontal-section descent criterion is the application in §5.3. Native covering-space existence does not supply completeness of a nonlinear connection.

## How to read the build

Layers 1–3 specialize the general input, moduli and intrinsic-dynamics construction while verifying the classical admission and comparison conditions. Layer 4 constructs the analytic comparison, including its essential all-strata properness theorem. Layer 5 applies the independent continuation theorem to that comparison and then verifies the classical observer conditions. Layers 6–8 develop the surface comparison, geometric operations, invariant loci and tau sections. Layer 9 derives all classical displays from a common first-jet comparison. Layer 10 selects normalized analytic solutions and connects the existing Hastings–McLeod theory. Layer 11 treats geometric and analytic confluence. No statement in Layers 1–5 depends on deriving a classical scalar equation in Layer 9.

## Layer 1: geometric input and the classical complexity condition

### 1.1 Binding the general decorated-connection input

Use the objects and arrows of MeromorphicConnectionModuli §1.1 directly. This is an import binding, not a second definition of decorated connections. Record the determinant, local decorations, weights and marking that the classical restriction in §1.3 will retain. The genus-zero rank-two restriction is imposed there, not in the general framework. Identify the local presentations used in the Painlevé sources with these same objects, preserving filtrations, logarithmic lattices and ramified descent. The invariant adjoint and projective objects are End⁰(E) and the PGLᵣ connection; no globally trace-subtracted rank-r connection or square root of the determinant is introduced. (I23, §§2–4.)

**API.**

- Identify every imported object and arrow without copying its carrier.
- Verify the odd-determinant and resonant/ramified presentation comparisons on the classical inputs to be selected.

**Checks.**

- On E = O ⊕ O(−1), the determinant has odd degree; a putative global half-determinant twist does not exist. The carrier must still allow this bundle when the prescribed determinant matches it.
- Two logarithmic residues with the same repeated eigenvalue, one scalar and one nonzero Jordan block, are not identified by specifying the eigenvalues. Their allowed parabolic objects and monodromy differ.
- Changing the root w to −w in a rank-two ramified chart changes the displayed branches but gives an equivalent descended object; forgetting the descent arrow fails this check.
- With I23's ramified convention, a rank-two ramified point contributes 2c + 1/2 to the residue/degree relation. Replacing it by 2c changes that relation by 1/2.
- Rank zero is rejected before slope stability or the dimension formula is applied. At r = 1 the adjoint bundle End⁰(E) has rank zero, without changing the required positive rank of E.
- For A = 0 and frame change g = diag(z,1), g⁻¹dg = diag(1,0)dz/z; subtracting half its trace gives diag(1/2,−1/2)dz/z. The scalar discrepancy prevents gluing a rank-two trace-subtracted connection on E, while the induced End⁰(E) and PGL₂ connections glue.

*Needs:* framework:MeromorphicConnectionModuli/1.1.

### 1.2 Binding the general time-deformation problem

Use MeromorphicConnectionModuli §1.2 for the admitted deformation problem, its coordinate-change arrows, marking covers and fixed exponent parameters. For the classical subcategory verify the regular-singular determinant with fixed residues has the compatible time lift required by that contract. Identify the genus-zero local slices and their actual tangent maps; do not construct a second time-base carrier. The reduced versal problem remains the input to §1.3; its one-dimensionality is proved in §1.4. Strong isomonodromy preserves transported analytic data, not a fixed-coordinate irregular polynomial. (HEU10, Theorem 1.1; I23, §§5, 11.)

**API.**

- Identify the fixed-parameter/time tangent decomposition through the imported construction.
- Verify the determinant lift and genus-zero coordinate-change coherence required by the classical restriction.

**Checks.**

- Four ordered logarithmic points have one modulus after quotient by PGL₂: 4 − 3 = 1; its cross-ratio avoids 0, 1 and ∞.
- A change τ = 2t multiplies the displayed horizontal generator by 1/2; retaining its coefficient unchanged gives a different parametrized system.
- Two solutions with different movable pole sets use the same Bθ. A base that deletes one solution's poles fails this requirement.

*Needs:* target:1.1; framework:MeromorphicConnectionModuli/1.2.

### 1.3 The rank-two degree-four subcategory

Define the classical differential Painlevé input class by genus zero, rank two, a structural polar divisor of degree four, the local moduli conditions of §1.1, a regular-singular determinant connection with fixed residues and its compatible transport, the reduced versal formal-data deformation from §1.2, and nonempty stable fibers. On genus zero the determinant residues obey their sum = −degree convention for ∇ = d + A. The time deformation is the actual reduced deformation problem, not an arbitrarily chosen constant or nonversal curve in a larger base. Nonemptiness is a domain condition on the moduli problem; neither one-dimensional time nor continuation is a field of this definition. Prove the reduced-time dimension in §1.4, independently of the phase dimension. Keep the connection data themselves as objects; do not define this class as a six-element type. (VDPS09, §2.2 and Table 1; I23, Theorem 7.5.)

In the pole-budget comparison, r is the projective Katz invariant, computed from trace-free exponential differences. It is not the maximal slope of an arbitrary scalar twist of the connection. The classical determinant normalization avoids extra scalar irregular times. Adding an arbitrary scalar irregular part belongs to a separate rank-one extension with a specified strong time lift; it is not silently included in the one-dimensional deformation count. None of these local/formal comparisons requires a global square root of the determinant line.

**API.**

- Restrict the general connection functor to this full subcategory of input data and retain its arrows.
- Extract rank, genus and structural degree invariantly; prove their preservation under the stated equivalences.
- Compare the formal pole budget with Katz invariants: m = r + 1 for integral r, and m = r + 3/2 for a positive half-integral r in rank two.
- State nonemptiness and excluded discriminants explicitly on each parameter base, including exceptional logarithmic exponents.

**Checks.**

- Four logarithmic points have budget 1 + 1 + 1 + 1 = 4 and belong to this complexity class.
- Five logarithmic points have phase dimension 2·5 − 6 = 4, and three have phase dimension 2·3 − 6 = 0; neither is a two-dimensional Painlevé input.
- Two ramified points of Katz slope 1/2 have budget 2 + 2 = 4. Requiring integral slopes would lose this input.
- A logarithmic residue can vanish at a phase point without changing the structural degree. Recomputing the budget from its actual nonzero poles would wrongly remove that point.

*Needs:* §§1.1–1.2; the moduli dimension theorem in §2.3 is a conclusion about this definition, not an input to it.

### 1.4 Classification of formal profiles and time normalizations

Classify the allowed rank-two formal profiles of structural degree four, retaining the nondegenerate leading-term and reduced-deformation hypotheses. First classify underlying profiles after forgetting the order of the pole labels: enumerate partitions of four and the integral or half-integral generic local slope at each irregular part. This gives ten underlying profiles. Recover the original ordered input through its label-assignment groupoid: a permutation induces a reindexing equivalence between labelled presentations, not a label-preserving arrow in the original groupoid. There are seventeen ordered slope profiles, with counts 2, 8, 6 and 1 for one, two, three and four poles; the corresponding unordered counts are 2, 5, 2 and 1. These are counts of formal profile shapes, not of objects with continuous exponent parameters.

Prove that every labelled realization has one essential time parameter after quotienting the permitted label-preserving curve-coordinate changes. In a presentation with n poles the dimension calculation is n + Σ⌈rᵢ⌉ − 3 = Σmᵢ − 3 = 1, with the automorphism stabilizers and the chosen marking/slices explicitly checked. The determinant normalization and its transport remove no required projective direction and add no scalar irregular direction. Prove that all ten underlying presentations and every label assignment admit this determinant normalization. The table in §9.2 is a table of underlying profiles; its coordinate formulas are transported along the label-reindexing equivalences. (VDPS09, §2.2, Table 1, printed pp.18–19.)

Prove the familiar time domains only after fixing the displayed marking and normalization: the four-point cross-ratio base, a nonzero irregular time for the multiplicative-looking time charts, and an affine time for the polynomial charts. These are charts or marking covers of the intrinsic time problem; they are not six definitions of dynamics. The classification is restricted to this rank-two formal complexity, and does not classify every two-dimensional nonautonomous system.

**Checks.**

- The ordered tuples (1,0,0) and (0,1,0) have orders (2,1,1) and (1,2,1). They have the same underlying profile but are not identified by a label-preserving arrow.
- Enumerating ordered compositions of 4, with one local type for a part 1 and two for each larger part, gives 2 + 8 + 6 + 1 = 17. Forgetting order gives 2 + 5 + 2 + 1 = 10.
- A label permutation preserves the pole budget and the time dimension, but transports the residue parameters and cross-ratio chart; it does not leave every displayed coordinate unchanged.

*Needs:* §§1.1–1.3; finite-ramification normal forms; genus-zero marked-curve automorphisms.

### Examples

For a single ramified pole with slope 5/2, the structural order is 4 and the three irregular coefficients are reduced by the two-dimensional affine coordinate group to one essential time. For two unramified poles of slope 1, there are two irregular coefficients and one residual scaling, again leaving one time. These calculations concern input types before any scalar Painlevé equation is introduced.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 2: moduli and the intrinsic symplectic form

### 2.1 Classical specialization of the full stable moduli

Apply MeromorphicConnectionModuli §2.1 to §1.3. Verify its determinant, stability and local-model admission hypotheses on the classical input; boundedness is supplied by the general construction. Identify its output with the full classical stable moduli problem. The stack, rigidification, coarse family and étale universal-object covers are the imported constructions. Retain all permitted bundle types and the actual residual μ₂ stabilizer before rigidification. Own the comparison of every classical framed chart with its actual locally closed or open locus; a balanced chart never replaces the entire moduli space. (I23, Theorem 5.1.)

**API.**

- Identify the classical moduli functor with the restricted general functor, including arrows and determinant identification.
- Verify every framed chart inclusion, its complement, and the weight-chamber common stable loci.

**Checks.**

- A stable object may have scalar automorphisms before rigidification. A set-valued quotient that claims all stabilizers were trivial fails this example.
- A family can leave a trivial-bundle chart by bundle jumping while remaining in the moduli space. Its phase path is not declared singular for that reason.
- In the extension family 0 → O(−1) → E_t → O(1) → 0, E₀ = O(−1) ⊕ O(1) while E_t = O ⊕ O for t ≠ 0. The two splitting strata pull back to {0} and its complement in A¹; the first is not open. The full connection moduli must retain such bundle jumps on the permitted connection locus.
- A ramified generic local factor is irreducible, so it has no global ∇-invariant line and is stable for every weight; this is I23 Remark 2.9, not a claim that every special solution is absent.

*Needs:* target:1.3; framework:MeromorphicConnectionModuli/2.1.

### 2.2 Specializing the deformation complex and pairing

Specialize MeromorphicConnectionModuli §2.2 to the determinant-fixed family of §2.1, and prove that infinitesimal classical families and gauges correspond to its cocycles and coboundaries. Use its actual three-term ramified cone and ℂ-linear differential-operator/Čech construction. Do not replace the commutator differential by an O-linear map, or truncate the cone without a proved quasi-isomorphism. Verify the determinant restriction and trace-sign convention on the same complex. (I23, equation (6.9), Propositions 6.3 and 7.2.)

**API.**

- Construct the restriction comparison with the general cone, including the determinant-fixed tangent directions.
- Verify gauge, trace-sign and local-presentation compatibility under this comparison.

**Checks.**

- An infinitesimal gauge change by u changes a connection representative by the commutator differential of u; its tangent class is zero.
- Without a determinant identification scalars have an infinitesimal automorphism direction; fixing it in characteristic zero removes that direction, although the finite μ₂ stabilizer remains until rigidification.
- With ω = dq ∧ dp, the ordered tangent pair (∂q, ∂p) has pairing +1 and the reversed pair −1; a reversed trace convention must be corrected before transport formulas are used.

*Needs:* target:2.1; framework:MeromorphicConnectionModuli/2.2.

### 2.3 The classical symplectic surface as a construction output

Apply MeromorphicConnectionModuli §§2.3–2.4 to the family and complex identified in §§2.1–2.2. Verify the determinant-fiber comparison; genus zero contributes no omitted Jacobian directions. Substituting g = 0, r = 2 and deg P = 4 in the admitted general dimension theorem gives 2. Smoothness, nondegeneracy and relative closedness are outputs. The finite-flat auxiliary unfolding, its simple-connection moduli, both generic logarithmic quasi-isomorphisms and the smooth-density argument are proved once in the general framework, before any confluence theorem. Here identify its central stable fiber, complex and form with the actual classical family, including admissible nonreduced base change. Do not invoke Layer 11. (I23, Theorems 7.5 and 8.1, Propositions 8.2–8.3.)

**API.**

- Verify the fixed-determinant and central-fiber comparisons needed to specialize the general theorem.
- Export the same relative tangent bundle and symplectic form on the entire classical family.

**Checks.**

- Genus zero, rank two and degree four give −8 + 2 + 8 = 2; structural degree five instead gives 4.
- Fixing the determinant in positive genus removes 2g directions when the determinant-map comparison applies; the genus-zero coincidence cannot be exported unchanged.
- A skew pairing which vanishes identically is closed but is not symplectic; nondegeneracy must follow from the actual duality computation.
- At r = 1 and g = 1 the unfixed-determinant formula gives 2, and fixing the entire line connection gives 0. The rank-zero input that would incorrectly give 2 is outside the domain.
- For r = 2, local order 2 and q₁ = 2, the unfolding equation is (z − 2h²)(z − h²). Its fiber at h = 0 is z² and at h = 1 is (z − 2)(z − 1); modulo h² it is again z². Check the central and pulled-back complexes and forms, rather than identifying this family with fixed distinct sections.

*Needs:* target:1.3; target:2.1; target:2.2; framework:MeromorphicConnectionModuli/2.3; framework:MeromorphicConnectionModuli/2.4.

### 2.4 Exceptional strata are part of the phase space

Prove that the construction retains all w-stable logarithmic resonance, reducible and apparent-singularity strata allowed by its fixed local moduli conditions. Describe how the local filtration resolves the ambiguity of repeated eigenvalues. Record nonemptiness separately. At generic ramified points use the irreducibility theorem rather than inventing reducible objects there. Layer 4 will identify the images of these already constructed strata in the character space. A vanishing leading irregular coefficient changes the input stratum and is handled by §9.3 and Layer 11. (I23, §2 and Remark 2.9; IIS06, §4, especially Theorems 4.10–4.12; VDPS09, §2.2 and §3.)

*Needs:* §§2.1–2.3; the local structures of §1.1. The analytic interpretation by Riemann–Hilbert is supplied in Layer 4, not used to define these strata.

### Examples

At genus zero and rank two, the dimension calculation gives −8 + 2 + 2·4 = 2. An affine phase chart has coordinates (q,p), but points missing from that chart remain genuine initial conditions. On a resonance divisor, distinct parabolic initial points can have the same coarse monodromy character; the phase space must retain them.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 3: construction of the time connection

### 3.1 Specializing the strong isomonodromy construction

Apply MeromorphicConnectionModuli §3.1 to the classical time problem and the family of Layer 2. Identify its strong extensions with the classical universal-object charts, including kernel lattices, logarithmic flags and ramified descent. The total pole class is Ω¹_X(log D) ⊗ O_X(P − D); its moving-coordinate generators dz/zᵐ and dε/zᵐ⁻¹ remain comparison lemmas, with a regular time coefficient at a logarithmic pole. Import existence, uniqueness and gluing of strong extensions, and obtain the same splitting h of NonlinearConnections §1.1. This target does not assume h or recover it from a prescribed scalar equation. (I23, Definition 10.1, Propositions 10.7 and 10.10.)

**API.**

- Compare the classical kernel lattices and moving-pole filtration with the general strong-extension class.
- Identify the resulting tangent splitting, its linearity and its base-change maps without creating a second connection object.

**Checks.**

- A zero time tangent lifts to zero; adding an arbitrary vertical vector would violate uniqueness of the integrable extension.
- Rescaling the time tangent by 2 rescales its lift by 2, while changing the time coordinate to 2t rescales the normalized generator by 1/2.
- The zero map cannot be a splitting over a nonzero time tangent because dπ ∘ 0 = 0 ≠ id.

*Needs:* target:1.2; target:2.1; target:2.2; target:2.3; framework:MeromorphicConnectionModuli/3.1; framework:NonlinearConnections/1.1.

### 3.2 The imported flatness theorem on classical inputs

Use MeromorphicConnectionModuli §3.2 and the identification of §3.1 to obtain h([v,w]) = [h(v),h(w)] on the classical family. Verify that the two-parameter strong-extension comparison restricts to this time problem. The general mixed-term proof is not repeated for each formal profile; no analytic Stokes theorem or scalar equation is a premise. (I23, Theorem 11.6.)

**API.**

- Verify the restriction comparison for the mixed extension and export the bracket identity.

*Needs:* target:3.1; framework:MeromorphicConnectionModuli/3.2.

### 3.3 Symplectic preservation and total form by general comparison

First specialize the actual symplectic-preservation theorem of MeromorphicConnectionModuli §3.2. Flatness by itself does not supply preservation. Then apply NonlinearConnections §1.6 to (π,h,ω) and obtain the closed total form Ω(v,w) = ω(v − h(dπv), w − h(dπw)), its kernel and transport laws. Identify this form with the classical family, rather than introducing a second Hamiltonian object. A Darboux/time chart and local exactness give the downstream expression dq ∧ dp + dH ∧ dt. (I23, Definition 11.4 and Corollary 11.8.)

**API.**

- Identify the imported relative and total forms and their horizontal kernel.
- Verify Hamiltonian signs and time-dependent coordinate comparisons only after choosing the stated local charts.

**Checks.**

- For H = p²/2, contraction with ∂t + p∂q annihilates dq ∧ dp + p dp ∧ dt; using the opposite sign does not.
- H and H + t² give the same vertical vector field and extended two-form, but different scalar functions.
- On a symplectic fiber, Ω has no nonzero vertical kernel vector; degenerating ω to zero would fail this characterization.

*Needs:* target:2.3; target:3.1; target:3.2; framework:MeromorphicConnectionModuli/3.2; framework:NonlinearConnections/1.6.

### 3.4 Coherent restriction of the general construction

Use MeromorphicConnectionModuli §§3.3–3.4 to identify all objects in Layers 1–3 as the classical restriction of one construction, with coherent presentation, gauge and admissible base-change comparisons. Verify the cocycle diagrams for the classical markings and time slices. Changes of labels, determinant or stability chamber remain the explicitly permitted morphisms or correspondences, with stated domains. A later coordinate dictionary must commute with this construction; it is not a new definition of the dynamics.

**API.**

- Prove the classical specialization square and its triple-overlap coherence.
- Keep all imported structures on one moduli family and one nonlinear connection.

*Needs:* target:1.1; target:1.2; target:2.1; target:3.1; target:3.2; target:3.3; framework:MeromorphicConnectionModuli/3.3; framework:MeromorphicConnectionModuli/3.4.

### Examples

The Hamiltonian chart H = p²/2 − 2q³ − tq represents a horizontal kernel, but the kernel is constructed without this formula. Replacing H by H + c(t) preserves it. A marking change acts on the parameterized family; it does not erase the marking from the input groupoid.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 4: analytic comparison, including exceptional points

### 4.1 Sectorial local systems and ramified analytic descent

Construct the analytic classification of the permitted local meromorphic connections by formal graded data, sectorial solutions and Stokes transition maps, retaining resonant logarithmic lattices and flags. Prove sectorial existence, overlap uniqueness, cocycle identities and analytic dependence on the admissible time parameters. At a ramified point perform the construction on the finite cover and prove equivariant descent, including the deck permutation of the exponential factors. A formal Laurent-series classification alone does not prove these analytic assertions. (I23, §9, Theorem 9.7 and Corollary 9.11; BOA01, §§3–6; HEU10, §2; BY15, Remark 3 and Definitions 7 and 13.)

**API.**

- Construct solution-sector restriction, refinement and change of sectorial normalization.
- Recover the actual local analytic connection and prove full faithfulness on decorated objects.
- Compare the logarithmic, unramified and ramified descriptions through the same descent language.
- Prove that integrable time extension is equivalent to strong local constancy of these data at the stated local scope.

**Checks.**

- A rank-one exponential exp(1/z) has irregular growth despite trivial ordinary monodromy; ordinary monodromy alone cannot classify the object.
- A nontrivial unipotent logarithmic monodromy matrix differs from the identity although both eigenvalues equal 1.
- On a quadratic cover, one full turn in z exchanges the two formal exponential branches; a sectorial construction that returns each branch individually without the deck action fails descent.

*Needs:* Layer 1; §§3.1–3.2 for the strong-extension interpretation; FormalConnectionsOpers F2–F3; ComplexKahlerGeometry K3.0/K4; PadicDifferentialEquationsAndRigidCohomology §RD.6.52a. The analytic sectorial and ramified Stokes constructions are owned here.

### 4.2 The Betti family and complete transport

For the regular-singular subcategory, use MeromorphicConnectionModuli §4.1 and verify that its marked Betti family agrees with this target. The genuinely irregular and ramified transport extensions remain the scoped obligations below.

Construct the generalized monodromy groupoid by gluing the local data of §4.1 with the global local system on the punctured curve. Keep the enriched groupoid with logarithmic lattices and flags distinct from the ordinary affine character quotient obtained by forgetting those decorations. In the ordinary quotient impose the closed spectral-invariant and determinant constraints, and retain the exponent parameter θ as a separate fiber-product coordinate. At resonance do not fix a single nonclosed Jordan conjugacy class: scalar and allowed unipotent strata with the prescribed spectrum must remain present. Construct locally constant transport along admissible marked deformations, including changes of Stokes-sector presentations. Prove composition and inverse laws and completeness along every compact path in Bθ. A singular character fiber is permitted; transport is defined by the groupoid/topological construction, not by an assumed smooth tangent splitting there. (VDPS09, §§1–3; BOA14, §10, Theorem 10.2; BY15, Proposition 19, Theorem 21 and Corollary 22.)

BOA14's cited family-transport theorem has untwisted scope. Extend its isotopy construction to the rank-two ramified objects of BY15 by retaining the exponential covering, grading and deck action, constructing deck-compatible equivalences of the Stokes groupoids, and descending the framing action and closed spectral constraints. Prove independence, composition and homotopy compatibility before concatenating local products along a compact path. BY15's quasi-Hamiltonian/Poisson theorem by itself is not this family-transport theorem.

**API.**

- Construct restriction, gluing, gauge-conjugation and change-of-marking functors.
- Distinguish the decorated groupoid, its categorical quotient and the locus where it represents individual orbits.
- Prove local product descriptions over simply connected admissible time neighborhoods and their continuation along finite chains.
- Define the complete transport on the coarse quotient and its lift on any required decoration space.

**Checks.**

- θ and θ + 1 give the same exponential eigenvalue but need not give the same logarithmic lattice; the comparison target retains θ.
- A reducible representation and its semisimplification can have the same coarse character. The quotient is not declared a faithful encoding of all connection objects.
- Transport around a nontrivial loop may act nontrivially on the fiber; completeness does not imply trivial monodromy.

*Needs:* target:1.2; target:4.1; roadmap:SchemeAndStackFoundations §1.17; roadmap:ComplexComparisonPartII §C−1.1/C0.3; roadmap:UniversalCovers §completed covering and lifting interface; roadmap:SmoothBundlesConnections §B1.5/B5; framework:MeromorphicConnectionModuli/4.1.

### 4.3 Riemann–Hilbert and compatibility on the whole phase space

The regular-singular RH map and its all-point horizontal compatibility are imported through MeromorphicConnectionModuli §4.1, after identifying the same parabolic moduli and residue-parameter target. This import does not discharge the irregular local reconstruction.

Construct RHθ: Mθᵃⁿ → Rθ over Bθ by the analytic classification and prove that it is holomorphic. Prove that it sends every horizontal trajectory of §3.1 to the transport of §4.2, including trajectories inside resonance, reducible and exceptional loci. On the stated stable irreducible/nonresonant open locus prove the inverse comparison; elsewhere record the actual fibers and decoration data rather than asserting injectivity. Compare the integrable-extension construction with the local analytic reconstruction, and descend from universal-object covers. (IIS06, Theorems 4.10–4.12; IS12, Theorem 5.1; I23, §9 and §11.)

The theorem's all-strata scope is a construction target: the generic unramified theorem is one of its inputs, not a replacement for the missing resonant or ramified comparison. No scalar equation is used in the extension across these loci.

**API.**

- Construct the holomorphic RH map from the universal-object cover and prove descent and base-change naturality.
- Compare the decorated local reconstruction with the forgetful ordinary character quotient.
- Prove horizontal compatibility at every retained point and the inverse theorem only on its stated open locus.

**Checks.**

- Two distinct points on an exceptional fiber can have the same ordinary character; the construction must not choose one as an inverse.
- At a resonant logarithmic point, equal eigenvalues do not justify deleting either the allowed scalar or unipotent stratum.
- Retaining exponent lifts distinguishes θ from θ + 1 even when their ordinary exponential eigenvalues agree.

*Needs:* target:2.1; target:2.4; target:3.1; target:3.2; target:4.1; target:4.2; roadmap:ComplexComparisonPartII §C−1.1/C0.3; roadmap:ComplexComparisonPartII §C5.6; framework:MeromorphicConnectionModuli/4.1.

### 4.4 Proper comparison for the full classical input class

On the four-logarithmic-point branch, verify 2·4 − 2·2 − 2 = 2 > 0 and the fixed-determinant/marking comparison, then apply MeromorphicConnectionModuli §4.2 (I13, Theorem 2.2). The source retains the exponent parameters by a fiber product. No general irregular properness is inferred from this regular-singular theorem; the all-classical extension below remains an owned target.

For each admitted degree-four rank-two input and every allowed exponent parameter, prove that RHθ is proper as a map of the whole time family, with the exponent lift retained in its target, on the full stable moduli space of §2.1. Establish the corresponding family statement on admitted parameter charts; properness of each fixed-time map is not sufficient. The target has the ordinary generalized character data with its fixed closed constraints; no solution-dependent open subset is removed. State surjectivity onto the realizable component separately from properness. This includes resonant logarithmic and stable reducible points and the generic ramified local structures defining the classical class. (IIS06, Definition 2.11 and Theorems 4.10–4.12; IS12, Theorem 5.1 and the scope warning of Remark 6.3; HEU10, Theorem 1.1.)

The required extension is owned here. Develop the proof through four concrete intermediate results: boundedness of local lattices uniformly over compact families of generalized characters with fixed exponent lifts; extension of the retained flags and factorized structures in a relative projective parameter space with their closed incidence relations; semistable replacement after the necessary base change and elementary modifications, followed by semistable = stable for the chosen weights and uniqueness in the separated moduli problem; and compatibility of these extensions with global gluing and the analytic moduli topology. Stability is open but is not thereby preserved by arbitrary limits. Verify that these results give compact inverse images of compact subsets, rather than merely closed fibers or pointwise solvability. A projective flag variety alone does not prove the theorem, since the underlying connection may also escape.

HEU10's universal strong isomonodromic deformation gives an independent possible route to the continuation conclusion of §5.2. Such a route must establish the identification of the time bases, extension of local decorations, determinant and stability preservation, bundle-jumping compatibility, descent, and equality with §3.1. It does not by itself prove the properness required in this target. I23's global foliation theorem and IS12's generic theorem also do not discharge it. The compactness theorem remains an explicit internal proof-development task.

*Needs:* target:2.1; target:2.2; target:2.3; target:2.4; target:4.1; target:4.2; target:4.3; roadmap:SchemeAndStackFoundations §4.14; roadmap:AlgebraicModuliForArithmeticGeometry §5.1/7.1/8; mathlib:IsProperMap; framework:MeromorphicConnectionModuli/4.2.

### Examples

An exceptional RH fiber can be a projective curve. A chosen point on it is still an initial condition and has its own horizontal lift; taking an arbitrary inverse of the coarse RH map would discard this information. A trivial-bundle chart may fail the strong Riemann–Hilbert problem at an isolated time even though the full bundle-valued connection continues.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 5: intrinsic solutions and the Painlevé property

### 5.1 Classical horizontal germs from general local theory

Apply NonlinearConnections §1.3 to the actual holomorphic flat splitting of §§3.1–3.2. A geometric Painlevé germ is its native horizontal-section germ with specified initial point; the evaluation bijection, local uniqueness and holomorphic parameter dependence are the general outputs. Verify that the admitted parameter charts of Layer 1 meet the joint-holomorphic hypotheses. The former named holomorphic-horizontal-lifts gap is now the explicit general proof target NonlinearConnections §1.3, not an unexpanded assumption of this application.

**API.**

- Verify the joint-holomorphic family hypotheses and identify geometric Painlevé germs with the imported section germs.
- Use the general evaluation bijection and naturality on the actual classical fibers.

**Checks.**

- On π: B × F → B with the product splitting, a horizontal section is b ↦ (b,x₀), not an arbitrary map B → F.
- A section must satisfy dπ ∘ ds = id; a constant map into the total space is not a section over a nonconstant time neighborhood.
- For the holomorphic vector field q′ = q² with q(0) = 1, the local solution is 1/(1 − t); local existence does not imply continuation in the affine phase chart through t = 1.

*Needs:* target:3.1; target:3.2; framework:NonlinearConnections/1.3.

### 5.2 Classical completeness by proper semiconjugacy

Apply NonlinearConnections §1.4, whose continuous-time local ODE and compact-extension floor is §1.2, to the constructed phase family. Verify the complete target transport of §4.2, the actual partial-lift compatibility of §4.3 at every permitted point, and the relative proper map of §4.4. Obtain a unique horizontal lift for every admitted θ, initial time b₀, point x₀ ∈ Mθ,b₀ and compact piecewise C¹ path in Bθ beginning at b₀. The target may be singular, and exceptional fibers are retained. Neither a local inverse of RH nor properness of π is required. The general compact-containment proof lives entirely in NonlinearConnections; this target owns the classical hypothesis checks and the resulting geometric Painlevé property. Poles of a chosen scalar observable do not change the admitted base.

**API.**

- Check the hypotheses of the general proper-transfer theorem, including exceptional fibers.
- Export the full initial-point and compact-path quantifiers independently of every scalar chart.

**Checks.**

- For y′ = y², y(0) = 1, the projection of M = ℂ_t × ℂ_y to the complete target time line is compatible but not proper. Along t ∈ [0,1), y = 1/(1 − t), with values 2 and 4 at t = 1/2 and 3/4, and no finite value at 1. This excludes replacing properness of F by mere continuity or projection compatibility.
- For identity F on the trivial family and constant fiber transport, the proper transfer returns the unique constant fiber coordinate. For a proper fiber with an exceptional curve, the compact-containment argument uses its compact preimage and never selects an inverse of F.
- The base path γ(s) = |s − 1/2|³ᐟ² on [0,1] is C¹, while γ′ is not C¹ at 1/2. Its constant-splitting lift is a valid input to the continuous-time local theorem; a proof requiring the autonomized field to be C¹ would impose an unsupported extra hypothesis.

*Needs:* target:4.2; target:4.3; target:4.4; target:5.1; framework:NonlinearConnections/1.4.

### 5.3 Classical transport, universal-cover sections and descent

Apply NonlinearConnections §1.5 to the flatness of §3.2 and completeness of §5.2. Its construction produces the actual endpoint transport, fundamental-groupoid action and universal-cover horizontal section through every classical initial point. Identify this action with the constructed connection rather than assuming a monodromy action as input. Use §3.3 and NonlinearConnections §1.6 for symplectic preservation. Descend precisely for initial points fixed by the resulting deck/monodromy action; completeness alone does not imply single-valuedness on Bθ.

**API.**

- Identify the imported transport and universal-cover sections on the classical moduli family.
- Verify presentation compatibility and the actual stabilizer condition for descent.

**Checks.**

- A path followed by its reversal gives the identity on every initial condition, including exceptional points.
- On B = ℂ× with H = qp/(2t), the equations are q′ = q/(2t), p′ = −p/(2t). A positive generator of π₁(B) sends (q,p) to (−q,−p), and two such loops give the identity. The symplectic multiplier is (−1)(−1) = 1, while a trivial-transport implementation would give the wrong first loop.
- In that model only the origin is fixed by the generator. Every other initial point gives a complete section on the universal cover that does not descend to B; completeness alone is insufficient for descent.

*Needs:* target:3.2; target:3.3; target:5.2; framework:NonlinearConnections/1.5; framework:NonlinearConnections/1.6.

### 5.4 Classical observable adapters

Use the observable notion of NonlinearConnections §1.7 on the classical phase family. Own the construction of each claimed classical morphism to ℙ¹, or its stated rational domain and resolution/lift comparison. Prove defined pullback along every claimed solution stratum and exclude an identically infinite pullback before calling the result a scalar meromorphic function. Observers, their domains and normalization remain explicit data; the generic evaluation theorem does not supply these application-specific verifications.

**API.**

- Construct the actual classical observer and verify its pullback/lift domain.
- Compare its normalizations and overlap maps using the general observable naturality law.

**Checks.**

- Q ≡ ∞ is an everywhere defined ℙ¹-valued observer, but it does not produce an ordinary meromorphic function with isolated poles.
- The rational map [x:y] on ℂ² is undefined on the constant curve (0,0); rationality alone does not define a pullback along every solution.
- In the infinity chart, Q(t) = 1/t becomes 1/Q(t) = t, holomorphic at 0. Its pole is a chart event, not a failure of geometric continuation.

*Needs:* target:5.1; target:5.3; framework:NonlinearConnections/1.7.

### 5.5 Meromorphic evaluation on the classical time curve

Verify the one-dimensional time conclusion of §1.4 and apply NonlinearConnections §1.7 to §§5.3–5.4. Every claimed non-identically-infinite scalar evaluation is meromorphic on the universal cover of the admitted time curve, with finite-order poles at its interior scalar singularities. Observer resolution and non-indeterminacy for every claimed stratum remain the application obligations of §5.4. The single-valued descent criterion is separate. This transfers one intrinsic theorem to the coordinate comparisons, rather than proving six scalar continuation theorems.

**API.**

- Export the meromorphic evaluation theorem only on the verified classical observer domains.

*Needs:* target:1.4; target:5.3; target:5.4; framework:NonlinearConnections/1.7.

### Examples

The affine equation q′ = q² has a movable pole at t = 1 for q(0) = 1. Its projective vector field extends in u = 1/q as u′ = −1. This separates affine-coordinate escape from geometric continuation. On B = ℂ*, a horizontal system can have complete continuation on the universal cover and nontrivial monodromy around 0; this does not contradict the theorem.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 6: comparison with initial-condition surfaces

### 6.1 Additive Okamoto–Painlevé pairs

Define the comparison groupoid of smooth projective rational surfaces S with a nonzero effective anticanonical divisor Y, satisfying Y·Yᵢ = 0 for every irreducible component, with D = Y_red a simple normal-crossing divisor. Require additive type, expressed by the additive identity component of Pic⁰(Y), and nonfibered type: no elliptic fibration has a fiber nY with n ≥ 1. Retain markings when a root basis or normalized time is used. Construct the relative versions of these conditions. (STT02, Definitions 1.1 and 1.3, Proposition 1.2 and Tables 2–3.)

**API.**

- Extract the weighted boundary intersection graph and the orthogonal lattices in Pic(S).
- Prove invariance under pair isomorphisms and compatibility with admissible families.
- Compare the complement S \ D with its logarithmic tangent and two-form sheaves.
- Distinguish the boundary-root lattice from a symmetry-root lattice.

**Checks.**

- A smooth elliptic anticanonical boundary has elliptic Picard identity component, not additive, and is excluded.
- A multiplicative cycle has multiplicative Picard identity component and is excluded.
- Requiring a global affine-plane chart would exclude the D₈ case; that additional requirement is absent.

*Needs:* SchemeAndStackFoundations §§2.6–2.7, 3.4, 4.17 and 5.9–5.10; AlgebraicVectorBundles L0A–L0C/L1A–L1B; ComplexComparisonPartII C3.2d.2/C3.2f.1–2. For this proper flat family construct the logarithmic tangent sheaf as the derivations preserving the boundary ideal. For the possibly nonreduced boundary prove O_B ≅ p_*O_Y universally and H²(Y,O_Y) = 0, and verify the smoothness and constant-dimension hypotheses of the Picard identity-component supplier, including formal smoothness when the base is nonreduced. Then compute its identity component by normalization/unit exact sequences. This is not an application of a smooth-curve Jacobian theorem.

### 6.2 Compactification and the eight boundary types

Construct a compactification of the degree-four connection moduli family with the pair structure of §6.1, after the stated marking/base changes, and prove that its complement is the full phase family. Prove the extension and comparison of the symplectic form and time distribution, including exceptional curves and nontrivial bundle charts. Classify the additive normal-crossing boundary types as D₄, D₅, D₆, D₇, D₈, E₆, E₇ and E₈. These are affine boundary diagrams. (STT02, Proposition 1.2 and Tables 2–3; VDPS09, introduction and Table 1; IIS06, §10 for the fully established PVI comparison.)

The all-profile comparison is a construction and proof target. VDPS09's introductory conjectural global comparison is not used as an established theorem. Prove overlap identifications, coverage and the extension at the omitted charts before asserting a global isomorphism. The compactification is not used to bypass §4.4 or to infer completeness merely from existence of a foliation.

**API.**

- Construct the relative compactification and its boundary divisor with its multiplicities and intersection pairing.
- Prove the full open-complement comparison, including bundle-jumping and exceptional charts.
- Compare the deformation and relative two-form under that isomorphism, and record the marking/base-change law.

**Checks.**

- Two presentations of boundary type D₆ can have different formal pole data; the common boundary label alone is not a moduli isomorphism.
- The D₈ complement must be retained even without the extra affine-plane hypothesis of older definitions.
- An omitted exceptional curve invalidates the full-complement assertion even if the open rational chart and its scalar formula are correct.

*Needs:* Layers 1–3; §§2.1 and 6.1; SchemeAndStackFoundations §§4.11, 4.14, 4.17 and 5.9–5.10. Construct the particular compactification and its charts here. No scalar Painlevé property is a prerequisite.

### 6.3 Intrinsic comparison of the time line

Let F = Θ_S(−log D) and N_D = O_S(D)/O_S. Construct L = H⁰(D,F ⊗ N_D), prove that it is one-dimensional for these pairs, and construct its injection into local cohomology. Establish the family/base-change theorem for L and compare its Kodaira–Spencer image with the time direction of §3.1. Prove the connecting-map/intersection-matrix identity intrinsically; do not repeat a different coordinate computation for each boundary graph. (TER02, Theorem 2.1 and Proposition 2.1; STT02, Theorem 3.1.)

Do not assert equality with the entire local-cohomology space as a standing premise: TER02 Conjecture 2.1 and the restricted results of ST04 Appendix A have different scope. A line is not a distinguished nonzero vector; a normalized time supplies a generator. Prove equality of the lifted distributions by the deformation comparison and uniqueness on the prescribed algebraic complement.

**API.**

- Construct the first boundary-layer line, its injection into supported cohomology and its restriction maps.
- Prove the intersection-matrix formula and the dimension calculation without choosing a scalar Painlevé chart.
- Establish locally free base change and the comparison of its Kodaira–Spencer image with the time tangent line.

**Checks.**

- Rescaling a chosen nonzero time vector rescales its image in L, while L itself is unchanged.
- The injection L → H¹_D(S,F) alone does not prove that its target is one-dimensional.
- Over A = ℂ[ε]/(ε²), the module A/(ε) has a one-dimensional fiber at the unique point but is not a free rank-one A-module: its ℂ-length is 1 instead of 2. Constant fiber dimension alone therefore does not establish the claimed locally free base change; the actual cohomological hypotheses must be proved.

*Needs:* §§3.1–3.4 and 6.1–6.2; SchemeAndStackFoundations §§2.6–2.7, 2.20 and 5.9; JacobianChallenge Layer C. The constant-rank hypotheses, family/base-change and Kodaira–Spencer comparisons for this specific logarithmic boundary line are proved here.

### Examples

The boundary type E₈ is associated with one ramified rank-two presentation, while E₇ has two. Thus a boundary label and a connection presentation are different kinds of data. The first boundary-layer line has dimension 1; claiming the same dimension for every full local-cohomology group would require an additional theorem and is not used here.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 7: geometric transformations and invariant reductions

### 7.1 Functors on decorated connections

Construct elementary modifications along an invariant local flag, tensor product with an admitted rank-one connection, duality and relabeling as functors between the actual decorated moduli problems. Specify the new determinant, exponent and stability data and the locus on which the transformed object is stable. Use the kernel construction for a modification, its induced connection, and the inverse modification; retain the comparison arrows. Extend these functors to strong integrable families by preservation of the allowed pole filtration and kernel lattices. (IIS06, Definition 3.5 and §7; I23, §§2–4 and Definition 10.1.)

**API.**

- Construct the transformed bundle and connection before passing to coarse moduli, with their determinant and local-type formulas.
- Prove pullback, composition and inverse comparisons on their specified domains.
- Describe the change of weights or required wall-crossing correspondence instead of declaring stability invariant without proof.
- Distinguish a functorial isomorphism of moduli problems, an open birational correspondence and a scalar solution substitution.

**Checks.**

- Modifying along a one-dimensional quotient at a logarithmic pole changes the bundle degree by −1; leaving the determinant unchanged fails the determinant comparison.
- Tensoring rank two by a line connection L changes the determinant by L², including its connection; it does not construct a square root of a previously fixed odd-degree determinant.
- The inverse modification recovers the original decorated object with its arrow on the common admissible locus, while forgetting the distinguished flag need not permit the inverse.

*Needs:* §§1.1, 2.1 and 3.1; AlgebraicVectorBundles L0A–L0C/L1A–L1B; FormalConnectionsOpers F2–F3. The Painlevé-specific stability and strong-extension comparisons are owned here.

### 7.2 Horizontal and symplectic transformation laws

Prove that each admitted transformation intertwines h by applying the uniqueness of strong extensions to its transformed family. Prove the transformation law for ω by the induced map of deformation complexes and trace pairing. Construct the resulting action groupoid on the parameterized moduli family, and establish relations by natural isomorphisms of the functors. On a marked surface compare its action on Pic(S) with the corresponding integral root reflections and diagram automorphisms. State the actual symmetry root lattice and its parameter hyperplanes separately from the boundary root diagram. (IIS06, Theorem 7.4 and Theorem 10.13 for PVI; STT02, Tables 2–3 and the marked deformation construction.)

The functors in §7.1 are not assumed to generate the full affine Weyl group. Construct the additional reflections on the moduli of marked pairs, identify the induced birational correspondence of connection moduli through §6.2, and prove its horizontal and symplectic extension on the claimed domain. The central PVI reflection is a required test: it is not generated merely by the local gauge modifications listed in §7.1. IIS06 Remark 7.5(2) describes a Fourier-transform realization; a Fourier–Laplace or middle-convolution implementation would likewise require its own functor and strong-extension comparison. The marked-surface construction is the specified route here. The PVI theorem is not cited as a theorem for every profile. Verify the actual reflection and Coxeter relations, effective-locus conditions and extension across chart complements before deriving rational Bäcklund formulas in §9.4. An identity of rational maps on a dense open set must be upgraded before claiming an everywhere defined automorphism.

**API.**

- Construct the marked-pair reflection correspondences and compare them with the connection-functor generators on their common domains.
- Prove horizontal and symplectic intertwining, relations and compatibility with parameter changes.
- Record the regular domain and the extension theorem for each claimed global map.

**Checks.**

- The PVI central reflection sends κ₀ to −κ₀ and κⱼ to κⱼ + κ₀ for j = 1,2,3,4. It preserves 2κ₀ + Σκⱼ = 1: at κ₀ = 1/2, κⱼ = 0 the transformed tuple has κ₀ = −1/2 and κⱼ = 1/2, giving −1 + 2 = 1. Omitting the κ₀ sign change gives 3 instead. Local integer shifts and sign changes alone do not construct this reflection.
- A reflection squared must give the original marked family with its comparison arrow, not merely the same boundary diagram.
- A birational formula with a pole on an invariant curve is not an automorphism of that curve until a regular extension is proved.

*Needs:* §§2.2–2.3, 3.4, 6.2 and 7.1; SchemeAndStackFoundations §§3.4 and 5.9–5.10. No scalar differential equation is used to define or justify the action.

### 7.3 Invariant rational curves and Riccati dynamics

For the admitted nonfibered additive pair, construct the local family of an interior smooth rational curve C with C² = −2. Prove invariance under the time distribution using the logarithmic deformation sequence. Retain the étale or finite base change needed to continue that family; descent to the original base requires its own monodromy check. On the resulting relative ℙ¹-bundle, identify the restricted connection as a projective linear connection, using H⁰(ℙ¹,Tℙ¹) ≅ sl₂. The coordinate lemma then has q′ = a(t)q² + b(t)q + c(t). A linear rank-two lift is asserted locally, or globally only with its lifting obstruction resolved. (ST04, §2.4, Proposition 2.1, Remark 2.4 and Definition 2.3.) The PVI comparison with the Gauss equation is IIS06 Theorem 5.15; its Theorem 5.16 assumes analytic Painlevé property and is not used as a premise of this independent geometric construction.

Classify these interior nodal configurations by the boundary intersection lattice under ST04 Theorem 3.1's hypotheses. Deduce its nonexistence statement for the E₈, D₇ and D₈ boundary types. Linearization gives the relevant classical special-function families after the coordinate comparisons; the parameter restrictions and normalizations remain part of those lemmas.

**API.**

- Construct restriction of h to the invariant curve family and prove that its projection to time remains a splitting.
- Compare two projective coordinates by the induced Möbius gauge law, and compare local rank-two linearizations.
- Prove preservation under the admitted geometric transformations when they extend as regular isomorphisms along the whole curve family; otherwise construct the closure and prove the required curve and invariance properties separately.
- Compare the nodal-curve condition with reducible connections or exceptional RH fibers only in the presentations where that identification is proved.

**Checks.**

- A holomorphic vertical vector field on ℙ¹ has a polynomial coefficient of degree at most two in an affine coordinate; a cubic coefficient fails regularity at infinity.
- A ramified generic local factor forces global irreducibility, but an E₇ ramified presentation can still have an invariant Riccati curve. Thus “Riccati if and only if globally reducible connection” is not a presentation-independent theorem.
- A family of curves can be permuted by continuation around the time base; a local invariant curve does not automatically give a globally labeled subfamily.
- A rational solution need not lie on a Riccati curve; ST04 §6.2 supplies this distinction. This target is not a classification of all rational solutions.

*Needs:* §§3.1–3.4, 6.1–6.3 and 7.1; SchemeAndStackFoundations §§2.7, 4.14 and 5.9–5.10; ComplexKahlerGeometry K4's linear-connection carrier. The projective connection and its local rank-two lift comparison are constructed here.

### Examples

In the PII chart of §9.5 the curve p = 0 is invariant at α = −1/2. Its Riccati equation is the coordinate expression of a projective connection on that curve. The seed q = 0 at α = 0 has different geometry; it must not be used to infer that all rational solutions arise from invariant Riccati curves.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 8: the determinant line and tau sections

### 8.1 Importing the complex determinant-line construction

Use AnalyticRHPAndDeterminants §1.1 for the holomorphic complex index-zero determinant line, its canonical section, finite-dimensional stabilizations and coherent comparison maps. The former named gap is expanded there as a proof target proposed for HeegaardFloerPartII F0.0C; no accepted upstream implementation is asserted. Retain L_T = det(ker T)* ⊗ det(coker T) and the same native complex operator carriers. This target fixes the convention and the import interface used in §8.2; §8.2 must construct the actual operator family and verify index zero and holomorphic dependence. The generic construction is not repeated inside Painlevé, and a real orientation line is not substituted for it.

**API.**

- Fix the dual convention and identify the imported line/section without a second determinant carrier.
- State the exact holomorphic index-zero and descent checks that 8.2 must discharge.

**Checks.**

- For T_s: ℂ → ℂ, z ↦ sz, the standard frames give τ(s) = s, fixing the dual convention.
- For T_s(z) = s²z, the zero has order two although dim ker T₀ = 1; no unconditional equality between vanishing order and kernel dimension is supplied.
- An everywhere invertible constant family has nonvanishing determinant section; an identically singular index-zero family may have an identically zero section without invalidating its line.

*Needs:* framework:AnalyticRHPAndDeterminants/1.1.

### 8.2 An index-zero RHP realization and descent

Construct an analytic RHP chart from the decorated connection family of Layers 1–3 and the analytic comparison of §§4.1–4.3. Retain the reference bundle or modification, contours, local lattices, branches, framings and normalization in its marking data. Construct the associated Fredholm operator and prove its index zero; the assertion is not a field added to every connection by fiat. For the initial closed-contour model use a holomorphic invertible jump symbol in a fixed contour neighborhood and zero determinant winding. Compare the solvable normalized RHP with the corresponding marked connection and pull back §8.1's line and section. Extend this construction to the analytic sectorial models for every ramified and resonant stratum retained by §§1.1–1.3, with explicit adapters. Proving these adapters is part of the construction; neither cited generic source is claimed to supply all of them. (BERT17, §1 and Theorem 2.2; MAL04, §2.)

The auxiliary bundle matters. On ℙ¹, rank E = 2 and deg E = d give χ(E(−1)) = d and χ(E(k)) = d + 2k + 2. Thus a degree-minus-one phase object does not acquire an index-zero complex by the unexplained choice E(−1); no integral common line twist has Euler characteristic zero when d is odd. Construct the needed normalized index-zero complex or modification and its comparison with the original connection. Malgrange's degree-zero sewn-bundle construction does not remove this obligation.

Keep the reference bundle and auxiliary modification in the input marking. Unit transition factors for line and section are asserted only for proved equivalences, with any added auxiliary complex everywhere acyclic. An arbitrary change of reference bundle or modification can change the zero divisor. Treat it as a different normalized problem, and construct the relative determinant factor or meromorphic transformation with its divisor instead of declaring the two sections equal up to a unit. BERT17's factorization comparisons do not supply invariance under unrestricted bundle modification.

**API.**

- Construct RHP marking charts and the operator-family functor from their connection data.
- Prove comparison isomorphisms for changes of contour, factorization or normalization which give the same Fredholm family or a proved holomorphic chain/stable equivalence, with their identity and composition laws.
- Construct an equivariant line and section on the marked moduli groupoid/stack. Descend to a coarse space only after proving trivial stabilizer action on the line and section.
- Record exactly which strata have the required analytic adapter; completing the stated adapters is a proof target, not an assertion that the generic cited sources already cover every stratum.

**Checks.**

- The degree-minus-one example fails the E(−1) index test, even though its connection is a valid phase object.
- Scalar automorphisms act by the Euler-characteristic weight, which is zero here; this does not establish trivial action for all other possible stabilizers.
- Two elementary jump factorizations can give different scalar Fredholm determinants. Their nonzero transition factor, not literal equality, is the required comparison.

*Needs:* Layers 1–3, §§4.1–4.3 and 8.1; SchemeAndStackFoundations §§1.22 and 3.3 for stack descent and coherent Euler characteristic; ComplexComparisonPartII C0.3; OperatorTheory/ToeplitzOperators T3 and OperatorTheory/OperatorIdeals OI-B23/OI-B30; RandomMatrices §8.3 for local trace-class determinants. The analytic RHP sewing and index-zero realization are constructed here; the first-jet/scalar comparison belongs later in Layer 9.

### 8.3 The divisor and corrected variational comparisons

Prove that the determinant section vanishes precisely where its normalized RHP is not solvable. On a reduced connected smooth chart where it is not identically zero, construct its effective Cartier divisor; obtain a global divisor only through the line comparisons. This is the failure locus of the selected RHP normalization, not a declaration that the intrinsic phase space or horizontal section ceases to exist. Establish the local trace identity d log det(I − K) = −Tr((I − K)⁻¹dK) on the invertible locus of a holomorphic trace-class family, then derive the integrable-kernel variational formula and its frame-change law. (BERT17, Theorem 2.2, Proposition 2.3, formula (3.6), Theorem 3.3 and §3.1.2.)

Compare with the JMU form only under the stated formal-normalization hypotheses: the generic unramified diagonalizable-leading-term and logarithmic nonresonance locus of BERT10 Assumption 3.1 and §5.1, Proposition 5.1. Use BERT16 Definition 2.1 for the corrected sign, Theorem 2.1 for vertex curvature, and Theorem 2.2, which replaces BERT10 Theorem 5.1. The corrected local formula uses ω_M − θ_V, with dθ_V = η_V on the monodromy parameters. Along fixed-monodromy time directions θ_V has no component; factorization/frame corrections still have to be matched. Neither the raw Malgrange form nor its original modification is asserted closed on the full monodromy-and-time space. Removing contour vertices requires a proved sewing comparison.

**API.**

- Construct the section's divisor and its naturality under the comparisons of §8.2.
- Prove the local variational identity and its change under a nonvanishing frame multiplier.
- Construct the comparison with the selected JMU normalization on exactly the generic unramified, diagonalizable-leading-term and logarithmically nonresonant locus stated above. The delivered JMU comparison makes no assertion on additional ramified or resonant strata. On any such stratum with the proved §8.2 RHP adapter, the determinant section and the Fredholm trace variational identity remain the specified intrinsic objects.

**Checks.**

- A zero of the chosen tau representative can occur while the intrinsic horizontal solution continues through that time in another bundle chart.
- The family T_s = s² retains its double zero; the divisor calculation cannot replace multiplicity by kernel dimension.
- A graph with nontrivial vertex limits requires the BERT16 correction; disjoint closed contours do not justify omitting it from an unproved graph-to-contour comparison.
- The local connection d + [[0,z⁻²],[z⁻¹,0]]dz has projective slope 1/2: after z = w² and the gauge diag(1,w), its leading coefficient is 2(E₁₂ + E₂₁)/w². It is outside the JMU comparison locus here. A constructed index-zero RHP adapter still carries the determinant section and its Fredholm logarithmic derivative; no unspecified ramified JMU differential is inferred from that fact.

*Needs:* §§8.1–8.2; RandomMatrices §8.3's trace-class determinant/trace identities; divisor theory on analytic curves and smooth charts; the formal normalization comparison of §4.1. No all-strata JMU identity is imported from a generic theorem.

### 8.4 Hamiltonians, frames and scalar normalization

On the JMU comparison locus of §8.3, choose a time coordinate and symplectic chart of the already constructed dynamics and derive the relation between the selected determinant-frame logarithmic derivative and the local Hamiltonian. Prove the exact coefficient and gauge, factorization and time-only correction terms from §8.3; do not silently identify different Hamiltonian conventions. A local primitive supplied by a symplectic chart is not a canonical function on the whole phase family. This Hamiltonian/JMU identity is restricted to that locus, and does not assert an additional ramified/resonant identity. (MAL04, Theorem 5.12 in its logarithmic Schlesinger scope; BERT10, §5.1, Proposition 5.1, with BERT16.)

For every constructed marked RHP chart, including a ramified or resonant chart after its §8.2 adapter is proved, retain instead the general determinant-frame identity of §8.3, locally d log det(I − K) = −Tr((I − K)⁻¹dK) with its proved frame correction. Fix this actual logarithmic one-form and the frame prescription, then establish its scalar normalization by choosing a nonzero value in a determinant fiber at a regular base point. This normalization theorem does not require a JMU or Hamiltonian identification outside the generic comparison locus. (BERT17, Proposition 2.3 and formula (3.6).)

The differential-equation normalization is along a fixed-monodromy horizontal time leaf, away from the chosen divisor. There a closed scalar differential and a base-point value determine the representative on a simply connected domain. Any extension of this assertion to the full monodromy-and-time space must prove the required integrability after its frame corrections; simple connectedness alone does not remove curvature of a line connection.

**API.**

- On the specified JMU comparison locus, compare the symplectic/time convention of §3.3 with the variational identity and record all correction terms. On the broader RHP-adapter locus use the Fredholm identity with its prescribed frame, without an unstated JMU extension.
- Prove the transformation laws under a time change, a time-dependent symplectic chart change and a determinant-frame change.
- Prove uniqueness of scalar normalization on a connected simply connected regular domain after its base-point value is fixed; state separately the holonomy obstruction to descent.

**Checks.**

- If an identity uses d log τ = H dt, replacing H by H + c(t) requires multiplying τ by exp(∫c(t)dt), with the integration constant fixed.
- For a new time u = f(t), the same logarithmic one-form has coefficient (dt/du)H; an unchanged scalar coefficient would fail the comparison.
- Two representatives differing by a nonzero constant define the same logarithmic derivative but are different normalized scalar functions until the base-point values agree.

*Needs:* §§3.3–3.4 and 8.2–8.3; local complex symplectic primitives and line-bundle frame calculus. Classical equation-specific identifications are downstream in Layer 9.

### Examples

The one-dimensional operator families s, s² and 1 distinguish section, divisor multiplicity and invertibility. A valid degree-minus-one connection distinguishes the phase object from the auxiliary index-zero RHP complex. A contour/factorization change distinguishes an intrinsic line section from its scalar representatives. These examples test the common construction before any classical tau equation is displayed.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 9: classical expressions as coordinate comparison lemmas

### 9.1 Applying the intrinsic first-jet theorem

Use NonlinearConnections §1.8, formulated for an observer bundle and its first-jet bundle. For the classical time curve and phase surface, supply a local observer and prove that the induced jet map is an isomorphism on the stated domain. Apply the general equivalence between horizontal germs and scalar second-order germs on that domain. In a time/phase chart, write h(∂t) = ∂t + A∂q + B∂p and J(t,q,p) = (t,q,A); if p = P(t,q,v) is its genuine inverse, the coordinate comparison is q″ = (A_t + A A_q + B A_p)(t,q,P(t,q,q′)). The chain-rule theorem and intrinsic jet construction belong to the general framework. A_p ≠ 0 gives a local inverse only. Individual classical chart constructions belong to §9.2; meromorphic continuation additionally uses §5.5 and is not a hypothesis of the jet theorem.

**API.**

- Verify each chart/observer jet-isomorphism domain and record its complement.
- Obtain the scalar formula only as the coordinate expression of the imported jet construction.

**Checks.**

- If A = p, the inverse is p = q′ and the scalar equation is q″ = B(t,q,q′).
- If A is independent of p, J forgets the momentum and cannot be a jet chart; scalar uniqueness then cannot be inferred from geometric uniqueness by this argument.
- For A = p² there are two momentum branches away from p = 0; local invertibility does not identify the two branches globally.
- If a scalar formula divides by q, a solution crossing q = 0 must be treated through overlapping phase charts, not by declaring that the cleared denominator creates new solutions.

*Needs:* target:1.4; target:2.3; target:3.1; framework:NonlinearConnections/1.8.

### 9.2 Exhaustive presentation and equation comparisons

For every profile in §1.4 construct a concrete time/Darboux or equivalent symplectic chart from the connection moduli, with its inverse on its actual image. Identify h in this chart by the strong integrable extension of §3.1, apply §9.1, and prove the parameter and time-substitution dictionary to the standard equation below, including the required marking covers. The required comparison records the chosen local frames, the determinant convention, the chart domain, the momentum inverse, every denominator, and the omitted loci. Coverage of the full moduli space is the overlap theorem, not the claim that one rational chart covers it. Re-derive the scalar expression from the compatible system; the source corrections in §9.4 are part of the comparison. (VDPS09, §2.2, Table 1 and §4; IIS06, Theorems 10.6, 10.10 and 10.13; DLMF, §32.2(i), equations 32.2.1–32.2.6.)

In the following output table, slopes are projective Katz invariants and their order is forgotten only for the classification table; an omitted pole is written “—”. All seventeen ordered profiles are recovered with the label-assignment and reindexing comparisons of §1.4. The number of external parameters is the dimension of the generic exponent family, not the number of initial conditions. Boundary diagrams are affine.

| Slopes at 0, 1, ∞, t | Boundary type | External dimension | Displayed realization and exact locator |
|---|---|---:|---|
| 0, 0, 0, 0 | D₄ | 4 | PVI; IIS06 §10, Theorems 10.6 and 10.10 |
| 0, 0, 1, — | D₅ | 3 | PV; VDPS09 §4.3, equations (1)–(5) |
| 0, 0, 1/2, — | D₆ | 2 | degenerate PV; VDPS09 §4.4, equations (6)–(11) |
| 1, —, 1, — | D₆ | 2 | PIII(D₆); VDPS09 §4.5, equations (12)–(16) |
| 1/2, —, 1, — | D₇ | 1 | PIII(D₇); VDPS09 §4.6, equations (17)–(21) |
| 1/2, —, 1/2, — | D₈ | 0 | PIII(D₈); VDPS09 §4.7, equations (22)–(26) |
| 0, —, 2, — | E₆ | 2 | PIV; VDPS09 §4.8, equations (27)–(31) |
| 0, —, 3/2, — | E₇ | 1 | Flaschka–Newell realization; VDPS09 §4.9, equations (32)–(36); its immediate scalar coordinate is P34 |
| —, —, 3, — | E₇ | 1 | Jimbo–Miwa realization of PII; VDPS09 §4.10, equations (37)–(41) |
| —, —, 5/2, — | E₈ | 0 | PI; VDPS09 §4.11, equations (42)–(47) |

Prove the actual substitutions and admissible inverse domains relating the Flaschka–Newell scalar coordinate to PII and degenerate PV to PIII(D₆). Two rows sharing a boundary type are not declared identical decorated moduli problems. In particular, a scalar substitution from degenerate PV to PIII does not by itself identify their isomonodromic families. (AHT17, introduction and §§2–3.)

The six standard scalar conclusions, in the DLMF normalization and on their ordinary differential-equation domains, are:

| Equation | Coordinate expression |
|---|---|
| PI | q″ = 6q² + t |
| PII | q″ = 2q³ + tq + α |
| PIII | q″ = q′²/q − q′/t + (αq² + β)/t + γq³ + δ/q |
| PIV | q″ = q′²/(2q) + 3q³/2 + 4tq² + 2(t² − α)q + β/q |
| PV | q″ = (1/(2q) + 1/(q − 1))q′² − q′/t + (q − 1)²(αq + β/q)/t² + γq/t + δq(q + 1)/(q − 1) |
| PVI | q″ = (1/q + 1/(q − 1) + 1/(q − t))q′²/2 − (1/t + 1/(t − 1) + 1/(q − t))q′ + q(q − 1)(q − t)[α + βt/q² + γ(t − 1)/(q − 1)² + δt(t − 1)/(q − t)²]/[t²(t − 1)²] |

Each row is a theorem about a chart and a specified parameter map. The symbols α, β, γ, δ are local to that row. The following explicit dictionaries fix the intended normalization; their admissible inverse charts and momentum transformations are part of the proof.

| Source variables and parameters | Standard variables and coefficients |
|---|---|
| IIS06 (1)–(2), with 2κ₀ + κ₁ + κ₂ + κ₃ + κ₄ = 1 | PVI: α = κ₄²/2, β = −κ₁²/2, γ = κ₂²/2, δ = (1 − κ₃²)/2 |
| VDPS09 PV system (2)/(5), with the scalar correction in §9.4 | T = t, Q = q/(q − 1); (α,β,γ,δ) = (θ₁²/2,−θ₀²/2,1 − θ∞,−1/2) |
| VDPS09 degenerate PV system (8) | T = t², Q = q/(q − 1); (α,β,γ,δ) = (θ₁²/2,−θ₀²/2,−2,0) |
| VDPS09 PIII(D₆), (14) | T = t, Q = q; (α,β,γ,δ) = (4(θ∞ + 1),−4θ₀,4,−4) |
| VDPS09 PIII(D₇), (19) | t = T², Q(T) = Tq(T²); (α,β,γ,δ) = (4(θ∞ + 1),−8,4,0) |
| VDPS09 PIII(D₈), (24) | t = T², Q(T) = q(T²)/T; (α,β,γ,δ) = (8,−8,0,0) |
| VDPS09 PIV, (29) | t = 2T, Q(T) = 2q(2T); α = −θ∞ − 1, β = −2θ₀² |
| VDPS09 PII Jimbo–Miwa, (39) | T = t, Q = q; α = (θ∞ + 1)/2 |
| VDPS09 PI, (45), choose c⁵ = 2 | T = ct, Q = c⁻²q; Q″ = 6Q² + T |

For the Flaschka–Newell coordinate (34), choose c³ = 2 and set T = −ct, U(T) = cq(t). Then U″ = U′²/(2U) + 2U² − TU − θ₀²/(2U). Retain a chosen exponent sign a = ±θ₀. On U ≠ 0, Q = (U′ − a)/(2U) is the PII variable with α = a − 1/2; conversely U = Q′ + Q² + T/2. The exceptional branch U = 0, a = 0 cannot be reconstructed by division and keeps its full phase data. The square-time comparisons are local biholomorphisms on their nonzero domains or comparisons on the indicated covers; they are not global changes of coordinate on the same punctured line.

**API.**

- Export one comparison package per listed presentation, containing the explicit formulas, parameter map, inverse jet chart and overlap maps.
- Compare the source-specific Hamiltonian and the convention of §3.3 by equality of extended forms.
- Identify all excluded denominators and the phase charts through their allowed zero loci.
- Deduce the standard scalar Painlevé property from §5.5 on every observer stratum covered by the comparison.

**Checks.**

- There are ten presentation rows and eight boundary types; identifying every row with a different classical equation fails both counts.
- The standard PI scaling above changes both q and t. Rescaling t alone does not recover the coefficient 6 of q².
- PII's two linear-system presentations have different local singularity data; equality of their scalar solution formulas is not equality of input objects.
- A PIII comparison with γ = 4, δ = −4 cannot cover γ = δ = 0 by a nonzero scaling; the latter belongs to the boundary analysis of §9.3.

*Needs:* §§1.4, 2.1–2.4, 3.1–3.4, 5.5, 6.2 and 9.1. Connection matrices, scalar equations and coordinate Hamiltonians are conclusions of this layer.

### 9.3 Complete coefficient-boundary coverage

Classify all coefficient tuples of the standard PIII and PV displays by admissible nonzero scalings and inversions, proving their exact domains and inverse substitutions. The primitive Painlevé profiles and the elementary boundary equations are different outputs; a leading irregular coefficient zero is not a point inside a stratum defined by its nonvanishing. (FM19, §1.1 and equation (2); DIL21, §§5.2–5.3 and Appendix B.3; DLMF, equations 32.9.6 and 32.9.12.)

| Display | Coefficient condition | Comparison target |
|---|---|---|
| PIII | γδ ≠ 0 | D₆ profile |
| PIII | γ = 0 and αδ ≠ 0, or δ = 0 and βγ ≠ 0 | D₇ profile, with the inversion comparison between the two orientations |
| PIII | γ = δ = 0 and αβ ≠ 0 | D₈ profile |
| PIII | α = γ = 0, or β = δ = 0 | quadrature/elementary boundary |
| PV | δ ≠ 0 | ordinary PV |
| PV | δ = 0 and γ ≠ 0 | degenerate PV presentation |
| PV | γ = δ = 0 | quadrature boundary |

Prove that the PIII cases cover all tuples; the two elementary alternatives may overlap and are combined into one boundary class. Derive the boundary integrations on their stated time/observer domains, with branches and integration constants retained, and compare limiting initial data when a geometric degeneration is claimed. PIII with all four coefficients zero gives q = C exp(μ log t) on a chosen cover of ℂ*, including its nonzero-solution domain. A generic such power is not a single-valued function on ℂ*. Zero/constant solutions introduced by clearing q denominators require a separate original-equation domain check. These examples prevent the primitive classification from silently losing coefficient values.

*Needs:* §9.1–9.2; FormalLaurentPuiseux L1–L7 only for formal substitution algebra; ordinary complex differentiation and local branch/covering theory. The geometric collision theorem itself remains in Layer 11.

### 9.4 Hamiltonian, sigma and linear-system realizations

For each admitted presentation, derive the displayed Hamiltonian system from h and ω, and derive the Lax-pair compatibility from the same strong total connection. For sigma equations, transformations and tau logarithmic derivatives, state a forward lemma and a converse only on the locus where the reconstruction has been proved. Track additive Hamiltonian functions of time, multiplicative tau normalizations, branch choices and exceptional derivatives explicitly. (DLMF, §§32.6–32.7; VDPS09, §4; IIS06, Theorem 10.13; BERT17, Proposition 2.3 and Theorem 3.3.)

The source sign comparison is itself a lemma. In VDPS09 §4.1 the displayed equations p′ = F H_q, q′ = −F H_p, with F depending only on q, have kernel form dp ∧ dq/F + dH ∧ dt. The printed minus sign in that extended form is inconsistent with those equations, including the PI instance (44), (46), (47). On F ≠ 0, set Q = q, P = p/F(q), K(Q,P,t) = −H(F(Q)P,Q,t), using the source's argument order H(p,q,t); then dQ ∧ dP + dK ∧ dt is the negative of the correct source form and gives the convention of §3.3. Verify this identity directly before importing any source Hamiltonian.

VDPS09's printed PV equation (3) also disagrees with its system (2) and Hamiltonian (5). Differentiating q′ = 2p/t gives the exponent term [θ₀²(q − 1)² − θ₁²q²]/[2q(q − 1)t²], in place of the printed θ₀²/(2qt²) + θ₁²/[2(q − 1)t²]. At t = 1, q = 2, p = 0, θ₀ = 0, θ₁ = 1, θ∞ = 1, the compatible system gives q″ = 2 while the printed scalar equation gives 7/2. The comparison uses the re-derived expression and then the PV substitution of §9.2.

For sigma reconstruction include the derivative-nondegeneracy hypothesis and analytic extension argument. For example, the PI sigma relation (σ″)² + 4(σ′)³ + 2tσ′ − 2σ = 0 admits σ ≡ 0, whereas q = −σ′ ≡ 0 does not solve q″ = 6q² + t. Thus the unqualified reverse implication is false. On the branch σ″ not identically zero, differentiating and then extending the resulting analytic identity gives the required reconstruction. The entire excluded branch is σ = at + 2a³ with a constant; its q = −a never solves PI on an open time domain. This explicitly identifies the spurious scalar branches of this sigma relation.

Distinguish this PI obstruction from loss of phase information on a genuine invariant locus. In the PII normalization of §9.5, put c = α + 1/2 and σ = H. Direct differentiation gives σ′ = −p/2 and σ″ = 2qσ′ − c/2, hence q = (2σ″ + c)/(4σ′) and p = −2σ′ on σ′ ≠ 0. At c = 0 and p = 0, every Riccati trajectory q′ = −q² − t/2 has σ ≡ 0. These are genuine phase trajectories with distinct initial q, all having the same scalar sigma function. Retain that phase/initial-point data on this locus; there is no sigma-only inverse there. Isolated zeros of σ′ in the reconstructible branch require the stated analytic extension comparison, not totalized division.

*Needs:* §§3.3, 7.1–7.2, 8.3–8.4 and 9.1–9.3. Compatibility identities are verified on the original domains, and are extended only by an actual analytic or algebraic continuation theorem.

### 9.5 Concrete normalizations and special-solution checks

Prove the PI chart H = p²/2 − 2q³ − tq and the PII chart H = p²/2 − (q² + t/2)p − (α + 1/2)q from the corresponding moduli charts, and apply §9.1. The PII jet inverse is p = q′ + q² + t/2. The polynomial chart covers all finite (q,q′), while poles use the other phase charts. Establish its parameter dictionary with §9.2. (VDPS09, §§4.10–4.11; DLMF, §§32.2, 32.6 and 32.9.)

Construct the rational and classical-function families generated from the proved seed objects by §§7.1–7.2's admitted transformations, and prove their formulas only as the resulting coordinate lemmas. No completeness classification of all rational or algebraic solutions is imported from these few seeds.

**Checks.**

- At α = 0, q = 0 and p = t/2 form a horizontal section in this chart.
- At α = 1 and t ≠ 0, q = −1/t and p = 2/t² + t/2 satisfy both Hamilton equations; at t = 0 their geometric continuation uses another chart.
- At α = −1/2, p = 0 is invariant and q′ = −q² − t/2. Setting q = u′/u gives u″ = −tu/2 on u ≠ 0; this is the projective linearization of §7.3, with zeros of u interpreted in ℙ¹.
- H ↦ H + c(t) leaves both tests horizontal, but changes a normalized Hamiltonian tau representative by the corresponding exponential primitive when the identity of §8.4 applies.

*Needs:* §§7.1–7.3, 8.4 and 9.1–9.4; the actual chart/domain and parameter comparisons. Hastings–McLeod is not constructed here.

### Examples

The scalar equation may have an apparent denominator at a perfectly regular geometric initial point. Conversely, a denominator-cleared polynomial identity may admit functions absent from the original equation. The first-jet chart and the observer comparison resolve both issues without changing the intrinsic solution definition.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 10: normalized analytic and distinguished solutions

### 10.1 Boundary and sectorial selection data

Define boundary-selection data over the admitted geometric time family: an end and sector or specified approach path; its time coordinate and branches; local formal and Stokes data with a framing; any lattice, parabolic or resolution datum needed to select a de Rham lift; and a normalization for the requested observable or tau representative. Define equivalence by the actual marking transformations. The record contains no solution and no existence or uniqueness assertion. A specification becomes a characterization only after its analytic realization theorem. Linear Stokes data at a spectral singularity and nonlinear asymptotics at a time boundary are different constructions, connected by the theorem. (ILP18, §1.4 and §§3.3–3.4, 4.2–4.3, for the distinction in concrete realizations.)

**API.**

- Construct restriction to a smaller sector, branch change and transport of a boundary specification under a geometric comparison.
- Formulate realization by a normalized RHP and recovery of a decorated phase point without putting either result into the input definition.
- State uniqueness for the specified normalized problem and its selected lift, then prove equality with the intrinsic horizontal section constructed from that point.
- Define a connection constant as the comparison between two stated asymptotic normalizations of the same section along a specified continuation path.

**Checks.**

- Identical formal power-series asymptotics can leave exponentially small/Stokes freedom; that truncated specification does not automatically select one solution.
- Coarse monodromy data with a nontrivial exceptional RH fiber does not identify a unique phase point without the required lift data.
- Rescaling the observable or tau frame changes numerical asymptotic constants; equivalence of underlying horizontal sections does not erase that normalization.

*Needs:* §§4.1–4.3, 5.1–5.4 and 8.2–8.4; the marked coordinate and first-jet comparisons of Layer 9 only when a conventional scalar normalization is requested.

### 10.2 Geometric adapters for the general small-norm RHP theorem

Use AnalyticRHPAndDeterminants §§1.2–1.4 for the Cauchy solution class, small-norm inversion, weighted moments and parameter-uniform tails. This target owns the actual contours and local parametrices selected by §10.1. Prove the bounded Cauchy operators and reconstruction, the residual representation R = I + C(h), disappearance of small endpoint-circle integrals, and determinant removability for these geometric local models. Boundary L² traces alone are insufficient. Verify w ∈ L² ∩ L∞, det(I+w)=1 and a common operator gap ‖C_w‖ ≤ ρ < 1 on the stated parameter set; use the general ν = C₋w + C_wν solution, without assuming I ∈ L² on an unbounded contour.

For every claimed coefficient or uniform remainder, verify the actual weighted L¹/L² moment and tail hypotheses of §1.4. Uniform weighted norms alone do not give parameter-uniform little-o. Supply weighted-tail tightness, compact norm-continuous parameter control, or an additional moment on precisely the parameter set used by §§10.3 and 11.4. The general estimates and counterexamples are owned in the analytic framework.

Undo the verified parametrix reduction, reconstruct the decorated connection by §4.1, and identify its parameter variation with the strong splitting of Layer 3. Compare local solutions by uniqueness and continue by Layer 5. An arbitrary small jump does not specify this meromorphic-connection problem. Outside the verified small-norm domain, supply a separate vanishing/invertibility argument and prove its hypotheses. (ILP18, §3.3, Lemma 3.3, is a concrete application.)

**API.**

- Prove the contour, endpoint and determinant-removability adapters into the general Cauchy class.
- Verify the parameter-uniform gap and exact weighted-tail controls required by the chosen asymptotic conclusion.
- Reconstruct the actual decorated connection and prove its horizontality and overlap comparison.

**Checks.**

- Identity jump gives h = 0 and R = I in this class. On Γ = [0,1], the competing matrix I + exp(−1/z)z⁻¹E₁₂ has the same identity jump and normalization and has L² boundary correction with squared norm e⁻²/2, but an essential endpoint singularity. It is excluded by Cauchy reconstruction: h = R₊ − R₋ = 0 cannot reconstruct its nonzero correction.
- The estimate ‖ν‖₂ ≤ ‖C₋w‖₂/(1 − ρ) records the necessary loss as ρ approaches one; it does not provide a uniform estimate at ρ = 1.
- Failure of the small-norm hypothesis does not prove nonsolvability. On a counterclockwise unit circle the constant jump −I₂ has w = −2I₂ and ‖C_w‖ = 2, yet the solution R_out = I₂, R_in = −I₂ is in the Cauchy class, with h = −2I₂ and determinant one.
- On Γ = ℝ, let w_s(x) = a exp(−(x − s)²)E₁₂ with Re s > 1 and |Im s| < δ, choosing a > 0 so small that a exp(δ²) < 1. This is a Banach-holomorphic small-jump family with uniformly bounded zeroth L¹/L²/L∞ moments, determinant one and exact density h_s = w_s because E₁₂² = 0. Its zeroth moment is M₀ = a√π E₁₂. At s = n and z = in, n(C(w_n)(in) + M₀/(2πi·in)) tends to (a√π/(2πi))((1 − i)/2)E₁₂ ≠ 0. Thus a pointwise o(1/z) remainder need not be parameter-uniform; the translated mass fails the uniform tail condition.

*Needs:* target:3.1; target:3.2; target:4.1; target:5.1; target:5.3; target:10.1; framework:AnalyticRHPAndDeterminants/1.2; framework:AnalyticRHPAndDeterminants/1.3; framework:AnalyticRHPAndDeterminants/1.4.

### 10.3 Two precisely scoped connection-formula realizations

Translate ILP18 Theorems A and B into the boundary language, prove their normalized RHP realizations and transfer their endpoint and constant-ratio identities to §8's section. Keep the parameter dictionaries and branch choices explicit. The targets are the following source loci, not all parameters of the corresponding equations.

For Theorem A use the four logarithmic residues with eigenvalues ±θ_ν, 2θ_ν ∉ ℤ for ν = 0,t,1,∞, the marked monodromy cubic (1.16), and σ = σ₀ₜ, ρ = σₜ₁ satisfying σ,ρ ≠ 0 and 0 ≤ Re σ, Re ρ < 1/2. Require every member of the following four sets to avoid ℤ: {θ₀ ± θₜ ± σ}, {θ∞ ± θ₁ ± σ}, {θ₁ ± θₜ ± ρ}, {θ∞ ± θ₀ ± ρ}, with both signs independent. These are (1.13) and (1.17). With the source's t ∈ (0,1) endpoint branches and JMU normalization, prove its asymptotics (1.18a–b) and C₁/C₀ equal to the Barnes-G expression (1.19), using exactly the quantities (1.20–1.21). Propositions 3.20 and 3.24 and §3.9 supply the proof targets. Where an auxiliary denominator in (1.21) vanishes, use a proved continuation of the expression rather than totalized division.

For Theorem B use homogeneous PII, q″ = 2q³ + tq, and its source Stokes surface s₁ − s₂ + s₃ + s₁s₂s₃ = 0. Require s₁s₃ ≠ 1, Arg(1 − s₁s₃) ∈ (−π,π), s₂ ∉ ℝ and Arg(iϵs₂) ∈ (−π/2,π/2), where ϵ = sign Re(is₂) ∈ {−1,1}. These are (1.25). With d log τ = (q′² − q⁴ − tq²)dt, prove the two real-ray asymptotics (1.26) and C₊/C₋ equal to (1.28), with μ,ν from (1.27) and exp(iπη) = −iϵ/s₃. The literal η chart requires s₃ ≠ 0. Prove the stated η ↦ η + 2 invariance, normalization comparison and analytic extension to further allowed data; never assign an exponential logarithm to an undefined quotient. The proof locators are §§4.3–4.5 and Remark 4.8, with Barnes-function domains and removable limits explicit.

Separate the absolute-constant calibration in ILP18 §4.5 from the monodromy-dependent variational calculation. Its supporting proof targets are the Airy determinant constant χ = (log 2)/24 + ζ′(−1) in DIK08 Theorem 1, (2)–(3); the complex-sector pole-freeness in HXZ16 Theorem 2.1; and the uniform complex-sector Hamiltonian asymptotics and arc estimates used in ILP18 (4.74)–(4.76). Consume the existing Hastings–McLeod object and Fredholm identity from RandomMatrices §8.5. That contract and the first two estimates do not imply the third.

For the third supporting target, construct the Hastings–McLeod normalized RHP and sectorial parametrices on arg z ∈ [−π/3,0] and [2π/3,π], using its supplied scalar object rather than proving a second existence theorem. Apply §10.2 with uniform boundary-sector and weighted remainder estimates to recover the Hamiltonian asymptotics (4.74). With H_HM denoting ILP18's Hamiltonian normalization, prove that the integrals over the oriented large-circle arcs of H_HM(z)dz on the first sector and of (H_HM(z) − z²/4 + 1/(8z))dz on the second tend to zero. State and prove the uniform bounds, including the boundary rays, which justify these two limits; real-ray asymptotics alone do not suffice. ILP18 cites FIKN for the sectorial continuation and uses Jordan-type estimates at this step. Here this exact sectorial estimate is an owned RHP/parametrix proof target, not an unrecorded import of the whole FIKN theory. With the arc limits established, compute the remaining logarithmic contribution as +iπ/24 and the calibration as exp(χ + iπ/24).

The quantitative arc contract is the following, uniformly for z = R exp(iθ) and sufficiently large R. On the first sector prove |H_HM(z)| ≤ C R⁻¹ exp(−(4/3)R³ᐟ² cos(3θ/2)) + C R⁻⁵ᐟ². On the second set φ = θ − π and c = 2√2/3, and prove |H_HM(z) − z²/4 + 1/(8z)| ≤ C R⁻¹ᐟ⁴ exp(−cR³ᐟ² cos(3φ/2)) + C R⁻¹ exp(−2cR³ᐟ² cos(3φ/2)) + C R⁻⁷ᐟ⁴. These are bounds for the full sectorial expansions (4.74), with uniform remainders at the boundary. The angular integrals of each exponential are O(R⁻³ᐟ²), since the cosine has a simple zero at the oscillatory boundary. Multiplication by the arc-length factor R gives first-arc bound O(R⁻³ᐟ²) and second-arc bound O(R⁻³ᐟ⁴), hence the required vanishing.

**Checks.**

- A resonant exponent 2θ_ν ∈ ℤ is excluded from this PVI realization even though the corresponding decorated phase object may belong to the core theory.
- The PII source has α = 0. Its theorem does not become an arbitrary-α connection formula by changing a label.
- The Stokes triple (i,i,0) satisfies (1.25) but does not admit the literal η formula involving 1/s₃; the continued expression needs its own proof.
- Hastings–McLeod boundary Stokes data do not satisfy this generic PII input. Neither this theorem nor endpoint smoothness asserts absence of poles throughout every intermediate time interval.
- The entire function exp(−z²) is flat at both real ends but has modulus exp(R²/2) on arg z = −π/3. Pole-freeness plus real-ray decay therefore fails the sectorial arc test; the explicit uniform weighted bounds above are essential.

*Needs:* §§10.1–10.2, 8.3–8.4 and Layer 9's actual parameter and normalization dictionaries; AnalyticNumberTheoryPartII §§4.3–4.3a for Barnes G, its functional identities, zero/pole domains and sectorial asymptotics; ILP18's local parametrices and uniform endpoint estimates; RandomMatrices §8.5; the explicitly stated DIK08/HXZ16 and sectorial Hamiltonian/arc-vanishing calibration targets. No claim of closed formulas for every Painlevé connection constant is made.

### 10.4 The Hastings–McLeod bridge

Consume the scalar result already owned by RandomMatrices §8.5: its normalized real Hastings–McLeod solution of q″ = tq + 2q³, its uniqueness and real pole-freeness. At a regular real time t₀, use §9.1's first-jet inverse to construct the intrinsic phase point from (q(t₀),q′(t₀)). Apply §§5.1–5.3 and prove that the resulting horizontal section evaluates to the supplied scalar solution on its real domain and on the common analytic continuation. Prove independence of t₀ using uniqueness and the first-jet overlap comparison. The real initial values determine the local complex analytic solution; they do not by themselves prove its boundary behavior, which is consumed from the supplier.

The primary-source chart comparison is VDPS09 §4.10, translated to §9.5's momentum and Hamiltonian normalization. That source supplies the chart, not the Hastings–McLeod existence theorem consumed from RandomMatrices.

**API.**

- Construct the phase-point and horizontal-section bridge from the supplied first jet.
- Prove commutation with scalar evaluation and with continuation through changes of phase chart.
- Transport the supplier's reality and real pole-freeness assertions through that evaluation; retain its Airy normalization unchanged.

**Checks.**

- Replacing q ∼ Ai by q ∼ k Ai with k ≠ 1 does not satisfy the same supplier contract.
- Choosing a second regular real initial time produces the same horizontal section after transport, not a second distinguished solution.
- Real pole-freeness does not assert absence of poles at complex times, and the bridge does not infer that stronger statement.

*Needs:* RandomMatrices §8.5, through its §8.4 Airy/edge floor; §9.1's first-jet equivalence; §§5.1–5.5. Hastings–McLeod existence/uniqueness, its Fredholm identities and the Tracy–Widom formulas remain owned by RandomMatrices; this target adds no second supplier for them.

### Examples

The identity-jump model checks the RHP normalization. The generic PVI and homogeneous-PII loci distinguish a proved connection formula from an unrestricted all-parameter assertion. The Hastings–McLeod bridge checks interoperability with an independently owned scalar theory, without using its formula to define the intrinsic dynamics.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Layer 11: geometric confluence and convergence

### 11.1 Collision families of geometric connection data

Define a collision datum as the following geometric family, with arrows given by isomorphisms preserving all the data. Over a collision disk Δ_ε and an admitted limiting time/parameter domain, give a smooth projective curve family with a finite-flat structural divisor of degree four; ordered labels on its separated branches over ε ≠ 0 and their specialization map; a determinant line connection and its comparison; and a flat family of local polar-part conditions in the dual of gl₂ ⊗ O_P, with filtrations or factorized ramified descent as required. Specify the meromorphic-in-ε exponent map, the time map with nonzero derivative for ε ≠ 0, and any finite parameter cover used by these maps. Specify the local leading-coefficient orbit and the lower coefficients that determine its formal type, not merely the multiplicity of the divisor. The limiting formal condition is either a §1.1 condition with its actual minimal projective slope or a separately marked lower-complexity boundary condition. These are algebraic/formal data; no horizontal solution limit, symplectic equivalence or RHP convergence is a field of the definition.

The admitted primitive classical domain first requires both primitive endpoints to be objects of §1.3: genus zero, rank two, structural degree four, the admitted local formal structures, a regular-singular determinant with its fixed-residue compatible time transport, the actual reduced versal time problem, generic weights and nonempty stable fibers. Projective slopes or trace-free deformation ranks cannot replace this endpoint condition. Within that domain, impose the nonzero-leading/factorization relations and construct the regular comparison locus where the relative local-condition and deformation complexes have flat coherent terms and the constant ranks computed from the endpoint problems. Define it using the actual relation and Kodaira–Spencer maps, invariant under changes of presentation; neither the time/phase dimension conclusions of §1.4 and §2.3 nor equality of horizontal distributions is a field added to the input.

A boundary endpoint instead records its actual reduced structural/local conditions, determinant pole order and the rank or leading-term conditions that fail. It is not silently admitted to the primitive classical domain. It receives an elementary scalar confluence arrow only through its separately proved §9.3 dictionary and phase/first-jet comparison. An extra scalar irregular determinant is not a primitive endpoint merely because its projective profile agrees with one in §1.4. Construct the moduli/reduction comparisons on the specified regular locus, prove its rank description in the local model, and obtain the common phase charts and horizontal-field extension by solving the strong deformation equations of Layer 3. A component without this verified regular comparison has no asserted solution-convergence arrow.

For A = p_*O_P, import framework:AlgebraicConfluence/1.2’s relative dual Lie–Poisson structure and its residue comparison with the curve’s polar data. The split point algebras and the truncated local algebra at collision are coordinate realizations of this one finite-algebra family. Verify separately that the chosen local-condition orbits and relative reductions satisfy the regularity and flatness conditions needed by this collision datum; the general Poisson construction does not establish those properties. Apply the supplied fiber-negation isomorphism to the GMR23 conventions: dY/dz = A_source Y versus ∇ = d + A_ours requires A_ours = −A_source, for every Takiff coefficient and residue/exponent parameter. Identify the actual residue pairing, paired KKS form, moment map, reduction and Hamiltonian conventions through that isomorphism. An identity map of coefficient matrices is not this adapter.

Use GMR23 Definitions 3–4 and Theorem 12, §4.2, pp. 1428–1429, for its ordered cascade and Takiff models, and Theorem 13, §4.3, pp. 1435–1436, for limiting Hamiltonians on their stated domains. For each coordinate collision model satisfying the simple-zero and pole-bound hypotheses of framework:AlgebraicConfluence/1.1, instantiate that corrected principal-part lemma with V = M₂(ℂ). Its exact finite identity supplies the limiting Laurent coefficients and compact-uniform coefficient limit away from the collision point; the application must match these actual Laurent coefficients with the source’s time-dependent coefficient basis and the chosen exponent/time map. The printed Theorem 2, pp. 1391–1392, (12)–(15), is not used unchanged: C = O(ε⁻ʳ) makes CPʳ⁺¹ = O(ε), whereas the corrected ε⁻ʳ⁻¹ coefficient W gives the highest limit coefficient t₁ʳ⁺¹W. Under a nonlinear change of collision parameter, transport the holomorphic D_j correction specified by the general lemma as well. Neither this matrix coefficient limit nor a nonzero highest matrix coefficient determines the projective Katz slope or supplies a moduli/reduction comparison. Prove the full endpoint formal-type and regular-locus adapters already required above. GMR23 §5.1, p. 1441, explicitly restricts its Painlevé realizations to the nonramified case; the ramified comparisons remain owned applications.

**API.**

- Construct the collision-data groupoid, the specified rank-defined admitted domain, its special fiber and the determinant/local-structure comparison. Prove invariance of its domains under curve, frame and parameter-cover changes.
- Prove Poisson and symplectic-reduction compatibility on the stated regular loci and identify any needed resolution or modification.
- Prove convergence of the pulled-back horizontal distributions in common local charts from the geometric deformation equations.
- Construct the endpoint-profile adapters for every verified collision datum, retaining its leading orbit, lower coefficients, ramification and exponent map. A vanishing leading coefficient is sent to its computed new formal stratum or marked boundary. The quantified arrows are these collision-data comparisons, not an unstated finite list of familiar scalar arrows.

**Checks.**

- For O_Δ[z]/(z(z − ε)), ε ≠ 0 gives the product of two point algebras, while ε = 0 gives ℂ[z]/z². The central nilpotent class of z is part of the comparison.
- At r = 1, C = W/ε², P = t₁ε + t₂ε², B₀ = −W/ε² and B₁ = −t₁W/ε give the limit t₂W/z² + t₁²W/z³. For t₁ = 1, t₂ = 0, the entire expression equals W/[z²(z − ε)]. By contrast C = W/ε, B₀ = −W/ε, B₁ = W and P = ε give 2W/z² in the limit, with zero triple-pole coefficient.
- The family −B/(εz) + B/[ε(z − ε)] + C/z tends to B/z² + C/z. For B = diag(1,−1) the projective slope is 1. For B = E₁₂ and C = E₂₁ it is 1/2 after z = w² and gauge diag(1,w). For B = E₁₂ and C = 0, gauge I + E₁₂/z removes the pole. These cases have the same collision divisor but different endpoint formal data; the last leaves the generic irregular domain.
- With X = E₁₂, Y = E₂₁ and ν_source = diag(1,−1)/2, the source linear Poisson bracket is −1. At ν_ours = −ν_source the positive supplier bracket is also −1; pullback under fiber negation agrees, while identity comparison gives +1. For a Takiff algebra the bracket is zero when the sum of the two degrees exceeds the truncation degree.
- A global test family on ℙ¹ has poles 0, εT, 1, ∞ and coefficient (−B/ε + C)/z + (B/ε)/(z − εT) + D/(z − 1), with T ≠ 0 and εT ≠ 1. Its limit is TB/z² + C/z + D/(z − 1), and its residue at infinity remains −C − D. For the primitive classical test impose tr(B) = 0 and the specified determinant residues/transport. Regular semisimple trace-free B gives the underlying (0,0,1) profile; nilpotent B with the indicated nonzero lower coefficient gives (0,0,1/2). Verify the full §1.3 endpoint conditions, exponent map, stable locus and time comparison T ↦ εT before promoting either coefficient model to a moduli arrow.
- B = diag(1,2) has the same projective slope-one shape as its trace-free part diag(−1/2,1/2), but its limiting determinant has the term 3T dz/z². It is outside the primitive classical domain even though scalar twisting does not change invariant subbundles or the trace-free commutator complex.

*Needs:* Layers 1–3, including the finite-flat local-condition/deformation method; framework:AlgebraicConfluence/1.1 for the corrected vector-valued principal-part lemma and framework:AlgebraicConfluence/1.2 for the complex relative dual Poisson, residue and sign contracts. Construct this collision’s formal-type, orbit-flatness, regular-reduction and horizontal-field adapters on their verified loci. SymplecticGeometry/HamiltonianReduction R2–R3 supplies only its stated smooth real comparison floor; Layer 6 enters where resolved or compactified phase charts are used. Analytic solution convergence remains a separate theorem.

### 11.2 Confluence by the general compact-path theorem

Apply NonlinearConnections §1.9 to the actual time/phase comparison of §11.1. Supply a reference horizontal lift on a fixed compact piecewise C¹ time path avoiding the limiting fixed singularities. Verify finitely many common charts with a positive boundary margin, uniform convergence of the path-pulled fields (including the path velocity), a common local Lipschitz bound and convergent initial points. The general theorem then produces the approximating lifts on the entire path and proves uniform convergence; their existence/no-exit is not assumed. Import its segment estimate (initial error + ℓδ_ε)exp(Lℓ) and finite-chart gluing. Holomorphic fields give derivative bounds only on a larger common neighborhood where Cauchy estimates apply. Uniformity on compact time domains, parameter families or endpoint sectors requires its separate common-cover and path-family controls; none follows from convergence along one path.

**API.**

- Verify the exact common-chart and field-convergence hypotheses on each claimed geometric collision domain.
- Apply the imported no-exit and quantitative convergence theorem without a separate scalar proof.

**Checks.**

- On [0,2], the approximating fields F_n = 1/(n+1), limiting field F_ref = 0 and initial value 0 give x_n(t) = t/(n+1), with uniform error 2/(n+1). For identical zero fields and initial values (−1)ⁿ, the solutions do not converge; the initial-convergence hypothesis is essential.
- Coefficient convergence on a chart does not control a trajectory that leaves every common neighborhood; the positive-margin hypothesis is used in the proof.
- The estimate is uniform on the fixed compact path. It does not assert uniform convergence on an unbounded time ray or across a limiting fixed singularity.

*Needs:* target:11.1; framework:NonlinearConnections/1.9.

### 11.3 The cascade as coordinate comparison

Construct the cascade as the category generated by the verified collision-data arrows of §11.1, with endpoint identifications and the stated domains retained. Its morphisms are data-dependent comparisons; the ten underlying profiles alone do not specify an arrow. For each such arrow choose the time and phase charts only after the geometric comparison is built, then derive the scaled classical equation, its parameter map and its first-jet correspondence using Layer 9. The ramified (0,0,1/2) endpoint is obtained only on its nonzero lower-coefficient locus; a removable or vanishing-leading-term endpoint is placed in its separately computed lower stratum and receives a §9.3 scalar boundary comparison only where the first-jet comparison is proved. Prove coverage of each arrow's recorded domain, its nonzero scaling factors and its omitted charts. Apply §11.2 to obtain the solution limit for matched initial points. Composition uses compatible determinant, label, parameter-cover and time identifications; interchanging limits requires an additional uniform theorem. This theorem quantifies over the invariant collision-data class, and makes no claim that an unspecified finite graph exhausts every possible degeneration. (GMR23, Definitions 3–4, Theorems 12–13; the corrected Laurent lemma is owned by §11.1, and §5's source realizations retain their nonramified scope.)

**Checks.**

- Two paths to a profile can produce different time scales or parameter names; equality requires the comparison maps, not equality of the final classical label.
- An algebraic limit of a displayed equation without a first-jet inverse does not yet identify its phase points or solution germs.
- Successive limits with different allowable neighborhoods need not commute, even when the displayed limiting differential equations agree.

*Needs:* §§11.1–11.2; Layer 9's parameter dictionaries, first-jet equivalences and boundary comparisons; §3.4's functoriality. The classical scalar cascade is an output of these comparisons.

### 11.4 Tau-confluence adapters for general analytic convergence

Construct the actual determinant-line comparisons, frames, nonzero correction factors and common regular normalization point for the collision of §11.1. With these identifications, verify one of two independent general contracts. AnalyticRHPAndDeterminants §1.5 yields normalized scalar convergence from convergence of corrected logarithmic forms on controlled compact path families in a simply connected zero-free domain. The forms must be the actual determinant-frame forms of §8.3; JMU/Hamiltonian formulas can be used only on their proved comparison locus in §§8.3–8.4.

Alternatively, prove controlled moving-contour, measure and operator identifications with one Hilbert space and compact-uniform trace-norm convergence, then apply AnalyticRHPAndDeterminants §1.6. This route can include zeros; zero counts require nonvanishing of the limit on the chosen boundary and a limit not identically zero. The line/frame/operator comparisons are application obligations, not supplied by the abstract convergence theorems. Endpoint constants and nonlinear Stokes limits additionally require the verified uniform sectorial controls of §10.2 and compatible asymptotic normalization; §11.2 alone does not give them.

**API.**

- Construct and verify the line, frame, normalization and operator comparisons across the actual collision.
- Discharge the hypotheses of the chosen general convergence route and any additional zero-count or endpoint conclusion.

**Checks.**

- Multiplying τ_ε by an uncontrolled ε-dependent nonzero constant leaves d log τ_ε unchanged but can destroy convergence; the base-point normalization is essential.
- For τ_ε(z) = z − ε, scalar determinants converge across the zero, while their logarithmic derivatives do not converge uniformly in a neighborhood of it.
- Convergence on every fixed compact time interval does not give a uniform endpoint asymptotic estimate, so it cannot alone determine the limiting connection constant.

*Needs:* target:8.2; target:8.3; target:8.4; target:10.2; target:11.1; target:11.2; framework:AnalyticRHPAndDeterminants/1.5; framework:AnalyticRHPAndDeterminants/1.6.

### Examples

A two-pole collision tests the local algebra and Laurent rescaling before its classical display. Constant fields with mismatched initial points test the necessity of the analytic hypotheses. The determinant family z − ε tests the difference between function convergence and logarithmic-derivative convergence at a zero. These examples prevent a formal coefficient limit from being mistaken for the full confluence theorem.

### Dependencies

Use the exact *Needs* list at each target and the cross-package registry in `design/reuse_registry.json`. General proof prerequisites belong to their independent package; this layer verifies its stated application comparisons.

## Downstream consumers

A later random-matrix or integrable-probability application can consume this intrinsic phase/observable bridge together with RandomMatrices §§8.3–8.5, preserving the existing ownership of Fredholm determinants, the Airy edge and Hastings–McLeod theory. Such a joint consumer is a new downstream target; the existing RandomMatrices roadmap is not retroactively made to depend on this one.

Further consumers include geometric special-function and connection-formula comparisons, moduli of irregular connections and character varieties, and controlled degeneration problems. They consume the proved horizontal, symplectic, continuation and normalization interfaces at their actual scope. A differential-algebraic classification of all irreducible transcendents, a complete classification of algebraic special solutions, discrete/q-difference Painlevé systems and cluster or Sakai-wide constructions are separate extensions. None supplies a premise to the intrinsic differential construction above.

Implementation order follows the dependency graph: the native geometric/analytic and specified supplier extensions, then Layers 1–5; the surface and tau branches may proceed after their stated prerequisites; coordinate comparisons follow the relevant branches; normalized analytic applications and confluence consume those comparisons. This order keeps the common definitions and theorems independent of the classical scalar displays.


## References

- **I13.** Michi-aki Inaba. *[Moduli of parabolic connections on a curve and Riemann–Hilbert correspondence](https://arxiv.org/abs/math/0602004v2)*. Journal of Algebraic Geometry 22 (2013), 407–480. Cited preprint: arXiv math/0602004v2, 6 June 2012; Theorems 2.1–2.2, preprint pp. 5–6; §§1, 6. The family properness theorem uses the exponent fiber product and its exact numerical/stability hypotheses.

- **I23.** Michi-aki Inaba. *[Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation](https://sigma-journal.com/2023/013/)*. SIGMA 19 (2023), 013, 72 pages. Publisher version, 22 March 2023. Locators: Definitions 2.1–2.8; Remark 2.9; Theorems 5.1, 7.5, 8.1, 9.7 and 11.6; equation (6.9); Propositions 6.3, 7.2, 8.2–8.3, 10.7 and 10.10; Definitions 10.1 and 11.4; Corollaries 9.11 and 11.8; equations (8.2), (11.2) and (11.5).

- **IS12.** Michi-aki Inaba; Masa-Hiko Saito. *[Moduli of unramified irregular singular parabolic connections on a smooth projective curve](https://arxiv.org/abs/1203.0084v3)*. Kyoto Journal of Mathematics 53(2) (2013), 433–482. Cited version: arXiv 1203.0084v3 (22 November 2012); the key retains the preprint year. Locators: Theorem 5.1; Remark 6.3.

- **HEU10.** Viktoria Heu. *[Universal isomonodromic deformations of meromorphic rank 2 connections on curves](https://www.numdam.org/item/AIF_2010__60_2_515_0/)*. Annales de l'Institut Fourier 60(2) (2010), 515–549. Published text through NUMDAM; printed pp. 515–549. Locators: Theorem 1.1; Definitions 2.3 and 2.10; §2.

- **VDPS09.** Marius van der Put; Masa-Hiko Saito. *[Moduli spaces for linear differential equations and the Painlevé equations](https://arxiv.org/abs/0902.1702v5)*. Annales de l'Institut Fourier 59(7) (2009), 2611–2667. Cited version: arXiv 0902.1702v5 (12 November 2009); remaining internal inconsistencies are identified in §9.4. Locators: §2.2, Table 1, preprint pp. 18–19; §3; §4.1 and §§4.3–4.11; equations (12), (17) and (22).

- **IIS06.** Michi-aki Inaba; Katsunori Iwasaki; Masa-Hiko Saito. *[Dynamics of the Sixth Painlevé Equation](https://arxiv.org/abs/math/0501007v2)*. Séminaires et Congrès 14 (2006), 103–167. Cited version: arXiv math/0501007v2 (6 March 2005). Locators: Definitions 2.1–2.2 and 2.11; Lemma 2.12; Definition 3.5; Theorems 4.10–4.12, 5.15–5.16, 7.4, 10.6, 10.10 and 10.13; §§5, 7 and 10.

- **BOA01.** Philip Boalch. *[Symplectic Manifolds and Isomonodromic Deformations](https://arxiv.org/abs/2002.00052v1)*. Advances in Mathematics 163 (2001), 137–205. Cited version: arXiv 2002.00052v1, the author's 2020 deposit of the 2001 article. Locators: §§3–6; Theorems 7.1 and 7.3; §7.

- **BOA14.** P. P. Boalch. *[Geometry and braiding of Stokes data; Fission and wild character varieties](https://arxiv.org/abs/1111.6228v3)*. Annals of Mathematics 179(1) (2014), 301–365. Cited version: arXiv 1111.6228v3 (22 September 2012). Locators: §10, Theorem 10.2; §7 for Stokes data.

- **BY15.** Philip Boalch; Daisuke Yamakawa. *[Twisted wild character varieties](https://arxiv.org/abs/1512.08091v1)*. arXiv preprint 1512.08091. Cited version: arXiv 1512.08091v1 (26 December 2015). Locators: Remark 3; Definitions 7 and 13; Proposition 19; Theorem 21; Corollary 22.

- **STT02.** Masa-Hiko Saito; Taro Takebe; Hitomi Terajima. *[Deformation of Okamoto–Painlevé pairs and Painlevé equations](https://arxiv.org/abs/math/0006026v2)*. Journal of Algebraic Geometry 11(2) (2002), 311–362. Cited version: arXiv math/0006026v2 (18 September 2000), the three-author article. Locators: Definitions 1.1 and 1.3; Proposition 1.2; Tables 2–3; Theorem 3.1; §6.

- **TER02.** Hitomi Terajima. *[Local cohomology of generalized Okamoto–Painlevé pairs and Painlevé equations](https://arxiv.org/abs/math/0006027v1)*. Japanese Journal of Mathematics, New Series 28(1) (2002), 137–162. Cited version: arXiv math/0006027v1 (5 June 2000). Locators: Theorem 2.1; Proposition 2.1; Conjecture 2.1.

- **ST04.** Masa-Hiko Saito; Hitomi Terajima. *[Nodal curves and Riccati solutions of Painlevé equations](https://arxiv.org/abs/math/0201225v1)*. Journal of Mathematics of Kyoto University 44(3) (2004), 529–568. Cited version: arXiv math/0201225v1 (23 January 2002). Locators: §2.4; Proposition 2.1; Definition 2.3; Remark 2.4; Appendix A.

- **FM19.** Andrea E. V. Ferrari; Lionel Mason. *[Meromorphic Painlevé III transcendents and the Joukowski correspondence](https://arxiv.org/abs/1809.07885v2)*. Journal of Integrable Systems 4(1) (2019), xyz001. Cited version: arXiv 1809.07885v2 (30 January 2019). Locators: §1.1; equation (2).

- **DIL21.** Jan Dereziński; Artur Ishkhanyan; Adam Latosiński. *[From Heun Class Equations to Painlevé Equations](https://sigma-journal.com/2021/056/)*. SIGMA 17 (2021), 056, 59 pages. Publisher version, 7 June 2021. Locators: §§5.2–5.3; Appendix B.3.

- **AHT17.** Primitivo B. Acosta-Humánez; Marius van der Put; Jaap Top. *[Isomonodromy for the Degenerate Fifth Painlevé Equation](https://sigma-journal.com/2017/029/)*. SIGMA 13 (2017), 029, 14 pages. Publisher version, 9 May 2017. Locators: Introduction; §§2–3.

- **MAL04.** Bernard Malgrange. *[Déformations isomonodromiques, forme de Liouville, fonction τ](https://www.numdam.org/articles/10.5802/aif.2052/)*. Annales de l'Institut Fourier 54(5) (2004), 1371–1392. Published text through NUMDAM; printed pp. 1371–1392. Locators: §2, printed pp. 1372–1374; Theorem 5.12.

- **BERT10.** Marco Bertola. *[The dependence on the monodromy data of the isomonodromic tau function](https://arxiv.org/abs/0902.4716v2)*. Communications in Mathematical Physics 294 (2010), 539–579. Cited version: arXiv 0902.4716v2 (20 January 2016); always used with BERT16. Locators: Assumption 3.1; §5.1, Proposition 5.1; Theorem 5.1 only with the correction BERT16.

- **BERT16.** Marco Bertola. *[Corrigendum: The dependence on the monodromy data of the isomonodromic tau function](https://arxiv.org/abs/1601.04790v2)*. Communications in Mathematical Physics 381 (2021), 1445–1461. Cited version: arXiv 1601.04790v2 (19 September 2020), published in 2021 as Correction to: The Dependence on the Monodromy Data of the Isomonodromic Tau Function. The key retains the initial 2016 preprint year. Locators: Definition 2.1; Theorems 2.1 and 2.2.

- **BERT17.** Marco Bertola. *[The Malgrange Form and Fredholm Determinants](https://arxiv.org/abs/1703.00046v4)*. SIGMA 13 (2017), 046, 12 pages. Cited version: arXiv 1703.00046v4, carrying the SIGMA publication text. Locators: §1; Theorem 2.2; Proposition 2.3; formula (3.6); Theorem 3.3; §3.1.2.

- **ILP18.** A. R. Its; O. Lisovyy; A. Prokhorov. *[Monodromy dependence and connection formulae for isomonodromic tau functions](https://arxiv.org/abs/1604.03082v4)*. Duke Mathematical Journal 167(7) (2018), 1347–1432. Cited version: arXiv 1604.03082v4 (29 October 2018). Locators: §1.4, Theorems A and B, equations (1.13), (1.16)–(1.21), (1.25)–(1.28); Lemma 3.3; Propositions 3.20 and 3.24; §3.9; §§4.3–4.5, especially (4.74)–(4.76); Remark 4.8.

- **DIK08.** P. Deift; A. Its; I. Krasovsky. *[Asymptotics of the Airy-kernel determinant](https://arxiv.org/abs/math/0609451v2)*. Communications in Mathematical Physics 278 (2008), 643–678. Cited version: arXiv math/0609451v2 (21 June 2007). Locators: Theorem 1; equations (2)–(3).

- **HXZ16.** Min Huang; Shuai-Xia Xu; Lun Zhang. *[Location of Poles for the Hastings–McLeod Solution to the Second Painlevé Equation](https://arxiv.org/abs/1410.3338v2)*. Constructive Approximation 43(3) (2016), 463–494. Cited version: arXiv 1410.3338v2 (9 July 2015). Locators: Theorem 2.1.

- **GMR23.** Ilia Gaiur; Marta Mazzocco; Vladimir Rubtsov. *[Isomonodromic Deformations: Confluence, Reduction and Quantisation](https://doi.org/10.1007/s00220-023-04650-8)*. Communications in Mathematical Physics 400 (2023), 1385–1461. Publisher version of record, 1 March 2023, under CC BY 4.0. Locators: Theorem 2, pp. 1391–1392, (12)–(15), used only with the corrected rank-raising coefficient lemma in §11.1; Definitions 3–4 and Theorem 12, §4.2, pp. 1428–1429; brackets (96)–(97); Theorem 13, §4.3, pp. 1435–1436; §5.1, p. 1441, for its explicit nonramified scope.

- **DLMF.** P. A. Clarkson, *[Painlevé Transcendents, Chapter 32 of the NIST Digital Library of Mathematical Functions](https://dlmf.nist.gov/32)*. Version 1.2.8, released 15 September 2026. [§32.2](https://dlmf.nist.gov/32.2), equations 32.2.1–32.2.6; [§32.6](https://dlmf.nist.gov/32.6); [§32.7](https://dlmf.nist.gov/32.7); [§32.9](https://dlmf.nist.gov/32.9), especially equations 32.9.6 and 32.9.12. Standard scalar displays and normalization reference.
