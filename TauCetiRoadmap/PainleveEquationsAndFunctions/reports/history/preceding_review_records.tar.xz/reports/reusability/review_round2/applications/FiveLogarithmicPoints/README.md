# FiveLogarithmicPoints

> **Worked second consumer — mathematical draft.** Each item is a proof target with an explicit construction/witness, not a declaration that all framework proofs are complete. [日本語版](README.ja.md).

This application tests actual proof reuse: its admitted input has structural degree five, its time base has dimension two and its phase fibers have dimension four. The generic construction, extension and descent proofs are the same ones used by the classical application. No Painlevé target is a prerequisite.

## 1.1 Five logarithmic points with a nonempty stable input

Take an ordered five-pointed genus-zero curve. After the unique normalization of the first three points to 0, 1, ∞, its time base is B = {(t₁,t₂) ∈ ℂ² : t₁,t₂ ∉ {0,1}, t₁ ≠ t₂}. Thus dim B = 2 is a conclusion of the marked-curve quotient; coordinates on B display that quotient. Take rank 2, structural divisor P = a₁+⋯+a₅, determinant (O,d) with its fixed identification and trivial strong time transport, and full logarithmic flags with ordered residue pairs (1/4,−1/4), (1/4,−1/4), (1/6,−1/6), (1/6,−1/6), (1/4,−1/4). Choose weights αᵢ,₁ = i/100 and αᵢ,₂ = i/100 + 2ⁱ⁻¹/1000 for i=1,…,5. All ten are distinct and 0<αᵢ,₁<αᵢ,₂<1. A rank-one stability wall would require 2deg F + Σᵢ εᵢ2ⁱ⁻¹/1000 = 0 with εᵢ=±1; the signed sum has odd numerator and absolute value ≤31/1000, so equality is impossible. Thus stable = semistable for these numerical data. These are inputs to MeromorphicConnectionModuli §§1.1–1.2; no classical degree-four condition is imposed.

Prove nonemptiness for every configuration, not by assuming a phase-space point. For generators with γ₁⋯γ₅ = 1 set D = diag(i,−i), J = [[0,1],[−1,0]], K = diag(exp(πi/3),exp(−πi/3)), and (M₁,…,M₅) = (D,J,K,K⁻¹,(DJ)⁻¹). Their product is I and all local spectra are distinct. D and J have no common invariant line, so the representation is irreducible. The regular-singular correspondence with chosen logarithms exp(−2πiλ), and local logarithmic lattice changes from the canonical extension when needed, produces a logarithmic connection with the specified residues and flags on each pointed curve. This statement concerns monodromy irreducibility, not constant-matrix residue eigenlines.

The trace residues vanish and determinant monodromy is trivial. The determinant logarithmic connection therefore extends without poles to a flat line connection on ℙ¹, isomorphic to (O,d); choose that identification. There is no invariant proper subbundle, hence stability for the chosen weights. As an additional check, any sum choosing one residue at each pole is [3(σ₁+σ₂+σ₅)+2(σ₃+σ₄)]/12 with σᵢ ∈ {−1,1}; its numerator is odd, so it is never an integer. This independently excludes a rank-one invariant subconnection by the residue/degree relation. Nonempty fibers on the whole B are proved; a global marked object on B is not assumed.

**Hypotheses**

- Ordered five distinct points on ℙ¹; specified rank, logarithmic residues, determinant identification and generic weights. The two-dimensional time quotient and nonempty stable fibers are outputs.

**API**

- `fivePointAdmittedInputLaw1` — Identify the actual marked-curve quotient with B and its fixed collision discriminant.
- `fivePointAdmittedInputLaw2` — Construct the irreducible monodromy witness, its chosen logarithmic extension and determinant identification.
- `fivePointAdmittedInputLaw3` — Verify nonempty stable fibers without requiring a trivial rank-two underlying bundle.

**Tests**

- `fivePointAdmittedInputCheck1` — The product D J K K⁻¹ (DJ)⁻¹ equals I exactly; the eigenlines of D are the coordinate axes, and J interchanges them.
- `fivePointAdmittedInputCheck2` — The residue differences are 1/2 or 1/3, hence nonresonant. The signed-sum numerator is odd, excluding every integer sum.
- `fivePointAdmittedInputCheck3` — Replacing five poles by four changes the time dimension from 2 to 1; this is not a harmless chart change.
- `fivePointAdmittedInputCheck4` — A pair of residue matrices without a common constant eigenline is not by itself a certificate of differential-module irreducibility.

**Needs:** framework:MeromorphicConnectionModuli/1.1; framework:MeromorphicConnectionModuli/1.2; roadmap:ComplexComparisonPartII §C5.6 regular-singular correspondence, with chosen-logarithm lattice comparison.

**Source scope:** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 1.2 Constructed flat symplectic dynamics in phase dimension four

Apply MeromorphicConnectionModuli §3.4 to the verified input of §1.1. Its output is the full stable phase family π: M → B, retaining all allowed degree-zero bundle types, the relative trace symplectic form ω, and the constructed holomorphic flat splitting h. Verify the fixed-determinant comparison on genus zero. The general dimension formula gives 2·2²(0−1)+2+2(2−1)·5 = 4; fixing the determinant removes 2g = 0 directions here. Smoothness and symplecticity are construction outputs, not fields in the input. Use NonlinearConnections §1.6 for the closed total form, after the moduli construction has proved actual preservation of ω. The two commuting horizontal time directions exist intrinsically; no scalar Garnier formula or Hamiltonian coordinates are used.

**Hypotheses**

- The fully verified input and nonemptiness of 1.1; no phase space, splitting or symplectic form is supplied as input.

**API**

- `fivePointConstructedDynamicsLaw1` — Verify the admission and determinant comparison for the general construction.
- `fivePointConstructedDynamicsLaw2` — Export the same nonlinear connection object, relative dimension four and closed total form.
- `fivePointConstructedDynamicsLaw3` — Identify its pullback and presentation comparisons; keep the time dimension two.

**Tests**

- `fivePointConstructedDynamicsCheck1` — The fiber dimension is −8+2+10=4, not 2; deg P=5 is never replaced by the classical budget.
- `fivePointConstructedDynamicsCheck2` — Flatness alone does not preserve e^{t₁}ω; the actual preservation theorem must be invoked.
- `fivePointConstructedDynamicsCheck3` — The global moduli family is not replaced by its trivial-bundle matrix chart.

**Needs:** target:1.1; framework:MeromorphicConnectionModuli/3.4; framework:NonlinearConnections/1.6.

**Source scope:** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 1.3 A verified proper RH comparison

Use MeromorphicConnectionModuli §§4.1–4.2, with I13 Theorem 2.2, on this logarithmic moduli problem. Verify g=0, r=2, n=5, rn−2r−2 = 4 > 0 and generic stability weights. Identify the constructed determinant-fixed moduli with the same determinant fiber of I13's family, using the rank-one determinant comparison and the actual coarse/gerbe comparison. Take the marked character family with the residue parameters retained through its fiber product with the exponent map λ ↦ exp(−2πiλ). Properness is a theorem about this actual family map, inherited through the proved Cartesian/base-change comparison. It is not a hypothesis in §1.1 or an inference from the existence of a foliation.

Use the complete Betti path transport of §4.1 and prove that the strong splitting of §1.2 maps every partial horizontal lift to that transport. Source and target comparisons use the full admitted moduli, rather than a chosen bundle chart. Only the regular-singular theorem is consumed. No general irregular properness or classical Painlevé continuation theorem is imported.

**Hypotheses**

- The actual logarithmic input and constructed connection of 1.1–1.2, with the checked I13 numerical range and the determinant/marking comparison. Properness and partial-lift compatibility are conclusions to verify via the general theorem.

**API**

- `fivePointProperRhLaw1` — Identify the precise I13 moduli and exponent-retaining Betti target after determinant fixing.
- `fivePointProperRhLaw2` — Verify properness by the proved Cartesian comparison and all-point horizontal compatibility.

**Tests**

- `fivePointProperRhCheck1` — Here 2·5−4−2=4>0; the source theorem is not applied without its genus/rank/pole inequality.
- `fivePointProperRhCheck2` — Forgetting the logarithms and retaining only their exponentials loses the properness statement.
- `fivePointProperRhCheck3` — Properness of RH does not say that π: M→B is proper.

**Needs:** target:1.1; target:1.2; framework:MeromorphicConnectionModuli/4.1; framework:MeromorphicConnectionModuli/4.2.

**Source scope:** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## 1.4 Reusing complete transport and its exact limits

Apply NonlinearConnections §1.4 to §1.3 and obtain unique horizontal lifts through every point of every fiber for every compact piecewise C¹ path in B. Apply §1.3 of that framework for holomorphic local germs, §1.5 for the fundamental-groupoid action and the global horizontal section on a pointed universal cover of B, and §1.6 for symplectic preservation. The action and section are outputs of the constructed flat connection; descent to B holds exactly for fixed initial points of its nonlinear monodromy action.

When the proper RH family has been constructed on a topological marking cover, first lift the given path γ in B to that cover after choosing its initial marking. Apply the general proper-transfer theorem to the pulled-back connection and the lifted compact path, then project the resulting horizontal lift to M. The connection-preserving pullback map and local uniqueness prove independence of the initial marking and of overlapping marking charts. Thus completeness is asserted for all paths in B, without assuming a global topological marking of the five-punctured family.

This is the second actual consumer of the same general extension and descent proofs used for the classical family. Its transitive dependency closure must contain no PainleveEquationsAndFunctions target, formal-profile enumeration, additive surface classification or scalar Painlevé formula. This condition is checked on the expanded graph, not only on direct imports.

Do not apply the scalar first-jet theorem for a two-dimensional phase fiber to this four-dimensional fiber, or assert a one-variable pole statement on the two-dimensional base. If a holomorphic time curve C→B and an admissible observer with defined pullback and non-infinity condition are separately supplied, use base change and NonlinearConnections §1.7 to obtain the corresponding meromorphic evaluation on that curve. A future Garnier coordinate dictionary is a downstream comparison and is not required by any target here.

**Hypotheses**

- The constructed flat symplectic connection and verified proper semiconjugacy of 1.2–1.3. Optional curve-observer conclusions additionally require the stated curve and admissibility data.

**API**

- `fivePointCompleteTransportLaw1` — Instantiate the same completeness and groupoid-action theorems on a two-time/four-phase family.
- `fivePointCompleteTransportLaw2` — Verify no transitive dependency on the classical application.
- `fivePointCompleteTransportLaw3` — State the optional one-dimensional observer pullback with all its additional hypotheses.

**Tests**

- `fivePointCompleteTransportCheck1` — The expanded prerequisite graph excludes every Painlevé target, including its degree-four definition.
- `fivePointCompleteTransportCheck2` — Complete transport can have nontrivial monodromy; a universal-cover section need not descend.
- `fivePointCompleteTransportCheck3` — On a time curve the phase fiber still has dimension four, whereas a scalar first-jet fiber has dimension two; the scalar first-jet isomorphism cannot simply be asserted.

**Needs:** target:1.2; target:1.3; framework:NonlinearConnections/1.3; framework:NonlinearConnections/1.4; framework:NonlinearConnections/1.5; framework:NonlinearConnections/1.6; framework:NonlinearConnections/1.7.

**Source scope:** I13 Theorems 2.1–2.2 and its regular-singular correspondence, plus I23 admitted logarithmic construction. All generic results are consumed through the named frameworks; this application verifies their hypotheses.

## Sources

- **I13:** Michi-aki Inaba, *Moduli of parabolic connections on a curve and Riemann–Hilbert correspondence*, [arXiv:math/0602004v2](https://arxiv.org/abs/math/0602004v2), Theorems 2.1–2.2; journal publication J. Algebraic Geom. 22 (2013), 407–480.
- **I23:** Michi-aki Inaba, [*Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation*](https://sigma-journal.com/2023/013/), SIGMA 19 (2023), 013.
