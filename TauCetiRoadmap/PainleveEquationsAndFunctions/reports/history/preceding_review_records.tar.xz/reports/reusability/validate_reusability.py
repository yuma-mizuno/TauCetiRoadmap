#!/usr/bin/env python3
"""Text, reference and dependency checks for this mathematical draft.

This script neither runs a Worker nor checks a theorem prover.  A successful
result certifies the listed consistency properties, not mathematical truth.
"""
from pathlib import Path
import json,re,hashlib,tomllib,sys

ROOT=Path(__file__).resolve().parents[2]
REG=ROOT/'design/reuse_registry.json'
OUT=ROOT/'reports/reusability/validation.json'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
def check(name,ok,detail=None):
 item={'name':name,'passed':bool(ok)}
 if detail is not None:item['detail']=detail
 checks.append(item)

registry=json.loads(REG.read_text());nodes={};modules={};plans={};edges={};external={}
for m in registry['modules']:
 mid=m['id'];modules[mid]=m
 paths=[ROOT/m[k] for k in ['plan','english','japanese']]
 for path in paths:check(mid+': file '+str(path.relative_to(ROOT)),path.is_file())
 p=json.loads(paths[0].read_text());plans[mid]=p
 en=paths[1].read_text();ja=paths[2].read_text()
 check(mid+': roadmap identifier',p['roadmap']==mid)
 targets=[t for l in p['layers'] for t in l['targets']]
 check(mid+': unique target IDs',len({t['id'] for t in targets})==len(targets))
 enids=re.findall(r'^#{2,3} (\d+\.\d+) ',en,re.M);jaids=re.findall(r'^#{2,3} (\d+\.\d+) ',ja,re.M)
 check(mid+': English target order',enids==[t['id'] for t in targets])
 check(mid+': Japanese target order',jaids==[t['id'] for t in targets])
 for t in targets:
  key=mid+'/'+t['id'];nodes[key]=dict(module=mid,role=m['role'],target=t);edges[key]=[];external[key]=[]
  for fld in ['statement','hypotheses','prerequisites','api','tests','readme_needs']:
   check(key+': '+fld+' exists',fld in t)
  match=re.search(r'^#{2,3} '+re.escape(t['id'])+r' [^\n]+\n.*?(?=^#{2,3} |\Z)',en,re.M|re.S)
  jmatch=re.search(r'^#{2,3} '+re.escape(t['id'])+r' [^\n]+\n.*?(?=^#{2,3} |\Z)',ja,re.M|re.S)
  es=match.group() if match else '';js=jmatch.group() if jmatch else ''
  check(key+': English title',t['title'] in es)
  check(key+': exact English statement',t['statement'] in es)
  check(key+': exact Needs',t['readme_needs'] in es)
  for typ in ['api','tests']:
   for a in t[typ]:check(key+': '+typ+' '+a['name'],a['statement'] in es)
  # Japanese clauses are authored translations, not obtained by deleting English.
  check(key+': Japanese prose',bool(re.search(r'[ぁ-んァ-ン一-龯]',js)))
  jdata=t.get('ja',t.get('translation'))
  if jdata:
   check(key+': exact Japanese statement',jdata['statement'] in js)
   for typ in ['api','tests']:
    check(key+': Japanese '+typ+' cardinality',len(jdata[typ])==len(t[typ]))
    for i,a in enumerate(jdata[typ]):check(key+': Japanese '+typ+' '+str(i+1),a in js)
  else:
   # All API/test bullet items are in corresponding section order; semantic
   # equivalence is independently reviewed, not inferred from this count.
   ec=len(re.findall(r'^- ',es,re.M));jc=len(re.findall(r'^- ',js,re.M))
   check(key+': bilingual bullet coverage',ec==jc,{'english':ec,'japanese':jc})
  if m['role']=='framework':check(key+': proposed owner is explicit',bool(t.get('proposed_owner')))

def resolve(mid,ref):
 if ref.startswith('target:'):return mid+'/'+ref[7:]
 if ref.startswith('framework:') or ref.startswith('application:'):return ref.split(':',1)[1]
 return None
for key,node in nodes.items():
 for ref in node['target']['prerequisites']:
  dest=resolve(node['module'],ref)
  if dest is None:
   external[key].append(ref)
   check(key+': no unexplained gap '+ref,not ref.startswith('gap:'))
   if ref.startswith('roadmap:'):
    name=ref[8:].split()[0]
    check(key+': no hidden in-bundle roadmap reference '+ref,name not in modules)
   continue
  check(key+': resolves '+ref,dest in nodes)
  if dest in nodes:edges[key].append(dest)

vis={};stack=[];cycles=[];memo={}
def visit(n):
 if vis.get(n)==1:
  cycles.append(stack[stack.index(n):]+[n]);return set()
 if vis.get(n)==2:return memo[n]
 vis[n]=1;stack.append(n);out=set()
 for d in edges[n]:out.add(d);out.update(visit(d))
 stack.pop();vis[n]=2;memo[n]=out;return out
for key in nodes:visit(key)
check('Combined graph is acyclic',not cycles,cycles)
for key,node in nodes.items():
 closure=memo[key]
 if node['role']=='framework':
  bad=sorted(n for n in closure if nodes[n]['role']!='framework')
  check(key+': general closure excludes applications',not bad,bad)
 if node['module']=='FiveLogarithmicPoints':
  bad=sorted(n for n in closure if n.startswith('PainleveEquationsAndFunctions/'))
  check(key+': second consumer excludes Painleve transitively',not bad,bad)
 if node['module']=='PainleveEquationsAndFunctions' and int(node['target']['id'].split('.')[0])<=8:
  bad=sorted(n for n in closure if n.startswith('PainleveEquationsAndFunctions/9.'))
  check(key+': intrinsic layers precede scalar comparisons',not bad,bad)

check('English canonical mirror',sha(ROOT/'README.md')==sha(ROOT/'design/README.md'))
check('Japanese canonical mirror',sha(ROOT/'README.ja.md')==sha(ROOT/'design/README.ja.md'))
sources=tomllib.loads((ROOT/'sources.toml').read_text())['source'];sourceids={s['id'] for s in sources}
check('Unique source keys',len(sourceids)==len(sources))
check('I13 inspected source retained','I13' in sourceids)
for mid,p in plans.items():
 for key in p.get('source_keys',[]):check(mid+': source '+key,key in sourceids)
 for s in p.get('sources',[]):check(mid+': source '+s['key'],s['key'] in sourceids)
 for l in p['layers']:
  for t in l['targets']:
   if 'locator' in t and 'source' in t['locator']:
    check(mid+'/'+t['id']+': locator source',t['locator']['source'] in sourceids)

rootplan=plans['PainleveEquationsAndFunctions']
for g in rootplan.get('expanded_named_gaps',[]):
 dest=resolve('PainleveEquationsAndFunctions',g['expanded_as'])
 check('Named gap expanded explicitly: '+g['slug'],dest in nodes)
check('Old named gaps not claimed proved',len(rootplan.get('expanded_named_gaps',[]))==2 and all('not discharged' in g['resolution'] for g in rootplan['expanded_named_gaps']))

# The original diagnostic statements remain; extraction must not silently lose
# the failure cases that motivated the stronger contracts.
before=json.loads((ROOT/'reports/reusability/history/before/design/plan.json').read_text())
now={t['id']:t for l in rootplan['layers'] for t in l['targets']}
for l in before['layers']:
 for t in l['targets']:
  check('Preserved original target '+t['id'],t['id'] in now)
  for a in t['tests']:
   check('Preserved original diagnostic '+a['name'],any(a['statement']==b['statement'] for b in now[t['id']]['tests']))

counts={}
for mid,p in plans.items():
 ts=[t for l in p['layers'] for t in l['targets']]
 counts[mid]={'targets':len(ts),'api_laws':sum(len(t['api']) for t in ts),'diagnostics':sum(len(t['tests']) for t in ts)}
graph={'schema':'mathematical-reuse-graph/v1','meaning':'edges point from a target to its prerequisites; external foundations remain named contracts, not falsely completed in-bundle targets','nodes':[{'id':k,'module':n['module'],'role':n['role'],'prerequisites':edges[k],'external_contracts':external[k]} for k,n in nodes.items()]}
(ROOT/'design/reuse_graph.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n')
result={'scope':'Text/graph/byte consistency only; no Worker, theorem-prover or mathematical proof execution','checks':len(checks),'failures':[x for x in checks if not x['passed']],'counts':counts,'total_targets':len(nodes),'internal_edges':sum(map(len,edges.values())),'sources':len(sources),'plan_hashes':{m:sha(ROOT/d['plan']) for m,d in modules.items()},'details':checks}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['checks','failures','counts','total_targets','internal_edges','sources']},ensure_ascii=False,indent=2))
sys.exit(bool(result['failures']))
