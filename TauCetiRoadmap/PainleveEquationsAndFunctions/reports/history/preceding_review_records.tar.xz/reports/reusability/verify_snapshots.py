#!/usr/bin/env python3
"""Verify immutable review inputs and final binding, without running a Worker."""
from pathlib import Path
import json,hashlib,sys
R=Path(__file__).resolve().parents[2];D=R/'reports/reusability'
checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for manifest in sorted(D.glob('review_round*/manifest.json')):
 for item in json.loads(manifest.read_text()):
  path=R/item['snapshot'] if 'snapshot' in item else manifest.parent/item['path']
  check(str(path.relative_to(R))+' frozen bytes',path.is_file() and sha(path)==item['sha256'])
final=D/'review_round3/manifest.json'
for item in json.loads(final.read_text()):
 path=R/item['path'];check(str(path.relative_to(R))+' equals final reviewed bytes',path.is_file() and sha(path)==item['sha256'])
for who in ['analysis','nonlinear','moduli']:
 f=D/'review_round3'/('closure_'+who+'_author.json');check(who+' final reviewer record exists',f.is_file())
 if f.is_file():
  p=json.loads(f.read_text());v=p.get('decision',p.get('verdict',''))
  check(who+' final assigned-scope acceptance',v=='pass' or v.startswith('accepted'))
  for k in ['additional_findings','new_findings']:
   if k in p:check(who+' has no new findings',not p[k])
res={'scope':'Immutable snapshots and final mathematical-source byte binding; not proof verification','checks':len(checks),'failures':[x for x in checks if not x['passed']],'details':checks}
(D/'snapshot_validation.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:res[k] for k in ['checks','failures']},ensure_ascii=False,indent=2));sys.exit(bool(res['failures']))
