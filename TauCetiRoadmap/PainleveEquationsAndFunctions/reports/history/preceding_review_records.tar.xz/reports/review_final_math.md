> Historical pre-strict-review record. Its approval language does not apply to the current artifact. The current findings, repairs, immutable snapshots and verdicts are recorded in strict_review_report.md and strict_review/.

# Final narrow mathematical repair check

Date: 2026-11-05. Reviewed only the requested final README §§7.2–7.3 and 9.2/9.4/9.5, including the explicit dictionaries. Inspected README SHA256: `776b0ebe3abbaf10a04609cbac760dd536db88378de29db9eb4481d82ebde042` (1073 lines). No main README was edited. This is a correction-status check, not a new full-roadmap review.

## Result

**No further mathematical correction was found in the inspected substitutions or accepted repairs.** The maps below are correct as written, on the specified ordinary-equation domains and chosen covers. Their extension over excluded phase loci remains the explicit comparison theorem promised by the roadmap.

| Presentation | Status and check |
|---|---|
| PVI | The dictionary \(\alpha=\kappa_4^2/2,\ \beta=-\kappa_1^2/2,\ \gamma=\kappa_2^2/2,\ \delta=(1-\kappa_3^2)/2\) agrees with IIS06 (1)–(2). The source time x is the standard time, and its q is the standard observer. |
| PV | \(T=t,\ Q=q/(q-1)\), with coefficients \((\theta_1^2/2,-\theta_0^2/2,1-\theta_\infty,-1/2)\), agrees with the scalar equation re-derived from VDPS09 (2)/(5), not its erroneous printed (3). |
| Degenerate PV | \(T=t^2,\ Q=q/(q-1)\) gives \((\theta_1^2/2,-\theta_0^2/2,-2,0)\). A local inverse branch is required when expressing source t in terms of T. |
| PIII(D6) | The direct dictionary \((4(\theta_\infty+1),-4\theta_0,4,-4)\) agrees with VDPS09 (14). |
| PIII(D7) | \(t=T^2,\ Q(T)=Tq(T^2)\) gives \((4(\theta_\infty+1),-8,4,0)\). |
| PIII(D8) | \(t=T^2,\ Q(T)=q(T^2)/T\) gives \((8,-8,0,0)\). |
| PIV | \(t=2T,\ Q(T)=2q(2T)\) gives \(\alpha=-\theta_\infty-1,\ \beta=-2\theta_0^2\). In detail, \(Q_T=4q_t\) and \(Q_{TT}=8q_{tt}\); VDPS09 (29)'s linear term becomes \(2(T^2+\theta_\infty+1)Q\), giving the stated sign of α. |
| PII Jimbo–Miwa | The direct dictionary \(\alpha=(\theta_\infty+1)/2\) agrees with VDPS09 (39). |
| PI | For \(c^5=2\), \(T=ct,\ Q=c^{-2}q\) changes VDPS09 (45) to \(Q_{TT}=6Q^2+T\). |
| PII Flaschka–Newell/P34 | For \(c^3=2\), \(T=-ct,\ U=cq\) gives exactly the displayed P34 equation. Choosing \(a=\pm\theta_0\), \(Q=(U_T-a)/(2U)\) gives PII with \(\alpha=a-1/2\) on \(U\ne0\); its stated inverse \(U=Q_T+Q^2+T/2\) is correct. |

For the final FN inverse, the direct identity is

\[
Q_T+Q^2=\frac{U_{TT}}{2U}-\frac{U_T^2}{4U^2}+\frac{a^2}{4U^2}
=U-T/2.
\]

Together with \(U_T=2QU+a\), this gives \(Q_{TT}=2Q^3+TQ+a-1/2\). The exceptional \(U=0,a=0\) refers to the extended Hamiltonian/phase locus; the displayed rational P34 expression itself is undefined there. The current text's instruction to keep full phase data and not divide is appropriate.

## Status of the prior repair requests

- **Missing symmetry generator:** resolved at roadmap level. §7.2 now explicitly owns the additional marked-surface reflections and their comparison/extension. It no longer claims that elementary local operations generate the full group. The PVI central-reflection test is correct, and the chosen route does not silently add an RH dependency.
- **Riccati proof ownership:** resolved. §7.3 uses the nodal-curve deformation and \(H^0(\mathbb P^1,T\mathbb P^1)\simeq\mathfrak{sl}_2\); it explicitly excludes IIS06 5.16 as a premise. The global lift and whole-curve domain qualifications are retained. K4 is correctly described as the linear-connection carrier supplier.
- **VDPS09 source errors:** resolved. §9.4 has both the two-form sign repair and the PV (3) repair, including the correct countercheck \(2\ne7/2\).
- **Time covers:** resolved. §9.2 states the square-time maps and distinguishes them from global time-coordinate isomorphisms.
- **PI sigma reconstruction:** resolved. The branch \(\sigma''\not\equiv0\) is separated from the entire extraneous family \(\sigma=at+2a^3\).
- **PI/PII charts and seeds:** unchanged and correct. The three PII seed checks, the inverse momentum, and \(q=u'/u\Rightarrow u''=-tu/2\) at \(\alpha=-1/2\) are consistent. Generated solution families now refer to §§7.1–7.2.

The revised material continues to state construction/proof targets rather than claim that all-strata global geometric comparisons have already been proved or implemented. No acceptance claim is made here about uninspected sections or Lean elaboration.
