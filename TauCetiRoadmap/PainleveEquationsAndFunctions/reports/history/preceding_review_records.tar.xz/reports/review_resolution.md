> Historical pre-strict-review record. Its approval language does not apply to the current artifact. The current findings, repairs, immutable snapshots and verdicts are recorded in strict_review_report.md and strict_review/.

# Review resolution and remaining proof targets

The delivered roadmap is a completed draft specification. Review findings below were repaired in the final README/plan. This report does not assert mathematical proof completion, Lean elaboration or official Worker acceptance.

## Review coverage

- `review_front_classification.md` and `review_front_connections.md`: independent reading of the first six layers, including the input class, deformation complex, strong extensions, RH target, continuation and surface comparison.
- `review_tail_classification.md`: independent reading of Layers 7 and 9, with direct formula/normalization checks.
- `review_tail_connections.md`: independent reading of Layers 8, 10 and 11, including determinant section/descent, scoped connection formulas and confluence.
- `review_final_math.md`: narrow recheck of the repaired symmetry/reduction scope and all final coordinate dictionaries; it makes no claim about uninspected sections.
- `review_final_contract.md`: final structural, dependency, source-key and native-name audit against the inspected Worker contract.

The agents were collaborators of the same assistant session. They were not Worker processes or external peer reviewers. Original review notes retain their reviewed-snapshot qualifications. This resolution table describes the resulting final specification.

| Finding | Final resolution |
|---|---|
| One-dimensional time assumed before it was proved | §1.3 uses the reduced versal deformation problem; §1.4 proves the dimension with automorphism/stabilizer checks. |
| Arbitrary determinant can carry extra scalar irregular times | The general input permits it; the classical subcategory uses a transported regular-singular determinant. Projective Katz slopes and optional scalar extensions are distinguished. |
| Ramified deformation complex described as two-term | §2.2 uses I23's three-term cone and records the ℂ-linear differential-operator nature. |
| Flatness plus relative flags too weak for strong extension uniqueness | §3.1 defines Ω¹(log D)⊗O(P−D), kernel-lattice preservation and its local coordinate characterization. D is the coefficient-one relative Cartier divisor. |
| Fixed determinant versus scalar rigidification confused | The μ₂ residual stabilizer is explicit; the two operations are separate. |
| Decorated reconstruction versus ordinary character quotient blurred | §4.2 retains the forgetful passage and closed spectral-invariant constraints at resonance, with exponent lifts. |
| Heu continuation used as if it implied proper RH | §4.4 separates the independent continuation route from properness. Relative compactness, stable replacement and topology comparison remain required. |
| Generic or untwisted results used at excessive scope | §4.2's ramified transport extension, §4.4's all-strata properness and §6.2's global surface comparison are explicit owned proof targets. |
| Surface Picard/base-change supplier too vague | Exact SSF, JacobianChallenge C and ComplexComparisonPartII C3.2d/f contracts and their hypotheses are specified. |
| Full local cohomology dimension tacitly substituted for a boundary line | §6.3 constructs the first boundary-layer line and does not assume equality with all supported cohomology. |
| Local modifications insufficient for the full PVI reflection group | §7.2 adds marked-pair reflections and requires their extension and relations, including the central PVI reflection. |
| Riccati loci identified universally with reducible connections | §7.3 uses invariant interior rational curves; reducibility/RH identifications are presentation-specific. Full-curve regularity is required for transport of those curves. |
| An APP-dependent theorem used for an independent Riccati proof | §7.3 uses ST04's invariant-curve construction and holomorphic vector fields on ℙ¹. IIS06 Theorem 5.16 is explicitly not that premise. |
| Arbitrary auxiliary modification declared tau-invariant by a unit | §8.2 limits unit gluing to proved Fredholm/chain/stable equivalences; general modifications carry a relative determinant factor and possible divisor change. |
| Closed curvature form used as if it constructed a line bundle | §8.1 consumes actual finite-dimensional stabilization, determinant section and cocycle construction. |
| Odd-degree bundle silently treated as an index-zero E(−1) complex | §8.2 gives χ(E(−1))=deg E and constructs a genuine auxiliary index-zero realization. |
| JMU/Schlesinger comparison overscoped | §§8.3–8.4 retain BERT16 corrections, MAL04's logarithmic scope and separate ramified/resonant adapters; normalization is along fixed-monodromy time leaves. |
| VDPS09 extended-form sign inconsistent with its Hamilton equations | §9.4 proves the corrected plus sign and the exact transformation to the roadmap's convention; `VDPS09_sign_audit.md` records the primary check. |
| VDPS09 PV equation (3) inconsistent with its system (2)/(5) | §9.4 gives the corrected exponent term and the rational-number countercheck, then §9.2's PV dictionary. |
| D7/D8/degenerate-PV comparison treated as constant time scaling | §9.2 includes the nonconstant square-time maps and their marking covers. |
| Scalar/jet inverses and sigma branches implicit | §9.1 requires an actual first-jet isomorphism; §9.2 treats the FN inverse and excluded U=0 branch; §9.4 identifies all PI linear sigma branches. |
| Generic connection formula treated as an all-parameter theorem | §10.3 lists ILP18 A/B hypotheses, auxiliary chart exclusions and absolute-calibration targets. |
| Small jump alone claimed to reconstruct prescribed connection | §10.2 reconstructs only after undoing the supplied geometric local-model parametrix. |
| Confluent coefficients taken to imply solution/tau convergence | §11.2 requires matched initial data, common tubes and uniform bounds; §11.4 separately compares lines, frames, fixed Hilbert spaces and endpoint estimates. |
| General determinant supplier cited as RandomMatrices 8.4 | Corrected to §8.3; §8.4 remains the Airy/edge floor and §8.5 owns Hastings–McLeod. |
| FormalConnectionsOpers F6.2 called a normal-form supplier | Removed from that contract; F6.2 is cyclic-vector/flag–oper theory. RD.6.52a is the direct finite-ramification normal-form supplier. |
| Tau Ceti compact-extension theorem given a nonexistent namespace | The exact plan prerequisite is `tauceti:maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo` at the root namespace. The earlier audit's namespace sentence is corrected in the delivered copy. |
| Plan structural mismatches | Primary-source locator for the 10.4 chart bridge, `roadmap` keys for future consumers, exact gap sentences and packaged evidence paths were repaired. |

## Proof obligations deliberately retained

The internal targets in `plan.json` under `owned_proof_obligations` remain proof-development goals: the ramified family-transport extension, all-strata relative proper RH, full surface comparison, boundary-line family comparison, additional reflection action, all required tau adapters, calibrated connection-formula estimates and complex/geometric confluence adapters.

These are not unresolved drafting questions or unassigned placeholders. Their objects, hypotheses, proof steps, source limitations and owner target are specified. They are also not claimed to be open problems in contemporary mathematics: the report distinguishes the inspected sources' scope from the full proposed theorem.

The two generic missing supplier contracts are `holomorphic-horizontal-lifts` and `complex-holomorphic-determinant-family`. Their exact owner sections and one-sentence requirements appear in README and plan. No permission to publish or modify those supplier roadmaps is implied by recording these draft extensions.

## Validation boundary

Static/contract checks and the reported exact-arithmetic diagnostics succeeded. Those checks do not prove completeness of RH, analytic existence, descent or any other main theorem. `Suggested.lean` intentionally has no theorem declarations because the required genuine carriers are missing at the audited pins. The official Lean runtime did not run successfully, so no elaboration success is reported.
