# Source and metadata audit

Date: 2026-11-05. This report audits the local draft's citations and provenance. It does not certify mathematical proof, Lean elaboration or acceptance by a running Worker.

## Result

- The manifest has 23 unique source entries: 22 downloaded primary PDFs and one web-only secondary reference.
- All 22 PDF SHA-256 hashes were recomputed from the actual cached bytes and agree with their original download records.
- Fetch URLs and timestamps come from those original records; a metadata page or text extraction was not substituted for the hashed PDF.
- The audited source-schema and embedded-text validators returned no problems. No Worker entrypoint was run.
- No duplicate source ID, DOI or unversioned arXiv work identifier occurs.
- Every adopted source is mapped to numbered targets in the final README/plan; the inventory includes the final literal citations and scoped chart comparisons.
- metadata.toml contains exactly topic = "math.AG".
- The older two-author Classification of Okamoto–Painlevé pairs source ST02 remains outside the adopted manifest because the final specification does not cite it. STT02 is the distinct three-author deformation paper.
- No source PDF, extracted source text or quoted source passage is included in the package.

The schema word certified means the cited text's retrieval and byte provenance are recorded. It does not mean that every roadmap target has already been proved in that text. The manifest says this both in its opening comment and in each certified entry's version note.

## Source inventory

The year column is the published year when a journal version was verified; the stable reference key may retain a preprint year. Section/theorem locators use the explicitly named downloaded text.

| Key | Year | Cited text | Status | Target sections |
|---|---:|---|---|---|
| I23 | 2023 | publisher text | certified | 1.1, 1.2, 1.3, 2.1, 2.2, 2.3, 2.4, 3.1, 3.2, 3.3, 3.4, 4.1, 4.3, 4.4, 5.1, 7.1 |
| IS12 | 2013 | 1203.0084v3 | certified | 4.3, 4.4 |
| HEU10 | 2010 | publisher text | certified | 1.2, 3.4, 4.1, 4.4 |
| VDPS09 | 2009 | 0902.1702v5 | certified | 1.3, 1.4, 2.4, 4.2, 5.4, 6.2, 9.1, 9.2, 9.4, 9.5, 10.4 |
| IIS06 | 2006 | math/0501007v2 | certified | 2.4, 4.3, 4.4, 5.1, 5.2, 5.3, 5.4, 5.5, 6.2, 7.1, 7.2, 7.3, 9.1, 9.2, 9.4 |
| BOA01 | 2001 | 2002.00052v1 | certified | 3.3, 4.1, 5.3 |
| BOA14 | 2014 | 1111.6228v3 | certified | 4.2 |
| BY15 | 2015 | 1512.08091v1 | certified | 4.1, 4.2 |
| STT02 | 2002 | math/0006026v2 | certified | 5.4, 6.1, 6.2, 6.3, 7.2 |
| TER02 | 2002 | math/0006027v1 | certified | 6.3 |
| ST04 | 2004 | math/0201225v1 | certified | 6.3, 7.3, 9.5 |
| FM19 | 2019 | 1809.07885v2 | certified | 9.3 |
| DIL21 | 2021 | publisher text | certified | 9.3 |
| AHT17 | 2017 | publisher text | certified | 9.2 |
| MAL04 | 2004 | publisher text | certified | 8.1, 8.2, 8.4 |
| BERT10 | 2010 | 0902.4716v2 | certified | 8.3, 8.4 |
| BERT16 | 2021 | 1601.04790v2 | certified | 8.3, 8.4, 11.4 |
| BERT17 | 2017 | 1703.00046v4 | certified | 8.1, 8.2, 8.3, 8.4, 9.4, 11.4 |
| ILP18 | 2018 | 1604.03082v4 | certified | 10.1, 10.2, 10.3, 10.4 |
| DIK08 | 2008 | math/0609451v2 | certified | 10.3 |
| HXZ16 | 2016 | 1410.3338v2 | certified | 10.3 |
| GMR23 | 2023 | publisher text | certified | 11.1, 11.2, 11.3, 11.4 |
| DLMF | 2026 | DLMF 1.2.8 | uncertified | 9.2, 9.3, 9.4, 9.5 |

## Bibliographic decisions

Authors and titles were checked against the downloaded first pages. Where a publication year or fuller name was absent from the selected preprint, publisher, institutional or author records supplied the bibliographic comparison.

- **IS12:** the downloaded preprint is arXiv 1203.0084v3, dated 22 November 2012; the published article is in Kyoto Journal of Mathematics 53(2) (2013), 433–482, DOI 10.1215/21562261-2081261. The stable key is retained. [Author publication list](https://www2.kobe-u.ac.jp/~mhsaito/saito-publication.html).
- **VDPS09:** the article is Annales de l'Institut Fourier 59(7) (2009), 2611–2667, DOI 10.5802/aif.2502. The cited text is v5 (12 November 2009), using its preprint pagination. Its version notice is not a guarantee that all displayed formulas are internally consistent: roadmap §9.4 records the remaining Hamiltonian-form sign and PV-coefficient inconsistencies and the independent comparison checks. [Version record](https://arxiv.org/abs/0902.1702v5).
- **BOA01:** publication is 2001; arXiv 2002.00052v1 is the author's 2020 accessibility deposit of that article. It is not a new 2020 theorem. [Author-deposited record](https://arxiv.org/abs/2002.00052v1).
- **BOA14:** the fetched unversioned URL resolved to arXiv 1111.6228v3, whose first page says 22 September 2012. Publication is Annals of Mathematics 179(1) (2014), 301–365. [Publisher record](https://annals.math.princeton.edu/2014/179-1/p05).
- **BY15:** the fetched bytes identify arXiv 1512.08091v1 (26 December 2015). The manifest makes no unverified later journal-publication claim. [Author-deposited record](https://arxiv.org/abs/1512.08091).
- **STT02, TER02 and ST04:** the selected preprints date from 2000, 2000 and 2002, while their publication years are 2002, 2002 and 2004. The source keys and downloaded version locators are retained. STT02 is not the similarly titled single-author conference note. [Saito publication list](https://www2.kobe-u.ac.jp/~mhsaito/saito-publication.html); [Terajima publisher record](https://www.jstage.jst.go.jp/article/math1924/28/1/28_1_137/_article/-char/ja).
- **FM19:** the downloaded first page says Andrea Ferrari; the publisher gives Andrea E. V. Ferrari. The second author is Lionel Mason. [Publisher record](https://academic.oup.com/integrablesystems/article/4/1/xyz001/5369217).
- **BERT10:** the original article is from 2010, but the downloaded arXiv v2 dates from 20 January 2016 and explicitly points to its correction. [Version record](https://arxiv.org/abs/0902.4716v2).
- **BERT16:** the key retains the initial preprint year 2016. The cited v2 is dated 19 September 2020 and was published as a correction in Communications in Mathematical Physics 381 (2021), 1445–1461. Its title in the selected bytes is Corrigendum; the published title begins Correction to. The sign and contour-vertex corrections are mandatory where used. [Version record](https://arxiv.org/abs/1601.04790v2); [publisher record](https://doi.org/10.1007/s00220-020-03904-z).
- **BERT17:** the actual request was unversioned; the recorded response filename identifies 1703.00046v4.pdf. The downloaded first page carries the SIGMA 2017 article header. The actual request URL, rather than an invented versioned fetch, is retained in fetched_from.
- **ILP18:** v4 (29 October 2018) is the selected 54-page text. Its version note says the introduction and subsection 3.3 were revised to match the published article. [Version record](https://arxiv.org/abs/1604.03082v4).
- **DIK08 and HXZ16:** publication years are 2008 and 2016; the selected arXiv versions date from 21 June 2007 and 9 July 2015. They supply separately stated absolute-constant and complex-sector calibration obligations in §10.3, beyond RandomMatrices' real-axis Hastings–McLeod contract. [DIK publisher record](https://link.springer.com/article/10.1007/s00220-007-0409-x); [HXZ publisher record](https://link.springer.com/article/10.1007/s00365-015-9307-1).
- **GMR23:** the exact publisher PDF is openly licensed under Creative Commons Attribution 4.0, as stated in its final pages. Its printed-page locators are 1385–1461. This observed open article is distinguished from a general assumption that every Springer article is accessible. [Publisher record](https://doi.org/10.1007/s00220-023-04650-8).

## DLMF's explicit uncertified status

Official rendered text for §§32.2, 32.6, 32.7 and 32.9 was read. The chapter page identified P. A. Clarkson as author and displayed version 1.2.8, released 15 September 2026. Direct raw-byte retrieval of §32.2 returned HTTP 403 in this environment. No raw HTML snapshot, raw-fetch timestamp or SHA-256 is invented.

The entry is therefore institutional and uncertified. This does not mean unread: its version note states that the official page text was read. It supplies the standard scalar equations, Hamiltonian/transformation conventions and elementary boundary displays. It is not the source for the intrinsic moduli construction or global continuation proof.

Official pages: [Chapter 32](https://dlmf.nist.gov/32), [§32.2](https://dlmf.nist.gov/32.2), [§32.6](https://dlmf.nist.gov/32.6), [§32.7](https://dlmf.nist.gov/32.7), [§32.9](https://dlmf.nist.gov/32.9).

## Metadata choice

The roadmap's primary organization is the intrinsic geometry of meromorphic connection moduli, their deformations, symplectic forms, horizontal distribution and surface comparison. Consequently math.AG is the closest single topic. Scalar ordinary differential equations are downstream comparisons, so the choice is not made solely from the word Painlevé.

At the inspected revisions:

- ComplexCurveModuli uses math.AG.
- FormalConnectionsOpers uses math.AG.
- ComplexKahlerGeometry uses math.CV.
- RandomMatrices uses math.PR.

Evidence: [ComplexCurveModuli metadata](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/ComplexCurveModuli/metadata.toml), [FormalConnectionsOpers metadata](https://github.com/TauCetiProject/TauCetiRoadmap/blob/1aab7da18ead3b687f442771f7786d8f236ce155/TauCetiRoadmap/FormalConnectionsOpers/metadata.toml), [ComplexKahlerGeometry metadata](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/ComplexKahlerGeometry/metadata.toml), [RandomMatrices metadata](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/RandomMatrices/metadata.toml).

## Mechanical validation and limits

The original pure validate_manifest function, its classification helpers/constants and the exact Sources defaults were loaded from the audited Worker revision 46e12afb791b1efab8fd8b3285370d689ba2e7b8 using Python AST. The unchanged manifest_text_problems function checked for embedded source passages. No Worker service, lane, command loop or remote write was invoked.

TOML parsing, source-key uniqueness, DOI/work deduplication, target mapping, all PDF magic headers and all byte hashes were checked. The mechanical result is zero source-schema findings and zero embedded-text findings. The full hashes and original download URLs/times are in sources.toml; the local machine-readable audit retains the recomputation results.

These checks do not close the roadmap's all-strata properness, compactification, ramified/resonant RHP-adapter or confluence proof obligations. The mathematical review treats those as explicit construction targets, with source hypotheses and limitations retained.

Suggested.lean was not elaborated: the independently downloaded official Lean executable failed to locate its application path in this environment. Neither this manifest audit nor static inspection of a Lean signature changes that outcome.


## Strict-review source corrections and scope refinements

The new frozen-snapshot review rechecked the seeded target sample and every source involved in a finding. These refinements supersede broader wording in the pre-review reports.

- **I23 §8, Proposition 8.2 and (8.2):** closedness needs its auxiliary finite-flat coalescing-divisor moduli family, étale universal-object cover, relative deformation complex and generic logarithmic comparison. Target 2.3 now owns that construction before using Proposition 8.3; it does not import the later confluence layer. Smoothness over an integral auxiliary base gives the density argument, after which nonreduced base changes use the proved equality.
- **BERT10/BERT16/MAL04:** the delivered JMU/Hamiltonian comparison is explicitly generic unramified and logarithmically nonresonant (with MAL04's narrower Schlesinger model). The general determinant/Fredholm identity remains on every constructed marked-RHP chart. A ramified or resonant RHP adapter does not by itself define an extra JMU differential or identify it with a Hamiltonian.
- **ILP18 (4.74)–(4.76):** DIK08 and HXZ16 alone do not provide the uniform complex-sector Hamiltonian asymptotics or the arc-vanishing estimates used in the absolute calibration. Target 10.3 owns their precise weighted sectorial bounds via the Hastings–McLeod RHP and parametrices. ILP's use of FIKN is recorded; no unexamined FIKN theorem is silently added as a supplier.
- **GMR23 Theorem 2, (12)–(15), pp.1391–1392:** the printed C=O(ε⁻ʳ), P=O(ε) imply CPʳ⁺¹=O(ε), so that formula cannot justify the claimed new highest pole coefficient. The corrected lemma in 11.1 uses C with pole order r+1 and compensation of the actual Laurent coefficients B_j. At r=1, C=W/ε², B₀=−W/ε², B₁=−t₁W/ε and P=t₁ε+t₂ε² give t₂W/z²+t₁²W/z³. This is a direct coefficient calculation, not a claim that the printed theorem was already correct.
- **GMR23 (96)–(97):** the negative Lie–Poisson sign is transported to the positive supplier by A_ours=−A_source. Section 5.1 explicitly confines its scalar realizations to the nonramified case. The roadmap's invariant collision-data groupoid and additional ramified/boundary comparisons are explicitly owned constructions.

The source byte hashes and original fetch times were preserved; the locator and version-scope fields were updated. Exact computations and round-specific verdicts are in the strict-review records.
