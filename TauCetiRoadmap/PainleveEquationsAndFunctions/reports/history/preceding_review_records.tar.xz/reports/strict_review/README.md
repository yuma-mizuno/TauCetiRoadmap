# Strict-review evidence archive

> Historical archive: this directory preserves the original three review rounds. The current mathematical-only review and canonical binding are in `../mathematical_review/` and `../mathematical_review_report.ja.md`.

This archive records a manual application of the inspected TauCetiRoadmapWorker rubrics. No Worker was run. Reviewer sessions were separate from author repairs; they did not provide the distinct-model-family condition. The current result is in `../strict_review_report.md` and `final_review.json` when finalized.

## Reading the record

- `round1/`, `round2/`, and subsequent numbered directories contain a frozen `artifact/`, its authoritative `snapshot.json`, the seeded source sample, reviewer reports, finding records and target-level calculation ledgers.
- The archived `artifact/` directories are historical versions. Their reports and any internal `SHA256SUMS` retain the state at the moment of freezing; the surrounding `snapshot.json` is the authoritative byte manifest for that review. The top-level package checksum covers the final distributed archive.
- `round1_author_resolution.json` and `round2_author_resolution.json` separate author repairs from independent later closure. Repeated findings by different reviewers are deduplicated there.
- Paths under `_strict_review/` in original reviewer records name their original working locations. The corresponding packaged locations are under this directory. Source caches, library checkouts and toolchain binaries are intentionally not included.
- A passed numerical or symbolic control tests a displayed formula, a hypothesis or a proposed API. It is not a proof of a global construction. A precise future proof obligation remains a roadmap target.

## Reproduction

From the package root:

```bash
python3 reports/validate_draft.py
python3 reports/verify_review_snapshots.py
python3 reports/strict_review/reproduce/core_compute.py
python3 reports/strict_review/reproduce/tau_compute.py
```

The main validator and the core/tau calculators require only the Python standard library. The main validator reports whether external source bytes were actually rehashed; PDFs are not distributed. The snapshot verifier checks byte integrity and the connection between the final frozen content and the delivered canonical files.

The scalar-coordinate calculator requires an installed SymPy:

```bash
python3 reports/strict_review/reproduce/geometry_calculations.py
```

The `reproduce/` copies differ from the original round-2 programs only in paths, output locations and the removal of a private dependency-bootstrap path. Exact original/adapted hashes and execution qualifications are recorded in `reproduce/portability_changes.json`. Calculators write to `reproduce/results/`; they do not overwrite reviewer records. The core/tau portable outputs were compared with the archived JSON and agreed exactly. A new portable geometry execution was not obtained in this runtime because SymPy was absent; the earlier recorded exact round-2 results and their later scoped reuse remain separately identified. The original per-round scripts are retained as provenance, including their original environment-specific paths.

## Independent gates

`Suggested.lean` uses real native-carrier definitions and two admitted headline proofs. The official pinned Lean runtime failed before elaboration, so neither successful type checking nor a formal proof is claimed. Zero actionable mathematical/design findings, if recorded by the final reviewers, does not discharge that compiler gate or the distinct-model-family gate.
