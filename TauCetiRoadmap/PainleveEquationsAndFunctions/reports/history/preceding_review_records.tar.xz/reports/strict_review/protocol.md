# Strict local review protocol

Date: 2026-11-05. Scope: the user's unpublished intrinsic Painlevé roadmap. This is a manual application of the Worker review rubrics, not a Worker run, a GitHub review or an official acceptance.

## Fixed criteria

- Worker revision: 46e12afb791b1efab8fd8b3285370d689ba2e7b8. Read the actual review, whole-document red-team, section red-team, adversarial, defect-class, supplier-gap and Lean-file instructions.
- The actual project configuration requests two red-team rounds and reviewers from different model families. This session can perform separate fresh-context reviewer passes and author repairs; no claim is made that those reviewers have different model families or satisfy the Worker identity-separation gate.
- P1: false, vacuous, or unowned mathematical premise. P2: overclaim, missing hypothesis, undefined target scope or unpinned convention. P3: locator, check or concrete policy defect. Every finding needs a reproducible witness and an exact repair.
- The immutable round-1 README SHA256 is 720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731. Reviewers do not edit the artifact. The author applies the union of established findings, records rejected suggestions with reasons, regenerates dependent artifacts, and freezes another snapshot.
- Fresh independent review covers all 44 numbered targets. The core reviewer covers Layers 1–5; the geometry reviewer Layers 6,7,9; the tau/analysis reviewer Layers 8,10,11. The root reads the full document, current supplier evidence, source manifest, dependency data and acceptance file.
- Each target receives concrete adversarial examples or structural countermodels with computed values; generic claims that something was checked do not count as evidence. Source checking includes a reproducible 15-target seeded sample, all flagged sources and changed source claims.
- Re-review checks every repaired finding, all changed passages and the same defect elsewhere. The final reviewed content must be identified by hashes. A final edit invalidates the earlier verdict for that edited passage until reviewed.
- A roadmap target is a planned construction/proof, not an already proved theorem. A label such as owned proof obligation does not excuse an unspecified or circular prerequisite. Precise named supplier gaps may be conditional contracts, as the Worker permits.

## Distinct outcomes

The record keeps mathematical/design findings, static artifact checks, Lean elaboration and reviewer-separation status separate. The Worker package rubric requires a passing elaboration and zero findings for acceptance. Static checks, a zero-declaration Lean file, and inability to start Lean do not count as a passing elaboration.

The pinned Lean executable was retried directly with its documented LEAN_SYSROOT setting. It again exited with `error: failed to locate application`. No environment restriction was bypassed, no compiled result was obtained and this gate remains unpassed.

The user has authorized only a draft. No Worker entrypoint, lane, provider job, board write, issue, pull request, push or publication is part of this review.
