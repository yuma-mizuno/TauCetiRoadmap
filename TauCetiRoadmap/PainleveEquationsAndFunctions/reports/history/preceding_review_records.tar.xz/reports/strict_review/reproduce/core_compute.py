# Portable copy: only filesystem/import-bootstrap/output paths differ from archived original.
"""Read-only mathematical review calculations; never edits the frozen artifact."""
from fractions import Fraction as Q
from itertools import product, combinations
import cmath
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]/'round2'
output_dir = Path(__file__).resolve().parent/'results'
output_dir.mkdir(exist_ok=True)
artifact = root / 'artifact'
result = {'artifact_sha256': {str(p.relative_to(artifact)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [artifact/'README.md', artifact/'design/plan.json', artifact/'Suggested.lean']}}

# Katz slopes and actual integer structural costs used by 1.3--1.4.
types = [(Q(0),1), (Q(1,2),2), (Q(1),2), (Q(3,2),3), (Q(2),3), (Q(5,2),4), (Q(3),4)]
profiles = {}
for n in range(1,5):
    ordered = [tuple(v[0] for v in vs) for vs in product(types,repeat=n) if sum(v[1] for v in vs)==4]
    unordered = sorted(set(tuple(sorted(v)) for v in ordered))
    profiles[str(n)] = {'ordered_count':len(ordered),'unlabelled_count':len(unordered),'ordered_profiles':[[str(v) for v in p] for p in ordered],'unlabelled_profiles':[[str(v) for v in p] for p in unordered]}
result['profiles'] = profiles
result['profile_totals'] = {'ordered':sum(v['ordered_count'] for v in profiles.values()),'unlabelled':sum(v['unlabelled_count'] for v in profiles.values())}
assert result['profile_totals']=={'ordered':17,'unlabelled':10}

# Positive-rank dimension controls; the rank-zero substitution is a rejected domain input.
def dim(r,g,d): return 2*r*r*(g-1)+2+r*(r-1)*d
result['dimensions'] = [{'rank':r,'genus':g,'polar_degree':d,'unfixed':dim(r,g,d),'fixed_determinant_if_det_map_surjective':dim(r,g,d)-2*g} for r,g,d in [(2,0,4),(2,0,5),(2,1,4),(1,1,4)]]
result['excluded_rank_zero'] = {'formal_formula':dim(0,0,4),'actual_zero_object_tangent':0,'admitted':False}
assert [x['unfixed'] for x in result['dimensions']]==[2,4,10,2]
assert Q(-1)+1==0
result['determinant_and_gauge']={'degree_plus_residue':0,'induced_adjoint_rank_for_rank_2':2**2-1,'gauge_trace_residue':1,'projected_diagonal':[str(Q(1,2)),str(Q(-1,2))],'ramified_trace_for_c_quarter':str(2*Q(1,4)+Q(1,2))}
result['unfolding']={'polynomial':'z^2 - 3*h^2*z + 2*h^4','discriminant':'h^4','central':'z^2','h_equals_1_roots':[1,2],'dual_number_h_equals_epsilon':'z^2 since epsilon^2=0','flat_rank':2}

# Stable reducible point for the instruction not to delete exceptional strata.
weights=[Q(1,5),Q(3,10),Q(2,5),Q(3,5)]
total=sum(weights)
subsets=[sum(weights[i] for i in c) for n in range(5) for c in combinations(range(4),n)]
assert total==Q(3,2) and Q(3,4) not in subsets and max(weights)<total/2
result['stable_reducible']={'weights':[str(v) for v in weights],'parabolic_degree':str(total),'rank_2_slope':str(total/2),'largest_constant_invariant_line_degree':str(max(weights)),'no_subset_at_wall':True}

# Exact matrix arithmetic for the symplectic sign and gauge-composition controls.
def matmul(A,B): return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def matadd(A,B): return [[a+b for a,b in zip(ra,rb)] for ra,rb in zip(A,B)]
for p in [Q(0),Q(2),Q(-3,2)]:
    omega=[[0,1,0],[-1,0,p],[0,-p,0]]
    assert matmul(omega,[[p],[0],[1]])==[[0],[0],[0]]
result['total_form']={'omega_matrix':'[[0,1,0],[-1,0,p],[0,-p,0]]','kernel_vector':'(p,0,1)','test_p':['0','2','-3/2'],'kernel_products':'zero','flat_wrong_splitting':'h=partial_t+q*partial_q','wrong_form':'dq wedge dp + q dp wedge dt','wrong_form_differential':'dq wedge dp wedge dt != 0'}
gauge=[]
for t in [Q(0),Q(1),Q(-1,2)]:
    G=[[1,t],[0,1]]; inv=[[1,-t],[0,1]]; H=[[1,0],[0,-1]]; N=[[0,1],[0,0]]
    A=matadd(matmul(matmul(inv,H),G),matmul(inv,N))
    assert A==[[1,2*t+1],[0,-1]]
    gauge.append({'t':str(t),'matrix':[[str(v) for v in row] for row in A]})
result['time_dependent_gauge']=gauge

# Nontrivial transport, rejecting the always-identity implementation.
loops=[]
for k in [0,1,2]:
    u=2j*cmath.pi*k
    q=cmath.exp(u/2); p=2*cmath.exp(-u/2)
    assert abs(q-(-1)**k)<1e-12 and abs(p-2*(-1)**k)<1e-12
    loops.append({'loops':k,'exact_endpoint':[(-1)**k,2*(-1)**k]})
result['transport']={'initial':[1,2],'endpoints':loops,'one_loop_jacobian':[[-1,0],[0,-1]],'symplectic_multiplier':1,'fixed_points':'{(0,0)}'}

# Fixed-time properness does not imply properness of the whole family.
result['deleted_cover']=[{'n':n,'z':str(1-Q(1,n)),'image_time':str((1-Q(1,n))**2)} for n in [2,4,8,16]]
result['deleted_cover_limit']={'z':1,'time':1,'z_is_in_source':False,'remaining_point_over_time_1':-1,'all_time_fibers_finite':True}
result['affine_blowup_ode']=[{'time':str(t),'q':str(1/(1-t))} for t in [Q(0),Q(1,2),Q(3,4)]]

# Native transfer regularity: a C^1 path need not yield a C^1 autonomized field.
result['piecewise_c1_time_control']={'path':'abs(s-1/2)^(3/2)','derivative':'(3/2)*sign(s-1/2)*sqrt(abs(s-1/2))','right_difference_quotients_at_half':[{'h':h,'quotient':1.5/(h**0.5)} for h in [1e-2,1e-4,1e-6]],'consequence':'gamma derivative is continuous but not differentiable at 1/2'}

# A nonlinear no-exit signature witness, not merely an estimate for supplied solutions.
result['no_exit_witness']={'field':'F_epsilon(t,y)=y^2+epsilon','reference':'u0(t)=1/(1-t)','interval':['0','1/2'],'initial':1,'tube_radius':1,'tube_y_bounds':[0,3],'phase_lipschitz_bound':6,'field_error':'abs(epsilon)','gronwall_bound':'(1/2)*abs(epsilon)*exp(3)','sufficient_epsilon_bound':'abs(epsilon)<exp(-3)','then_error':'<1/2','missing_conclusion_to_state':'existence of nearby full-interval solutions, no exit, and uniform convergence'}
result['observer_controls']={'directions':{'[1:2]':'1/2','[0:1]':'0'},'rational_origin_value':'undefined','pole_order_of_1_over_t_cubed':3,'constant_infinity_reciprocal':'identically zero, excluded','essential_exp_one_over_t_limits':['infinity on positive real approach','0 on negative real approach']}
result['reused_unchanged_control_note']='Other exact symbolic controls in core_ledger.json are independently rechecked unchanged Round-1 calculations, explicitly marked per target; they are not alleged proof of the general roadmap theorem.'
(output_dir/'core_computations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'profile_totals':result['profile_totals'],'dimension_controls':len(result['dimensions']),'transport':result['transport'],'native_time_counterexample':result['piecewise_c1_time_control'],'artifact_hashes':result['artifact_sha256']},ensure_ascii=False,indent=2))
