# Portable copy: only filesystem/import-bootstrap/output paths differ from archived original.
"""Read-only exact/numerical cross-checks for strict review round 2.
Writes only the associated computed supplement, never the immutable artifact.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib, json, math
ART=Path(__file__).resolve().parents[1]/'round2/artifact'
OUT=Path(__file__).resolve().parent/'results'
OUT.mkdir(exist_ok=True)
assert hashlib.sha256((ART/'README.md').read_bytes()).hexdigest()=='bded7b400716d663957a13a462349b688a525cda5889b8f3bac55b8bc8f31316'
assert hashlib.sha256((ART/'design/plan.json').read_bytes()).hexdigest()=='b68bbe5fa893c3f777ce681d8297c125141e4d7bc4cb3d0acd49bcbf79827738'
results={}
# Sparse Laurent polynomials over Q, independent of numerical cancellation.
def padd(a,b):
 d=dict(a)
 for k,v in b.items():d[k]=d.get(k,Q(0))+v
 return {k:v for k,v in d.items() if v}
def pmul(a,b):
 d={}
 for i,x in a.items():
  for j,y in b.items():d[i+j]=d.get(i+j,Q(0))+x*y
 return {k:v for k,v in d.items() if v}
def ppow(a,n):
 d={0:Q(1)}
 for _ in range(n):d=pmul(d,a)
 return d
def peval(a,e):return sum((v*e**k for k,v in a.items()),Q(0))
laurent=[]
for r in range(6):
 P={i:Q(i+1) for i in range(1,r+2)} # t1=2
 C={k:Q(k+r+4) for k in range(-r-1,2)} # leading W=3
 coeffs=[]; Bs=[]
 for j in range(r+1):
  CP=pmul(C,ppow(P,j))
  B=padd({k:-v for k,v in CP.items() if k<0},{0:Q(5+j),1:Q(1)})
  # Negative terms cancel algebraically, not only numerically.
  combined=padd(B,CP)
  assert all(k>=0 for k in combined)
  coeffs.append(combined.get(0,Q(0)));Bs.append(B)
 top=pmul(C,ppow(P,r+1))
 assert min(top)==0 and top[0]==3*2**(r+1)
 coeffs.append(top[0])
 z=Q(2); lim=sum((v/z**(j+1) for j,v in enumerate(coeffs)),Q(0))
 vals=[]
 for N in [100,1000,10000]:
  e=Q(1,N);p=peval(P,e);c=peval(C,e)
  a=sum((peval(B,e)/z**(j+1) for j,B in enumerate(Bs)),Q(0))+c/(z-p)
  finite=sum((c*p**j/z**(j+1) for j in range(r+2)),Q(0))
  remainder=c*p**(r+2)/(z**(r+2)*(z-p))
  assert c/(z-p)==finite+remainder
  vals.append({'epsilon':str(e),'value':str(a),'limit':str(lim),'error_over_epsilon':float((a-lim)/e)})
 laurent.append({'r':r,'limit_coefficients':list(map(str,coeffs)),'highest':str(top[0]),'tests':vals})
results['corrected_laurent_r0_through_r5']=laurent
# Printed versus repaired r=1, plus nontrivial second time.
e=Q(1,4);z=Q(2)
new=-1/(e*e*z)-1/(e*z*z)+1/(e*e*(z-e))
assert new==1/(z*z*(z-e))==Q(1,7)
old=-1/(e*z)+1/(z*z)+1/(e*(z-e))
assert old==1/(z*z)+1/(z*(z-e))
results['r1_exact']={'repaired_at_epsilon_1_4_z_2':str(new),'printed_at_epsilon_1_4_z_2':str(old),'repaired_limit':'W/z^3','printed_limit':'2W/z^2','t1_2_t2_3_limit_at_z2':'5/4'}
# Exact Gaussian-rational arithmetic for the ILP eta-periodicity test.
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def inv(a):
 d=a[0]*a[0]+a[1]*a[1];return (a[0]/d,-a[1]/d)
def div(a,b):return mul(a,inv(b))
one=(Q(1),Q(0));ii=(Q(0),Q(1))
s1=(Q(1,5),Q(0));s3=(Q(0),Q(1,3))
s2=div(add(s1,s3),sub(one,mul(s1,s3)))
assert s2==(Q(20,113),Q(39,113))
assert add(sub(s1,s2),add(s3,mul(mul(s1,s2),s3)))==(Q(0),Q(0))
u=inv(sub(one,mul(s1,s3)));v=neg(mul(ii,s2));w=(Q(3),Q(0))
assert sub(w,v)==mul(u,sub(w,inv(w)))
ratio=div(mul(sub(w,v),sub(w,v)),mul(mul(u,u),mul(sub(w,inv(w)),sub(w,inv(w)))))
assert ratio==one
results['eta_shift_ratio']={'s2':list(map(str,s2)),'u':list(map(str,u)),'v':list(map(str,v)),'ratio':list(map(str,ratio))}
# Finite-dimensional determinants, frame cocycles, PII normalization, and trace norm.
assert Q(2,3)*Q(3,5)==Q(2,5)
q=Q(1);qp=Q(2);t=Q(0);p=qp+q*q+t/2
H=p*p/2-(q*q+t/2)*p-q/2
Htau=qp*qp-q**4-t*q*q
assert (p,H,Htau)==(Q(3),Q(1),Q(3)) and Htau==2*H+q+t*t/4
assert Q(1)/(Q(1,20)-Q(1,10))-Q(1)/Q(1,20)==-40
results['reused_exact_controls']={'stabilization_cocycle':'(2/3)(3/5)=2/5','PII_p_H_Htau':list(map(str,(p,H,Htau))),'log_derivative_difference_epsilon_0_1_z_0_05':-40,'moved_interval_Jacobian_det':'1-(1/4)*2=1/2; omission gives 3/4','ghost_L2_norm_squared':math.exp(-2)/2,'resolvent_rho_half':2,'resolvent_rho_0_9':10,'Takiff_sign_source_and_target':[-1,-1]}
# Uniform arc estimate: theta on either arc shifted by pi/3 gives sin(3u/2).
# sin(3u/2)>=3u/pi for u in [0,pi/3], hence integral exp(-a R^(3/2)cos)<=pi/(3a R^(3/2)).
arc=[]
for R in [10,100,1000]:
 a=4/3;c=2*math.sqrt(2)/3
 angular1=math.pi/(3*a*R**1.5)
 angular2=math.pi/(3*c*R**1.5)
 first_bound=angular1+(math.pi/3)*R**(-1.5)
 second_bound=R**.75*angular2+math.pi/(6*c*R**1.5)+(math.pi/3)*R**(-.75)
 arc.append({'R':R,'first_bound_C1':first_bound,'first_bound_times_R_3_2':first_bound*R**1.5,'second_bound_C1':second_bound,'second_bound_times_R_3_4':second_bound*R**.75})
assert Q(1,8)*(Q(1)-Q(2,3))==Q(1,24)
results['HM_arcs']={'inequality':'sin(3u/2)>=3u/pi, 0<=u<=pi/3','rates':['R^-3/2','R^-3/4'],'phase_log_arc_in_units_i_pi':'1/24','bounds':arc}
# Scalar determinant obstruction in the broad collision carrier.
B=(Q(1),Q(2));trB=sum(B);mean=trB/2
assert trB==3 and (B[0]-mean,B[1]-mean)==(-Q(1,2),Q(1,2))
results['classical_scope_countermodel']={'B':['1','2'],'trace_double_pole':'3T/z^2','trace_free_B':['-1/2','1/2'],'projective_slope':1,'ad_action_of_scalar':'[cI,X]=0; trace-free complexes and stability do not detect determinant irregularity'}
# Independence of compact-path, initial-value and endpoint claims.
results['ODE_and_tau_controls']={'xprime_epsilon_length2_epsilon_1_8':str(2*Q(1,8)),'xprime_x_initial_epsilon':'error=epsilon*exp(length), sharp when delta=0','nonconvergent_initial':'x_n(t)=(-1)^n for zero fields','noncommuting_limits':'epsilon/(epsilon+delta): epsilon-first=0, delta-first=1','tau_basepoint':'exp(1/epsilon) -> normalized tau=1','tau_compact_not_endpoint':'exp(epsilon*t^2) ->1 on each fixed compact but diverges as t->+infinity for every epsilon>0'}
(OUT/'tau_computations.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print('All exact assertions passed; wrote tau_computations.json. Checked general Laurent identity plus r=0..5, eta periodicity, PII normalization, arc exponents, trace obstruction and unchanged controls.')
