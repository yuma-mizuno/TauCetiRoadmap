# Roadmap: intrinsic Painlevé equations and functions

**Summary.** Construct Painlevé dynamics from moduli of meromorphic connections, and construct Painlevé functions from the horizontal sections of that dynamics. The input consists of a curve, a structural polar divisor, a determinant connection, local formal moduli conditions, and stability and marking data. The phase space, its symplectic form, and its horizontal distribution are constructed from this input. A common continuation theorem precedes every classical scalar equation. The ten rank-two connection presentations, their eight additive surface types, and the six classical differential equations are comparison results. The theory includes resonant parameters, allowed reducible connections, ramified irregular singularities, special invariant loci, tau sections, normalized analytic solutions, and confluence. Elementary coefficient degenerations are covered by a separate boundary comparison.

## Scope and ownership

This roadmap owns the moduli problem for decorated meromorphic connections needed by Painlevé dynamics; its deformation-complex specialization, symplectic form and isomonodromic splitting; the analytic Stokes and global Riemann–Hilbert constructions required for these moduli; complete geometric continuation; observable evaluation; comparison with additive Okamoto–Painlevé surfaces; geometric transformations and invariant Riccati loci; the isomonodromic specialization of the determinant line and tau section; and the coordinate, boundary and confluence comparisons. The Stokes and compact-containment arguments are stated at the generality used here. The generic complex determinant-family construction is consumed from the specified HeegaardFloer extension, then specialized to the connection problem.

The generic formal connection and formal gauge language is supplied by FormalConnectionsOpers F2–F3. Finite-ramification normal forms are consumed directly from PadicDifferentialEquationsAndRigidCohomology §RD.6.52a. The word “formal” in those contracts does not supply an analytic Stokes classification or a global isomonodromic deformation. SchemeAndStackFoundations supplies stacks, deformation foundations and Quot/Hilbert constructions. AlgebraicModuliForArithmeticGeometry supplies rigidification and general representability criteria. ComplexComparisonPartII supplies complex analytic spaces, coherent analytification and its stated regular-singular comparisons. SmoothBundlesConnections supplies general smooth connections and transport; DifferentialGeometry supplies local and maximal flows. Their mathematical objects are used through adapters, not recreated under Painlevé-specific names.

RandomMatrices §8.5 owns Hastings–McLeod existence and uniqueness, real pole-freeness, and its Fredholm/Tracy–Widom identities. Section 10.4 here owns only the bridge from that scalar solution to an intrinsic horizontal section. RandomMatrices is a supplier of that bridge; it is not made to depend on this roadmap. The trace-class determinant required by the tau branch is consumed from RandomMatrices §8.3 at its stated operator generality. New applications using both theories are downstream consumers of both.

Difference and q-difference Painlevé dynamics, a general Sakai classification of discrete systems, cluster realizations, arbitrary-rank wild nonabelian Hodge theory, a classification of every algebraic special solution, and numerical connection constants for every asymptotic regime have different scope. They are not prerequisites of the differential theory specified here. Rational and classical-function solutions included here are the explicit families obtained from the geometric reductions and transformations of Layers 7 and 9; no completeness classification of all such solutions is asserted.

## Conventions

Work over ℂ. Curves are smooth connected projective curves, with a finite nonempty ordered set of pairwise distinct marked points. The classical subcategory has genus zero and rank two. Write P = Σ mᵢaᵢ for the structural polar divisor; it bounds the poles and records the local moduli problem. It is not the divisor of nonzero poles of each individual connection. Apparent singularities and scalar residues at a marked point are allowed when the local conditions allow them.

An object is a vector bundle E on the whole curve, a meromorphic connection ∇: E → E ⊗ Ω¹(P), an isomorphism of its determinant connection with the specified line connection, and the local structures below. All relevant bundle splitting types are retained. The general input permits a meromorphic determinant; the classical complexity subcategory uses a regular-singular determinant with fixed residues and its compatible moving-curve transport. This still allows odd determinant degree. At a logarithmic point prescribe residue eigenvalues and a compatible filtration; do not freeze one complete formal isomorphism class at resonant parameters. At an unramified irregular point use a generic distinct-leading-term formal condition. At a ramified point use the generic factorized ramified condition, with ramified descent. Leading coefficients required to be nonzero remain nonzero within a fixed irregular stratum. Their vanishing belongs to Layer 11.

Weights are denoted w, avoiding confusion with the classical scalar coefficient α. Use generic stability weights for which semistability equals stability on the specified numerical data. Stability concerns ∇-invariant subbundles. Changing a weight chamber is a wall-crossing problem, not an auxiliary-choice invariance. Isomorphisms preserve the determinant identification, labels and prescribed local structures. Retain these arrows before rigidification or passage to a coarse moduli space. For a stable rank-two object with determinant identification fixed, the residual scalar group is μ₂, not the full multiplicative group; fixing the determinant and rigidifying this remaining group are different operations.

Write Θ for fixed external residue/exponent parameters and Bθ for an admitted marked time base with θ ∈ Θ fixed. Write πθ: Mθ → Bθ for the phase family. The distinction between fixed parameters and time directions is part of the deformation problem. For the convention ∇ = d + A, a logarithmic residue λ has monodromy eigenvalue exp(−2πiλ); sources using d − A or exponent θ = −λ have exp(2πiθ). Retain the actual logarithm parameters in the fiber product defining the comparison target: forgetting them is not a proper map.

The horizontal splitting is h: π*TB → TM with dπ ∘ h = id. Its image is the invariant dynamics. A vector field representing it requires a chosen time vector. A local solution is a holomorphic section s of π satisfying ds(v) = h(v), with a specified initial point. Paths are compact piecewise C¹ paths in the fixed admitted base. The base is never punctured further according to the poles of a selected solution.

Use ω = dq ∧ dp and ι_Xω = d_phase H in a Hamiltonian chart. Thus q′ = H_p and p′ = −H_q. The extended form is Ω = dq ∧ dp + dH ∧ dt, whose kernel contains ∂t + X. Under τ = f(t) the normalized horizontal generator scales by dt/dτ. A scalar Hamiltonian is local and can change by a time-only function or by the generator of a time-dependent symplectic coordinate change.

“Painlevé function” first means a geometric horizontal section or its germ. A scalar function is the evaluation of a specified admissible observable, with a time coordinate and normalization. An everywhere defined map to ℙ¹ may give the constant value ∞; the usual meromorphic-function conclusion excludes that case. Universal-cover continuation and single-valued descent to B are different conclusions.

## Exact supplier contracts

### From Mathlib and Tau Ceti

Use native `ChartedSpace`, `ModelWithCorners`, `TangentSpace`, `Bundle.TotalSpace`, `FiberBundle`, `VectorBundle`, `MDifferentiable`, `ContMDiff`, and `CovariantDerivative` rather than a second manifold, tangent or smooth-connection carrier. Use native schemes, sheaves, complexes, category/groupoid vocabulary and proper-map topology. These are carrier-level suppliers, not an assertion that connection moduli are already constructed.

Tau Ceti's `Geometry/Manifold/IntegralCurve/Basic.lean`, `Extension.lean`, `Maximal.lean` and `Flow.lean` provide the integral-curve/maximal-extension floor. Its `Geometry/Manifold/Distribution.lean` and `Analysis/ODE/Frobenius.lean` provide the relevant smooth integrability floor. Its `Analysis/Complex/RiemannSurface/Meromorphic.lean` provides meromorphic vocabulary on native complex curves. Use the exact statements and finite-dimensional/Hausdorff hypotheses recorded in the package's declaration audit; a smooth flow is not silently a holomorphic parameter-dependent flow.

### From TauCetiRoadmap.SchemeAndStackFoundations

Consume §1.18 for stacks and 2-fiber products, §1.23 for the stated moduli interfaces, §§4.2–4.6 for infinitesimal deformation and obstruction foundations, and §4.14 for the Noetherian projective Quot/Hilbert and Hom/Isom constructions. Use §§2.2, 2.6 and 2.7 for Čech/coherent cohomology and cohomology with supports, §2.20 for relative duality and the coherent Serre pairing, and §3.3 for vector-bundle degrees and curve Riemann–Roch. For Layer 6 use §3.4's divisor/Picard groups, §4.11's modifications and strict transforms, §4.17's normal-crossing divisors, and §§5.9–5.10's surface intersection pairing, adjunction and numerical lattice theory. The logarithmic deformation and boundary-Picard calculations specific to these pairs are constructed in §6.1. Layer 2 supplies the particular connection functor, its equations, boundedness and deformation complex. A generic representability criterion does not itself construct this moduli space.

### From TauCetiRoadmap.AlgebraicModuliForArithmeticGeometry

Consume §5.1 for rigidification and §7.1 for the stated Artin representability criteria; use §8's framed deformation/versality machinery only after checking its hypotheses on the connection deformation complex. The scalar gerbe and the descent of the tensors in Layer 2 are application theorems here.

### From TauCetiRoadmap.FormalConnectionsOpers

Consume F2.1–F2.4 for algebraic sheaf connections and the stated analytic horizontal-trivialization comparison in its regular setting, and F3 for formal gauge groupoids. F6.2 concerns cyclic vectors and the flag/oper equivalence, and is not the finite-ramification normal-form supplier. F8's formal oper isomonodromy groupoid does not provide the analytic time connection of Layer 3.

### From TauCetiRoadmap.PadicDifferentialEquationsAndRigidCohomology

Consume §RD.6.52a only in its characteristic-zero Laurent-series formal-normal-form and descent scope. Layer 1 specializes it to complex rank-two local moduli conditions. No p-adic analytic theorem is used as a complex sectorial theorem.

### From TauCetiRoadmap.ComplexComparisonPartII and ComplexCurveModuli

Consume ComplexComparisonPartII C−1.1 for the generic complex analytic-space carrier, coherent analytic quotients, gluing, fiber products and scheme analytification; C0 for the corresponding coherent-module language. Use C5.6 only for its regular-singular Riemann–Hilbert scope. ComplexCurveModuli D2.0 supplies the native-manifold/analytic-space adapter and D0 the stated genus-zero family comparisons. Neither supplies a ramified Stokes theorem. The meromorphic connection, irregular descent and moduli-specific analytic comparisons are constructed here. For the boundary Picard carrier in §6.1, use ComplexComparisonPartII C3.2d.2 and C3.2f.1–2 after proving their proper-flat and universal-functions hypotheses; smooth geometrically integral curve representability does not cover a nonreduced Y.

### From TauCetiRoadmap.JacobianChallenge

Consume Layer C's proper coherent direct-image, cohomology-and-base-change and constant-rank comparison at their actual hypotheses, including the Grauert-style locally free base-change conclusion. In §6.3 verify these hypotheses for the boundary-line family. Do not replace arbitrary base change by the flat-base-change statement alone.

### From TauCetiRoadmap.AnalyticNumberTheoryPartII

Consume §§4.3 and 4.3a for the canonical Barnes G function, its Weierstrass-product normalization G(1) = 1, gamma recurrence with its pole/zero domains, zero multiplicities and sectorial logarithmic asymptotics with remainder. These are used only in §10.3's explicit connection constants. This proposed supplier is not an assertion that a Barnes G carrier is already present in Mathlib.

### From TauCetiRoadmap.SmoothBundlesConnections and DifferentialGeometry

Consume SmoothBundlesConnections B1.5 for Ehresmann splittings and its proper-submersion theorem, B5 for the transport/flat-bundle/fundamental-group interfaces, and DifferentialGeometry Layer 3, including §3.5, for local, maximal and time-dependent smooth flows. The projection Mθ → Bθ is not assumed proper; the proper map used in Layer 5 is the Riemann–Hilbert comparison.

What SmoothBundlesConnectionsPartII must provide (gap:holomorphic-horizontal-lifts): an integrable holomorphic Ehresmann splitting of a submersion between finite-dimensional complex manifolds has unique local holomorphic horizontal sections through every point, jointly holomorphic in initial data and auxiliary holomorphic parameters.

This is a specified complex extension of the smooth transport supplier, placed before the solution layer; it is not asserted to be a theorem already written in B1.5. Its proof uses complex local ODE existence and parameter dependence, with the multivariable compatibility supplied by integrability.

### From TauCetiRoadmap.RandomMatrices

Consume §8.3's trace-class Fredholm determinant construction and identities for the determinant branch after establishing that the operators here satisfy that contract. Consume §8.5's scalar Hastings–McLeod existence/uniqueness and real pole-freeness only in §10.4. The determinant line of a family of general index-zero Fredholm operators, its descent, and its relation to Riemann–Hilbert solvability are separate constructions in Layer 8.

### From TauCetiRoadmap.HeegaardFloer and OperatorTheory

Consume HeegaardFloer §2.2/F0.0 for its real Fredholm determinant-line stabilization, exact-sequence comparison and pullback laws; its real bundle is not a holomorphic complex line. Consume OperatorTheory/ToeplitzOperators T3 for the complex matrix-symbol Fredholm/index theorem, and OperatorTheory/OperatorIdeals OI-B23/OI-B30 for the relevant operator-ideal and trace-class carrier. The operators attached to connection data, their index-zero normalization, their canonical section and their marking comparisons are application constructions in Layer 8.

What HeegaardFloerPartII must provide (gap:complex-holomorphic-determinant-family): a holomorphic family of complex index-zero Fredholm operators has a holomorphic determinant line and canonical section constructed through finite-dimensional stabilizations, with comparison isomorphisms satisfying refinement, cocycle and holomorphic base-change laws.

This proposed complex extension of F0.0 is required before §8.1; a real determinant line or an arbitrary closed two-form does not discharge it.

### From TauCetiRoadmap.ComplexKahlerGeometry and AlgebraicVectorBundles

Consume ComplexKahlerGeometry K1's complex inverse/implicit-function comparison, K3.0's holomorphic calculus, K4's holomorphic connection, gauge, tensor, pullback and curvature interfaces, and K7.1's projective-space charts. Use AlgebraicVectorBundles L0A–L0C/L1A–L1B for locally free sheaves, duals, determinants and geometric bundle carriers. The meromorphic/formal adapters and relative complex symplectic constructions in Layers 1–3 extend those carriers with the specified poles; none is inferred from a merely real symplectic statement.

### From TauCetiRoadmap.FormalLaurentPuiseux

Consume L1–L7 for scalar Laurent/Puiseux fields, substitution, derivations, residues and finite ramification/descent. Formal connection normal forms still come from the separate connection suppliers. Scalar formal series alone supply neither sectorial summation nor analytic Stokes data.

### From TauCetiRoadmap.LieGroupoidsPoisson and SymplecticGeometry

Consume LieGroupoidsPoisson G4.6A's positive smooth real Lie–Poisson bracket, with {ℓξ,ℓη} = ℓ[ξ,η], and SymplecticGeometry/HamiltonianReduction R2–R3's smooth real coadjoint/KKS and regular free/proper reduction constructions only for the underlying smooth comparison. Section 11.1 constructs the complex algebraic/holomorphic Takiff bracket, residue pairing, orbit/reduction comparison and their family behavior. A real reduction theorem is not silently promoted to that complex statement.

### From TauCetiRoadmap.UniversalCovers

Consume the completed roadmap's covering-space carrier and lifting/fundamental-group interface. The horizontal-section descent criterion is the application in §5.3. Native covering-space existence does not supply completeness of a nonlinear connection.

## How to read the build

Layers 1–3 construct the input, moduli and intrinsic dynamics. Layer 4 constructs the analytic comparison, including its essential all-strata properness theorem. Layer 5 proves continuation once, using that comparison, and then treats observables. Layers 6–8 develop the surface comparison, geometric operations, invariant loci and tau sections. Layer 9 derives all classical displays from a common first-jet comparison. Layer 10 selects normalized analytic solutions and connects the existing Hastings–McLeod theory. Layer 11 treats geometric and analytic confluence. No statement in Layers 1–5 depends on deriving a classical scalar equation in Layer 9.

## Layer 1: geometric input and the classical complexity condition

### 1.1 Decorated connection data and its groupoid

Define the input groupoid of pointed curves with a structural polar divisor, rank, prescribed determinant connection, local formal moduli conditions and generic stability weights. Local conditions are logarithmic filtrations with prescribed graded residues, generic unramified irregular structures, or generic factorized ramified structures. Define an object over a base by a locally free sheaf and relative meromorphic connection with these structures, and define arrows by actual compatible bundle isomorphisms. Permit arbitrary base changes through Cartesian pullback with its coherence isomorphisms. The ramified local model is expressed on a cover with descent data; a coordinate and root used to display it are presentation data. (I23, §2, Definitions 2.1–2.8; §§3–4.)

**API.**

- Construct restrictions, pullbacks, composition and inverse of arrows, with the associator and identity laws.
- Identify the underlying formal differential module and its trace-free part without choosing a square root of the determinant line.
- Compare equivalent local presentations by ramified descent, keeping parabolic flags and logarithmic lattices.
- Express determinant compatibility by an isomorphism of line connections; derive the residue/degree equation in a chosen local convention.

**Checks.**

- On E = O ⊕ O(−1), the determinant has odd degree; a putative global half-determinant twist does not exist. The carrier must still allow this bundle when the prescribed determinant matches it.
- Two logarithmic residues with the same repeated eigenvalue, one scalar and one nonzero Jordan block, are not identified by specifying the eigenvalues. Their allowed parabolic objects and monodromy differ.
- Changing the root w to −w in a rank-two ramified chart changes the displayed branches but gives an equivalent descended object; forgetting the descent arrow fails this check.
- With I23's ramified convention, a rank-two ramified point contributes 2c + 1/2 to the residue/degree relation. Replacing it by 2c changes that relation by 1/2.

*Needs:* FormalConnectionsOpers F2–F3; PadicDifferentialEquationsAndRigidCohomology §RD.6.52a; SchemeAndStackFoundations §1.18.

### 1.2 Time deformation and external parameters

Construct the deformation groupoid of the curve, marked poles and allowed irregular polar coefficients while fixing the determinant convention, exponent parameters and the local topological marking. Quotient coordinate changes as arrows, then construct local smooth slices or marking covers. Define Bθ as the admitted time space on such a cover. Prove that isomorphisms of presentations induce equivalent time families, with compatible changes of the tangent directions. Strong isomonodromy preserves the transported analytic/Stokes data, including the resonant and lattice decorations, under the admitted variation of irregular type; it does not freeze the fixed-coordinate irregular polar part. Fixed exponent parameters alone do not define the phase trajectory. For the classical regular-singular determinant, construct its compatible flat time lift and prove coherence under moving-curve coordinate changes. (HEU10, Theorem 1.1, Definitions 2.3 and 2.10; I23, §5 and §11.)

**API.**

- Separate tangent directions along Bθ from variation in θ, and compare the pullback tangent sequence.
- Construct marking changes and local time reparametrizations with their coherence laws.
- Identify the collision and vanishing-leading-term discriminant from the input, independently of initial conditions.
- Compare the curve-jet description of HEU10 with the formal-coefficient description used by I23.

**Checks.**

- Four ordered logarithmic points have one modulus after quotient by PGL₂: 4 − 3 = 1; its cross-ratio avoids 0, 1 and ∞.
- A change τ = 2t multiplies the displayed horizontal generator by 1/2; retaining its coefficient unchanged gives a different parametrized system.
- Two solutions with different movable pole sets use the same Bθ. A base that deletes one solution's poles fails this requirement.

*Needs:* §1.1; ComplexCurveModuli D0 and D2.0; ComplexComparisonPartII C−1.1.

### 1.3 The rank-two degree-four subcategory

Define the classical differential Painlevé input class by genus zero, rank two, a structural polar divisor of degree four, the local moduli conditions of §1.1, a regular-singular determinant connection with fixed residues and its compatible transport, the reduced versal formal-data deformation from §1.2, and nonempty stable fibers. On genus zero the determinant residues obey their sum = −degree convention for ∇ = d + A. The time deformation is the actual reduced deformation problem, not an arbitrarily chosen constant or nonversal curve in a larger base. Nonemptiness is a domain condition on the moduli problem; neither one-dimensional time nor continuation is a field of this definition. Prove the reduced-time dimension in §1.4, independently of the phase dimension. Keep the connection data themselves as objects; do not define this class as a six-element type. (VDPS09, §2.2 and Table 1; I23, Theorem 7.5.)

In the pole-budget comparison, r is the projective Katz invariant, computed from trace-free exponential differences. It is not the maximal slope of an arbitrary scalar twist of the connection. The classical determinant normalization avoids extra scalar irregular times. Adding an arbitrary scalar irregular part belongs to a separate rank-one extension with a specified strong time lift; it is not silently included in the one-dimensional deformation count. None of these local/formal comparisons requires a global square root of the determinant line.

**API.**

- Restrict the general connection functor to this full subcategory of input data and retain its arrows.
- Extract rank, genus and structural degree invariantly; prove their preservation under the stated equivalences.
- Compare the formal pole budget with Katz invariants: m = r + 1 for integral r, and m = r + 3/2 for a positive half-integral r in rank two.
- State nonemptiness and excluded discriminants explicitly on each parameter base, including exceptional logarithmic exponents.

**Checks.**

- Four logarithmic points have budget 1 + 1 + 1 + 1 = 4 and belong to this complexity class.
- Five logarithmic points have phase dimension 2·5 − 6 = 4, and three have phase dimension 2·3 − 6 = 0; neither is a two-dimensional Painlevé input.
- Two ramified points of Katz slope 1/2 have budget 2 + 2 = 4. Requiring integral slopes would lose this input.
- A logarithmic residue can vanish at a phase point without changing the structural degree. Recomputing the budget from its actual nonzero poles would wrongly remove that point.

*Needs:* §§1.1–1.2; the moduli dimension theorem in §2.3 is a conclusion about this definition, not an input to it.

### 1.4 Classification of formal profiles and time normalizations

Classify the allowed rank-two formal profiles of structural degree four, retaining the nondegenerate leading-term and reduced-deformation hypotheses. Enumerate partitions of four and the integral or half-integral generic local slope at each irregular part; quotient the permitted marked-curve automorphisms. Prove that the resulting ten profiles have one essential time parameter. In a presentation with n poles the dimension calculation is n + Σ⌈rᵢ⌉ − 3 = Σmᵢ − 3 = 1, with the automorphism stabilizers and the chosen marking/slices explicitly checked. The determinant normalization and its transport remove no required projective direction and add no scalar irregular direction. Prove that all ten standard presentations admit this determinant normalization. The table in §9.2 is the output of this theorem. (VDPS09, §2.2, Table 1, printed pp.18–19.)

Prove the familiar time domains only after fixing the displayed marking and normalization: the four-point cross-ratio base, a nonzero irregular time for the multiplicative-looking time charts, and an affine time for the polynomial charts. These are charts or marking covers of the intrinsic time problem; they are not six definitions of dynamics. The classification is restricted to this rank-two formal complexity, and does not classify every two-dimensional nonautonomous system.

*Needs:* §§1.1–1.3; finite-ramification normal forms; genus-zero marked-curve automorphisms.

### Examples

For a single ramified pole with slope 5/2, the structural order is 4 and the three irregular coefficients are reduced by the two-dimensional affine coordinate group to one essential time. For two unramified poles of slope 1, there are two irregular coefficients and one residual scaling, again leaving one time. These calculations concern input types before any scalar Painlevé equation is introduced.

### Dependencies

FormalConnectionsOpers F2–F3; PadicDifferentialEquationsAndRigidCohomology §RD.6.52a; SchemeAndStackFoundations §1.18; ComplexCurveModuli D0/D2.0; ComplexComparisonPartII C−1.1.

## Layer 2: moduli and the intrinsic symplectic form

### 2.1 The stable moduli family on all bundles

Construct the stack of w-stable objects of §1.1 in families, its scalar rigidification and its relative coarse moduli family over the admitted time and exponent base. Impose the connection and local-structure equations on a bounded parameter space of bundles with filtrations, and verify representability, separatedness and finite type. Construct a universal object on an appropriate étale cover and prove descent of the tangent constructions; do not postulate a universal bundle on the coarse space. The determinant-fixed specialization on genus zero has no omitted Jacobian directions. (I23, Theorem 5.1 and the setup of §10.)

**API.**

- Identify geometric points and families up to the appropriate arrows, with an explicit coarse-map universal property.
- Prove restriction and admissible base-change comparisons, including determinant fibers.
- Compare splitting-type charts with open substacks; every use of the trivial-bundle chart records its complement.
- Describe wall-crossing maps for different weight chambers on their actual common stable locus.

**Checks.**

- A stable object may have scalar automorphisms before rigidification. A set-valued quotient that claims all stabilizers were trivial fails this example.
- A family can leave a trivial-bundle chart by bundle jumping while remaining in the moduli space. Its phase path is not declared singular for that reason.
- A ramified generic local factor is irreducible, so it has no global ∇-invariant line and is stable for every weight; this is I23 Remark 2.9, not a claim that every special solution is absent.

*Needs:* Layer 1; SchemeAndStackFoundations §§1.18, 1.23 and 4.14; AlgebraicModuliForArithmeticGeometry §§5.1, 7.1 and 8.

### 2.2 The deformation complex and its pairing

Construct the deformation complex from infinitesimal endomorphisms preserving the determinant and local structures, permitted infinitesimal connection variations, and the factorized-structure relations. Begin with the two-term connection complex G•. In the ramified case construct I23's full cone F• = Cone(G• → S•ram[1])[−1], including its terms in degrees 0, 1 and 2 and both differentials. A two-term replacement is permitted only after proving the appropriate quasi-isomorphism. Identify first-order automorphisms, tangent vectors and obstruction classes with its hypercohomology, and construct the trace/Serre-duality pairing. The commutator with ∇ is generally a ℂ-linear first-order differential operator, not an O-linear map; use the complex of sheaves of ℂ-vector spaces with its coherent terms, Čech resolution and termwise duality, rather than silently treating it as a complex in D(QCoh). Prove independence of the affine cover and formal presentation by chain maps and quasi-isomorphisms. (I23, §6, equation (6.9), Proposition 6.3 and §7, Proposition 7.2.)

**API.**

- Give the differential, local compatibility equations and the map from an infinitesimal family to its cocycle.
- Prove gauge-change and coboundary compatibility in both directions.
- Construct the trace-free/determinant decomposition and the dual complex with its signs.
- Prove naturality of the pairing under input isomorphisms and admissible base change.

**Checks.**

- An infinitesimal gauge change by u changes a connection representative by the commutator differential of u; its tangent class is zero.
- Without a determinant identification scalars have an infinitesimal automorphism direction; fixing it in characteristic zero removes that direction, although the finite μ₂ stabilizer remains until rigidification.
- With ω = dq ∧ dp, the ordered tangent pair (∂q, ∂p) has pairing +1 and the reversed pair −1; a reversed trace convention must be corrected before transport formulas are used.

*Needs:* §2.1; SchemeAndStackFoundations §§2.2, 2.6, 2.20, 3.3 and 4.2–4.6. The differential-operator/Čech total-complex adapter and the ramified cone are constructed here.

### 2.3 Smoothness, dimension and relative symplecticity

Prove smoothness of the stable family by the deformation complex and its obstruction analysis, and identify its relative tangent bundle. In I23's unfixed-determinant general setup the nonempty fiber dimension is 2r²(g − 1) + 2 + r(r − 1)deg P. In the classical genus-zero rank-two specialization it is 2. If a fixed-determinant general-genus theorem is exported, remove the 2g determinant directions with a proved determinant-map comparison; do not reuse the unfixed formula unchanged. (I23, Theorem 7.5.)

Construct the relative two-form from §2.2, prove nondegeneracy, and prove closedness using the deformation/unfolding argument, with descent from the universal-object cover. The result is a relative symplectic surface family for the degree-four subcategory. No Hamiltonian chart is a premise. (I23, Theorem 8.1 and Proposition 8.3.)

**API.**

- Identify the relative tangent sheaf with first deformation hypercohomology and prove compatibility with parameter restriction.
- Descend the trace pairing to the phase family and prove nondegeneracy and closedness there.
- Compare fixed and varying determinant directions before specializing the dimension formula.

**Checks.**

- Genus zero, rank two and degree four give −8 + 2 + 8 = 2; structural degree five instead gives 4.
- Fixing the determinant in positive genus removes 2g directions when the determinant-map comparison applies; the genus-zero coincidence cannot be exported unchanged.
- A skew pairing which vanishes identically is closed but is not symplectic; nondegeneracy must follow from the actual duality computation.

*Needs:* §§2.1–2.2; relative differential forms and the coherent trace pairing.

### 2.4 Exceptional strata are part of the phase space

Prove that the construction retains all w-stable logarithmic resonance, reducible and apparent-singularity strata allowed by its fixed local moduli conditions. Describe how the local filtration resolves the ambiguity of repeated eigenvalues. Record nonemptiness separately. At generic ramified points use the irreducibility theorem rather than inventing reducible objects there. Layer 4 will identify the images of these already constructed strata in the character space. A vanishing leading irregular coefficient changes the input stratum and is handled by §9.3 and Layer 11. (I23, §2 and Remark 2.9; IIS06, §4, especially Theorems 4.10–4.12; VDPS09, §2.2 and §3.)

*Needs:* §§2.1–2.3; the local structures of §1.1. The analytic interpretation by Riemann–Hilbert is supplied in Layer 4, not used to define these strata.

### Examples

At genus zero and rank two, the dimension calculation gives −8 + 2 + 2·4 = 2. An affine phase chart has coordinates (q,p), but points missing from that chart remain genuine initial conditions. On a resonance divisor, distinct parabolic initial points can have the same coarse monodromy character; the phase space must retain them.

### Dependencies

Layer 1; SchemeAndStackFoundations §§4.2–4.6/4.14; AlgebraicModuliForArithmeticGeometry §§5.1/7.1/8; the deformation pairing of §2.2. No scalar equation or Painlevé property is used.

## Layer 3: construction of the time connection

### 3.1 Infinitesimal integrable extensions

For a time tangent vector at a moduli point, construct a strong integrable extension of the universal connection over the corresponding dual-number deformation. On the moving total curve X, let D be the sum of the marked relative Cartier divisors with coefficient one, formed on the smooth ambient family and pulled back to the infinitesimal base. The permitted total-form pole filtration is Ω¹_X(log D) ⊗ O_X(P − D), relative to any fixed auxiliary base. Require integrability and preservation of the kernel lattices attached to the local filtrations, defined by E → E|D/filtration with the appropriate structural thickening at each pole. This specifies the extension intrinsically. Prove the coordinate lemma: in a moving polar coordinate z the permitted forms are generated by dz/zᵐ and dε/zᵐ⁻¹. In particular the time coefficient is regular at logarithmic points. Preservation of the relative flags on each fiber alone is insufficient. Prove existence and uniqueness up to the specified identity-on-the-central-fiber isomorphism within this strong extension class. Compare local extensions on overlaps and descend. This constructs h: π*TB → TM and proves dπ ∘ h = id. (I23, Definition 10.1, equation (10.1), Propositions 10.7 and 10.10 and equation (11.2).)

**API.**

- Construct the lift from a time tangent and prove additivity and O-linearity.
- Prove restriction, base-change and input-isomorphism naturality of the lift.
- Compare lifts computed with different local coordinates, formal diagonalizations and universal-object covers.
- Identify the induced horizontal subbundle and its projection isomorphism to π*TB.

**Checks.**

- A zero time tangent lifts to zero; adding an arbitrary vertical vector would violate uniqueness of the integrable extension.
- Rescaling the time tangent by 2 rescales its lift by 2, while changing the time coordinate to 2t rescales the normalized generator by 1/2.
- The zero map cannot be a splitting over a nonzero time tangent because dπ ∘ 0 = 0 ≠ id.

*Needs:* Layers 1–2; infinitesimal local lifting and factorized-structure comparison in I23 §§4 and 10, constructed through §§1.1 and 2.2.

### 3.2 Flatness of the constructed splitting

Prove h([v,w]) = [h(v),h(w)] for time vector fields by comparing two-parameter strong extensions and their mixed term. Prove that holomorphic integral sections carry strong integrable total meromorphic connections. The comparison with generalized local monodromy/Stokes constancy is a separate theorem in §4.1; it is not used in this algebraic bracket calculation. (I23, Theorem 11.6 and its second-order extension argument.)

*Needs:* §3.1 and the second-order deformation/overlap comparison of §2.2; ComplexKahlerGeometry K4's curvature calculus. There is no dependency on Layer 4 or 5.

### 3.3 Symplectic preservation and the total form

Define the total two-form Ω(v,w) = ω(v − h(dπv), w − h(dπw)). Prove it is closed and that its kernel is precisely the horizontal distribution. Deduce that horizontal transport preserves the fiber symplectic forms wherever it is defined. This constructs a coordinate-independent substitute for a scalar Hamiltonian. Derive the local expression dq ∧ dp + dH ∧ dt only after a symplectic trivialization and local exactness have been supplied. (I23, Definition 11.4 and Corollary 11.8; BOA01, Theorems 7.1 and 7.3.)

**API.**

- Recover the relative form by vertical restriction and the horizontal distribution as the kernel.
- Prove functoriality under the admissible base changes and isomorphisms of §3.1.
- Compare two Hamiltonian potentials in a fixed chart: their difference is constant along connected phase fibers.
- State the extra generator term for a time-dependent symplectic change of coordinates through equality of the extended two-forms.

**Checks.**

- For H = p²/2, contraction with ∂t + p∂q annihilates dq ∧ dp + p dp ∧ dt; using the opposite sign does not.
- H and H + t² give the same vertical vector field and extended two-form, but different scalar functions.
- On a symplectic fiber, Ω has no nonzero vertical kernel vector; degenerating ω to zero would fail this characterization.

*Needs:* §§2.3, 3.1–3.2; differential-form and local symplectic calculus at its stated complex generality.

### 3.4 Choice independence and genuine parameter changes

Prove that different presentations of the same decorated deformation problem induce canonically compatible phase-family isomorphisms preserving h and ω. Include cocycle compatibility for three presentations. Keep changes of labels, determinant connection and weight chambers as explicit morphisms or correspondences with stated domains, rather than identifying them automatically. A time-dependent gauge transformation changes a displayed matrix equation but not the integrable connection object. (HEU10, Theorem 1.1; I23, uniqueness in Propositions 10.7 and 10.10.)

*Needs:* §§1.1–1.2, 2.1 and 3.1–3.3.

### Examples

The Hamiltonian chart H = p²/2 − 2q³ − tq represents a horizontal kernel, but the kernel is constructed without this formula. Replacing H by H + c(t) preserves it. A marking change acts on the parameterized family; it does not erase the marking from the input groupoid.

### Dependencies

Layers 1–2; intrinsic infinitesimal integrability and ComplexKahlerGeometry K4. Algebraic construction, flatness and symplecticity precede the analytic Stokes interpretation in §4.1.

## Layer 4: analytic comparison, including exceptional points

### 4.1 Sectorial local systems and ramified analytic descent

Construct the analytic classification of the permitted local meromorphic connections by formal graded data, sectorial solutions and Stokes transition maps, retaining resonant logarithmic lattices and flags. Prove sectorial existence, overlap uniqueness, cocycle identities and analytic dependence on the admissible time parameters. At a ramified point perform the construction on the finite cover and prove equivariant descent, including the deck permutation of the exponential factors. A formal Laurent-series classification alone does not prove these analytic assertions. (I23, §9, Theorem 9.7 and Corollary 9.11; BOA01, §§3–6; HEU10, §2; BY15, Remark 3 and Definitions 7 and 13.)

**API.**

- Construct solution-sector restriction, refinement and change of sectorial normalization.
- Recover the actual local analytic connection and prove full faithfulness on decorated objects.
- Compare the logarithmic, unramified and ramified descriptions through the same descent language.
- Prove that integrable time extension is equivalent to strong local constancy of these data at the stated local scope.

**Checks.**

- A rank-one exponential exp(1/z) has irregular growth despite trivial ordinary monodromy; ordinary monodromy alone cannot classify the object.
- A nontrivial unipotent logarithmic monodromy matrix differs from the identity although both eigenvalues equal 1.
- On a quadratic cover, one full turn in z exchanges the two formal exponential branches; a sectorial construction that returns each branch individually without the deck action fails descent.

*Needs:* Layer 1; §§3.1–3.2 for the strong-extension interpretation; FormalConnectionsOpers F2–F3; ComplexKahlerGeometry K3.0/K4; PadicDifferentialEquationsAndRigidCohomology §RD.6.52a. The analytic sectorial and ramified Stokes constructions are owned here.

### 4.2 The Betti family and complete transport

Construct the generalized monodromy groupoid by gluing the local data of §4.1 with the global local system on the punctured curve. Keep the enriched groupoid with logarithmic lattices and flags distinct from the ordinary affine character quotient obtained by forgetting those decorations. In the ordinary quotient impose the closed spectral-invariant and determinant constraints, and retain the exponent parameter θ as a separate fiber-product coordinate. At resonance do not fix a single nonclosed Jordan conjugacy class: scalar and allowed unipotent strata with the prescribed spectrum must remain present. Construct locally constant transport along admissible marked deformations, including changes of Stokes-sector presentations. Prove composition and inverse laws and completeness along every compact path in Bθ. A singular character fiber is permitted; transport is defined by the groupoid/topological construction, not by an assumed smooth tangent splitting there. (VDPS09, §§1–3; BOA14, §10, Theorem 10.2; BY15, Proposition 19, Theorem 21 and Corollary 22.)

BOA14's cited family-transport theorem has untwisted scope. Extend its isotopy construction to the rank-two ramified objects of BY15 by retaining the exponential covering, grading and deck action, constructing deck-compatible equivalences of the Stokes groupoids, and descending the framing action and closed spectral constraints. Prove independence, composition and homotopy compatibility before concatenating local products along a compact path. BY15's quasi-Hamiltonian/Poisson theorem by itself is not this family-transport theorem.

**API.**

- Construct restriction, gluing, gauge-conjugation and change-of-marking functors.
- Distinguish the decorated groupoid, its categorical quotient and the locus where it represents individual orbits.
- Prove local product descriptions over simply connected admissible time neighborhoods and their continuation along finite chains.
- Define the complete transport on the coarse quotient and its lift on any required decoration space.

**Checks.**

- θ and θ + 1 give the same exponential eigenvalue but need not give the same logarithmic lattice; the comparison target retains θ.
- A reducible representation and its semisimplification can have the same coarse character. The quotient is not declared a faithful encoding of all connection objects.
- Transport around a nontrivial loop may act nontrivially on the fiber; completeness does not imply trivial monodromy.

*Needs:* §§1.2, 4.1; SchemeAndStackFoundations §1.17 and ComplexComparisonPartII C−1.1 for quotient/gluing foundations; UniversalCovers and SmoothBundlesConnections B5 for the fundamental-groupoid interface.

### 4.3 Riemann–Hilbert and compatibility on the whole phase space

Construct RHθ: Mθᵃⁿ → Rθ over Bθ by the analytic classification and prove that it is holomorphic. Prove that it sends every horizontal trajectory of §3.1 to the transport of §4.2, including trajectories inside resonance, reducible and exceptional loci. On the stated stable irreducible/nonresonant open locus prove the inverse comparison; elsewhere record the actual fibers and decoration data rather than asserting injectivity. Compare the integrable-extension construction with the local analytic reconstruction, and descend from universal-object covers. (IIS06, Theorems 4.10–4.12; IS12, Theorem 5.1; I23, §9 and §11.)

The theorem's all-strata scope is a construction target: the generic unramified theorem is one of its inputs, not a replacement for the missing resonant or ramified comparison. No scalar equation is used in the extension across these loci.

**API.**

- Construct the holomorphic RH map from the universal-object cover and prove descent and base-change naturality.
- Compare the decorated local reconstruction with the forgetful ordinary character quotient.
- Prove horizontal compatibility at every retained point and the inverse theorem only on its stated open locus.

**Checks.**

- Two distinct points on an exceptional fiber can have the same ordinary character; the construction must not choose one as an inverse.
- At a resonant logarithmic point, equal eigenvalues do not justify deleting either the allowed scalar or unipotent stratum.
- Retaining exponent lifts distinguishes θ from θ + 1 even when their ordinary exponential eigenvalues agree.

*Needs:* §§2.1, 2.4, 3.1–3.2 and 4.1–4.2; ComplexComparisonPartII C−1.1/C0 and its regular-singular comparison only where applicable.

### 4.4 Proper comparison for the full classical input class

For each admitted degree-four rank-two input and every allowed exponent parameter, prove that RHθ is proper as a map of the whole time family, with the exponent lift retained in its target, on the full stable moduli space of §2.1. Establish the corresponding family statement on admitted parameter charts; properness of each fixed-time map is not sufficient. The target has the ordinary generalized character data with its fixed closed constraints; no solution-dependent open subset is removed. State surjectivity onto the realizable component separately from properness. This includes resonant logarithmic and stable reducible points and the generic ramified local structures defining the classical class. (IIS06, Definition 2.11 and Theorems 4.10–4.12; IS12, Theorem 5.1 and the scope warning of Remark 6.3; HEU10, Theorem 1.1.)

The required extension is owned here. Develop the proof through four concrete intermediate results: boundedness of local lattices uniformly over compact families of generalized characters with fixed exponent lifts; extension of the retained flags and factorized structures in a relative projective parameter space with their closed incidence relations; semistable replacement after the necessary base change and elementary modifications, followed by semistable = stable for the chosen weights and uniqueness in the separated moduli problem; and compatibility of these extensions with global gluing and the analytic moduli topology. Stability is open but is not thereby preserved by arbitrary limits. Verify that these results give compact inverse images of compact subsets, rather than merely closed fibers or pointwise solvability. A projective flag variety alone does not prove the theorem, since the underlying connection may also escape.

HEU10's universal strong isomonodromic deformation gives an independent possible route to the continuation conclusion of §5.2. Such a route must establish the identification of the time bases, extension of local decorations, determinant and stability preservation, bundle-jumping compatibility, descent, and equality with §3.1. It does not by itself prove the properness required in this target. I23's global foliation theorem and IS12's generic theorem also do not discharge it. The compactness theorem remains an explicit internal proof-development task.

*Needs:* §§2.1–2.4 and 4.1–4.3; boundedness, projective parameter spaces and extension theory of SchemeAndStackFoundations §4.14 and the moduli construction. This is an internal proof-development target, not an assumed properness field.

### Examples

An exceptional RH fiber can be a projective curve. A chosen point on it is still an initial condition and has its own horizontal lift; taking an arbitrary inverse of the coarse RH map would discard this information. A trivial-bundle chart may fail the strong Riemann–Hilbert problem at an isolated time even though the full bundle-valued connection continues.

### Dependencies

Layers 1–3; the analytic local classification of §4.1; analytic gluing and moduli comparison suppliers. Properness and all-strata compatibility are proved before the continuation theorem and are never inferred from scalar Painlevé equations.

## Layer 5: intrinsic solutions and the Painlevé property

### 5.1 Horizontal germs and local analytic solution theory

Define the germ at b₀ of a holomorphic section s: U → Mθ with πθ ∘ s equal to the inclusion U → Bθ, s(b₀) = x₀ and ds_b(v) = h_s(b)(v). Equality of germs means equality on a neighborhood of b₀. Prove local existence and uniqueness for every x₀ and holomorphic dependence on initial points and admitted auxiliary parameters. Use the holomorphic-horizontal-lifts supplier; the constructed h, not an assumed solution operator, is its input. (IIS06, Definitions 2.1–2.2; I23, the local product (11.5).)

**API.**

- Construct restriction, germ equality and the evaluation map at the initial time.
- Prove uniqueness on connected overlap and gluing of compatible horizontal sections.
- Compare pullbacks under time-base isomorphisms and compatible maps of phase families.
- State the map from initial conditions to solution germs as a bijection at a fixed time.

**Checks.**

- On π: B × F → B with the product splitting, a horizontal section is b ↦ (b,x₀), not an arbitrary map B → F.
- A section must satisfy dπ ∘ ds = id; a constant map into the total space is not a section over a nonconstant time neighborhood.
- For the holomorphic vector field q′ = q² with q(0) = 1, the local solution is 1/(1 − t); local existence does not imply continuation in the affine phase chart through t = 1.

*Needs:* §§3.1–3.2; gap:holomorphic-horizontal-lifts; ComplexCurveModuli D2.0 and ComplexComparisonPartII C−1.1 for the native-manifold/analytic-space comparison.

### 5.2 Proper semiconjugacy prevents finite-time escape

Prove the following general transfer theorem. Let π: M → B be a holomorphic submersion with a holomorphic integrable splitting, let R → B carry complete continuous transport with the required local holomorphic compatibility, and let F: M → R be a proper map over B which sends every local horizontal lift to that transport. Then every compact piecewise C¹ base path has a unique horizontal lift through each initial point of M. The target R may be singular; only its transport and compactness are used. (IIS06, Lemma 2.12, with the smooth-source/local-uniqueness hypotheses made explicit.)

Indeed, the image of a maximal lift lies over the compact transported target path. Properness traps it in a compact subset of M. A finite subcover by local existence neighborhoods, or the maximal-integral-curve extension theorem, extends it at any purported finite endpoint. Local uniqueness glues the extensions. This uses compatibility at exceptional points, not just on a dense open set. No inverse to F is needed.

Apply this theorem to §4.4 and §4.3 to prove geometric Painlevé property for the entire classical input class. The quantifiers are: every admitted θ, every initial time b₀, every x₀ ∈ Mθ,b₀, and every compact piecewise C¹ path beginning at b₀ in Bθ. Poles of a later scalar observable do not restrict these quantifiers.

*Needs:* §§3.2, 4.2–4.4 and 5.1; Tau Ceti's maximal integral-curve extension and compact-containment floor. The map used for properness is F, not π.

### 5.3 Transport, universal-cover sections and descent

Construct the endpoint transport between fibers and prove identity, reversal and concatenation laws. Prove homotopy invariance relative endpoints from flatness and local uniqueness, and obtain an action of the fundamental groupoid. For a pointed universal cover B̃ → B, construct the unique global horizontal section through each initial point. Prove descent to B exactly when the initial point is fixed by the relevant deck/monodromy action. The action preserves the fiber symplectic forms. (IIS06, Definitions 2.1–2.2 and §5; BOA01, §7.)

**API.**

- Construct endpoint maps and their inverses, with concatenation in the chosen path-composition convention.
- Compare transport with pullback to covers and with input isomorphisms.
- Construct the universal-cover section and its deck-equivariance/descent criterion.

**Checks.**

- A path followed by its reversal gives the identity on every initial condition, including exceptional points.
- A contractible loop has trivial transport, whereas a noncontractible loop need not.
- A nonfixed initial point under deck transport gives a section on the universal cover which does not descend; completeness alone is insufficient for descent.

*Needs:* §§3.2–3.3 and 5.1–5.2; SmoothBundlesConnections B5; UniversalCovers. Only the application to the constructed nonlinear connection is owned here.

### 5.4 Admissible observables

Define an observable first as a morphism from the relevant phase family to ℙ¹, or as a rational map equipped with a stated domain and a proved resolution/lifting comparison. For a chosen horizontal section require that its pullback is defined and not identically ∞ before calling it a scalar meromorphic Painlevé function. Prove naturality under changes of presentation and specify which observer/time choices are retained. (IIS06, §10; VDPS09, §4; STT02, §6.)

**API.**

- Evaluate an everywhere defined observable on a horizontal germ or universal-cover section.
- Compare observers on overlaps through their actual transition maps.
- For a rational observer, construct its resolution and prove lift existence for the relevant section, or prove direct non-indeterminacy.
- Separate the ℙ¹-valued holomorphic object from its scalar meromorphic representative.

**Checks.**

- Q ≡ ∞ is an everywhere defined ℙ¹-valued observer, but it does not produce an ordinary meromorphic function with isolated poles.
- The rational map [x:y] on ℂ² is undefined on the constant curve (0,0); rationality alone does not define a pullback along every solution.
- In the infinity chart, Q(t) = 1/t becomes 1/Q(t) = t, holomorphic at 0. Its pole is a chart event, not a failure of geometric continuation.

*Needs:* §§5.1–5.3; the native meromorphic-curve and projective-line comparison; resolution and chart lifting as constructed for each observer.

### 5.5 Scalar meromorphic continuation

For an admissible observer and initial point, prove that its evaluation on the global horizontal section of §5.3 is meromorphic on the universal cover of the admitted time base. Prove that each interior singularity of the scalar representative is a pole of finite order. Where a classical observer requires several charts or a resolution, prove the hypotheses of §5.4 for every claimed solution stratum. State the single-valued descent criterion separately. This theorem gives scalar Painlevé property after the coordinate comparisons, without reproving six scalar continuation theorems. (IIS06, Lemma 2.12 and §10; the source supplies the geometric mechanism, while the observer pullback and non-indeterminacy assertions are explicit targets here.)

*Needs:* §§5.3–5.4; local meromorphic function theory on complex curves. No denominator-clearing convention is allowed to add undefined scalar solutions.

### Examples

The affine equation q′ = q² has a movable pole at t = 1 for q(0) = 1. Its projective vector field extends in u = 1/q as u′ = −1. This separates affine-coordinate escape from geometric continuation. On B = ℂ*, a horizontal system can have complete continuation on the universal cover and nontrivial monodromy around 0; this does not contradict the theorem.

### Dependencies

Layers 3–4; gap:holomorphic-horizontal-lifts; native maximal-flow and covering-space foundations; the observable's actual projective comparison. Coordinate displays are downstream consequences.

## Layer 6: comparison with initial-condition surfaces

### 6.1 Additive Okamoto–Painlevé pairs

Define the comparison groupoid of smooth projective rational surfaces S with a nonzero effective anticanonical divisor Y, satisfying Y·Yᵢ = 0 for every irreducible component, with D = Y_red a simple normal-crossing divisor. Require additive type, expressed by the additive identity component of Pic⁰(Y), and nonfibered type: no elliptic fibration has a fiber nY with n ≥ 1. Retain markings when a root basis or normalized time is used. Construct the relative versions of these conditions. (STT02, Definitions 1.1 and 1.3, Proposition 1.2 and Tables 2–3.)

**API.**

- Extract the weighted boundary intersection graph and the orthogonal lattices in Pic(S).
- Prove invariance under pair isomorphisms and compatibility with admissible families.
- Compare the complement S \ D with its logarithmic tangent and two-form sheaves.
- Distinguish the boundary-root lattice from a symmetry-root lattice.

**Checks.**

- A smooth elliptic anticanonical boundary has elliptic Picard identity component, not additive, and is excluded.
- A multiplicative cycle has multiplicative Picard identity component and is excluded.
- Requiring a global affine-plane chart would exclude the D₈ case; that additional requirement is absent.

*Needs:* SchemeAndStackFoundations §§2.6–2.7, 3.4, 4.17 and 5.9–5.10; AlgebraicVectorBundles L0A–L0C/L1A–L1B; ComplexComparisonPartII C3.2d.2/C3.2f.1–2. For this proper flat family construct the logarithmic tangent sheaf as the derivations preserving the boundary ideal. For the possibly nonreduced boundary prove O_B ≅ p_*O_Y universally and H²(Y,O_Y) = 0, and verify the smoothness and constant-dimension hypotheses of the Picard identity-component supplier, including formal smoothness when the base is nonreduced. Then compute its identity component by normalization/unit exact sequences. This is not an application of a smooth-curve Jacobian theorem.

### 6.2 Compactification and the eight boundary types

Construct a compactification of the degree-four connection moduli family with the pair structure of §6.1, after the stated marking/base changes, and prove that its complement is the full phase family. Prove the extension and comparison of the symplectic form and time distribution, including exceptional curves and nontrivial bundle charts. Classify the additive normal-crossing boundary types as D₄, D₅, D₆, D₇, D₈, E₆, E₇ and E₈. These are affine boundary diagrams. (STT02, Proposition 1.2 and Tables 2–3; VDPS09, introduction and Table 1; IIS06, §10 for the fully established PVI comparison.)

The all-profile comparison is a construction and proof target. VDPS09's introductory conjectural global comparison is not used as an established theorem. Prove overlap identifications, coverage and the extension at the omitted charts before asserting a global isomorphism. The compactification is not used to bypass §4.4 or to infer completeness merely from existence of a foliation.

**API.**

- Construct the relative compactification and its boundary divisor with its multiplicities and intersection pairing.
- Prove the full open-complement comparison, including bundle-jumping and exceptional charts.
- Compare the deformation and relative two-form under that isomorphism, and record the marking/base-change law.

**Checks.**

- Two presentations of boundary type D₆ can have different formal pole data; the common boundary label alone is not a moduli isomorphism.
- The D₈ complement must be retained even without the extra affine-plane hypothesis of older definitions.
- An omitted exceptional curve invalidates the full-complement assertion even if the open rational chart and its scalar formula are correct.

*Needs:* Layers 1–3; §§2.1 and 6.1; SchemeAndStackFoundations §§4.11, 4.14, 4.17 and 5.9–5.10. Construct the particular compactification and its charts here. No scalar Painlevé property is a prerequisite.

### 6.3 Intrinsic comparison of the time line

Let F = Θ_S(−log D) and N_D = O_S(D)/O_S. Construct L = H⁰(D,F ⊗ N_D), prove that it is one-dimensional for these pairs, and construct its injection into local cohomology. Establish the family/base-change theorem for L and compare its Kodaira–Spencer image with the time direction of §3.1. Prove the connecting-map/intersection-matrix identity intrinsically; do not repeat a different coordinate computation for each boundary graph. (TER02, Theorem 2.1 and Proposition 2.1; STT02, Theorem 3.1.)

Do not assert equality with the entire local-cohomology space as a standing premise: TER02 Conjecture 2.1 and the restricted results of ST04 Appendix A have different scope. A line is not a distinguished nonzero vector; a normalized time supplies a generator. Prove equality of the lifted distributions by the deformation comparison and uniqueness on the prescribed algebraic complement.

**API.**

- Construct the first boundary-layer line, its injection into supported cohomology and its restriction maps.
- Prove the intersection-matrix formula and the dimension calculation without choosing a scalar Painlevé chart.
- Establish locally free base change and the comparison of its Kodaira–Spencer image with the time tangent line.

**Checks.**

- Rescaling a chosen nonzero time vector rescales its image in L, while L itself is unchanged.
- The injection L → H¹_D(S,F) alone does not prove that its target is one-dimensional.
- A family dimension calculation without the required cohomology/base-change hypotheses does not identify the fibers of a relative line bundle.

*Needs:* §§3.1–3.4 and 6.1–6.2; SchemeAndStackFoundations §§2.6–2.7, 2.20 and 5.9; JacobianChallenge Layer C. The constant-rank hypotheses, family/base-change and Kodaira–Spencer comparisons for this specific logarithmic boundary line are proved here.

### Examples

The boundary type E₈ is associated with one ramified rank-two presentation, while E₇ has two. Thus a boundary label and a connection presentation are different kinds of data. The first boundary-layer line has dimension 1; claiming the same dimension for every full local-cohomology group would require an additional theorem and is not used here.

### Dependencies

Layers 1–3; algebraic surface and coherent deformation foundations; no scalar formulas. Layer 5 remains independent of this comparison, so its proof cannot become circular through an initial-condition construction that presupposes Painlevé property.

## Layer 7: geometric transformations and invariant reductions

### 7.1 Functors on decorated connections

Construct elementary modifications along an invariant local flag, tensor product with an admitted rank-one connection, duality and relabeling as functors between the actual decorated moduli problems. Specify the new determinant, exponent and stability data and the locus on which the transformed object is stable. Use the kernel construction for a modification, its induced connection, and the inverse modification; retain the comparison arrows. Extend these functors to strong integrable families by preservation of the allowed pole filtration and kernel lattices. (IIS06, Definition 3.5 and §7; I23, §§2–4 and Definition 10.1.)

**API.**

- Construct the transformed bundle and connection before passing to coarse moduli, with their determinant and local-type formulas.
- Prove pullback, composition and inverse comparisons on their specified domains.
- Describe the change of weights or required wall-crossing correspondence instead of declaring stability invariant without proof.
- Distinguish a functorial isomorphism of moduli problems, an open birational correspondence and a scalar solution substitution.

**Checks.**

- Modifying along a one-dimensional quotient at a logarithmic pole changes the bundle degree by −1; leaving the determinant unchanged fails the determinant comparison.
- Tensoring rank two by a line connection L changes the determinant by L², including its connection; it does not construct a square root of a previously fixed odd-degree determinant.
- The inverse modification recovers the original decorated object with its arrow on the common admissible locus, while forgetting the distinguished flag need not permit the inverse.

*Needs:* §§1.1, 2.1 and 3.1; AlgebraicVectorBundles L0A–L0C/L1A–L1B; FormalConnectionsOpers F2–F3. The Painlevé-specific stability and strong-extension comparisons are owned here.

### 7.2 Horizontal and symplectic transformation laws

Prove that each admitted transformation intertwines h by applying the uniqueness of strong extensions to its transformed family. Prove the transformation law for ω by the induced map of deformation complexes and trace pairing. Construct the resulting action groupoid on the parameterized moduli family, and establish relations by natural isomorphisms of the functors. On a marked surface compare its action on Pic(S) with the corresponding integral root reflections and diagram automorphisms. State the actual symmetry root lattice and its parameter hyperplanes separately from the boundary root diagram. (IIS06, Theorem 7.4 and Theorem 10.13 for PVI; STT02, Tables 2–3 and the marked deformation construction.)

The functors in §7.1 are not assumed to generate the full affine Weyl group. Construct the additional reflections on the moduli of marked pairs, identify the induced birational correspondence of connection moduli through §6.2, and prove its horizontal and symplectic extension on the claimed domain. The central PVI reflection is a required test: it is not generated merely by the local gauge modifications listed in §7.1. IIS06 Remark 7.5(2) describes a Fourier-transform realization; a Fourier–Laplace or middle-convolution implementation would likewise require its own functor and strong-extension comparison. The marked-surface construction is the specified route here. The PVI theorem is not cited as a theorem for every profile. Verify the actual reflection and Coxeter relations, effective-locus conditions and extension across chart complements before deriving rational Bäcklund formulas in §9.4. An identity of rational maps on a dense open set must be upgraded before claiming an everywhere defined automorphism.

**API.**

- Construct the marked-pair reflection correspondences and compare them with the connection-functor generators on their common domains.
- Prove horizontal and symplectic intertwining, relations and compatibility with parameter changes.
- Record the regular domain and the extension theorem for each claimed global map.

**Checks.**

- The PVI central reflection shifts κⱼ to κⱼ + κ₀ for j = 1,2,3,4, where 2κ₀ + Σκⱼ = 1; local integer shifts and sign changes alone do not construct it.
- A reflection squared must give the original marked family with its comparison arrow, not merely the same boundary diagram.
- A birational formula with a pole on an invariant curve is not an automorphism of that curve until a regular extension is proved.

*Needs:* §§2.2–2.3, 3.4, 6.2 and 7.1; SchemeAndStackFoundations §§3.4 and 5.9–5.10. No scalar differential equation is used to define or justify the action.

### 7.3 Invariant rational curves and Riccati dynamics

For the admitted nonfibered additive pair, construct the local family of an interior smooth rational curve C with C² = −2. Prove invariance under the time distribution using the logarithmic deformation sequence. Retain the étale or finite base change needed to continue that family; descent to the original base requires its own monodromy check. On the resulting relative ℙ¹-bundle, identify the restricted connection as a projective linear connection, using H⁰(ℙ¹,Tℙ¹) ≅ sl₂. The coordinate lemma then has q′ = a(t)q² + b(t)q + c(t). A linear rank-two lift is asserted locally, or globally only with its lifting obstruction resolved. (ST04, §2.4, Proposition 2.1, Remark 2.4 and Definition 2.3.) The PVI comparison with the Gauss equation is IIS06 Theorem 5.15; its Theorem 5.16 assumes analytic Painlevé property and is not used as a premise of this independent geometric construction.

**API.**

- Construct restriction of h to the invariant curve family and prove that its projection to time remains a splitting.
- Compare two projective coordinates by the induced Möbius gauge law, and compare local rank-two linearizations.
- Prove preservation under the admitted geometric transformations when they extend as regular isomorphisms along the whole curve family; otherwise construct the closure and prove the required curve and invariance properties separately.
- Compare the nodal-curve condition with reducible connections or exceptional RH fibers only in the presentations where that identification is proved.

**Checks.**

- A holomorphic vertical vector field on ℙ¹ has a polynomial coefficient of degree at most two in an affine coordinate; a cubic coefficient fails regularity at infinity.
- A ramified generic local factor forces global irreducibility, but an E₇ ramified presentation can still have an invariant Riccati curve. Thus “Riccati if and only if globally reducible connection” is not a presentation-independent theorem.
- A family of curves can be permuted by continuation around the time base; a local invariant curve does not automatically give a globally labeled subfamily.
- A rational solution need not lie on a Riccati curve; ST04 §6.2 supplies this distinction. This target is not a classification of all rational solutions.

Classify these interior nodal configurations by the boundary intersection lattice under ST04 Theorem 3.1's hypotheses. Deduce its nonexistence statement for the E₈, D₇ and D₈ boundary types. Linearization gives the relevant classical special-function families after the coordinate comparisons; the parameter restrictions and normalizations remain part of those lemmas.

*Needs:* §§3.1–3.4, 6.1–6.3 and 7.1; SchemeAndStackFoundations §§2.7, 4.14 and 5.9–5.10; ComplexKahlerGeometry K4's linear-connection carrier. The projective connection and its local rank-two lift comparison are constructed here.

### Examples

In the PII chart of §9.5 the curve p = 0 is invariant at α = −1/2. Its Riccati equation is the coordinate expression of a projective connection on that curve. The seed q = 0 at α = 0 has different geometry; it must not be used to infer that all rational solutions arise from invariant Riccati curves.

### Dependencies

Layers 1–3 and 6; the same deformation and trace pairing used to construct h and ω. The presentation-specific identification of a given invariant locus with an RH exceptional fiber uses Layer 4; the intrinsic nodal-curve construction is independent of that identification.

## Layer 8: the determinant line and tau sections

### 8.1 The holomorphic determinant-family contract

Consume a complex holomorphic extension of HeegaardFloer, Part II, F0.0's reusable Fredholm determinant construction. This is the named gap:complex-holomorphic-determinant-family, assigned to the proposed supplier target F0.0C; the existing real determinant and orientation theory is not that theorem. The input is a holomorphic family T_s: H₀ → H₁ of bounded complex Fredholm operators of index zero on an analytic base, initially with fixed Hilbert spaces. The output is a holomorphic line L_T with a canonical determinant section, stabilization comparisons, base change and operator-isomorphism naturality. Use L_T,s = det(ker T_s)* ⊗ det(coker T_s), the dual of the convention used for the real orientation line. (MAL04, §2, pp. 1372–1374, for the determinant-extension model; BERT17, §1, for its RHP application.)

The supplier proof chooses a finite-dimensional F and a: F → H₁ such that (T_s,a) is surjective locally. Its kernel K is a holomorphic bundle of rank dim F. Set L_F = det K* ⊗ det F and τ_F = det(K → F), using the projection. Construct comparison maps through common refinements and exact sequences, and prove their composition law before gluing. This gives an actual line and section. Closedness of a proposed curvature two-form alone does not give the required integral cocycle. The Painlevé specialization consumes this construction rather than defining a second determinant-family carrier.

**API.**

- Construct the dual-convention adapter and the finite-dimensional normalization.
- Glue stabilization lines and sections, independently of the stabilization, and prove holomorphic base-change compatibility.
- Construct the bundle-valued operator-family version using its trivialization comparisons.
- Identify the nonvanishing locus with the locus where T_s is invertible; keep existence of the line separate from generic nonvanishing of its section.

**Checks.**

- For T_s: ℂ → ℂ, z ↦ sz, the standard frames give τ(s) = s, fixing the dual convention.
- For T_s(z) = s²z, the zero has order two although dim ker T₀ = 1; no unconditional equality between vanishing order and kernel dimension is supplied.
- An everywhere invertible constant family has nonvanishing determinant section; an identically singular index-zero family may have an identically zero section without invalidating its line.

*Needs:* gap:complex-holomorphic-determinant-family, owned by HeegaardFloer Part II, proposed F0.0C; native complex Fredholm/index and finite-dimensional determinant carriers; ComplexComparisonPartII's holomorphic bundle and gluing interfaces. This target records and specializes that supplier contract.

### 8.2 An index-zero RHP realization and descent

Construct an analytic RHP chart from the decorated connection family of Layers 1–3 and the analytic comparison of §§4.1–4.3. Retain the reference bundle or modification, contours, local lattices, branches, framings and normalization in its marking data. Construct the associated Fredholm operator and prove its index zero; the assertion is not a field added to every connection by fiat. For the initial closed-contour model use a holomorphic invertible jump symbol in a fixed contour neighborhood and zero determinant winding. Compare the solvable normalized RHP with the corresponding marked connection and pull back §8.1's line and section. Extend this construction to the analytic sectorial models needed by the selected ramified and resonant strata, with their explicit adapters. (BERT17, §1 and Theorem 2.2; MAL04, §2.)

The auxiliary bundle matters. On ℙ¹, rank E = 2 and deg E = d give χ(E(−1)) = d and χ(E(k)) = d + 2k + 2. Thus a degree-minus-one phase object does not acquire an index-zero complex by the unexplained choice E(−1); no integral common line twist has Euler characteristic zero when d is odd. Construct the needed normalized index-zero complex or modification and its comparison with the original connection. Malgrange's degree-zero sewn-bundle construction does not remove this obligation.

**API.**

- Construct RHP marking charts and the operator-family functor from their connection data.
- Prove comparison isomorphisms for changes of contour, factorization or normalization which give the same Fredholm family or a proved holomorphic chain/stable equivalence, with their identity and composition laws.
- Construct an equivariant line and section on the marked moduli groupoid/stack. Descend to a coarse space only after proving trivial stabilizer action on the line and section.
- Record exactly which strata have the required analytic adapter; completing the stated adapters is a proof target, not an assertion that the generic cited sources already cover every stratum.

Keep the reference bundle and auxiliary modification in the input marking. Unit transition factors for line and section are asserted only for proved equivalences, with any added auxiliary complex everywhere acyclic. An arbitrary change of reference bundle or modification can change the zero divisor. Treat it as a different normalized problem, and construct the relative determinant factor or meromorphic transformation with its divisor instead of declaring the two sections equal up to a unit. BERT17's factorization comparisons do not supply invariance under unrestricted bundle modification.

**Checks.**

- The degree-minus-one example fails the E(−1) index test, even though its connection is a valid phase object.
- Scalar automorphisms act by the Euler-characteristic weight, which is zero here; this does not establish trivial action for all other possible stabilizers.
- Two elementary jump factorizations can give different scalar Fredholm determinants. Their nonzero transition factor, not literal equality, is the required comparison.

*Needs:* Layers 1–3, §§4.1–4.3 and 8.1; SchemeAndStackFoundations §§1.22 and 3.3 for stack descent and coherent Euler characteristic; ComplexComparisonPartII C0.3; OperatorTheory/ToeplitzOperators T3 and OperatorTheory/OperatorIdeals OI-B23/OI-B30; RandomMatrices §8.3 for local trace-class determinants. The analytic RHP sewing and index-zero realization are constructed here; the first-jet/scalar comparison belongs later in Layer 9.

### 8.3 The divisor and corrected variational comparisons

Prove that the determinant section vanishes precisely where its normalized RHP is not solvable. On a reduced connected smooth chart where it is not identically zero, construct its effective Cartier divisor; obtain a global divisor only through the line comparisons. This is the failure locus of the selected RHP normalization, not a declaration that the intrinsic phase space or horizontal section ceases to exist. Establish the local trace identity d log det(I − K) = −Tr((I − K)⁻¹dK) on the invertible locus of a holomorphic trace-class family, then derive the integrable-kernel variational formula and its frame-change law. (BERT17, Theorem 2.2, Proposition 2.3, formula (3.6), Theorem 3.3 and §3.1.2.)

Compare with the JMU form only under the stated formal-normalization hypotheses: the generic unramified diagonalizable-leading-term and logarithmic nonresonance locus of BERT10 Assumption 3.1 and §5.1, Proposition 5.1. Use BERT16 Definition 2.1 for the corrected sign, Theorem 2.1 for vertex curvature, and Theorem 2.2, which replaces BERT10 Theorem 5.1. The corrected local formula uses ω_M − θ_V, with dθ_V = η_V on the monodromy parameters. Along fixed-monodromy time directions θ_V has no component; factorization/frame corrections still have to be matched. Neither the raw Malgrange form nor its original modification is asserted closed on the full monodromy-and-time space. Removing contour vertices requires a proved sewing comparison.

**API.**

- Construct the section's divisor and its naturality under the comparisons of §8.2.
- Prove the local variational identity and its change under a nonvanishing frame multiplier.
- Construct the scoped comparison with the selected JMU normalization; keep any additional ramified/resonant comparison as a separately stated proof target.

**Checks.**

- A zero of the chosen tau representative can occur while the intrinsic horizontal solution continues through that time in another bundle chart.
- The family T_s = s² retains its double zero; the divisor calculation cannot replace multiplicity by kernel dimension.
- A graph with nontrivial vertex limits requires the BERT16 correction; disjoint closed contours do not justify omitting it from an unproved graph-to-contour comparison.

*Needs:* §§8.1–8.2; RandomMatrices §8.3's trace-class determinant/trace identities; divisor theory on analytic curves and smooth charts; the formal normalization comparison of §4.1. No all-strata JMU identity is imported from a generic theorem.

### 8.4 Hamiltonians, frames and scalar normalization

For a chosen time coordinate and symplectic chart of the already constructed dynamics, derive the relation between the selected determinant-frame logarithmic derivative and the local Hamiltonian. Prove the exact coefficient and gauge, factorization and time-only correction terms from §8.3; do not silently identify different Hamiltonian conventions. A local primitive supplied by a symplectic chart is not a canonical function on the whole phase family. Fix the corrected logarithmic one-form or line connection and the frame prescription; then establish the normalized scalar representative by choosing a nonzero value in a determinant fiber at a regular base point. The resulting scalar display and later classical tau formulas are comparison theorems. (MAL04, Theorem 5.12 in its logarithmic Schlesinger scope; BERT10, §5.1, Proposition 5.1, with BERT16; BERT17, formula (3.6).) The ramified and resonant extensions of the comparison require their constructed RHP adapters and variational proof; MAL04's theorem is not that extension.

The differential-equation normalization is along a fixed-monodromy horizontal time leaf, away from the chosen divisor. There a closed scalar differential and a base-point value determine the representative on a simply connected domain. Any extension of this assertion to the full monodromy-and-time space must prove the required integrability after its frame corrections; simple connectedness alone does not remove curvature of a line connection.

**API.**

- Compare the symplectic/time convention of §3.3 with the variational identity and record all correction terms.
- Prove the transformation laws under a time change, a time-dependent symplectic chart change and a determinant-frame change.
- Prove uniqueness of scalar normalization on a connected simply connected regular domain after its base-point value is fixed; state separately the holonomy obstruction to descent.

**Checks.**

- If an identity uses d log τ = H dt, replacing H by H + c(t) requires multiplying τ by exp(∫c(t)dt), with the integration constant fixed.
- For a new time u = f(t), the same logarithmic one-form has coefficient (dt/du)H; an unchanged scalar coefficient would fail the comparison.
- Two representatives differing by a nonzero constant define the same logarithmic derivative but are different normalized scalar functions until the base-point values agree.

*Needs:* §§3.3–3.4 and 8.2–8.3; local complex symplectic primitives and line-bundle frame calculus. Classical equation-specific identifications are downstream in Layer 9.

### Examples

The one-dimensional operator families s, s² and 1 distinguish section, divisor multiplicity and invertibility. A valid degree-minus-one connection distinguishes the phase object from the auxiliary index-zero RHP complex. A contour/factorization change distinguishes an intrinsic line section from its scalar representatives. These examples test the common construction before any classical tau equation is displayed.

### Dependencies

Layers 1–3 and §§4.1–4.3; §3.3's intrinsic symplectic dynamics; HeegaardFloer Part II proposed F0.0C, through gap:complex-holomorphic-determinant-family; RandomMatrices §8.3's trace-class determinant floor; coherent and analytic descent. Layer 9 is a consumer of this layer, not its prerequisite; properness in §4.4 is not an input to the determinant construction.

## Layer 9: classical expressions as coordinate comparison lemmas

### 9.1 The common first-jet comparison

Let a time/phase chart identify the already constructed horizontal generator with ∂t + A(t,q,p)∂q + B(t,q,p)∂p. Construct the first-jet map J(t,q,p) = (t,q,A(t,q,p)). On an explicitly stated open set where J is a holomorphic isomorphism onto its image, write its inverse momentum as p = P(t,q,v). Prove that a horizontal section has

q″ = (A_t + A A_q + B A_p)(t,q,P(t,q,q′)),

and conversely that a solution of this scalar equation, whose first jet stays in the stated image, reconstructs a horizontal section. The proof is one chain-rule calculation and the inverse identity. A nonzero partial derivative A_p gives a local inverse, not an automatic global inverse on an arbitrarily selected domain. This common lemma is applied to the constructed chart functions; it does not define h by the desired scalar formula. (VDPS09, §4.1 and §§4.3–4.11; IIS06, Theorems 10.6 and 10.10.)

**API.**

- Construct the induced bijection between horizontal germs and admissible scalar first-jet germs in a genuine jet chart.
- Compare the scalarization under changes of time, observer and Darboux coordinates.
- Transport the meromorphic continuation result only after checking the observer conditions of §5.4.
- Record the complement of every jet chart and the extra phase information retained there.

**Checks.**

- If A = p, the inverse is p = q′ and the scalar equation is q″ = B(t,q,q′).
- If A is independent of p, J forgets the momentum and cannot be a jet chart; scalar uniqueness then cannot be inferred from geometric uniqueness by this argument.
- For A = p² there are two momentum branches away from p = 0; local invertibility does not identify the two branches globally.
- If a scalar formula divides by q, a solution crossing q = 0 must be treated through overlapping phase charts, not by declaring that the cleared denominator creates new solutions.

*Needs:* §§3.1, 3.3 and 5.4–5.5; ComplexKahlerGeometry K3.0's holomorphic calculus and K1's complex inverse/implicit-function comparison. No profile-specific scalar existence theorem is a premise.

### 9.2 Exhaustive presentation and equation comparisons

For every profile in §1.4 construct a concrete time/Darboux or equivalent symplectic chart from the connection moduli, with its inverse on its actual image. Identify h in this chart by the strong integrable extension of §3.1, apply §9.1, and prove the parameter and time-substitution dictionary to the standard equation below, including the required marking covers. The required comparison records the chosen local frames, the determinant convention, the chart domain, the momentum inverse, every denominator, and the omitted loci. Coverage of the full moduli space is the overlap theorem, not the claim that one rational chart covers it. Re-derive the scalar expression from the compatible system; the source corrections in §9.4 are part of the comparison. (VDPS09, §2.2, Table 1 and §4; IIS06, Theorems 10.6, 10.10 and 10.13; DLMF, §32.2(i), equations 32.2.1–32.2.6.)

In the following output table, slopes are projective Katz invariants; an omitted pole is written “—”. The number of external parameters is the dimension of the generic exponent family, not the number of initial conditions. Boundary diagrams are affine.

| Slopes at 0, 1, ∞, t | Boundary type | External dimension | Displayed realization and exact locator |
|---|---|---:|---|
| 0, 0, 0, 0 | D₄ | 4 | PVI; IIS06 §10, Theorems 10.6 and 10.10 |
| 0, 0, 1, — | D₅ | 3 | PV; VDPS09 §4.3, equations (1)–(5) |
| 0, 0, 1/2, — | D₆ | 2 | degenerate PV; VDPS09 §4.4, equations (6)–(11) |
| 1, —, 1, — | D₆ | 2 | PIII(D₆); VDPS09 §4.5, equations (12)–(16) |
| 1/2, —, 1, — | D₇ | 1 | PIII(D₇); VDPS09 §4.6, equations (17)–(21) |
| 1/2, —, 1/2, — | D₈ | 0 | PIII(D₈); VDPS09 §4.7, equations (22)–(26) |
| 0, —, 2, — | E₆ | 2 | PIV; VDPS09 §4.8, equations (27)–(31) |
| 0, —, 3/2, — | E₇ | 1 | Flaschka–Newell realization; VDPS09 §4.9, equations (32)–(36); its immediate scalar coordinate is P34 |
| —, —, 3, — | E₇ | 1 | Jimbo–Miwa realization of PII; VDPS09 §4.10, equations (37)–(41) |
| —, —, 5/2, — | E₈ | 0 | PI; VDPS09 §4.11, equations (42)–(47) |

Prove the actual substitutions and admissible inverse domains relating the Flaschka–Newell scalar coordinate to PII and degenerate PV to PIII(D₆). Two rows sharing a boundary type are not declared identical decorated moduli problems. In particular, a scalar substitution from degenerate PV to PIII does not by itself identify their isomonodromic families. (AHT17, introduction and §§2–3.)

The six standard scalar conclusions, in the DLMF normalization and on their ordinary differential-equation domains, are:

| Equation | Coordinate expression |
|---|---|
| PI | q″ = 6q² + t |
| PII | q″ = 2q³ + tq + α |
| PIII | q″ = q′²/q − q′/t + (αq² + β)/t + γq³ + δ/q |
| PIV | q″ = q′²/(2q) + 3q³/2 + 4tq² + 2(t² − α)q + β/q |
| PV | q″ = (1/(2q) + 1/(q − 1))q′² − q′/t + (q − 1)²(αq + β/q)/t² + γq/t + δq(q + 1)/(q − 1) |
| PVI | q″ = (1/q + 1/(q − 1) + 1/(q − t))q′²/2 − (1/t + 1/(t − 1) + 1/(q − t))q′ + q(q − 1)(q − t)[α + βt/q² + γ(t − 1)/(q − 1)² + δt(t − 1)/(q − t)²]/[t²(t − 1)²] |

Each row is a theorem about a chart and a specified parameter map. The symbols α, β, γ, δ are local to that row. The following explicit dictionaries fix the intended normalization; their admissible inverse charts and momentum transformations are part of the proof.

| Source variables and parameters | Standard variables and coefficients |
|---|---|
| IIS06 (1)–(2), with 2κ₀ + κ₁ + κ₂ + κ₃ + κ₄ = 1 | PVI: α = κ₄²/2, β = −κ₁²/2, γ = κ₂²/2, δ = (1 − κ₃²)/2 |
| VDPS09 PV system (2)/(5), with the scalar correction in §9.4 | T = t, Q = q/(q − 1); (α,β,γ,δ) = (θ₁²/2,−θ₀²/2,1 − θ∞,−1/2) |
| VDPS09 degenerate PV system (8) | T = t², Q = q/(q − 1); (α,β,γ,δ) = (θ₁²/2,−θ₀²/2,−2,0) |
| VDPS09 PIII(D₆), (14) | T = t, Q = q; (α,β,γ,δ) = (4(θ∞ + 1),−4θ₀,4,−4) |
| VDPS09 PIII(D₇), (19) | t = T², Q(T) = Tq(T²); (α,β,γ,δ) = (4(θ∞ + 1),−8,4,0) |
| VDPS09 PIII(D₈), (24) | t = T², Q(T) = q(T²)/T; (α,β,γ,δ) = (8,−8,0,0) |
| VDPS09 PIV, (29) | t = 2T, Q(T) = 2q(2T); α = −θ∞ − 1, β = −2θ₀² |
| VDPS09 PII Jimbo–Miwa, (39) | T = t, Q = q; α = (θ∞ + 1)/2 |
| VDPS09 PI, (45), choose c⁵ = 2 | T = ct, Q = c⁻²q; Q″ = 6Q² + T |

For the Flaschka–Newell coordinate (34), choose c³ = 2 and set T = −ct, U(T) = cq(t). Then U″ = U′²/(2U) + 2U² − TU − θ₀²/(2U). Retain a chosen exponent sign a = ±θ₀. On U ≠ 0, Q = (U′ − a)/(2U) is the PII variable with α = a − 1/2; conversely U = Q′ + Q² + T/2. The exceptional branch U = 0, a = 0 cannot be reconstructed by division and keeps its full phase data. The square-time comparisons are local biholomorphisms on their nonzero domains or comparisons on the indicated covers; they are not global changes of coordinate on the same punctured line.

**API.**

- Export one comparison package per listed presentation, containing the explicit formulas, parameter map, inverse jet chart and overlap maps.
- Compare the source-specific Hamiltonian and the convention of §3.3 by equality of extended forms.
- Identify all excluded denominators and the phase charts through their allowed zero loci.
- Deduce the standard scalar Painlevé property from §5.5 on every observer stratum covered by the comparison.

**Checks.**

- There are ten presentation rows and eight boundary types; identifying every row with a different classical equation fails both counts.
- The standard PI scaling above changes both q and t. Rescaling t alone does not recover the coefficient 6 of q².
- PII's two linear-system presentations have different local singularity data; equality of their scalar solution formulas is not equality of input objects.
- A PIII comparison with γ = 4, δ = −4 cannot cover γ = δ = 0 by a nonzero scaling; the latter belongs to the boundary analysis of §9.3.

*Needs:* §§1.4, 2.1–2.4, 3.1–3.4, 5.5, 6.2 and 9.1. Connection matrices, scalar equations and coordinate Hamiltonians are conclusions of this layer.

### 9.3 Complete coefficient-boundary coverage

Classify all coefficient tuples of the standard PIII and PV displays by admissible nonzero scalings and inversions, proving their exact domains and inverse substitutions. The primitive Painlevé profiles and the elementary boundary equations are different outputs; a leading irregular coefficient zero is not a point inside a stratum defined by its nonvanishing. (FM19, §1.1 and equation (2); DIL21, §§5.2–5.3 and Appendix B.3; DLMF, equations 32.9.6 and 32.9.12.)

| Display | Coefficient condition | Comparison target |
|---|---|---|
| PIII | γδ ≠ 0 | D₆ profile |
| PIII | γ = 0 and αδ ≠ 0, or δ = 0 and βγ ≠ 0 | D₇ profile, with the inversion comparison between the two orientations |
| PIII | γ = δ = 0 and αβ ≠ 0 | D₈ profile |
| PIII | α = γ = 0, or β = δ = 0 | quadrature/elementary boundary |
| PV | δ ≠ 0 | ordinary PV |
| PV | δ = 0 and γ ≠ 0 | degenerate PV presentation |
| PV | γ = δ = 0 | quadrature boundary |

Prove that the PIII cases cover all tuples; the two elementary alternatives may overlap and are combined into one boundary class. Derive the boundary integrations on their stated time/observer domains, with branches and integration constants retained, and compare limiting initial data when a geometric degeneration is claimed. PIII with all four coefficients zero gives q = C exp(μ log t) on a chosen cover of ℂ*, including its nonzero-solution domain. A generic such power is not a single-valued function on ℂ*. Zero/constant solutions introduced by clearing q denominators require a separate original-equation domain check. These examples prevent the primitive classification from silently losing coefficient values.

*Needs:* §9.1–9.2; FormalLaurentPuiseux L1–L7 only for formal substitution algebra; ordinary complex differentiation and local branch/covering theory. The geometric collision theorem itself remains in Layer 11.

### 9.4 Hamiltonian, sigma and linear-system realizations

For each admitted presentation, derive the displayed Hamiltonian system from h and ω, and derive the Lax-pair compatibility from the same strong total connection. For sigma equations, transformations and tau logarithmic derivatives, state a forward lemma and a converse only on the locus where the reconstruction has been proved. Track additive Hamiltonian functions of time, multiplicative tau normalizations, branch choices and exceptional derivatives explicitly. (DLMF, §§32.6–32.7; VDPS09, §4; IIS06, Theorem 10.13; BERT17, Proposition 2.3 and Theorem 3.3.)

The source sign comparison is itself a lemma. In VDPS09 §4.1 the displayed equations p′ = F H_q, q′ = −F H_p, with F depending only on q, have kernel form dp ∧ dq/F + dH ∧ dt. The printed minus sign in that extended form is inconsistent with those equations, including the PI instance (44), (46), (47). On F ≠ 0, set Q = q, P = p/F(q), K(Q,P,t) = −H(F(Q)P,Q,t), using the source's argument order H(p,q,t); then dQ ∧ dP + dK ∧ dt is the negative of the correct source form and gives the convention of §3.3. Verify this identity directly before importing any source Hamiltonian.

VDPS09's printed PV equation (3) also disagrees with its system (2) and Hamiltonian (5). Differentiating q′ = 2p/t gives the exponent term [θ₀²(q − 1)² − θ₁²q²]/[2q(q − 1)t²], in place of the printed θ₀²/(2qt²) + θ₁²/[2(q − 1)t²]. At t = 1, q = 2, p = 0, θ₀ = 0, θ₁ = 1, θ∞ = 1, the compatible system gives q″ = 2 while the printed scalar equation gives 7/2. The comparison uses the re-derived expression and then the PV substitution of §9.2.

For sigma reconstruction include the derivative-nondegeneracy hypothesis and analytic extension argument. For example, the PI sigma relation (σ″)² + 4(σ′)³ + 2tσ′ − 2σ = 0 admits σ ≡ 0, whereas q = −σ′ ≡ 0 does not solve q″ = 6q² + t. Thus the unqualified reverse implication is false. On the branch σ″ not identically zero, differentiating and then extending the resulting analytic identity gives the required reconstruction. The entire excluded branch is σ = at + 2a³ with a constant; its q = −a never solves PI on an open time domain. This explicitly identifies the spurious scalar branches of this sigma relation.

*Needs:* §§3.3, 7.1–7.2, 8.3–8.4 and 9.1–9.3. Compatibility identities are verified on the original domains, and are extended only by an actual analytic or algebraic continuation theorem.

### 9.5 Concrete normalizations and special-solution checks

Prove the PI chart H = p²/2 − 2q³ − tq and the PII chart H = p²/2 − (q² + t/2)p − (α + 1/2)q from the corresponding moduli charts, and apply §9.1. The PII jet inverse is p = q′ + q² + t/2. The polynomial chart covers all finite (q,q′), while poles use the other phase charts. Establish its parameter dictionary with §9.2. (VDPS09, §§4.10–4.11; DLMF, §§32.2, 32.6 and 32.9.)

**Checks.**

- At α = 0, q = 0 and p = t/2 form a horizontal section in this chart.
- At α = 1 and t ≠ 0, q = −1/t and p = 2/t² + t/2 satisfy both Hamilton equations; at t = 0 their geometric continuation uses another chart.
- At α = −1/2, p = 0 is invariant and q′ = −q² − t/2. Setting q = u′/u gives u″ = −tu/2 on u ≠ 0; this is the projective linearization of §7.3, with zeros of u interpreted in ℙ¹.
- H ↦ H + c(t) leaves both tests horizontal, but changes a normalized Hamiltonian tau representative by the corresponding exponential primitive when the identity of §8.4 applies.

Construct the rational and classical-function families generated from the proved seed objects by §§7.1–7.2's admitted transformations, and prove their formulas only as the resulting coordinate lemmas. No completeness classification of all rational or algebraic solutions is imported from these few seeds.

*Needs:* §§7.1–7.3, 8.4 and 9.1–9.4; the actual chart/domain and parameter comparisons. Hastings–McLeod is not constructed here.

### Examples

The scalar equation may have an apparent denominator at a perfectly regular geometric initial point. Conversely, a denominator-cleared polynomial identity may admit functions absent from the original equation. The first-jet chart and the observer comparison resolve both issues without changing the intrinsic solution definition.

### Dependencies

Layers 1–8, with §9.1 supplying one scalarization theorem. This layer consumes geometric existence, continuation, symplecticity and functorial transformations; it does not supply them back to the earlier layers.

## Layer 10: normalized analytic and distinguished solutions

### 10.1 Boundary and sectorial selection data

Define boundary-selection data over the admitted geometric time family: an end and sector or specified approach path; its time coordinate and branches; local formal and Stokes data with a framing; any lattice, parabolic or resolution datum needed to select a de Rham lift; and a normalization for the requested observable or tau representative. Define equivalence by the actual marking transformations. The record contains no solution and no existence or uniqueness assertion. A specification becomes a characterization only after its analytic realization theorem. Linear Stokes data at a spectral singularity and nonlinear asymptotics at a time boundary are different constructions, connected by the theorem. (ILP18, §1.4 and §§3.3–3.4, 4.2–4.3, for the distinction in concrete realizations.)

**API.**

- Construct restriction to a smaller sector, branch change and transport of a boundary specification under a geometric comparison.
- Formulate realization by a normalized RHP and recovery of a decorated phase point without putting either result into the input definition.
- State uniqueness for the specified normalized problem and its selected lift, then prove equality with the intrinsic horizontal section constructed from that point.
- Define a connection constant as the comparison between two stated asymptotic normalizations of the same section along a specified continuation path.

**Checks.**

- Identical formal power-series asymptotics can leave exponentially small/Stokes freedom; that truncated specification does not automatically select one solution.
- Coarse monodromy data with a nontrivial exceptional RH fiber does not identify a unique phase point without the required lift data.
- Rescaling the observable or tau frame changes numerical asymptotic constants; equivalence of underlying horizontal sections does not erase that normalization.

*Needs:* §§4.1–4.3, 5.1–5.4 and 8.2–8.4; the marked coordinate and first-jet comparisons of Layer 9 only when a conventional scalar normalization is requested.

### 10.2 A common small-norm RHP existence engine

Construct the analytic engine on a fixed oriented contour with bounded Cauchy boundary operators on L². After the chosen parametrix reduction, require a residual jump I + w_s with w_s ∈ L² ∩ L∞, the stated endpoint/vertex compatibility, determinant-one condition and normalized growth class. Define C_w f = C₋(fw) and assume ‖C_w‖ ≤ ρ < 1 uniformly in the claimed parameter domain. Solve ν = C₋w + C_wν in L² by the Neumann series; recover μ = I + ν and the normalized RHP through its Cauchy transform. Using ν avoids assuming the constant identity matrix belongs to L² on an unbounded contour. Prove uniqueness, error estimates and holomorphic dependence for Banach-holomorphic parameter families. Add the weighted moment bounds needed to read coefficients at infinity. (ILP18, §3.3, Lemma 3.3, is a concrete parametrix application; the general operator argument and its exact contour hypotheses are a construction here.)

When the residual jump came from the original geometric local models through the specified parametrix reduction, undo that reduction, recover the decorated connection using §4.1, and prove that its parameter variation is the horizontal splitting of Layer 3. An arbitrary small L² jump does not by itself specify a meromorphic connection with the required poles. For a problem outside the small-norm domain, supply a vanishing lemma or a different invertibility argument and prove its hypotheses. No universal solvability assertion is obtained merely by writing down jumps.

**API.**

- Construct residual-jump operators, their uniform inverses and quantitative dependence on the jump.
- Produce sectorial solutions and coefficient asymptotics from the prescribed error and moment estimates.
- Compare solutions on sector overlaps by uniqueness, and then continue the recovered horizontal section by Layer 5.
- Distinguish an invertible normalized RHP from the stronger claim that an unaugmented coarse monodromy datum selects a unique exceptional phase point.

**Checks.**

- Identity jump gives the normalized identity matrix and zero residual error.
- The estimate ‖ν‖₂ ≤ ‖C₋w‖₂/(1 − ρ) records the necessary loss as ρ approaches one; it does not provide a uniform estimate at ρ = 1.
- Failure of the small-norm hypothesis does not prove nonsolvability. A separate invertibility or vanishing-lemma argument can still apply.

*Needs:* §10.1; §4.1's sectorial analytic reconstruction; native L² and bounded-operator/Neumann-series theory; Cauchy boundary operators and the exact contour estimates constructed here; §§3.1–3.2 and 5.1–5.3 for horizontal comparison and continuation.

### 10.3 Two precisely scoped connection-formula realizations

Translate ILP18 Theorems A and B into the boundary language, prove their normalized RHP realizations and transfer their endpoint and constant-ratio identities to §8's section. Keep the parameter dictionaries and branch choices explicit. The targets are the following source loci, not all parameters of the corresponding equations.

For Theorem A use the four logarithmic residues with eigenvalues ±θ_ν, 2θ_ν ∉ ℤ for ν = 0,t,1,∞, the marked monodromy cubic (1.16), and σ = σ₀ₜ, ρ = σₜ₁ satisfying σ,ρ ≠ 0 and 0 ≤ Re σ, Re ρ < 1/2. Require every member of the following four sets to avoid ℤ: {θ₀ ± θₜ ± σ}, {θ∞ ± θ₁ ± σ}, {θ₁ ± θₜ ± ρ}, {θ∞ ± θ₀ ± ρ}, with both signs independent. These are (1.13) and (1.17). With the source's t ∈ (0,1) endpoint branches and JMU normalization, prove its asymptotics (1.18a–b) and C₁/C₀ equal to the Barnes-G expression (1.19), using exactly the quantities (1.20–1.21). Propositions 3.20 and 3.24 and §3.9 supply the proof targets. Where an auxiliary denominator in (1.21) vanishes, use a proved continuation of the expression rather than totalized division.

For Theorem B use homogeneous PII, q″ = 2q³ + tq, and its source Stokes surface s₁ − s₂ + s₃ + s₁s₂s₃ = 0. Require s₁s₃ ≠ 1, Arg(1 − s₁s₃) ∈ (−π,π), s₂ ∉ ℝ and Arg(iϵs₂) ∈ (−π/2,π/2), where ϵ = sign Re(is₂) ∈ {−1,1}. These are (1.25). With d log τ = (q′² − q⁴ − tq²)dt, prove the two real-ray asymptotics (1.26) and C₊/C₋ equal to (1.28), with μ,ν from (1.27) and exp(iπη) = −iϵ/s₃. The literal η chart requires s₃ ≠ 0. Prove the stated η ↦ η + 2 invariance, normalization comparison and analytic extension to further allowed data; never assign an exponential logarithm to an undefined quotient. The proof locators are §§4.3–4.5 and Remark 4.8, with Barnes-function domains and removable limits explicit.

Separate the absolute-constant calibration in ILP18 §4.5 from the monodromy-dependent variational calculation. Its two additional inputs become supporting proof targets: the Airy determinant constant χ = (log 2)/24 + ζ′(−1) in DIK08 Theorem 1, (2)–(3), and the complex-sector pole-freeness in HXZ16 Theorem 2.1 needed for the contour deformation. Consume the existing Hastings–McLeod object and Fredholm identity from RandomMatrices §8.5; those contracts alone do not prove either additional input. The calibration consumer must establish these precise estimates, not add a second Hastings–McLeod existence theory.

**Checks.**

- A resonant exponent 2θ_ν ∈ ℤ is excluded from this PVI realization even though the corresponding decorated phase object may belong to the core theory.
- The PII source has α = 0. Its theorem does not become an arbitrary-α connection formula by changing a label.
- The Stokes triple (i,i,0) satisfies (1.25) but does not admit the literal η formula involving 1/s₃; the continued expression needs its own proof.
- Hastings–McLeod boundary Stokes data do not satisfy this generic PII input. Neither this theorem nor endpoint smoothness asserts absence of poles throughout every intermediate time interval.

*Needs:* §§10.1–10.2, 8.3–8.4 and Layer 9's actual parameter and normalization dictionaries; AnalyticNumberTheoryPartII §§4.3–4.3a for Barnes G, its functional identities, zero/pole domains and sectorial asymptotics; ILP18's local parametrices and uniform endpoint estimates; RandomMatrices §8.5 and the explicitly stated DIK08/HXZ16 calibration targets. No claim of closed formulas for every Painlevé connection constant is made.

### 10.4 The Hastings–McLeod bridge

Consume the scalar result already owned by RandomMatrices §8.5: its normalized real Hastings–McLeod solution of q″ = tq + 2q³, its uniqueness and real pole-freeness. At a regular real time t₀, use §9.1's first-jet inverse to construct the intrinsic phase point from (q(t₀),q′(t₀)). Apply §§5.1–5.3 and prove that the resulting horizontal section evaluates to the supplied scalar solution on its real domain and on the common analytic continuation. Prove independence of t₀ using uniqueness and the first-jet overlap comparison. The real initial values determine the local complex analytic solution; they do not by themselves prove its boundary behavior, which is consumed from the supplier.

The primary-source chart comparison is VDPS09 §4.10, translated to §9.5's momentum and Hamiltonian normalization. That source supplies the chart, not the Hastings–McLeod existence theorem consumed from RandomMatrices.

**API.**

- Construct the phase-point and horizontal-section bridge from the supplied first jet.
- Prove commutation with scalar evaluation and with continuation through changes of phase chart.
- Transport the supplier's reality and real pole-freeness assertions through that evaluation; retain its Airy normalization unchanged.

**Checks.**

- Replacing q ∼ Ai by q ∼ k Ai with k ≠ 1 does not satisfy the same supplier contract.
- Choosing a second regular real initial time produces the same horizontal section after transport, not a second distinguished solution.
- Real pole-freeness does not assert absence of poles at complex times, and the bridge does not infer that stronger statement.

*Needs:* RandomMatrices §8.5, through its §8.4 Airy/edge floor; §9.1's first-jet equivalence; §§5.1–5.5. Hastings–McLeod existence/uniqueness, its Fredholm identities and the Tracy–Widom formulas remain owned by RandomMatrices; this target adds no second supplier for them.

### Examples

The identity-jump model checks the RHP normalization. The generic PVI and homogeneous-PII loci distinguish a proved connection formula from an unrestricted all-parameter assertion. The Hastings–McLeod bridge checks interoperability with an independently owned scalar theory, without using its formula to define the intrinsic dynamics.

### Dependencies

Layers 3–5 and 8–9; the common analytic RHP engine constructed in §10.2; the precisely stated ILP18 parametrices; AnalyticNumberTheoryPartII §§4.3–4.3a; RandomMatrices §8.5 for the §10.3 calibration and §10.4 bridge. Asymptotic formulas are downstream normalizations of intrinsic solutions.

## Layer 11: geometric confluence and convergence

### 11.1 Collision families of geometric connection data

Construct confluence from a family of pointed curves and meromorphic connection data in which marked poles collide, with ordered marking, time rescaling, determinant comparison and a specified limiting local structure. A useful common local model is a finite flat family of divisors: away from collision its function algebra is a product of the separated point algebras, and at collision it is a truncated local algebra. Tensor with the fixed matrix Lie algebra, use its dual Poisson structure and residue pairing, and compare the corresponding connection data and reductions. Treat preservation of the chosen orbit, stability, ramified structure and phase-space charts as assertions to prove, rather than consequences of the divisor collision alone.

Use GMR23 Theorem 2, pp. 1391–1392, for a specified collision step with its Laurent scaling; Definitions 3–4 and Theorem 12, §4.2, pp. 1428–1429, for its ordered cascade and Takiff structure; and Theorem 13, §4.3, pp. 1435–1436, for its limiting Hamiltonians. The scaling polynomial, the nonvanishing time-change determinant and the actual orbit hypotheses remain explicit. Construct coordinate-independent comparison maps before expressing those formulas in local matrices. The source provides a common model, not an automatic adapter for every retained resonant or ramified stratum.

**API.**

- Construct the collision family, its special fiber and the comparison of the specified determinant/local structures.
- Prove Poisson and symplectic-reduction compatibility on the stated regular loci and identify any needed resolution or modification.
- Prove convergence of the pulled-back horizontal distributions in common local charts from the geometric deformation equations.
- Construct the required adapters to the selected classical profiles, including the stated limiting ramified and vanishing-leading-term boundary data; record excluded parameter faces explicitly.

**Checks.**

- A product of two simple-point algebras can specialize to a length-two local algebra; this is more data than simply substituting equal pole positions in a formula with a denominator.
- Confluence may require residues diverging with the collision parameter while a reorganized connection has a finite limit; bounded residues cannot be imposed silently.
- A leading coefficient reaching zero leaves its fixed generic irregular stratum. The limiting object must be placed in its new stratum or boundary comparison.

*Needs:* Layers 1–3; LieGroupoidsPoisson G4.6A and SymplecticGeometry/HamiltonianReduction R2–R3 for the underlying smooth real Lie–Poisson, coadjoint-orbit and reduction comparisons only; the complex algebraic/holomorphic Takiff bracket, residue pairing, reduction and family/normal-form adapters constructed in this target. Layer 6 enters where the chosen comparison uses its resolved or compactified phase charts. The analytic solution-convergence theorem follows separately.

### 11.2 A common compact-path solution-convergence theorem

Fix a compact piecewise C¹ time path γ avoiding the limiting fixed singularities and a reference horizontal lift x₀ along it. Require its graph to lie in finitely many common phase charts with a positive margin inside the comparison neighborhoods. After the prescribed time/phase identifications, assume F_ε → F₀ uniformly on a fixed neighborhood of this graph, a common local Lipschitz bound L in the phase variable, and matched initial points x_ε(0) → x₀(0). Prove existence of the compared lifts for sufficiently small ε and uniform convergence along γ. This is a general parameter-dependent ODE theorem applied to §11.1, not six confluence proofs based on scalar displays.

In one chart of path length ℓ, set δ_ε = sup ‖F_ε − F₀‖. The integral equation gives, until exit,

sup ‖x_ε − x₀‖ ≤ (‖x_ε(0) − x₀(0)‖ + ℓδ_ε) exp(Lℓ).

For small ε this bound is below the fixed boundary margin, so a first-exit argument prevents exit. Local existence extends the lift through the segment. A finite subdivision and uniqueness prove the result in all the charts. Holomorphic fields on a larger common neighborhood yield the derivative bounds by Cauchy estimates. A uniform theorem on compact time domains additionally states the common-cover, path-family and chart control used; convergence on one path does not provide those hypotheses. The source-supported field limit is GMR23 §4.3; the compact-neighborhood and no-exit transfer are explicit proof targets here.

**Checks.**

- Identical fields x′_ε = 0 with nonconvergent initial points do not give convergent solutions.
- Coefficient convergence on a chart does not control a trajectory that leaves every common neighborhood; the positive-margin hypothesis is used in the proof.
- The estimate is uniform on the fixed compact path. It does not assert uniform convergence on an unbounded time ray or across a limiting fixed singularity.

*Needs:* §11.1; §5.1 and gap:holomorphic-horizontal-lifts for local parameter dependence; Mathlib's `dist_le_of_approx_trajectories_ODE_of_mem` and `norm_le_gronwallBound_of_norm_deriv_right_le`, with their continuity, derivative and tube-membership hypotheses, and Tau Ceti's maximal-extension interface; the actual common-chart and derivative estimates of the collision family. The no-exit conclusion is proved here, not assumed in the Grönwall input.

### 11.3 The cascade as coordinate comparison

Construct the ordered differential confluence cascade on the geometric profile data of §11.1, including the claimed ramified targets and the separately identified elementary boundary strata. For each admitted arrow, choose the time and phase charts only after the geometric comparison is built; derive the scaled classical equation, its parameter map and its first-jet correspondence using Layer 9. Prove coverage of the arrow's stated parameter domain, the necessary nonzero scaling factors and the behavior of omitted charts. Apply §11.2 to obtain its solution limit for matched initial points. Composition of arrows means composition of geometric comparisons with compatible normalizations; an interchange of two limiting procedures requires an additional uniform theorem. (GMR23, Definitions 3–4, Theorems 2, 12 and 13; its Painlevé realizations in §5 have their stated scope and do not certify every additional adapter.)

**Checks.**

- Two paths to a profile can produce different time scales or parameter names; equality requires the comparison maps, not equality of the final classical label.
- An algebraic limit of a displayed equation without a first-jet inverse does not yet identify its phase points or solution germs.
- Successive limits with different allowable neighborhoods need not commute, even when the displayed limiting differential equations agree.

*Needs:* §§11.1–11.2; Layer 9's parameter dictionaries, first-jet equivalences and boundary comparisons; §3.4's functoriality. The classical scalar cascade is an output of these comparisons.

### 11.4 Normalized tau limits

Construct comparison isomorphisms of the determinant lines across an admitted collision family and specify the local frames and nonzero normalization factors, including any divergent factor to be removed. Fix a common regular base point and match the normalized values there. On a common simply connected domain away from the limiting divisor, prove convergence of normalized tau representatives when their corrected logarithmic derivative forms converge uniformly on compact path families. Integrate the difference along those paths, control the normalization constant and obtain locally uniform convergence. The forms are the corrected variational forms of §8.3, not an unverified identification with a scaled Hamiltonian. (BERT17, Proposition 2.3, formula (3.6), Theorem 3.3 and §3.1.2; BERT16, Theorem 2.2.)

Alternatively, where the line comparison is realized by local integrable kernels K_ε, construct controlled identifications with one fixed Hilbert space, including any moving-contour parametrization and measure factors, prove uniform trace-class norm convergence on compact parameter sets there, and use RandomMatrices §8.3's determinant continuity. This route can include zeros. Zero-count convergence in a fixed small domain requires a nonzero limiting determinant on its boundary and a limit not identically zero; prove that separate analytic consequence. Endpoint connection constants and nonlinear Stokes limits require uniform sectorial estimates near the time end and compatibility of their asymptotic normalization, in addition to §11.2's compact-path theorem. No unrestricted tau-adapter or connection-constant limit is asserted.

**API.**

- Construct the line, frame and common-Hilbert-space comparisons across the admitted collision.
- Prove normalized scalar convergence from either the corrected one-form estimates or trace-norm determinant estimates, with their distinct domains.
- Export zero-count or endpoint-constant conclusions only with their additional boundary and sectorial hypotheses.

**Checks.**

- Multiplying τ_ε by an uncontrolled ε-dependent nonzero constant leaves d log τ_ε unchanged but can destroy convergence; the base-point normalization is essential.
- For τ_ε(z) = z − ε, scalar determinants converge across the zero, while their logarithmic derivatives do not converge uniformly in a neighborhood of it.
- Convergence on every fixed compact time interval does not give a uniform endpoint asymptotic estimate, so it cannot alone determine the limiting connection constant.

*Needs:* §§8.1–8.4 and 11.1–11.2; RandomMatrices §8.3 for trace-norm determinant continuity; §10.2's uniform sectorial estimates only for the additional endpoint results; the explicit determinant-line and normalization comparisons constructed for the collision.

### Examples

A two-pole collision tests the local algebra and Laurent rescaling before its classical display. Constant fields with mismatched initial points test the necessity of the analytic hypotheses. The determinant family z − ε tests the difference between function convergence and logarithmic-derivative convergence at a zero. These examples prevent a formal coefficient limit from being mistaken for the full confluence theorem.

### Dependencies

Layers 1–3, 5 and 8–9; the constructed collision families and common local analytic estimates; GMR23's precisely scoped Poisson/Hamiltonian models; RandomMatrices §8.3. Layer 10 enters only when a confluence theorem additionally claims limits of distinguished asymptotic normalizations or connection constants.

## Downstream consumers

A later random-matrix or integrable-probability application can consume this intrinsic phase/observable bridge together with RandomMatrices §§8.3–8.5, preserving the existing ownership of Fredholm determinants, the Airy edge and Hastings–McLeod theory. Such a joint consumer is a new downstream target; the existing RandomMatrices roadmap is not retroactively made to depend on this one.

Further consumers include geometric special-function and connection-formula comparisons, moduli of irregular connections and character varieties, and controlled degeneration problems. They consume the proved horizontal, symplectic, continuation and normalization interfaces at their actual scope. A differential-algebraic classification of all irreducible transcendents, a complete classification of algebraic special solutions, discrete/q-difference Painlevé systems and cluster or Sakai-wide constructions are separate extensions. None supplies a premise to the intrinsic differential construction above.

Implementation order follows the dependency graph: the native geometric/analytic and specified supplier extensions, then Layers 1–5; the surface and tau branches may proceed after their stated prerequisites; coordinate comparisons follow the relevant branches; normalized analytic applications and confluence consume those comparisons. This order keeps the common definitions and theorems independent of the classical scalar displays.


## References

- **I23.** Michi-aki Inaba. *[Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation](https://sigma-journal.com/2023/013/)*. SIGMA 19 (2023), 013, 72 pages. Publisher version, 22 March 2023. Locators: Definitions 2.1–2.8; Remark 2.9; Theorems 5.1, 7.5, 8.1, 9.7 and 11.6; equation (6.9); Propositions 6.3, 7.2, 8.3, 10.7 and 10.10; Definitions 10.1 and 11.4; Corollaries 9.11 and 11.8; equations (11.2) and (11.5).

- **IS12.** Michi-aki Inaba; Masa-Hiko Saito. *[Moduli of unramified irregular singular parabolic connections on a smooth projective curve](https://arxiv.org/abs/1203.0084v3)*. Kyoto Journal of Mathematics 53(2) (2013), 433–482. Cited version: arXiv 1203.0084v3 (22 November 2012); the key retains the preprint year. Locators: Theorem 5.1; Remark 6.3.

- **HEU10.** Viktoria Heu. *[Universal isomonodromic deformations of meromorphic rank 2 connections on curves](https://www.numdam.org/item/AIF_2010__60_2_515_0/)*. Annales de l'Institut Fourier 60(2) (2010), 515–549. Published text through NUMDAM; printed pp. 515–549. Locators: Theorem 1.1; Definitions 2.3 and 2.10; §2.

- **VDPS09.** Marius van der Put; Masa-Hiko Saito. *[Moduli spaces for linear differential equations and the Painlevé equations](https://arxiv.org/abs/0902.1702v5)*. Annales de l'Institut Fourier 59(7) (2009), 2611–2667. Cited version: arXiv 0902.1702v5 (12 November 2009); remaining internal inconsistencies are identified in §9.4. Locators: §2.2, Table 1, preprint pp. 18–19; §3; §4.1 and §§4.3–4.11; equations (12), (17) and (22).

- **IIS06.** Michi-aki Inaba; Katsunori Iwasaki; Masa-Hiko Saito. *[Dynamics of the Sixth Painlevé Equation](https://arxiv.org/abs/math/0501007v2)*. Séminaires et Congrès 14 (2006), 103–167. Cited version: arXiv math/0501007v2 (6 March 2005). Locators: Definitions 2.1–2.2 and 2.11; Lemma 2.12; Definition 3.5; Theorems 4.10–4.12, 5.15–5.16, 7.4, 10.6, 10.10 and 10.13; §§5, 7 and 10.

- **BOA01.** Philip Boalch. *[Symplectic Manifolds and Isomonodromic Deformations](https://arxiv.org/abs/2002.00052v1)*. Advances in Mathematics 163 (2001), 137–205. Cited version: arXiv 2002.00052v1, the author's 2020 deposit of the 2001 article. Locators: §§3–6; Theorems 7.1 and 7.3; §7.

- **BOA14.** P. P. Boalch. *[Geometry and braiding of Stokes data; Fission and wild character varieties](https://arxiv.org/abs/1111.6228v3)*. Annals of Mathematics 179(1) (2014), 301–365. Cited version: arXiv 1111.6228v3 (22 September 2012). Locators: §10, Theorem 10.2; §7 for Stokes data.

- **BY15.** Philip Boalch; Daisuke Yamakawa. *[Twisted wild character varieties](https://arxiv.org/abs/1512.08091v1)*. arXiv preprint 1512.08091. Cited version: arXiv 1512.08091v1 (26 December 2015). Locators: Remark 3; Definitions 7 and 13; Proposition 19; Theorem 21; Corollary 22.

- **STT02.** Masa-Hiko Saito; Taro Takebe; Hitomi Terajima. *[Deformation of Okamoto–Painlevé pairs and Painlevé equations](https://arxiv.org/abs/math/0006026v2)*. Journal of Algebraic Geometry 11(2) (2002), 311–362. Cited version: arXiv math/0006026v2 (18 September 2000), the three-author article. Locators: Definitions 1.1 and 1.3; Proposition 1.2; Tables 2–3; Theorem 3.1; §6.

- **TER02.** Hitomi Terajima. *[Local cohomology of generalized Okamoto–Painlevé pairs and Painlevé equations](https://arxiv.org/abs/math/0006027v1)*. Japanese Journal of Mathematics, New Series 28(1) (2002), 137–162. Cited version: arXiv math/0006027v1 (5 June 2000). Locators: Theorem 2.1; Proposition 2.1; Conjecture 2.1.

- **ST04.** Masa-Hiko Saito; Hitomi Terajima. *[Nodal curves and Riccati solutions of Painlevé equations](https://arxiv.org/abs/math/0201225v1)*. Journal of Mathematics of Kyoto University 44(3) (2004), 529–568. Cited version: arXiv math/0201225v1 (23 January 2002). Locators: §2.4; Proposition 2.1; Definition 2.3; Remark 2.4; Appendix A.

- **FM19.** Andrea E. V. Ferrari; Lionel Mason. *[Meromorphic Painlevé III transcendents and the Joukowski correspondence](https://arxiv.org/abs/1809.07885v2)*. Journal of Integrable Systems 4(1) (2019), xyz001. Cited version: arXiv 1809.07885v2 (30 January 2019). Locators: §1.1; equation (2).

- **DIL21.** Jan Dereziński; Artur Ishkhanyan; Adam Latosiński. *[From Heun Class Equations to Painlevé Equations](https://sigma-journal.com/2021/056/)*. SIGMA 17 (2021), 056, 59 pages. Publisher version, 7 June 2021. Locators: §§5.2–5.3; Appendix B.3.

- **AHT17.** Primitivo B. Acosta-Humánez; Marius van der Put; Jaap Top. *[Isomonodromy for the Degenerate Fifth Painlevé Equation](https://sigma-journal.com/2017/029/)*. SIGMA 13 (2017), 029, 14 pages. Publisher version, 9 May 2017. Locators: Introduction; §§2–3.

- **MAL04.** Bernard Malgrange. *[Déformations isomonodromiques, forme de Liouville, fonction τ](https://www.numdam.org/articles/10.5802/aif.2052/)*. Annales de l'Institut Fourier 54(5) (2004), 1371–1392. Published text through NUMDAM; printed pp. 1371–1392. Locators: §2, printed pp. 1372–1374; Theorem 5.12.

- **BERT10.** Marco Bertola. *[The dependence on the monodromy data of the isomonodromic tau function](https://arxiv.org/abs/0902.4716v2)*. Communications in Mathematical Physics 294 (2010), 539–579. Cited version: arXiv 0902.4716v2 (20 January 2016); always used with BERT16. Locators: Assumption 3.1; §5.1, Proposition 5.1; Theorem 5.1 only with the correction BERT16.

- **BERT16.** Marco Bertola. *[Corrigendum: The dependence on the monodromy data of the isomonodromic tau function](https://arxiv.org/abs/1601.04790v2)*. Communications in Mathematical Physics 381 (2021), 1445–1461. Cited version: arXiv 1601.04790v2 (19 September 2020), published in 2021 as Correction to: The Dependence on the Monodromy Data of the Isomonodromic Tau Function. The key retains the initial 2016 preprint year. Locators: Definition 2.1; Theorems 2.1 and 2.2.

- **BERT17.** Marco Bertola. *[The Malgrange Form and Fredholm Determinants](https://arxiv.org/abs/1703.00046v4)*. SIGMA 13 (2017), 046, 12 pages. Cited version: arXiv 1703.00046v4, carrying the SIGMA publication text. Locators: §1; Theorem 2.2; Proposition 2.3; formula (3.6); Theorem 3.3; §3.1.2.

- **ILP18.** A. R. Its; O. Lisovyy; A. Prokhorov. *[Monodromy dependence and connection formulae for isomonodromic tau functions](https://arxiv.org/abs/1604.03082v4)*. Duke Mathematical Journal 167(7) (2018), 1347–1432. Cited version: arXiv 1604.03082v4 (29 October 2018). Locators: §1.4, Theorems A and B, equations (1.13), (1.16)–(1.21), (1.25)–(1.28); Lemma 3.3; Propositions 3.20 and 3.24; §3.9; §§4.3–4.5; Remark 4.8.

- **DIK08.** P. Deift; A. Its; I. Krasovsky. *[Asymptotics of the Airy-kernel determinant](https://arxiv.org/abs/math/0609451v2)*. Communications in Mathematical Physics 278 (2008), 643–678. Cited version: arXiv math/0609451v2 (21 June 2007). Locators: Theorem 1; equations (2)–(3).

- **HXZ16.** Min Huang; Shuai-Xia Xu; Lun Zhang. *[Location of Poles for the Hastings–McLeod Solution to the Second Painlevé Equation](https://arxiv.org/abs/1410.3338v2)*. Constructive Approximation 43(3) (2016), 463–494. Cited version: arXiv 1410.3338v2 (9 July 2015). Locators: Theorem 2.1.

- **GMR23.** Ilia Gaiur; Marta Mazzocco; Vladimir Rubtsov. *[Isomonodromic Deformations: Confluence, Reduction and Quantisation](https://doi.org/10.1007/s00220-023-04650-8)*. Communications in Mathematical Physics 400 (2023), 1385–1461. Publisher version of record, 1 March 2023, under CC BY 4.0. Locators: Theorem 2, pp. 1391–1392; Definitions 3–4 and Theorem 12, §4.2, pp. 1428–1429; Theorem 13, §4.3, pp. 1435–1436; §5.

- **DLMF.** P. A. Clarkson, *[Painlevé Transcendents, Chapter 32 of the NIST Digital Library of Mathematical Functions](https://dlmf.nist.gov/32)*. Version 1.2.8, released 15 September 2026. [§32.2](https://dlmf.nist.gov/32.2), equations 32.2.1–32.2.6; [§32.6](https://dlmf.nist.gov/32.6); [§32.7](https://dlmf.nist.gov/32.7); [§32.9](https://dlmf.nist.gov/32.9), especially equations 32.9.6 and 32.9.12. Standard scalar displays and normalization reference.
