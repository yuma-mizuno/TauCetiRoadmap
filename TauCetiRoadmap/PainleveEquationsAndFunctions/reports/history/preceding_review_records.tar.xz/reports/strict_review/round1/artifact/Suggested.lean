import Mathlib

/-!
# Painlevé equations and functions: target signatures

The roadmap is README.md. This file records the status of its intrinsic headline
theorems against the pinned Mathlib and Tau Ceti APIs; it does not replace that
roadmap.

The following headlines require carriers whose construction is part of the
roadmap or of its named suppliers. None can presently be stated on the pinned
APIs using only a few simple definitions on existing carriers.

* Intrinsic construction and classification of rank-two Painlevé data.
  Missing are families of pointed complex curves with irregular types, the
  corresponding parabolic meromorphic connection groupoids, ramified local
  descent, and the intrinsic structural polar-degree and local admissibility
  conditions together with their reduced deformation problem.
* Representability, deformation theory and the relative symplectic structure.
  Missing are the stable connection moduli functor, its rigidification and
  relative tangent complex, and the analytic realization of its moduli space.
* Construction and integrability of the isomonodromy splitting.
  Missing are the universal meromorphic connection, admissible deformation base
  and relative tangent sequence on the actual moduli family. A freely supplied
  horizontal distribution would not state the construction theorem.
* Full-stratum irregular Riemann–Hilbert correspondence.
  Missing are Stokes-filtered local systems with ramified descent, their
  parameterized moduli, and the actual Riemann–Hilbert map including resonant and
  reducible strata. The regular-singular and formal connection dictionaries
  alone do not provide these objects.
* Geometric Painlevé continuation and scalar meromorphy.
  Missing are the actual isomonodromy family and its Riemann–Hilbert comparison,
  together with meromorphic observables on the phase surfaces and the required
  treatment of indeterminacy. Native real integral curves and meromorphic
  functions on Riemann surfaces do not by themselves state this result.
* Intrinsic spaces of initial conditions and their boundary classification.
  Missing are the relevant marked rational surface pairs, their moduli,
  relative anticanonical divisors and the comparison with connection moduli.
* Modifications, symmetries and Riccati loci.
  Missing are elementary modifications on the connection groupoids, the
  induced correspondences between parameter spaces, and the invariant
  geometric loci and their projective-linear reductions. Invariant curves are
  not identified with reducibility without a separate comparison theorem.
* The normalized tau line and its determinant section.
  Missing are holomorphic determinant lines of the relevant index-zero
  Fredholm or Riemann–Hilbert families, the sewing identifications and the
  comparison with the isomonodromic differential. A line bundle or a closed
  differential form without those constructions does not define the target.
* Comparison with the classical scalar equations and their ten profiles.
  Missing are the intrinsic families above, their phase charts, the scalar
  observables and all normalization maps. Scalar differential equations on
  freely chosen functions would omit the intrinsic comparison theorem.
* Distinguished analytic solutions and the Hastings–McLeod comparison.
  Missing are the intrinsic monodromy/Stokes conditions that select horizontal
  sections and the scalar comparison with the solution owned by RandomMatrices.
  The general scalar existence theorem remains with its existing supplier.
* Controlled confluence of the intrinsic families.
  Missing are the degeneration families, parameter and frame identifications,
  limiting Stokes data and the topology in which horizontal sections converge.

Accordingly this file contains no theorem declarations. In particular, none of
the missing carriers is replaced by an unspecified predicate, an assumed
conclusion or an admitted data definition.
-/

namespace TauCetiRoadmap.PainleveEquationsAndFunctions

end TauCetiRoadmap.PainleveEquationsAndFunctions

