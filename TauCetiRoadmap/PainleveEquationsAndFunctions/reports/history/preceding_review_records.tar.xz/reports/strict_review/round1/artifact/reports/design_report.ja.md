# Painlevé ロードマップ：設計報告

2026-11-05。ドラフト。対象は `PainleveEquationsAndFunctions`。

## 完成した成果物

ロードマップ本文を **11層・44項目**で完成した。内訳は定義6、構成24、定理13、具体例1。定義・構成の各項目には API と3件以上の判別力のある検査例を付け、全体で API の法則114件、検査例112件を記載した。これらは今後実装・証明する契約であり、112件の Lean 証明を完了したという意味ではない。

本文 `README.md`、同一の `design/README.md`、構造化された `design/plan.json`、`sources.toml`、`metadata.toml`、`Suggested.lean`、レビュー・修正記録・検証スクリプトを収録した。Worker の CLI、lane、LLM ジョブ、投稿処理は起動していない。リポジトリを読む以外の GitHub 操作、push、issue、PR 作成は行っていない。

## 1. 採用した intrinsic な定義

主たる入力は、複素数体上の滑らかな射影曲線、印付きの構造的極因子、ベクトル束、指定 determinant connection、局所の形式的モジュライ条件、フィルトレーション・格子・分岐の降下データ、安定性の重みからなる。対象だけでなく、これらを保つ同型と基底変換も持つ groupoid として定義する。特定の自明束上の接続行列を全位相空間とはしない。

古典的 differential Painlevé の部分圏は、次の条件で切り出す。

- 曲線の種数は0、束の階数は2。
- 構造的極因子 P の次数は4。
- 局所データは本文 §1.1 の admissible な条件を満たす。対数点では graded residue と filtration を指定し、共鳴時に形式同型類一つを固定して許される Jordan・scalar strata を落とさない。
- determinant は固定残差を持つ regular-singular connection とし、動く曲線に沿った整合的な時間方向の拡張を構成する。determinant の次数が奇数でもよい。
- 安定性の一般的な重みを取り、非空な stable fiber を対象とする。
- 時間空間は、形式データの reduced versal deformation を座標変更で商して得る。

**時間が1次元であることも、位相空間が2次元であることも、Painlevé property も入力条件にはしない。** それぞれ別の定理として証明する。形式データの分類で使う Katz invariant は projective な指数であり、任意の scalar irregular twist の最大 slope ではない。一般の determinant は大きい入力圏で扱えるが、その余分な scalar deformation を古典的な1次元時間の計算に混ぜない。

この設計は `PI | PII | … | PVI` という有限型で定義を分岐させない。10個の接続 presentation、8個の加法型境界図式、6つの古典的 scalar equation は、後でこの入力から得る分類・比較の結果である。[I23, §§2–4; VDPS09, §2.2, Table 1.]

## 2. 接続モジュライを主構成に選んだ理由

| 候補 | 利点 | この設計での位置 |
|---|---|---|
| 装飾された有理型接続のモジュライ | 入力、変形複体、シンプレクティック形式、強い可積分拡張による時間発展を共通の構成にできる。分岐した局所データも扱える。 | 定義と主証明の基礎。Layers 1–5。 |
| Okamoto–Painlevé pair の変形 | 境界、初期値空間、反射、内部の −2 曲線と Riccati reduction を幾何学的に扱える。 | Layer 6 で主構成と比較し、Layer 7 で使用。 |

表面と反標準因子だけでは、正規化された時間方向のベクトル場は指定されない。また、最初の境界層から得る1次元空間と、全局所コホモロジーとの同一視を無条件に使うことはできない。そのため、表面側を定義の入口にして追加条件を暗黙に置くことを避け、接続から既に構成した分布との一致を証明する構造にした。[TER02, Theorem 2.1, Conjecture 2.1; STT02, Theorem 3.1.]

## 3. 時間発展を構成する仕組み

安定接続の族 π : M → B を構成した後、時間の接ベクトルに対する強い可積分拡張を構成し、その一意性から

h : π*TB → TM,  dπ ∘ h = id

を得る。h を任意に与えてから Painlevé と呼ぶ構成ではない。

全接続が取る微分形式は、動く全曲線 X と係数1の相対 Cartier divisor D に対して

Ω¹_X(log D) ⊗ O_X(P − D)

で intrinsic に指定する。局所座標 z、一次の時間変数 ε では dz/zᵐ と dε/zᵐ⁻¹ で生成される、というのが座標表示の補題になる。さらに filtration から得る kernel lattices を全接続が保存することを要求する。曲率ゼロだけで共鳴時の一意性を主張しない。[I23, Definition 10.1, (10.1), Propositions 10.7, 10.10.]

変形複体は、分岐点では次数0・1・2を持つ cone を用いる。単に「二項複体」とはしない。また [∇,−] は一般に O-線形でないので、coherent な項を持つ複素ベクトル空間層の複体として Čech hypercohomology と各項の Serre duality を組み合わせる。[I23, (6.9), Proposition 7.2.]

混合した二次の変形から flatness を証明し、trace pairing から構成した相対2形式の非退化性・閉性・水平輸送による保存を証明する。局所 Hamiltonian は、その後の表示である。

## 4. 関数と Painlevé property

一次的な解は初期点 x₀ を通る正則水平切断の芽 s である。条件は π ∘ s = id と ds = h。古典的な数値を取る関数は、許された observable Q を指定した後に Q ∘ s として得る。

大域継続の共通定理は、proper な写像 F : M → R が、既に構成した水平輸送を、完全な Betti transport に写す場合の no-escape theorem とする。コンパクトな時間経路の Betti 側の像はコンパクトであり、properness によって位相側の部分リフトもコンパクト集合に留まる。局所的な水平切断の存在・一意性で有限時刻の端を延長する。この議論は例外ファイバーで RH の逆写像を選ぶ必要がない。[IIS06, Lemma 2.12.]

普通の character quotient と、格子や filtration を保持する decorated reconstruction を区別する。共鳴時には非閉な Jordan orbit 一つでなく、trace 等の閉じた spectral constraints を使う。指数の logarithm parameter も保持する。

その後、普遍被覆上の大域水平切断、monodromy による元の基底への降下条件、observable の有理型継続を証明する。有理写像であることだけから、軌道上で定義されているとは言わない。indeterminacy locus に含まれる軌道や、恒等的に ∞ となる値も明確に区別した。

## 5. 全11層

| 層 | 内容 |
|---:|---|
| 1 | 入力 groupoid、時間変形、次数4の部分圏、形式 profile の分類 |
| 2 | 全束上の安定モジュライ、変形複体、次元、シンプレクティック形式 |
| 3 | 強い可積分拡張からの h、flatness、全2形式、naturality |
| 4 | sectorial/Stokes descent、character family、全 strata の RH 比較と properness |
| 5 | 解の芽、共通の継続定理、普遍被覆、observable と有理型性 |
| 6 | 加法型 Okamoto–Painlevé pair、8境界型、最初の境界層の時間直線 |
| 7 | 幾何学的変換・追加反射・関係式、内部有理曲線と Riccati reduction |
| 8 | 複素正則 Fredholm 行列式線束、RHP realization、τ切断と変分比較 |
| 9 | 共通一次ジェット補題、10 presentation の辞書、6式、係数境界、Hamiltonian・sigma・Lax 比較 |
| 10 | 境界・sectorial data、小ノルム RHP、厳密な適用範囲の接続公式、Hastings–McLeod bridge |
| 11 | 幾何学的衝突・Takiff 構造、共通コンパクト領域での解の収束、τの正規化された極限 |

座標表示は §9.1 の共通補題を介する。構成済みの分布が ∂t + A∂q + B∂p となるチャートで、J(t,q,p) = (t,q,A) が同型となる領域を指定し、その逆 p = P(t,q,q′) を使って

q″ = (A_t + A A_q + B A_p)(t,q,P(t,q,q′))

を得る。逆方向も同じ領域で証明する。J が退化する点や inverse branch を無視した scalar equivalence は主張しない。

PIII(D₆/D₇/D₈)、degenerate PV、Flaschka–Newell/P34 の比較まで明示した。PIII・PV の全係数について、primitive な型から外れる求積可能な境界も表に整理した。D7・D8・degenerate PV の時間変換には二乗写像の cover が必要であり、単なる定数倍として扱っていない。

## 6. レビューで修正した重要点

独立した担当者が前半、後半、最終辞書を読んだ。役割と確認範囲は各レビューに保存した。同じアシスタントの協働レビューであり、公式 Worker の承認や別機関の数学的査読とは表示しない。

- 一次元時間を仮定してから証明する循環を除去した。
- 任意 determinant の scalar irregular time と、classical な projective time を区別した。
- 分岐変形複体の三項構造、微分作用素としての線形性、strong extension の格子条件を修正した。
- 固定 determinant identification 後の scalar stabilizer は μ₂であることを明記した。
- Heu の普遍変形による継続ルートと RH properness の証明を分けた。継続だけから properness は出ない。
- 局所の elementary modifications だけでは PVI の中央反射を構成できないため、marked-pair 側の追加反射の構成と延長を目標に加えた。
- Riccati locus を、どの presentation でも「大域的に可約な接続」と同一視する誤りを除いた。
- τは line と section として構成する。任意の補助 modification は零因子を変え得るため、unit による比較は証明済み Fredholm equivalence に限定した。
- VDPS09 の実際の PDF に残る extended-form の符号と PV scalar equation の不整合を確認し、互換な系から導き直す訂正を記した。
- PI sigma equation の無条件の逆向き再構成を棄却した。σ = at + 2a³ は sigma 式を満たすが、対応する定数 q は PI を解かない。
- 正式な supplier の節と native declaration の完全修飾名を確認し、誤った F6.2 normal-form 帰属と maximal-integral-curve theorem の namespace を修正した。

## 7. 文献の射程と、これから証明する目標

全44項目は形式化の目標である。その中でも、引用した文献の狭い結果だけではそのまま達成できない拡張を明示した。

| 目標 | 追加の共通証明が必要な内容 |
|---|---|
| §4.2 | 分岐した Stokes groupoid に対する、deck action と整合する family transport |
| §4.4 | 全許容パラメータ・stable strata での族としての RH properness。一様 lattice bounds、decoration の延長、semistable replacement、位相比較 |
| §6.2 | 全 profile・全チャートのモジュライと表面の補集合との大域比較 |
| §6.3 | 最初の境界層の直線の族での base change と時間方向の同定 |
| §7.2 | 追加反射の構成、水平・シンプレクティックな延長、関係式 |
| §8.2 | 共鳴・分岐を含む index-zero RHP realization と許された降下・比較 |
| §10.3 | 適用範囲を限定した接続公式と、絶対定数の校正に必要な追加評価 |
| §11.1 | 複素 Takiff と各幾何学的 collision の実際の共通近傍、安定性・分岐の比較 |

これらを「文献上まだ未解決」とは断定していない。今回の資料が直接与える範囲を超える、ロードマップ自身が所有する証明課題という位置づけである。一般位置の結果を全パラメータの定理と読み替えていない。

一般的な supplier 拡張は2件に分けた。

1. `SmoothBundlesConnectionsPartII`：正則 Ehresmann splitting の局所水平切断と、初期条件・補助パラメータへの正則依存。
2. `HeegaardFloerPartII`：複素正則 index-zero Fredholm family の行列式線束と標準切断、stabilization と cocycle、正則基底変換。

既存 `RandomMatrices §8.5` の Hastings–McLeod 存在・一意性、実軸上の pole-freeness、Fredholm/Tracy–Widom identities の所有は維持した。本ロードマップはその解を intrinsic な水平切断へ送る bridge を作る。元の RandomMatrices に逆向きの依存を追加していない。

## 8. 検証と Lean の現状

固定した Mathlib と TauCeti のソースを確認した。最終依存図は44頂点・215本の内部依存で、循環と後方への前提参照はない。定義・構成の API、112検査例、出典 ID、named gap、README と plan の対応、ソースの provenance を検査した。符号・係数・退化分類などの脆い箇所には11組の有理数による計算検査を加えた。

23文献のうち22件は取得した本文の実バイト列の SHA-256 を照合した。DLMF は公式の表示本文を読んだが、生の取得が403になったためハッシュを捏造せず `uncertified` とした。manifest の `certified` は取得 provenance の意味であり、数学的証明の認証ではない。

現在の pins には、必要な接続モジュライ、Stokes/ramified character families、τ line の主要な型がまだ揃わない。従って `Suggested.lean` は11個の主目標と欠けている型を列挙し、**宣言数0**とした。結論を仮定する Prop、admitted なデータ定義、無関係な scalar 恒等式で主目標を代用していない。

指定された Lean 4.35.0-rc3 の公式 runtime はこの環境で `error: failed to locate application` となり、elaboration は完了していない。静的な形式・依存・出典検査の成功と、Lean のコンパイル成功を混同しない。ロードマップと監査パッケージは完成したが、そこに列挙した理論の形式化は今後の実装対象である。

主要文献の完全な書誌、版、定理番号、取得情報は `sources.toml` と本文 References に、修正履歴は `reports/review_resolution.md` に収録した。
