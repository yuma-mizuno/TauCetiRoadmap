# Final structural and dependency contract review

## Scope and result

This review reads the integrated README and design/plan.json, checks them against the pinned TauCetiRoadmapWorker prompts and pure validators, and checks the native prerequisites against the pinned source declarations. It does not invoke the Worker, a lane, a job-board action, a remote mutation, or Lean compilation. README and plan were not edited by this reviewer.

The intrinsic build order, all 44 target headings, definition/construction APIs and checks, the two named supplier gaps, and the RandomMatrices ownership direction pass the checks described below. Issues found during review are recorded with their repair status rather than hidden by a blanket acceptance claim.

### Remaining at the report snapshot

- C06: the FormalConnectionsOpers F6.2 normal-form attribution remains in README and/or plan.

The source-manifest provenance status is separate from the mathematical truth of any planned target. This is an independent local draft review, not official Worker acceptance or a formalization certificate.

## Reviewed snapshot

- README: 1084 lines; SHA-256 `720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`.
- design/plan.json: SHA-256 `f267cb3b55cfdc5c858035ed69132f5487416d5fbf855ed1230ce0c21f7656fd`.
- Worker contract: `46e12afb791b1efab8fd8b3285370d689ba2e7b8`.
- Roadmap main: `a0ad405e151ff6e42b3c5e372ac3f24e168ad68f`.
- Mathlib: `f6090c7095e1e56b3464c1daba5f24631f1290d2`.
- Tau Ceti: `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`.
- Lean toolchain recorded by the draft: `leanprover/lean4:v4.35.0-rc3`.

The two source checkouts' actual Git HEADs were reread and equal the Mathlib and Tau Ceti pins above. The README was read in chunks through all eleven layers, downstream consumers and References. The final refreshed supplier and Needs paragraphs were reread after integration edits.

## Concrete findings and dispositions

| ID | Finding | Disposition at this snapshot |
|---|---|---|
| C01 | Target 10.4 used `locator.source = "RandomMatrices"`, although the documented locator schema requires a sources.toml ID. A roadmap prerequisite and a primary-source identifier are different fields. | Repaired: the locator now uses VDPS09 §4.10 for the PII chart, explicitly retaining Hastings–McLeod existence as the RandomMatrices §8.5 prerequisite. The locator does not attribute that existence theorem to VDPS09. |
| C02 | All three consumers used `name`, rather than the documented `roadmap` key. | Repaired: each now uses `roadmap` and explicitly says `proposed future consumer`. The names are not claims that these roadmaps already exist. |
| C03 | Every supplier evidence entry pointed to package report paths that did not yet exist. | Repaired: reports/worker_contract.md and reports/worker_contract_addendum.md are now present. |
| C04 | Layer 7 Dependencies called the RH identification “optional,” conflicting with the contract's fixed-scope wording. | Repaired: the remaining text describes the presentation-dependent comparison without offering an unspecified optional branch. |
| C05 | Target 5.2 cited `TauCeti.Manifold.maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo`. The basename exists, but that qualified name does not: Maximal.lean declares it in the root namespace. | Repaired: the prerequisite is `tauceti:maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo`. The earlier supplier audit's namespace sentence was also corrected in the package report. |
| C06 | Exact supplier contracts attributed finite-ramification normal forms to FormalConnectionsOpers F6.2. At its pinned head, F6.2 is the cyclic-vector/GL_n flag–oper theorem. The source's Scope lines 98–101 explicitly says finite-ramification normal forms belong to PadicDifferentialEquationsAndRigidCohomology RD.6.52a and are not used there. | Still present; correction communicated to the parent author. |
| C07 | The repaired target 10.4 now cites VDPS09 in the README, but VDPS09's manifest `cited_for` still lacked 10.4 when checked. | Repaired by refreshing the manifest target map. |

C06 is a genuine source-section attribution error, not a missing mathematical supplier: the correct RD.6.52a owner is already declared directly. Remove F6.2 from this roadmap's formal supplier bundle unless an actual cyclic-vector comparison is deliberately required. Preserve the direct RD.6.52a contract. This repair does not introduce a third gap.

An earlier intermediate snapshot omitted FormalLaurentPuiseux and LieGroupoidsPoisson/SymplecticGeometry from the opening Exact supplier contracts section. These subsections are now present, including the smooth-real versus complex-algebraic scope distinction. The tau branch's Needs now names SSF 1.22/3.3, ComplexComparisonPartII C0.3 and the OperatorTheory children explicitly and no longer imports properness merely through a broad Layers 1–4 label.

## Mechanical plan and README checks

The audited `lanes/design.py:validate_plan` and `supplier_gap_problems` functions were loaded from their source AST together with their unchanged regex constants. The README scanners and dependency routines were likewise evaluated as pure functions over local strings. No lane class or Worker entrypoint was instantiated or called.

The checks found:

- **11 layers; 44 unique targets; 27 supplier-contract entries; 2 named supplier gaps.**
- **30 definition/construction targets**, every one with a nonempty API and at least three README Checks and JSON tests.
- **114 API statements and 112 tests** overall; API/check statement lists agree between README and plan.
- Every target has a Needs line, and the captured `readme_needs` agrees with its README line after regeneration.
- README headings and JSON target IDs agree exactly and occur in the same order.
- Each layer ends with Examples and Dependencies: eleven of each.
- The pure plan validator returns an empty problem list. This validator does not itself resolve locator IDs, native names or section ownership; C01, C05 and C06 demonstrate why the independent checks are necessary.
- README scanners for LaTeX delimiters, TeX residue, PR numbers, process residue, private paths, layer IDs, target IDs and pinned in-repository blob links all return empty findings.
- The README-to-Suggested.lean own-identifier check returns no missing identifiers. The planned JSON API names are proposed names; they are not presented in the README as existing Lean declarations.

The Checks are not merely duplicate prose: the reviewed definitions/constructions include wrong-sign, zero-map, absent-descent, bundle-jumping, noninvertible jet, pole-domain, normalization and multiplicity counterexamples. The theorem/example targets with no API are not incorrectly counted as missing definition APIs.

## Internal target dependency graph

The plan contains **215 internal target edges**. Every referenced target exists. No self-reference, forward reference or strongly connected component of size greater than one was found. The listed numerical layer order is therefore a topological order for the target graph.

No prerequisite edge from Layers 1–5 points to Layer 9 or later. Thus the plan data preserve the stated separation: input, moduli, splitting, comparison and continuation do not depend on the displayed scalar equations. The surface branch and tau branch depend on their declared earlier constructions; the scalar, distinguished-solution and confluence targets consume them later.

Conditional dependencies are described rather than used as covert backwards edges. In particular, endpoint/connection-constant conclusions in 11.4 require the additional sectorial estimates from 10.2; the compact-domain determinant convergence statement has its separately stated hypotheses.

## Supplier gaps and exact ownership

Both gap entries pass the exact-sentence comparison against the README:

| Gap | Named owner and proposed target | Exact direct users |
|---|---|---|
| `holomorphic-horizontal-lifts` | SmoothBundlesConnectionsPartII, proposed H1 | 5.1, 11.2 |
| `complex-holomorphic-determinant-family` | HeegaardFloerPartII, proposed F0.0C | 8.1 |

The README has precisely the required `What <Supplier> must provide (gap:<slug>): <needs>` sentences, and each matches the plan's needs text. `neededBy` equals the actual direct gap prerequisites. Neither owner is `none`. These are openly missing supplier contracts, not claims that the base roadmaps already contain the extensions.

The holomorphic gap does not turn the merely smooth Ehresmann/flow floor into complex parameter-dependent existence. The Fredholm gap does not turn the real orientation line into a holomorphic complex determinant line. The latter now expressly includes the canonical section and stabilization/refinement/base-change comparisons. These are the two recorded external supplier gaps; internally owned all-strata RH, compactification, marked-surface reflection, RHP-normalization and confluence adapters remain explicit proof-development targets, with source-scope limitations recorded in prose and JSON.

## Native declaration verification

Every native prerequisite was matched to its actual declaration and surrounding namespace at the pins. The final required spellings are:

| Native name | Pinned source file | Scope checked |
|---|---|---|
| `AlgebraicGeometry.Scheme` | Mathlib/AlgebraicGeometry/Scheme.lean | Structure in `AlgebraicGeometry`, line 40. |
| `ContinuousLinearMap.IsFredholm` | Mathlib/Analysis/Normed/Operator/Fredholm/Basic.lean | Structure in `ContinuousLinearMap`, line 123; strictness, closed range, finite kernel/cokernel and complemented kernel are fields. |
| `IsProperMap` | Mathlib/Topology/Maps/Proper/Basic.lean | Root structure, line 77. |
| `IsProperMap.isCompact_preimage` | Same file | Line 210; proper map plus compact target set implies compact inverse image. |
| `MDifferentiable` | Mathlib/Geometry/Manifold/MFDeriv/Defs.lean | Root definition, line 278. |
| `mfderiv` | Same file | Root definition, line 336. |
| `MeromorphicAt` | Mathlib/Analysis/Meromorphic/Basic.lean | Root definition, line 36. |
| `dist_le_of_approx_trajectories_ODE_of_mem` | Mathlib/Analysis/ODE/Gronwall.lean | Root theorem, line 162; includes both trajectory tube-membership hypotheses. |
| `norm_le_gronwallBound_of_norm_deriv_right_le` | Same file | Root theorem, line 134; continuity on Icc, right derivative on Ico and norm estimate. |
| `maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo` | TauCeti/Geometry/Manifold/IntegralCurve/Maximal.lean | **Root namespace**, line 364. Requires the real C¹ autonomous-field and complete-model/manifold hypotheses present in the file. |
| `TauCeti.RiemannSurface.MeromorphicAt` | TauCeti/Analysis/Complex/RiemannSurface/Meromorphic.lean | Definition in `TauCeti.RiemannSurface`, line 74. |
| `TauCeti.RiemannSurface.MeromorphicAt.comp` | Same file | Theorem in that namespace, line 169; composition through holomorphic maps between native complex-curve carriers. |

The maximal-curve theorem is a compact-containment floor, not a ready-made complex Ehresmann path-lifting theorem. The roadmap supplies the path/local-flow application or the finite-neighborhood argument. The Grönwall theorem assumes membership in a tube; it does not supply the first-exit/no-exit proof. Target 11.2 explicitly owns that step. Native meromorphic-curve vocabulary is not an automatic higher-dimensional rational-map pullback theorem; the observer/admissibility comparison remains in 5.4–5.5.

No elaboration was attempted again. Existence of these declarations in source is not proof that a future Suggested.lean statement using them has elaborated.

## Source coverage and status labels

The References bibliography and sources.toml contain the same **23 work IDs**. Every primary source key used in a target subsection is represented in the manifest. The incidental strings OI-B23, OI-B30 and P34 are operator target labels or an equation name, not missing bibliography entries.

After C01's repair, every JSON `locator.source` is a manifest ID. C07 records the required follow-up to its `cited_for` bookkeeping. The sources retain 22 actual PDF-provenance records and a separately explained web-only DLMF record. No provenance status is interpreted as mathematical proof.

All 44 JSON targets carry planned formalization status. The draft states the restricted scope of published theorems and records common extensions as its own proof tasks. In particular, it does not present the all-strata properness target, full moduli–surface comparison, ramified family transport, or all normalization adapters as already formalized theorems. `draft_complete` concerns the document, while `formalization_complete` is false and the failed Lean elaboration is disclosed.

## External dependency direction and RandomMatrices

The pure dependency parser was run over this README and **27 cached audited roadmap READMEs**, including the relevant open heads and main/completed suppliers. It detects no cycle containing PainleveEquationsAndFunctions in that graph.

The direct proposed suppliers detected by that parser are AlgebraicModuliForArithmeticGeometry, AnalyticNumberTheoryPartII, ComplexComparisonPartII, FormalConnectionsOpers, and PadicDifferentialEquationsAndRigidCohomology. On a purely in-memory copy of ORDER, inserting this draft immediately after the last of those suppliers, PadicDifferentialEquationsAndRigidCohomology, gives no UPWARD/CYCLE/unknown-order finding for the draft. ORDER itself was not changed. The two proposed Part II gap owners are conditional prerequisites to be added before their consumer when actually created; this check does not pretend they already have jobs or merge-order entries.

RandomMatrices' pinned README contains no occurrence of PainleveEquationsAndFunctions, and the parsed graph has no RandomMatrices → PainleveEquationsAndFunctions edge. This draft consumes RandomMatrices §§8.3–8.5. Its downstream prose describes a future joint consumer rather than revising RandomMatrices. No new generic determinant or second Hastings–McLeod existence owner is exported back into the unchanged supplier.

The graph check is limited to the cached audited roadmap texts, not a freshly fetched exhaustive repository-wide graph. The local draft's new edges and the specified RandomMatrices direction were checked; repository submission and global gates were not run.

## Evidence locations

- Worker prompt: `_research/worker_contract_sources/prompts/design.md` and `prompts/sections/{readme-shape,dependencies,gaps-and-order,lean-form}.md`.
- Pure routines: `_research/worker_contract_sources/tauceti_roadmap_worker/{gates,depgraph}.py` and `lanes/design.py`.
- F6.2 ownership evidence: `_research/roadmap_proposed/FormalConnectionsOpers/README.md`, scope lines 94–101 and target heading at line 1845, at head `1aab7da18ead3b687f442771f7786d8f236ce155`.
- Native source trees: `_validation/mathlib` and `_validation/tauceti`, at the verified pins above.
- Previous detailed supplier evidence: package reports/worker_contract.md and reports/worker_contract_addendum.md.

Suggested.lean remains the documented zero-declaration case permitted when the intrinsic headline carriers are unavailable at the pins. This review does not add generic padding or infer a successful Lean build from textual checks.

## Final correction recheck

The author repaired C06 after the snapshot above. A direct reread confirms that the scope and exact contracts assign finite-ramification normal forms directly to PadicDifferentialEquationsAndRigidCohomology RD.6.52a. The remaining mention of FormalConnectionsOpers F6.2 correctly identifies cyclic vectors and expressly distinguishes it from those normal forms. No target prerequisite or formal supplier section in the regenerated plan names F6.2; the FormalConnectionsOpers contract is F2–F3, and the direct RD.6.52a dependency remains.

**C06 is closed. No concrete structural or dependency-contract finding remains from this review.** This recheck retains all limitations stated above: it is not Worker acceptance or a successful Lean elaboration.

Final rechecked hashes:

- README.md SHA-256: `720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`.
- design/plan.json SHA-256: `f267cb3b55cfdc5c858035ed69132f5487416d5fbf855ed1230ce0c21f7656fd`.
