# Independent review: Painlevé roadmap, Layers 1–6

Reviewed 2026-11-05 by the classification/scope reviewer. This is a review of the complete **457-line snapshot** saved as `review_front_classification.snapshot.md`, SHA256 `5af7e5c91bd60252994fa808db2466c5feb53a7e29fb9546ae6c3a08a81ad97c`. Line references below refer to that snapshot. Subsequent edits and Layers 7–11 were not reviewed in this pass. No main deliverable was edited.

## Findings requiring changes

### F1. The cited ramified deformation complex has three terms, not two

**Location:** §2.2, line 179; affects §2.3's tangent and duality construction.

The phrase “the actual two-term deformation complex” is incompatible with the construction cited. I23 §6, equations (6.6)–(6.9), printed/PDF pp.26–27, defines

\[
F^\bullet=\operatorname{Cone}\bigl(G^\bullet\to S^\bullet_{\rm ram}[1]\bigr)[-1],
\]

with nonzero terms in degrees 0, 1 and 2. The connection complex \(G^\bullet\) is two-term; the ramified factorization complex contributes additional deformation variables and relations. Explicitly, the displayed \(F^2\) contains the restriction/compatibility term and \(A^1\). Proposition 6.3 identifies the tangent space with \(\mathbb H^1(F^\bullet)\), and Proposition 7.2 constructs its pairing.

**Repair:** Start with the connection complex, then specify the cone, all its terms and both differentials. A two-term replacement is permissible only after an explicit quasi-isomorphism that respects determinant specialization, tangent classes, obstruction classes and the pairing. The roadmap must not silently discard the relation term.

**Additional carrier correction, independently confirmed after root raised it:** The commutator differential obeys

\[
D(fu)=df\otimes u+fD(u).
\]

It is a first-order complex-linear differential operator, not an \(\mathcal O_C\)-linear map. Thus \(F^\bullet\) is a complex of sheaves of complex vector spaces with coherent \(\mathcal O_C\)-module terms; in families its differential is linear over the relative base. Do not place it directly in \(D(\operatorname{QCoh}C)\). In I23 (6.9), the additional part of \(d_F^0\) is algebraic, and \(d_F^1\) consists of restriction, \(\delta\) and \(\Theta\), which are \(\mathcal O_C\)-linear. Acyclic affine Čech totalization and termwise coherent Serre duality, followed by the differential/trace compatibility, give the appropriate route.

### F2. Curvature zero and a lifted relative filtration do not define the unique horizontal lift

**Location:** §3.1, line 222, and its first check at line 233.

I23 Definition 10.1 uses stricter conditions than the prose states. Equation (10.1), printed/PDF pp.53–54, gives a sheaf of allowed total differentials generated locally by

\[
\frac{dz}{z^m},\qquad \frac{d\epsilon}{z^{m-1}}.
\]

At a logarithmic point the time coefficient is regular, in the moving coordinate vanishing on the marked section. Definition 10.1(iv)(a)–(c) also requires that the **total** connection preserve the kernel lattices determined by the logarithmic, unramified and ramified structures. Preserving only the structure of the relative connection is weaker.

**Concrete local counterexample to the weaker uniqueness claim:** Put \(A=\operatorname{diag}(1,0)\) and \(N=E_{12}\). Both

\[
d+A\,dz/z,\qquad d+A\,dz/z+z^{-1}N\,d\epsilon
\]

have the same relative logarithmic connection and are flat: \(d(z^{-1}N)+[A,z^{-1}N]dz/z=0\). They cannot be related by a regular gauge transformation equal to the identity at \(\epsilon=0\), since cancelling the time coefficient requires the meromorphic infinitesimal gauge \(z^{-1}N\). The pole bound in I23 excludes the second extension.

**Repair:** Define the allowed total-differential sheaf and the total preservation of all kernel lattices before stating existence and uniqueness. Then cite I23 Propositions 10.7/10.10 at precisely that scope. The roadmap's resonance coverage makes this requirement substantive.

### F3. The slope and time classification must remove the scalar determinant part explicitly

**Location:** conventions line 19; §1.1 line 88; §1.3 line 128; §1.4 lines 140–150.

The input allows an arbitrary prescribed determinant connection, whereas VDPS09's Table 1 is a determinant-reduced rank-two classification. “Katz invariant” without qualification normally refers to the full differential module. It need not equal the projective/trace-free slope used by the table.

For instance, I23 §4, equations (4.2)–(4.3), permits at a rank-two structural order-two ramified point the branches

\[
\nu_\pm=a\,dz/z^2\pm b\,dz/z^{3/2},\qquad a,b\ne0.
\]

The full module has maximal slope 1, while the branch difference, and hence the projective/adjoint irregular type, has slope \(1/2\). The latter is the ramified entry of the ten-profile table. A global square root of the determinant is neither necessary nor generally available.

**Repair:** Define the classification slope from the formal exponential differences or the adjoint differential module, and give the scalar reconstruction separately. State which scalar coefficients are fixed/external and which are quotiented from the time problem.

This also affects the one-time quotient. If an arbitrary irregular determinant is fixed literally and only its automorphisms are quotiented, it may remove the expected curve reparametrizations. For example, the fixed scalar connection \(d+z^2dz\) at a sole pole is not preserved by the full affine coordinate group. The count “three irregular coefficients minus two affine coordinates” therefore needs a **projective reduced time functor** with compatible reconstruction of the scalar determinant, or a stated determinant convention that is preserved by the relevant curve automorphisms. Merely renaming the slopes does not prove this quotient comparison.

**Agreed repair direction (root's subsequent proposal, not a re-review of an edited file):** Keep arbitrary determinants in the general input groupoid, but require a regular-singular determinant with fixed residues in the classical subcategory, transported with the moving marked curve. Prove the residue/degree compatibility and coherent coordinate/time-lift comparison; retain the ramified half-residue correction and odd degree. All ten standard profiles are to be shown to admit this normalization. Treat an arbitrary scalar irregular determinant as a separate rank-one strong-extension/twist branch, outside the one-time count. This resolves the identified determinant/time obstruction without a global half-determinant line.

### F4. The one-dimensional time condition is used as both an input and an output

**Location:** §1.3 line 122; §1.4 lines 140–146.

The definition includes “an admissible one-dimensional reduced time deformation”, then asks the following classification to prove the reduced-time assertion. This is not a contradiction if one-dimensionality is deliberately a hypothesis, but it leaves the intended characterization ambiguous. An arbitrary one-dimensional pullback, including a constant or nonversal curve in a higher-dimensional deformation base, is not the same object as the reduced universal deformation problem.

**Repair:** Construct the reduced formal-data deformation functor with the scalar/coordinate quotient of F3; specify its local versality and admissible marking cover; select the classical class by rank two, genus zero, structural degree four and the actual local conditions; then prove its reduced time dimension is one. Choose the one-dimensional charts after that proof. Alternatively retain dimension one as a restriction but stop claiming that it has been derived independently from the earlier definition.

### F5. Determinant fixing and scalar rigidification should not be conflated

**Location:** §2.2 line 191, “before determinant rigidification”.

The object already includes a determinant identification. For a stable rank-two object, scalar automorphisms preserving that identification lie in \(\mu_2\), not the unrestricted \(\mathbb G_m\); their infinitesimal Lie algebra in characteristic zero is zero. Rigidification of this finite scalar stabilizer is different from imposing the determinant condition on deformation theory.

**Repair:** Say that scalar stabilizers can remain after fixing the determinant, identify them as the determinant-preserving roots of unity in the simple case, and distinguish their rigidification from taking the trace-free infinitesimal complex. The existing odd-degree determinant check in §1.1 is good and should remain.

## Supplier precision: exact repairs for Layer 6

The broad phrases at lines 433, 449 and 457 can be replaced by existing precise contracts. The following were read in the cached roadmaps; they are specifications/suppliers, not a claim that every target is already implemented.

| Needed construction | Verified owner and scope |
|---|---|
| Coherent cohomology, affine acyclicity, flat base change | SchemeAndStackFoundations §2.6 |
| Cohomology with supports and local-cohomology comparison | SchemeAndStackFoundations §2.7, including the support localization triangle and Noetherian colimit-of-Ext comparison |
| Čech spectral sequences | SchemeAndStackFoundations §2.2 |
| Coherent duality and surface/curve Serre duality | SchemeAndStackFoundations §2.20; §3.3 for the vector-bundle curve specialization |
| Cartier/Weil/Picard class comparisons | SchemeAndStackFoundations §3.4 |
| Modifications and strict transforms | SchemeAndStackFoundations §4.11, using its blow-up suppliers |
| Strict normal-crossing boundary carrier | SchemeAndStackFoundations §4.17 |
| Surface intersection pairing | SchemeAndStackFoundations §5.9, including its stated bridge to AbundanceStatement §4A |
| Adjunction, surface Riemann–Roch, numerical lattice and Hodge index | SchemeAndStackFoundations §5.10 |
| Tensor, dual and locally free sheaf carriers | AlgebraicVectorBundles L0–L2; this roadmap explicitly does **not** own Picard schemes or intersection theory |
| Proper coherent pushforward, semicontinuity and the constant-rank cohomology/base-change theorem needed by the line \(L\) | JacobianChallenge Layer C |
| Picard algebraic space for the possibly reducible/nonreduced boundary \(Y\) | ComplexComparisonPartII C3.2d.2, assuming proper flat finite presentation and universal \(\mathcal O_B\cong p_*\mathcal O_Y\) |
| Identity-component Picard carrier | ComplexComparisonPartII C3.2f.1–C3.2f.2; the latter invokes AlgebraicModuliForArithmeticGeometry §7.9 and its full-structure component criterion |

The JacobianChallenge README was fetched at the same audited content revision `a0ad405e151ff6e42b3c5e372ac3f24e168ad68f` and is now cached under `_research/roadmap_sources/TauCetiRoadmap/JacobianChallenge/`. Its Layer D representability contract is for geometrically integral schemes, so that contract alone does **not** supply \(\operatorname{Pic}^0(Y)\) for a nonreduced or reducible anticanonical boundary. The more general Part II contract above does. The application must prove universal functions and the relevant one-dimensional smooth identity component; it must not import the properness of a smooth curve's Jacobian to the additive group \(\mathbb G_a\).

Likewise, SchemeAndStackFoundations §2.6 only supplies flat base change. The all-base-change assertion for the first-boundary line needs JacobianChallenge C's stated coherent-flatness and constant-dimension hypotheses, or a direct application-specific kernel calculation proving the same conclusion. The classical parameter bases are reduced/smooth, and the family is to be restricted to a fixed admissible relative-SNC stratum before using that contract.

The logarithmic tangent sheaf can be constructed in §6.1 as derivations preserving the boundary ideal; prove local freeness and the exact sequences using §4.17's SNC charts. This is a concrete construction in the comparison, not an unexplained generic supplier. The boundary intersection classification and the connecting-map/intersection-matrix identity likewise remain explicit application proofs. No additional generic gap is necessary once these precise contracts and application obligations are recorded.

## Points checked without finding a new logical defect

1. **The core architecture is intrinsic.** Layers 1–3 construct decorated moduli, their symplectic form and the horizontal distribution; none selects a PI–PVI scalar tag. The classification is intended as a theorem. F3–F4 make that intention precise.

2. **The degree-four dimension calculation is correctly qualified.** I23 Theorem 7.5 gives \(2r^2(g-1)+2+r(r-1)\deg P\) in its unfixed-determinant setting. The genus-zero rank-two value is 2, and the text explicitly warns that fixing determinant in higher genus removes additional directions. It does not infer one time merely from this phase dimension.

3. **Special strata are not removed.** Full bundles, generic stability chambers, repeated logarithmic eigenvalues, reducible stable objects and apparent marked singularities remain present. Leading-term vanishing is correctly a change of input stratum. Generic ramification forces global irreducibility, but the text correctly declines to infer absence of special solutions from that fact.

4. **No actual cycle was found at §3.2/§4.1.** The algebraic bracket/flatness theorem depends on infinitesimal lifts. Its interpretation as constancy of analytic Stokes data depends on §4.1; the latter only needs local analytic classification and the input. The separation must survive in the target DAG, as two theorem nodes rather than one block with a backward blanket dependency.

5. **The full all-strata Riemann–Hilbert properness result is honestly labeled a proof-development target.** §4.4 does not falsely cite I23's foliation or IS12's generic theorem as a full proof. It identifies boundedness, extension, stable reduction and gluing obligations. This is the main mathematical research burden of the uniform continuation route; this review does not certify that those four proposed steps already prove the desired theorem. Their exact hypotheses still require implementation-level proof development. The continuation theorem may depend on the target, but the roadmap must not report it as already established in the cited generality.

6. **The proper-semiconjugacy continuation argument is structurally correct.** The proper map is RH, not the phase projection. Compact containment plus local uniqueness works even with singular target or exceptional positive-dimensional fibers. Its compatibility hypothesis is required at every source point, which the draft explicitly demands.

7. **Observable germs are correctly limited.** A globally defined \(\mathbb P^1\)-map can be evaluated on every geometric section; ordinary meromorphic-function language excludes identically infinite evaluation. A rational observer needs a domain/lift proof. The example of \([x:y]\) on the constant zero curve correctly detects the otherwise invalid pullback. The scalarization layer must preserve these conditions.

8. **The surface scope is the intended eight-type scope.** Additive, nonfibered generalized Okamoto–Painlevé pairs with reduced SNC boundary exclude elliptic and multiplicative cases, and do not impose the old \(\mathbb A^2\)-chart condition that omits \(D_8\). The compactification is a theorem target, not a definition or a shortcut to global continuation. VDPS09's global comparison conjecture is not inflated to a theorem.

9. **The first-boundary line avoids the known conjectural premise.** §6.3 uses \(H^0(D,\Theta_S(-\log D)\otimes N_D)\), the proven one-dimensional object of TER02 Theorem 2.1/Proposition 2.1. It does not assume full local cohomology is one-dimensional for every parameter. Family base change, Kodaira–Spencer comparison and equality of distributions remain explicit proof obligations. A line is correctly distinguished from a normalized generator.

10. **Hamiltonian signs and gauge dependence are consistent.** With \(\omega=dq\wedge dp\), \(\iota_X\omega=dH\) gives \(q'=H_p,p'=-H_q\), and \(dq\wedge dp+dH\wedge dt\) annihilates \(\partial_t+X\). This local one-time expression should remain scoped to a one-dimensional time chart; the invariant total form itself also makes sense for a higher-dimensional flat symplectic connection.

## Guard for the unreviewed later layers

Do not define the intrinsic Riccati locus as “globally reducible connections” in every presentation. Generic ramified factors are globally irreducible by I23 Remark 2.9, but the ramified E7/Flaschka–Newell presentation realizes PII, which has Riccati parameter values. Invariant nodal curves or appropriately decorated exceptional RH fibers are the broader carrier; global reducibility is one mechanism in particular presentations. This is a scope warning, not an assessment of text in Layers 7–11.

## Source locators used in this review

- I23: §4 equations (4.2)–(4.3); §6 equations (6.6)–(6.9), Proposition 6.3; §7 Proposition 7.2, Theorem 7.5; §10 equation (10.1), Definition 10.1, Propositions 10.7/10.10; Remark 2.9.
- VDPS09: §2.2/Table 1, printed p.19; introductory global-comparison scope warning.
- STT02: Definitions 1.1/1.3, Proposition 1.2, Tables 2–3; Remark 6.1(2).
- TER02: Theorem 2.1, Proposition 2.1, Conjecture 2.1.
- ST04: Appendix A, Theorem A.2 and Remark A.1.

Primary PDF versions, URLs, hashes and extraction metadata are recorded under `_research/sources/`. The present report does not quote enough of any primary source to substitute for that source.
