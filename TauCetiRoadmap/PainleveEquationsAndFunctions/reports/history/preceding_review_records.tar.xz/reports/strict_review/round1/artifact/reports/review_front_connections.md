# Independent review of README Layers 1–6: connections and continuation

Reviewed the complete first-six-layer draft in `PainleveEquationsAndFunctions/README.md` on 2026-11-05. This is an internal research/review note, not a mathematical proof certificate. The principal construction is sound as a roadmap after the repairs below. In particular, the order “moduli → intrinsic splitting → analytic comparison → common continuation → coordinate realizations” meets the user's intrinsic-definition requirement. The classical formulas are not used to define the phase space or prove completeness.

## Required repairs

### R1. Do not impose the time dimension which Layer 1 subsequently proves

Section 1.3 currently includes “an admissible one-dimensional reduced time deformation” in the input class, while §1.4 promises to prove that the formal-profile quotient has one essential time. Remove “one-dimensional” from §1.3. Admit the relevant smooth marked deformation/quotient from §1.2, with its nondegenerate polar type and nonempty stable fibers; then prove the dimension in §1.4.

The actual calculation is conditional on the good local formal types and the quotient construction. For the degree-four rank-two class it is

\[
 n+\sum_i\lceil r_i\rceil-3=\sum_i m_i-3=1.
\]

The stabilizer/marking issue still needs verification; phase dimension two does not establish time dimension one. The ten-profile classification is consequently a theorem about the geometric input, not a disguised enumeration used in its definition.

### R2. The ramified deformation complex is not a two-term complex

Section 2.2 says “actual two-term deformation complex” and then appends factorized ramification terms. In I23 §6, equation (6.9), the factorized complex has degrees 0, 1, and 2; its last term is \(F^2=\mathcal G^1\oplus\mathcal A^1\). Use “the deformation complex, including the factorized ramification terms and relations” without the two-term assertion. If a two-term replacement is later useful, construct its quasi-isomorphism and establish its valid scope rather than assuming it.

This was independently identified by the classification reviewer. The rest of the proposed hypercohomology/pairing interface is appropriate, provided it applies to the actual complex.

### R3. Specify strong integrable extensions before asserting uniqueness

Section 3.1 currently asks only for zero curvature and local structures lifting the prescribed relative deformation. This is too weak to invoke I23's uniqueness at resonant logarithmic points. I23 Definition 10.1 and equation (10.1), printed pp.53–54, impose an allowed total-form sheaf whose local description in a moving polar coordinate is

\[
 \widetilde\Omega_v
 =\mathcal O\,\frac{dz}{z^m}
   +\mathcal O\,\frac{d\epsilon}{z^{m-1}}.
\]

For a logarithmic point, \(m=1\), the time component is regular in that moving coordinate. Moreover, the **total connection** preserves each kernel lattice associated to the logarithmic, unramified, and ramified flags:

\[
 \ker\bigl(E\longrightarrow E|_D/\mathrm{flag}_k\bigr).
\]

Add these conditions, or an invariant definition proved equivalent to them, to §3.1. Prove coordinate/presentation invariance of the allowed-form sheaf. Then use I23 Propositions 10.7 and 10.10 for the corresponding strong extension construction and uniqueness. Merely checking that each relative fiber is parabolic leaves room for a different resonant deformation problem, including non-Schlesinger directions.

The logarithmic example is especially useful as a check: a deformation with an extra polar time component is not automatically admitted because its total curvature vanishes.

### R4. Separate the decorated local groupoid from the ordinary character target

Sections 4.1–4.2 retain logarithmic lattices and flags to formulate a fully faithful local reconstruction. Section 4.4 seeks a proper map to ordinary generalized character data, where different stable parabolic objects may lie in the same fiber. Make the forgetful passage explicit:

1. construct the decorated local/Betti groupoid used in analytic reconstruction;
2. forget lattice/flag decorations to obtain ordinary Stokes representations;
3. pass to the affine invariant quotient, retaining the prescribed exponent \(\theta\) in a fiber product.

Do not accidentally define the §4.4 target as the decorated fine space, or assert that the coarse quotient classifies every individual object.

At logarithmic resonance, “prescribed formal monodromy constraints” needs further precision. Prescribe the appropriate **closed spectral-invariant constraints**, retaining every permitted Jordan stratum. For rank two with determinant fixed, these include a fixed trace. Fixing one nonclosed conjugacy orbit can discard the scalar limit of a nontrivial unipotent orbit, even though both are allowed by the same exponent data. A fixed-conjugacy-class symplectic leaf is useful on a suitable stratum but is not the whole all-parameter target.

### R5. Heu gluing does not prove properness merely by proving continuation

The second proof paragraph of §4.4 currently presents universal strong isomonodromic deformation plus “no-escape comparison” as an alternative proof of proper RH. This implication has not been justified and is generally unavailable: completeness of a source connection does not imply that a comparison map has compact fibers or is proper.

Keep §4.4's properness theorem as an independent required target if Layer 5 continues to use it. Alternatively, move the Heu route into a **separate proof of the continuation theorem**, with the full bridge obligations listed in the draft. That alternative can discharge GPP without discharging RH properness. Parent has already accepted this distinction.

### R6. Properness must be relative and include stable replacement

The target of §4.4 is plausible for the classical class, and the audit did not find a counterexample caused merely by generic stability weights. It is nevertheless not supplied at this full scope by I23 or IS12. Keep the source-scope warning and explicitly state the family-level map over the time/exponent base. Properness of every fixed-time map alone does not imply properness of the family.

The proposed proof decomposition is useful, with the following refinements:

- Bounded local lattices must be uniform over compact families of ordinary generalized characters, with exponent lifts retained; projectivity of flag fibers does not control the underlying lattice.
- Construct a relative parameter space for the compatible lattices, flags, factorized structures, and gluing data. Closed incidence conditions and a projective relative GIT construction are possible tools, but their hypotheses must be proved for the analytic RH problem.
- Prove semistable extension/replacement after the stated base changes and modifications, then use the chosen generic weights to identify semistability with stability. Stability is open; openness alone does not prove that a limit remains stable.
- State uniqueness for the stable replacement in the appropriate separated coarse/rigidified moduli problem. Do not claim that all initial lattices over a coarse character are unique.
- Compare the topology supplied by the parameter construction, analytic reconstruction, and the given coarse moduli space; then prove compact inverse images or an equivalent properness criterion.

This is a concrete proof-development target. It should not be described as a newly discovered open problem in the literature. IS12 Remark 6.3 is a direct scope warning for that paper, not a statement about all subsequent literature.

### R7. Small wording and dependency repairs

- Section 1.2's assertion that strong isomonodromy preserves “the actual local analytic type” should be qualified by the admitted variation of irregular type. The prescribed irregular polar coefficients move with time. Preserve the **transported analytic/Stokes datum, including the resonant/lattice decoration**, under that admitted deformation; do not assert that the fixed-coordinate meromorphic connection germ is literally unchanged.
- Section 2.4 may construct the exceptional algebraic strata immediately. Its assertion about their images in Betti space belongs to the later comparison of §4.3. Say “subsequently identify their Betti images” to make the dependency direction unambiguous.

## Betti transport: verified uniform references and remaining ramified task

Two supplementary primary sources give a better common foundation for §4.2 than the ten explicit cubic surfaces:

**BOA14:** Philip Boalch, *Geometry and braiding of Stokes data; Fission and wild character varieties*, Annals of Mathematics 179 (2014), 301–365, arXiv:1111.6228v3. Section 10 defines admissible deformations by constancy of the root pole orders. **Theorem 10.2**, printed p.50, constructs the local system of Poisson varieties, hence transport along all paths. Remark 10.3 also treats individual group orbits at the set level. Theorem 10.4 gives the framed local version. These results apply to the untwisted irregular types used in that paper; a ramified local formal type is not included simply because it becomes unramified on a finite cover.

**BY15:** Philip Boalch and Daisuke Yamakawa, *Twisted wild character varieties*, arXiv:1512.08091v1. Remark 3 gives a coordinate-independent exponential local system. Definitions 7 and 13 formulate the irregular class and twisted Stokes local systems. **Proposition 19**, printed p.17, relates the framed groupoid to twisted Stokes representations, with the change-of-framing action. **Theorem 21 and Corollary 22**, printed p.19, construct the twisted quasi-Hamiltonian/Poisson character spaces. Lemma 23 supplies the local finite-dimensional product description.

BY15 does **not** state a complete admissible-family transport theorem. Do not cite Theorem 21 as if it did. Use its intrinsic objects and adapt BOA14's transport argument to the rank-two good ramified class as a stated common proof task:

1. retain the exponential covering, grading, formal monodromy twist, and deck action;
2. trivialize an admissible marked family locally by an isotopy of the real oriented blow-up and its Stokes data;
3. induce equivalences of the twisted Stokes groupoids compatible with deck descent;
4. prove independence of choices, composition, inverse, and homotopy invariance;
5. descend equivariantly to the affine quotient and its fixed spectral-invariant locus;
6. concatenate local transport along finite chains covering a compact path.

For the generic rank-two local types, the nonzero leading exponential difference prevents a change of local slope or the relevant Stokes incidence pattern inside the admitted stratum. This makes the extension substantially more concrete than an unrestricted arbitrary-rank wall-crossing theorem. No separate cubic is needed to define transport. The proof still has to establish analytic dependence and compatibility with §4.3.

## Positive verification of the continuation argument

Sections 5.1–5.5 have the correct logical shape. With a holomorphic integrable splitting already defined **everywhere on the smooth phase space**, a proper semiconjugacy to complete Betti transport prevents finite-time escape. For a compact base path its Betti image is compact; properness puts every partial horizontal lift in a fixed compact subset of the source. Finite local ODE charts and uniform local existence extend the lift at a proposed terminal time. Local uniqueness glues the extensions.

This argument needs neither injectivity of RH nor a chosen inverse on an exceptional fiber. It does need compatibility for every local lift, including lifts initially contained in exceptional strata. The source must satisfy the finite-dimensional Hausdorff/local-flow hypotheses, and target transport must be continuous. The draft already records these points appropriately.

Universal-cover continuation follows from local uniqueness and flatness. Descent to the original time base is a separate fixed-point condition for nonlinear monodromy. Scalar meromorphicity also remains separate: an admissible observable must be defined along the horizontal section, with indeterminacy handled explicitly and the identically-infinite projective value excluded from the usual scalar-function conclusion. The draft does not conflate these conclusions.

The surface branch of Layer 6 is correctly downstream. Neither a completed rational surface nor a regular algebraic vector field on it alone proves GPP. A claimed moduli–surface identification must establish its own all-parameter and all-chart scope; it cannot be used to hide the properness/continuation target. The draft's separation of this comparison from Layers 1–5 is appropriate.

## Published scope which must remain visible

- I23 provides the mixed logarithmic/unramified/generic ramified moduli, deformation, symplectic form, and algebraic isomonodromic splitting. It does not itself provide the full §4.4 properness statement.
- IS12's RH isomorphism and GPP theorems impose generic unramified, nonresonant, irreducible hypotheses. Theorem 6.3's five displayed unramified families do not cover PI or the ramified presentations. Remark 6.3 explicitly distinguishes the needed resonant/reducible extension.
- IIS06 proves the all-parameter logarithmic comparison relevant to PVI and provides the abstract proper-semiconjugacy continuation pattern. It is not an all-ramified theorem.
- HEU10's universal deformation theorem is useful for a second uniform continuation route. Its §5.1 classical comparison has additional nonresonant/irreducible/trivial-bundle starting hypotheses. The bridge to I23's full decorated moduli is an actual task, not an automatic citation.
- BY15 supplies intrinsic twisted/ramified character spaces; BOA14 supplies the explicit complete-transport theorem in its untwisted admissible-family scope.

## Verified Hamiltonian sign issue in the main comparison source

The apparent minus sign in VDPS09 is real, not PDF extraction noise. PDF page index 41 (printed p.42), equations (44), (46), and (47), was rendered and visually inspected. The source displays \(q'=2p\), \(p'=3q^2+t\), and \(H=-p^2+q^3+tq\), but prints \(dp\wedge dq-dH\wedge dt\). This form does not annihilate the displayed time vector field. The compatible sign is **plus**.

The root draft's own convention \(dq\wedge dp+dK\wedge dt\), with \(q'=K_p\) and \(p'=-K_q\), is consistent. A separate audit gives the invariant conversion and a concrete contraction check: `_research/VDPS09_sign_audit.md`. Do not copy the source's extended-form sign without this correction.

## Primary URLs and local evidence

- I23: <https://sigma-journal.com/2023/013/sigma23-013.pdf>
- IS12: <https://arxiv.org/pdf/1203.0084v3>
- HEU10: <https://www.numdam.org/article/AIF_2010__60_2_515_0.pdf>
- VDPS09: <https://arxiv.org/pdf/0902.1702v5>
- BOA14: <https://arxiv.org/pdf/1111.6228>
- BY15: <https://arxiv.org/pdf/1512.08091>

Fetched PDF bytes, SHA256 hashes, page counts, and timestamps are recorded in `_research/sources/<ID>.json`; corresponding extracted text is cached beside each PDF. The sign evidence image is `_research/VDPS09_page42.png`.
