# Independent review: tail Layers 8, 10, 11

Reviewed `_research/tail_layers_tau.md` in full and checked the relevant cached primary-source passages on 2026-11-05. This review reports concrete changes, not a request for further open-ended research. The tail's main proof order is appropriate. The determinant-line construction, the distinction between a normalized RHP failure and a phase singularity, the small-norm engine, and the compact-path confluence argument are all substantially stronger than an equation-by-equation summary.

## Required correction: §8.2 auxiliary changes are too unrestricted

The second API bullet promises comparison isomorphisms for changes of “contour, factorization, normalization and auxiliary modification.” The last two categories are too broad if the comparison is required to preserve the same determinant section up to a holomorphic unit, as §8.3's global divisor construction then requires.

An arbitrary change of reference bundle/modification can change the normalized RHP's solvability locus and hence its tau zero divisor. Equal Fredholm index alone does not prevent this: adding a finite index-zero complex with differential multiplication by a parameter s multiplies the determinant section by s. Such a change is not an everywhere invertible stabilization.

**Concrete replacement.** Retain the reference bundle/modification and normalization as genuine marking input. Glue the line and section only under changes for which one has proved a holomorphic equivalence of the Fredholm families, or a chain/stabilization equivalence with an everywhere acyclic auxiliary complex, together with the determinant-functor compatibility. These comparisons give the required holomorphic units and cocycles. For a general auxiliary modification, construct the relative determinant factor or the appropriate meromorphic transformation law, and record the change of divisor. It is a comparison between different marked tau objects, not automatically an auxiliary-choice invariance.

Accordingly, adjust the corresponding §8.3 divisor-naturality claim and §11.4 line comparisons to refer to **these proved equivalences**. A line and section on the marked moduli stack can be intrinsic to that marked problem without being canonically independent of every reference bundle.

**Source check.** BERT17 §3.1, Theorem 3.3, and §3.1.2 compare specified factorizations of the same jump problem and contour changes inside a common analyticity domain. Theorem 3.3's multiplier is nonzero because of the stated determinant-one and minor conditions. This is not a theorem about arbitrary bundle modifications. MAL04 §2 similarly obtains unit changes from different finite-rank regularizations of the same Toeplitz family; it does not identify all changed RHP normalizations.

## Necessary source qualifier: §8.4 and MAL04

The Hamiltonian/line-connection statement of MAL04 Theorem 5.12 is in the **logarithmic Schlesinger setting** developed in §§4–5. Section 7.1 extends its resonance scope in that setting by a Hartogs argument. Section 7.2 discusses the extension to irregular singularities as an additional undertaking.

Add this qualifier next to the citation in §8.4. Its all-classical irregular or ramified comparison must remain a target derived from the specified RHP adapters and variational formula, not a consequence of MAL04 Theorem 5.12. The current §8.3 restriction of the BERT10/BERT16 JMU comparison is correct and should be retained.

## Small precision repairs

### §8.4: normalization requires a fixed differential/frame prescription

A base-point value alone does not choose a holomorphic frame: a frame can be multiplied by exp(f) with f vanishing at that point. State uniqueness after fixing the corrected logarithmic one-form (or the corresponding line connection) and the chosen compatible frame prescription, then fixing the value at the base point. On a horizontal simply connected regular time domain, integrate that fixed closed form. This is consistent with the existing text's intended normalization; it just makes the premise of the uniqueness claim explicit.

### §10.2: retain the inverse-parametrix/local-model premise

The Neumann-series RHP engine applies to general small residual jumps. Recovering a meromorphic connection of the specified polar type is an additional assertion: reverse the chosen parametrix transformations and prove that the resulting logarithmic derivative has exactly the prescribed poles, determinant, local lattices and descent. Only the admitted isomonodromic jump variation can then be identified with Layer 3's splitting. The current text promises this proof; add a phrase that the reconstruction is for residual problems obtained from §10.1's geometric local models, not for every abstract L² jump family.

### §11.4: trace-norm convergence uses one identified operator space

State that the kernels are first transported to a **common Hilbert space**, through explicitly controlled contour/weight/trivialization identifications. Then \(\|K_\epsilon-K_0\|_1\to0\) and determinant continuity have a defined meaning. A pointwise kernel limit on moving contours does not supply this premise. If zero-count convergence is stated, say that the small domain is a domain in the one-dimensional complex time variable; the stated boundary nonvanishing and nonidentically-zero conditions then give the usual Rouché consequence.

These are local wording repairs, not new research branches.

## Confirmed points: no repair needed

### Determinant construction and descent

- The convention \(L_T=\det(\ker T)^*\otimes\det(\operatorname{coker}T)\) matches the finite-dimensional determinant section. The stabilization model \(L_F=\det K^*\otimes\det F\), with section induced by the projection \(K\to F\), is the correct construction. Its signs and comparison maps must satisfy the stated normalization, which the roadmap explicitly asks to prove.
- Stabilizations and common refinements provide an actual line-bundle cocycle. The warning that a closed curvature form alone does not construct that cocycle is correct.
- The odd-degree calculation is correct: for rank two on \(\mathbb P^1\), \(\chi(E(k))=d+2k+2\). An odd d cannot be made index zero by a common integral line twist. The additional RHP complex/modification is therefore a real obligation.
- The section can be identically zero on a family. On a connected smooth chart where it is not identically zero, its effective Cartier divisor is legitimate. The examples correctly distinguish divisor multiplicity from kernel dimension.
- Coarse descent is conditioned on trivial stabilizer action. Index zero removes the scalar Euler-characteristic weight, but any larger admitted automorphism group still needs its own action check.
- BERT16's correction is used correctly: the raw Malgrange form is not declared closed in all time and monodromy directions, and vertex corrections are not discarded by analogy with disjoint closed contours. BERT17's conclusion explicitly warns that intersecting contours need not yield trace-class IIKS operators, so the promised sectorial adapters are essential and are appropriately marked as targets.

### Analytic solution selection

- The boundary-selection record does not assume existence, uniqueness or a selected solution. It retains the exceptional RH lift data needed for an unambiguous phase point.
- Writing \(\mu=I+\nu\) and solving for \(\nu\in L^2\) correctly avoids assuming that I belongs to L² on an unbounded contour. The bound \(\|\nu\|_2\le\|C_-w\|_2/(1-\rho)\) is valid under the stated operator norm bound. Endpoint/growth and moment conditions remain needed, as the draft says.
- The detailed ILP18 Theorem A restrictions agree with (1.13), (1.17). Theorem B is correctly limited to homogeneous PII and the specified Stokes locus. The check \((s_1,s_2,s_3)=(i,i,0)\) does satisfy (1.25) but makes the literal η formula undefined, so the draft's explicit continuation task is justified.
- The numerical calibration is correctly separated from the monodromy-dependent calculation. Neither a Hastings–McLeod existence theorem nor real pole-freeness alone supplies the cited complex-sector estimate or Airy determinant constant.
- The Hastings–McLeod bridge consumes the scalar theorem and constructs the intrinsic section through an initial first jet; it does not duplicate the scalar existence/uniqueness proof or claim complex pole-freeness.

### Confluence

- GMR23 Theorem 2 concerns a specified Laurent scaling of a collision, Theorem 12 the ordered Takiff cascade, and Theorem 13 its Hamiltonian formulas. The draft correctly treats its ramified/resonant moduli adapters and uniform common-chart estimates as separate proof targets. Formal Laurent limits do not by themselves discharge those analytic estimates.
- The finite-flat divisor model must use its residue/Frobenius pairing, as written; an ordinary trace-of-multiplication pairing could degenerate in the special fiber and is not a substitute.
- The compact-path convergence theorem has the needed positive boundary margin, uniform local field convergence, common phase Lipschitz control, and convergent initial conditions. Its Grönwall estimate, first-exit argument and finite chart gluing are valid. It does not infer convergence on an unbounded ray, across a fixed limiting singularity, or for arbitrary unmatched initial data.
- The tau limit through integrated logarithmic derivatives requires a common regular domain and matched constants. The alternative trace-norm route can pass through zeros. The example \(\tau_\epsilon(z)=z-\epsilon\) correctly distinguishes these routes.
- Compact-path convergence alone does not determine endpoint connection constants. The draft explicitly requires additional uniform sectorial/asymptotic estimates, so it does not hide that gap in the scalar confluence calculation.

## Quick check of current README §3.1

The intrinsic permitted-form expression is correct:

\[
 \Omega^1_{X/A}(\log D)\otimes\mathcal O_X(P-D),
\]

where A is the fixed auxiliary base and D is the divisor formed by the marked sections with multiplicity one. In a moving coordinate z and infinitesimal time ε, this has the local generators \(dz/z^m\) and \(d\epsilon/z^{m-1}\), as required by I23 Definition 10.1. In the dual-number situation, “reduced marked divisor” should mean this multiplicity-one relative Cartier divisor, not the scheme-theoretic reduction of a nonreduced infinitesimal family. One safe implementation is to define the logarithmic sheaf on the smooth ambient marked family and then pull it back to the infinitesimal deformation.

The preservation of the kernel lattices is now also present. This repairs the resonant uniqueness issue raised in the front review.

## Source locators used

- MAL04 §2, printed pp.1372–1374; §§4–5, Theorem 5.12; §§7.1–7.2.
- BERT10 Assumption 3.1 and Proposition 5.1, with BERT16 Theorems 2.1–2.2 and Remarks 2.2–2.3.
- BERT17 Theorem 2.2, Proposition 2.3, Theorem 3.3, §3.1.2, and conclusion on intersecting contours.
- ILP18 equations (1.13), (1.17), (1.25)–(1.28), Theorems A/B, Remark 4.8 and §4.5.
- GMR23 Theorems 2, 12 and 13; the cached printed page markers agree with the locators in the tail draft.
- I23 equation (10.1) and Definition 10.1.

All sources were checked from the cached primary PDFs/text. No remote mutation, Worker invocation or README edit was performed.
