#!/usr/bin/env python3
"""Reproducible local checks for this draft, independent of the Worker.

Usage: python3 reports/validate_draft.py [--source-cache /path/to/research/sources]
The optional source cache is not distributed. These checks do not elaborate Lean
or establish the mathematical theorems planned in the roadmap.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction as F
import hashlib
import itertools
import json
from pathlib import Path
import re
import tomllib

parser = argparse.ArgumentParser()
parser.add_argument('--source-cache', type=Path)
args = parser.parse_args()
pkg = Path(__file__).resolve().parents[1]
failures: list[str] = []
checks: list[dict] = []

def check(name, condition, detail=''):
    checks.append({'name': name, 'pass': bool(condition), 'detail': detail})
    if not condition:
        failures.append(name + (': ' + detail if detail else ''))

readme = (pkg/'README.md').read_text()
plan = json.loads((pkg/'design/plan.json').read_text())
manifest = tomllib.loads((pkg/'sources.toml').read_text())
metadata = tomllib.loads((pkg/'metadata.toml').read_text())
lean = (pkg/'Suggested.lean').read_text()
targets = [t for layer in plan['layers'] for t in layer['targets']]
ids = [t['id'] for t in targets]
by_id = {t['id']: t for t in targets}
sources = {s['id']: s for s in manifest['source']}
suppliers = {s['roadmap'] for s in plan['suppliers']}
gaps = {g['slug']: g for g in plan['gaps']}

check('canonical_design_readme_identical', readme == (pkg/'design/README.md').read_text())
check('expected_roadmap_identity', plan['roadmap'] == 'PainleveEquationsAndFunctions')
check('eleven_layers_and_44_targets', len(plan['layers']) == 11 and len(targets) == 44)
check('unique_target_ids', len(ids) == len(set(ids)))
readme_ids = re.findall(r'^### (\d+\.\d+) ', readme, re.M)
check('readme_plan_target_identity', ids == readme_ids)
check('metadata_topic', metadata.get('topic') == 'math.AG')
check('readme_no_latex_delimiters', not any(x in readme for x in ['$$','\\[','\\]','\\(','\\)']))
check('no_machine_paths_in_canonical_readme', '/workspace/' not in readme and '_research/' not in readme)
check('canonical_sections_present', all(x in readme for x in ['**Summary.**','## Scope and ownership','## Conventions','## Exact supplier contracts','## How to read the build','## Downstream consumers','## References']))

prefix = re.compile(r'^(?:(?:mathlib|tauceti):[A-Za-z_][\w.\x27!?]*|roadmap:[A-Z][A-Za-z0-9]*(?:\s.*)?|target:[\w.]+|gap:[A-Za-z0-9][\w.-]*)$')
edges = {}
for t in targets:
    tid = t['id']
    edges[tid] = []
    check(f'{tid}_nonempty_statement_and_hypotheses', bool(t['statement']) and bool(t['hypotheses']))
    check(f'{tid}_locator', bool(t['locator'].get('source')) and bool(t['locator'].get('where')))
    check(f'{tid}_known_locator_source', t['locator']['source'] in sources or t['locator']['source'] in suppliers or t['locator']['source'] in ['Mathlib','TauCeti'])
    if t['kind'] in ('definition','construction'):
        check(f'{tid}_api_and_discriminating_checks', len(t.get('api',[])) >= 1 and len(t.get('tests',[])) >= 3)
    for p in t['prerequisites']:
        check(f'{tid}_prerequisite_syntax_{p}', bool(prefix.fullmatch(p)))
        if p.startswith('target:'):
            dep = p[7:]
            check(f'{tid}_known_target_{dep}', dep in by_id)
            edges[tid].append(dep)
            check(f'{tid}_earlier_target_{dep}', dep in by_id and ids.index(dep) < ids.index(tid))
        elif p.startswith('gap:'):
            check(f'{tid}_known_gap_{p[4:]}', p[4:] in gaps)
        elif p.startswith('roadmap:'):
            owner = p[8:].split()[0]
            check(f'{tid}_known_supplier_{owner}', owner in suppliers)

visited=set();active=set();cycles=[]
def visit(n):
    if n in active:
        cycles.append(n); return
    if n in visited:return
    active.add(n)
    for d in edges[n]:
        if d in edges:visit(d)
    active.remove(n);visited.add(n)
for tid in ids:visit(tid)
check('target_dag_acyclic', not cycles)
check('core_has_no_coordinate_dependencies', all(int(d.split('.')[0]) <= 5 for t in ids if int(t.split('.')[0]) <= 5 for d in edges[t]))
check('properness_is_proved_before_transfer', '4.4' in edges['5.2'] and '4.3' in edges['5.2'])
check('tau_has_no_scalar_or_properness_dependency', all(not d.startswith(('9.','10.')) and d != '4.4' for tid in ['8.1','8.2','8.3','8.4'] for d in edges[tid]))
check('random_matrix_ownership_not_reversed', all(c['roadmap'] != 'RandomMatrices' for c in plan['consumers']))

for slug,g in gaps.items():
    exact=f"What {g['supplier']} must provide (gap:{slug}): {g['needs']}"
    check(f'{slug}_exact_readme_contract', exact in readme)
    check(f'{slug}_named_owner_and_section', bool(re.fullmatch(r'[A-Z][A-Za-z0-9]*',g['supplier'])) and bool(g['section']))
    check(f'{slug}_all_consumers_known', all(x in by_id for x in g['neededBy']))

check('source_manifest_schema', manifest.get('schema') == 'tauceti-roadmap-sources/v1')
check('source_manifest_identity', manifest.get('roadmap') == plan['roadmap'])
check('23_unique_sources', len(sources) == len(manifest['source']) == 23)
status_counts=Counter(s['status'] for s in manifest['source'])
check('22_certified_plus_one_web_read_uncertified', status_counts == {'certified':22,'uncertified':1})
source_hashes={}
for s in manifest['source']:
    check(f"source_{s['id']}_cited_targets_known", all(x in by_id for x in s.get('cited_for',[])))
    check(f"source_{s['id']}_required_bibliography", all(s.get(x) for x in ['authors','title','year','locator_scheme','licence_class','status']))
    if s['status']=='certified':
        check(f"source_{s['id']}_provenance", bool(re.fullmatch(r'[a-f0-9]{64}',s.get('sha256',''))) and bool(s.get('fetched_from')) and bool(s.get('fetched_at')))
        if args.source_cache:
            pdf=args.source_cache/(s['id']+'.pdf')
            digest=hashlib.sha256(pdf.read_bytes()).hexdigest() if pdf.is_file() else None
            check(f"source_{s['id']}_actual_bytes_hash", digest == s['sha256'])
            source_hashes[s['id']]=digest
check('dlmf_no_fabricated_byte_hash', sources['DLMF']['status']=='uncertified' and not sources['DLMF'].get('sha256'))
check('source_bytes_not_embedded_in_package', not any(p.suffix.lower() in ['.pdf','.png','.jpg'] for p in pkg.rglob('*') if p.is_file()))

lean_code=re.sub(r'/\-.*?\-/','',lean,flags=re.S)
check('lean_import_and_namespace', lean_code.strip().startswith('import Mathlib') and 'namespace TauCetiRoadmap.PainleveEquationsAndFunctions' in lean_code)
decls=re.findall(r'^\s*(?:noncomputable\s+)?(?:def|theorem|lemma|axiom|opaque|abbrev|structure|class|instance)\b',lean_code,re.M)
check('no_fabricated_lean_declarations', len(decls)==0 and not re.search(r'\b(sorry|axiom|opaque|set_option)\b',lean_code))
check('missing_headlines_disclosed', lean.count('\n* ')==11 and 'no theorem declarations' in lean)

# Exact-arithmetic diagnostics of the specific fragile normalizations. These
# are discriminating checks, not formal proofs of the general theory.
math_checks=[]
def math_check(name, ok, detail):
    check(name,ok,detail);math_checks.append(name)

def contraction(v,m):
    return [sum(v[i]*m[i][j] for i in range(3)) for j in range(3)]
a,b=F(2),F(3)
canonical=[[0,1,a],[-1,0,b],[-a,-b,0]]
math_check('canonical_extended_form_sign', contraction([b,-a,1],canonical)==[0,0,0], 'ω=dq∧dp; Ω=ω+dH∧dt; q′=H_p and p′=−H_q.')
wrong=[[0,-1,0],[1,0,2],[0,-2,0]]
right=[[0,-1,0],[1,0,-2],[0,2,0]]
math_check('vdps_printed_sign_counterexample', contraction([2,0,1],wrong)==[0,-4,0] and contraction([2,0,1],right)==[0,0,0], 'PI source point q=t=0,p=1: printed minus fails, plus annihilates the vector.')
t,q,p,th0,th1,thi=map(F,[1,2,0,0,1,1])
pdot=(2*q-1)*p*p/((q-1)*q*t)+(th0*th0*(q-1)**2-th1*th1*q*q)/(4*q*(q-1)*t)+(q-1)*q*(2*q*t-t+2*thi-2)/4
correct=2*pdot/t-2*p/t**2
printed=(q-1)*q*(2*q*t-t+2*thi-2)/(2*t)+th0*th0/(2*q*t*t)+th1*th1/(2*(q-1)*t*t)
math_check('vdps_pv_scalar_counterexample', correct==2 and printed==F(7,2), 'Source system (2) versus printed scalar equation (3).')
ok=True
for t in map(F,[-2,1,2,3]):
    q=-1/t;dq=1/t**2;ddq=-2/t**3;p=2/t**2+t/2;dp=-4/t**3+F(1,2)
    ok &= ddq==2*q**3+t*q+1 and dq==p-q*q-t/2 and dp==2*q*p+F(3,2)
math_check('pii_rational_jet_normalization',ok,'α=1, q=−1/t, p=2/t²+t/2 at four distinct nonzero rational times.')
ok=True
for t,q in itertools.product(map(F,[-2,0,3]),map(F,[-1,0,2])):
    dq=-q*q-t/2
    ok &= -2*q*dq-F(1,2)==2*q**3+t*q-F(1,2)
math_check('pii_riccati_parameter',ok,'p=0 is invariant at α=−1/2 and differentiates to the expected scalar equation.')
ok=all(4*a**3+2*t*a-2*(a*t+2*a**3)==0 for a,t in itertools.product(map(F,[-2,0,1,3]),map(F,[-1,0,2])))
math_check('pi_sigma_excluded_linear_branches',ok,'σ=at+2a³ satisfies the sigma relation; its constant q is not a PI solution on an open domain.')
profile_counts=[]
for a,b,g,d in itertools.product([0,1],repeat=4):
    classes=[bool(g*d), bool((g==0 and a*d) or (d==0 and b*g)), bool(g==d==0 and a*b), bool((a==g==0) or (b==d==0))]
    profile_counts.append(sum(classes))
math_check('piii_coefficient_boundary_partition',all(n==1 for n in profile_counts),'All sixteen zero/nonzero coefficient patterns have exactly one of D6,D7,D8,quadrature classes.')
math_check('pv_coefficient_boundary_partition',all(sum([d!=0,d==0 and g!=0,g==d==0])==1 for g,d in itertools.product([0,1],repeat=2)),'All four gamma/delta zero patterns covered exactly once.')
profiles=[[0,0,0,0],[0,0,1],[0,0,F(1,2)],[1,1],[F(1,2),1],[F(1,2),F(1,2)],[0,2],[0,F(3,2)],[3],[F(5,2)]]
ceil=lambda x:(F(x).numerator+F(x).denominator-1)//F(x).denominator
math_check('ten_profiles_structural_budget',all(sum(ceil(r)+1 for r in profile)==4 for profile in profiles),'All ten projective Katz profiles have Σm=4 and formal count Σm−3=1; the geometric quotient theorem remains a proof target.')
a,b=F(2),F(1,2)
math_check('piv_scaling_coefficients',a*a*b*b==1 and a**3*b==4 and a**4/8==2 and a*a/(8*b*b)==2,'t=2T,Q=2q; α=−θ∞−1, β=−2θ₀².')
ok=True
for u,v,t,a in [(F(1),F(2),F(3),F(4)),(F(2),F(-3),F(1),F(0)),(F(1,2),F(0),F(-2),F(3))]:
    dd=v*v/(2*u)+2*u*u-t*u-a*a/(2*u)
    q=(v-a)/(2*u)
    dq=(dd*u-(v-a)*v)/(2*u*u)
    ok &= dq==u-q*q-t/2
    ddq=v-2*q*dq-F(1,2)
    ok &= ddq==2*q**3+t*q+a-F(1,2)
math_check('fn_p34_to_pii_inverse',ok,'Nonzero U chart, Q=(U′−a)/(2U), α=a−1/2 and inverse U=Q′+Q²+T/2.')

hashes={str(p.relative_to(pkg)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [pkg/'README.md',pkg/'Suggested.lean',pkg/'metadata.toml',pkg/'sources.toml',pkg/'design/README.md',pkg/'design/plan.json']}
report={'scope':'Local static/contract and exact-arithmetic diagnostic validation, not Worker acceptance or proof certification.',
        'worker_started':False,'network_or_remote_writes':False,
        'lean_elaboration':{'status':'not performed','reason':'Official pinned runtime failed to locate application in the environment; no runtime restriction bypassed.'},
        'counts':{'layers':len(plan['layers']),'targets':len(targets),'readme_checks':sum(len(t['tests']) for t in targets),
                  'api_laws':sum(len(t['api']) for t in targets),'supplier_contracts':len(plan['suppliers']),'supplier_gaps':len(gaps),
                  'sources':len(sources),'source_statuses':dict(status_counts),'lean_declarations':len(decls),
                  'validation_checks':len(checks),'exact_arithmetic_diagnostics':len(math_checks)},
        'source_bytes_rehashed':bool(args.source_cache),'source_hashes':source_hashes,'file_hashes':hashes,
        'failures':failures,'checks':checks}
(pkg/'reports/validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'failures':failures,'counts':report['counts'],'source_bytes_rehashed':bool(args.source_cache)},ensure_ascii=False,indent=2))
raise SystemExit(bool(failures))
