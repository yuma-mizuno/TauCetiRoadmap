# Supplier audit supplement

Date: 2026-11-05. This supplements worker_contract.md and records the exact additional foundations used by the final eleven-layer draft. It is an audit of source ownership and hypotheses, not a claim that these roadmap targets have already been implemented in Lean.

## Main-roadmap foundations

All main references below were inspected at TauCetiRoadmap revision a0ad405e151ff6e42b3c5e372ac3f24e168ad68f.

### Coherent cohomology, complexes and duality

[SchemeAndStackFoundations](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/SchemeAndStackFoundations/README.md):

- §2.2 owns Leray/Čech spectral sequences and the acyclic-cover comparison on abelian sheaves.
- §2.6 owns quasi-coherent higher direct images and flat base change in its qcqs regime, with proper coherent finiteness delegated to JacobianChallenge.
- §2.7 owns cohomology with supports, localization triangles, local-to-global comparison and the specified Noetherian local-cohomology bridge.
- §2.20 owns relative dualizing complexes/modules and their Serre-duality comparisons.
- §3.3 owns vector-bundle degree, determinant/dual/modification laws and the curve Riemann–Roch/duality comparisons.
- §1.22 owns quasi-coherent modules on stacks, presentation/descent equivalence and the qualified pushforward interface.

[JacobianChallenge Layer C](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/JacobianChallenge/README.md) supplies coherent higher direct images for proper maps over locally Noetherian bases, finite affine-base cohomology, flat base change, and the stated cohomology/base-change and semicontinuity criteria. Its locally free conclusion from constant fibre dimension requires a reduced base; over nonreduced bases the stronger base-change/surjectivity hypotheses must be proved.

The connection differential [∇,−] is generally a complex-linear differential operator, not an O-linear map. Therefore the connection complex is not automatically an object of D(QCoh). The Čech total-complex construction and termwise coherent-duality adapter for this specific connection problem belong to Painlevé §2.2. Ramified cone relations and their signs also belong there.

### Surfaces, divisors and Picard components

SchemeAndStackFoundations §3.4 supplies Cartier/Weil divisor class and Picard-groupoid comparisons; §4.11 supplies modifications and strict transforms; §4.17 supplies strict normal crossings; §§5.9–5.10 supply the intersection pairing, adjunction, numerical equivalence and Hodge-index framework.

The numerical quotient Num(S) is not automatically the marked Pic(S) used for a rational surface presentation. The rational-surface comparison, marked boundary lattice, affine Dynkin labels and logarithmic deformation calculations are specific targets of Painlevé §§6.1–6.3. The boundary diagram is also not automatically the symmetry root system in §7.2.

[ComplexComparisonPartII](https://github.com/TauCetiProject/TauCetiRoadmap/blob/84cbfee00308efa17b1f989d7149fa9319140a4d/TauCetiRoadmap/ComplexComparisonPartII/README.md) remains proposed, at PR 848 head 84cbfee00308efa17b1f989d7149fa9319140a4d:

- C3.2d.2 represents the relative fppf Picard sheaf for a proper flat finitely presented family with universal functions after every base change.
- C3.2f.1 defines the full identity-component sheaf, retaining nonreduced structures.
- C3.2f.2 gives its representability under the stated smooth-component and locally constant dimension hypotheses; smoothness over a nonreduced base needs formal smoothness along the component.
- C0.3 gives the holomorphic bundle/locally free coherent sheaf comparison.

These are meaningful suppliers for the anticanonical boundary family, including nonreduced Y. Painlevé §6.1 must verify their hypotheses and compute the actual Pic⁰(Y); a Picard functor for a smooth integral curve does not by itself cover that boundary. Relative rank/base-change for the first boundary time line is established in §6.3, not inferred from its pointwise dimension alone.

## The two named external extensions

1. SmoothBundlesConnectionsPartII, proposed extension of B1.5: gap:holomorphic-horizontal-lifts. It must supply unique local holomorphic integral sections of an integrable holomorphic Ehresmann splitting on a finite-dimensional complex submersion, jointly holomorphic in initial data and admitted auxiliary parameters. The existing smooth B1.5 theorem is not this theorem.
2. HeegaardFloerPartII, proposed target F0.0C: gap:complex-holomorphic-determinant-family. It must supply the specified complex holomorphic stabilization/determinant-line family and its refinement, cocycle and base-change comparisons. The final exact contract must also locate the construction of the canonical determinant section. The dual line convention det(ker T)* tensor det(coker T) is retained. The existing real F0.0 orientation family does not give that complex section.

The proposal status is explicit; these are not represented as sections already present in the audited parent roadmap. The corresponding complex application constructions, section normalization, RHP sewing and divisor multiplicities remain in Painlevé Layer 8 as specified.

## Barnes G: an existing proposed owner, not a new gap

[AnalyticNumberTheoryPartII](https://github.com/TauCetiProject/TauCetiRoadmap/blob/1458ecbf2e6f645150a94b1a3371f558a22e30b5/TauCetiRoadmap/AnalyticNumberTheoryPartII/README.md), PR 1167 head 1458ecbf2e6f645150a94b1a3371f558a22e30b5, explicitly supplies:

- §4.3: the canonical Weierstrass-product Barnes G, entireness, normalization, zero multiplicities, Gamma recurrence away from Gamma poles and the meromorphic recurrence, logarithmic derivative, positivity and normalized asymptotics.
- §4.3a: rigorous full-sector remainder and differentiated estimates, with normalized analytic logarithms.
- §4.3b: the balanced Gamma-quotient estimates needed by that branch.

The arbitrary recurrence and G(1)=1 alone do not characterize G; the product normalization is essential. The cited source uses analytic logarithms on the slit plane, not the pointwise principal logarithm of G's values. Painlevé §10.3 consumes this exact supplier for its ILP18 formulas. It is at line 84 of the audited ORDER.txt, before the existing formal normal-form supplier at line 110. No native Barnes G carrier was found at the audited Mathlib/TauCeti pins.

## Complex Takiff/Poisson comparison in Layer 11

[SymplecticGeometry/HamiltonianReduction](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/SymplecticGeometry/HamiltonianReduction/README.md) R2 supplies finite-dimensional smooth real homogeneous coadjoint orbits and their KKS form. Its orbit map may be an immersion rather than an embedded closed submanifold. R3 supplies the qualified regular/free/proper reduction and descended symplectic-form theorem, with separate singular and orbifold branches.

[LieGroupoidsPoisson](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/LieGroupoidsPoisson/README.md) G4.6A is the precise positive Lie–Poisson supplier, with the bracket of linear functions equal to the linear function of the Lie bracket. G0.1 supplies the smooth constant-rank/submersion and transverse-product floor; it does not itself supply the Lie–Poisson theorem.

These contracts support an underlying smooth comparison. They do not automatically construct complex algebraic or holomorphic Takiff orbit families and reductions. That adapter, its residue pairing, stability/orbit domain and confluence comparison are owned by Painlevé §11.1. No third external gap is needed merely to rename this specified application construction.

## Native estimate used in the compact-path transfer

At Mathlib pin f6090c7095e1e56b3464c1daba5f24631f1290d2, Analysis/ODE/Gronwall.lean supplies:

- norm_le_gronwallBound_of_norm_deriv_right_le;
- dist_le_of_approx_trajectories_ODE_of_mem;
- gronwallBound_K0, gronwallBound_of_K_ne_0 and gronwallBound_continuous_ε.

The approximate-trajectory theorem assumes continuity on the closed time interval, right derivatives on its half-open part, a common Lipschitz constant on the specified time-dependent tube, actual membership of both trajectories in that tube and explicit derivative-error bounds. Painlevé §11.2 adds the common-chart positive margin and first-exit argument. The native estimate does not by itself prove compact containment or an all-time confluence theorem.

## Integration status

This supplement adds exact existing supplier sections and two explicit proposed extensions; it does not run a Worker, create supplier jobs or alter the merge order. The draft's mathematical completion means that these obligations have named owners and precise statements, not that every supplying roadmap or Painlevé theorem has already been formalized.

