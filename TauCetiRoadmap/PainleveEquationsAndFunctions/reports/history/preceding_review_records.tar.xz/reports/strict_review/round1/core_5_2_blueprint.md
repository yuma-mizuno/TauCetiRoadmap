# §5.2 native-carrier statability blueprint

**Status: signature design, unelaborated.** The candidate `core_5_2_candidate.lean` is a separate review artifact. It is neither a proved theorem nor an accepted Worker package. No Lean process was run for this review. The parent reports that even the pinned `lean --version` fails to locate its application. Typeclass inference and all declarations must be checked when the runtime is available.

## Why the zero-declaration rationale is insufficient

Frozen README §5.2 first asks for a **general** proper-semiconjugacy transfer theorem. The actual Painlevé moduli, its RH comparison, Stokes data, and observables occur only in its application paragraph. Its target R is expressly allowed to be singular: only complete continuous transport and compactness are used. Thus even the carrier of complex analytic spaces is unnecessary for this general statement.

The candidate states a more general real C¹ splitting theorem on arbitrary finite-dimensional Hausdorff second-countable native manifolds. Every holomorphic splitting in §5.2 gives this C¹ input by restriction of scalars. Integrability is not needed for continuation along one prescribed path; it enters the later homotopy-invariance theorem. Therefore this change does not specialize the theorem to one ODE or assume its conclusion. It removes unused hypotheses. A separate complex wrapper may retain the original hypotheses literally.

The candidate has four small real definitions: finite subdivisions, a horizontal splitting, differential horizontal lifts, and actual continuous target trajectories (plus the elementary piecewise-C¹ predicate). None is an opaque proposition or a fake moduli carrier. The splitting is a section of the native hom bundle Hom(π*TB,TM), with pointwise right-inverse equation dπ∘h=id. The lift equation is π∘η=γ and h(dπ(η′))=η′; the latter avoids dependent equality casts and is equivalent to η′=h(γ′) by the chain rule. It is imposed on each closed C¹ segment. Uniqueness is equality on [0,1], not equality of arbitrary extensions beyond the path interval.

The target transport has actual trajectory functions, initial-value, continuity and base-projection laws. The theorem explicitly requires semiconjugacy on every existing prefix lift; the draft's local semiconjugacy plus the usual transport restriction law yields this by uniqueness and gluing. This is a real compatibility hypothesis, not an assumed source solution operator. Properness traps each existing source prefix in the preimage of the compact target trajectory. Local C¹ ODE existence and uniqueness then supply continuation at a finite endpoint. The candidate still owes this proof and the nonautonomous path adapter.

## Exact native imports and declarations inspected

At Mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2`:

- `Mathlib.Geometry.Manifold.VectorBundle.Pullback`, `ContMDiffVectorBundle.pullback`: a `ContMDiffMap` pulls back a native vector bundle and its differentiable structure.
- `Mathlib.Geometry.Manifold.VectorBundle.Hom`, `contMDiffWithinAt_hom_bundle` and `contMDiffAt_hom_bundle`: total space `Bundle.TotalSpace (EB →L[𝕜] EM) (fun x ↦ E₁ x →L[𝕜] E₂ x)` and coordinate criteria. For the candidate, E₁=π*TB and E₂=TM.
- `Mathlib.Geometry.Manifold.IsManifold.Basic`, `TangentSpace`; native `ChartedSpace`, `IsManifold` and `ModelWithCorners` supply the source/base carriers.
- `Mathlib.Geometry.Manifold.MFDeriv.Defs`, `HasMFDerivWithinAt`, `mfderivWithin` and `mfderiv`: actual manifold derivatives on intervals.
- `Mathlib.Geometry.Manifold.VectorField.LieBracket`, `VectorField.mlieBracketWithin`: the optional literal complex-integrability wrapper can quantify local holomorphic fields V,W on an open U and require `[hV,hW] = h[V,W]` on π⁻¹(U). Quantifying only global holomorphic fields would be insufficient on a base with few such fields.
- `Mathlib.Topology.Maps.Proper.Basic`, `IsProperMap` and `IsProperMap.isCompact_preimage`: properness already includes continuity. No opaque analytic-properness predicate is required here.

At Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`:

- `TauCeti.Geometry.Manifold.IntegralCurve.Maximal`, `maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo` proves the compact-containment continuation floor for autonomous real vector fields.
- `TauCeti.Geometry.Manifold.IntegralCurve.Basic`, `IsMIntegralCurveOn.map_of_mfderiv_eq` and `IsMIntegralCurveAt.map_of_mfderiv_eq` express derivative-compatible curve transport.

The first theorem does **not** directly discharge the pathwise transfer theorem: a piecewise C¹ base path produces a nonautonomous horizontal equation, so local path charts, parameter/time augmentation where valid, and finite subdivision remain substantive proof work. That affects proof construction, not the availability of the statement's carriers.

## Literal complex version

Take finite-dimensional complex native manifolds M,B; `π : ContMDiffMap 𝓘(ℂ,EM) 𝓘(ℂ,EB) M B ∞`; and a native holomorphic section h of Hom(π*TB,TM). Require `(mfderiv ... π x).comp (h x) = ContinuousLinearMap.id ℂ _`. Local integrability is the displayed `mlieBracketWithin` equality for all local holomorphic vector fields. Use underlying real models for piecewise C¹ paths and restrict the complex linear maps to real linear maps. Keep exactly the same topological R, `IsProperMap F`, target transport and prefix compatibility. The real candidate implies the desired continuation conclusion, and the holomorphic local-lift supplier supplies the holomorphic-germ refinement used in §5.1.

## Required validation before use

1. Elaborate the candidate at the exact pins, resolving any notation/instance issues without replacing its definitions by opaque predicates.
2. Check the full theorem type against §5.2, including finite subdivisions, endpoint behavior, every initial point, possible singular target, and interval-only uniqueness.
3. Verify the complex-to-real wrapper and the prefix compatibility adapter from the intended transport laws.
4. Exercise the proper identity case; the proper blowdown with exceptional fibers; and the nonproper deleted-cover countermodel recorded in ledger row 5.2. Do not call a compact-preimage lemma the whole continuation theorem.

The supported conclusion is that the blanket claim “none ... can presently be stated ... using a few simple definitions on existing carriers” has not survived a separate audit of §5.2. This review does not assert that the candidate elaborates, that its proof is complete, or that a zero-declaration package is accepted.
