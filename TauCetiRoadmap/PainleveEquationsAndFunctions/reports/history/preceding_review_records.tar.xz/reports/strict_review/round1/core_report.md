# Independent strict review: core Layers 1–5

## Assessment

**Needs changes.** The frozen core has six P2 findings and one P3 check defect. I did not establish a P1 false headline theorem in the scoped core. The P2 findings concern real input/output contracts and an omitted prerequisite construction, plus an unsupported blanket statability conclusion. Several ambitious theorems are explicitly future proof obligations; this report does not treat those promises as completed proofs, and it does not mark a theorem false merely because its proof is not in a roadmap.

The all-strata, whole-family irregular RH properness theorem in §4.4 is a substantial new proof target. I23's foliation construction and IS12's generic RH isomorphism do not prove it. The draft correctly identifies this limitation and gives a staged route. The compactness transfer in §5.2 is mathematically sound once whole-family properness and exceptional-stratum compatibility have been proved. My assessment does not certify completion of that new RH proof.

### Frozen evidence and independence

- README SHA256: `720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`.
- Plan SHA256: `f267cb3b55cfdc5c858035ed69132f5487416d5fbf855ed1230ce0c21f7656fd`.
- Paths: `_strict_review/round1/artifact/README.md`, `artifact/design/plan.json`, and `artifact/Suggested.lean`.
- Actual Worker rubric read: `prompts/review.md`, `prompts/redteam.md`, and `prompts/sections/adversarial.md`, `defect-classes.md`, `gaps-and-order.md`, `lean-form.md`, under `_research/worker_contract_sources`.
- No prior review reports were used as evidence. Parent messages supplied proposed concerns; each finding below was checked against the frozen text, explicit mathematical witnesses, and relevant source/native declarations. No subagent was used for this scoped pass.
- No canonical artifact was edited, no Worker was executed, and no external mutation, push or PR was made. The separate candidate file is review evidence only.
- No Lean elaboration was run. The parent reports a runtime failure even for pinned `lean --version`; therefore this report makes **no package-accepted claim**. Mathematical review, native-carrier statability, successful elaboration, and independent Worker-family review are different gates.

### Exact scope

Scope, Conventions, the direct supplier contracts needed in Layers 1–5, all 21 numbered targets and their API/Checks, the corresponding plan entries, and the zero-declaration explanation in Suggested.lean were assessed. Source comparison included HEU10, VDPS09, I23, IIS06, IS12 and the relevant twisted Stokes definitions in BY15. BOA01/BOA14 are supporting citations; I have not independently reconstructed every proof in those papers or every transitive supplier. The source comparisons below identify the precise result on which each sampled core target can rely. Layers 6–13 are outside this report's mathematical verdict, except where the core would otherwise rely on a forward reference.

## Findings

### C01 — P2: The trace-free output has no defined invariant carrier

**Location.** README.md:116; design/plan.json target 1.1 API law 2

**Claim under review.** Identify the underlying formal differential module and its trace-free part without choosing a square root of the determinant line.

**Concrete witness.** With A=0 and frame change g=diag(z,1), trace subtraction gives diag(1/2,-1/2) dz/z; the gauge transform of zero is diag(1,0) dz/z. The discrepancy is -(1/2)I dz/z.

**Exact repair.** Replace the ambiguous output by the induced connection on End^0(E), of rank r^2-1, and/or the associated PGL_r connection. Restrict A-tr(A)I/r to a local comparison expression, not an invariant rank-r differential module. State source and target explicitly.

**Acceptance test.** On E=O ⊕ O(-1), End^0(E) and the PGL_2 object glue, whereas a global half-determinant twist would require a line of degree -1/2. Check the gauge formula for g=diag(z,1).

**Status.** independent finding

### C02 — P2: The ten-profile count omits the ordered-label convention

**Location.** README.md:17,21,172; design/plan.json target 1.4

**Claim under review.** After quotienting the permitted marked-curve automorphisms, the allowed structural-degree-four profiles are the ten standard profiles.

**Concrete witness.** Ordered slope tuples (1,0,0) and (0,1,0) have structural orders (2,1,1) and (1,2,1). A label-preserving isomorphism cannot identify them. There are 17 ordered profiles, versus 10 unordered profiles.

**Exact repair.** State that there are ten underlying profiles after forgetting/reindexing the ordered pole labels, and separately recover every labelled input by a label-assignment groupoid. Do not identify label permutations within the original groupoid.

**Acceptance test.** Count ordered compositions of 4 with one local choice for part 1 and two for each larger part: n=1:2, n=2:8, n=3:6, n=4:1; total 17. The corresponding unordered counts are 2+5+2+1=10.

**Status.** independent finding

### C03 — P2: The general rank range does not exclude rank zero

**Location.** README.md:109-127 and 226-229; design/plan.json targets 1.1 and 2.3

**Claim under review.** The generalized input takes a rank, and the nonempty stable-fiber dimension is 2r^2(g-1)+2+r(r-1)deg P.

**Concrete witness.** Set r=0, E=0 on P^1, with its unique connection, determinant (O,d), empty local filtrations and no ramified pole. The slope-stability quantifier over proper positive-rank invariant subbundles is empty. This gives a singleton moduli fiber with zero tangent complex, while the printed formula is 2. If stability is instead defined only for positive rank, that domain restriction is missing from the input contract.

**Exact repair.** Require r >= 1 in the general intrinsic input and in every dimension/decomposition statement; impose the additional rank/local-degree restrictions of the ramified supplier when used. State that slope stability is defined on that positive-rank domain.

**Acceptance test.** Reject r=0 at construction. At r=1,g=1, the unfixed determinant dimension is 2, and fixing the entire determinant connection removes both directions, giving 0.

**Status.** independent finding

### C04 — P2: The closedness route lacks its early coalescing-divisor moduli construction

**Location.** README.md:17,228-244; design/plan.json target 2.3; I23 section 8, especially Proposition 8.2 before Proposition 8.3

**Claim under review.** Prove closedness using the deformation/unfolding argument with only targets 2.1-2.2 and relative forms/trace pairing listed as inputs.

**Concrete witness.** The I23 proof uses D_h=(z-h^2 q_1)(z-h^2), for example q_1=2 in rank 2 and local order 2. At h=0 its support is one doubled point; at h!=0 it is two distinct simple points. This is not a family in Layer 1: fixed ordered pairwise-distinct marked sections with fixed multiplicities cannot have these two fibers. I23 separately constructs an algebraic-space moduli family in Proposition 8.2 and its deformation complex before proving closedness in Proposition 8.3. Neither the existing fixed-profile 2.1 family nor a future Layer 11 confluence theorem supplies this automatically.

**Exact repair.** Add an explicitly owned subconstruction in 2.3 for this finite-flat coalescing divisor, its factorized simple-connection moduli, etale universal-object cover, relative deformation complex and form, and central-fiber comparison. State the smooth/flat or dense-open argument that transfers vanishing of d omega from the logarithmic generic fibers. Keep it independent of Layer 11. Alternatively supply a direct trace-complex closedness proof requiring no such unfolding.

**Acceptance test.** For r=2,m=2,q_1=2 compute D_0=z^2 and D_1=(z-2)(z-1); construct the central/generic moduli and form identifications, including the nonreduced base h^2=0, and verify the claimed closedness restriction.

**Status.** independent finding

### C05 — P2: The generic proper-semiconjugacy headline is omitted from the statability analysis

**Location.** Suggested.lean module docstring and zero-declaration conclusion; README.md:421-429; design/plan.json target 5.2

**Claim under review.** None of the headline results can be stated using a few definitions on native carriers, because continuation needs the actual Painleve family and its RH comparison.

**Concrete witness.** Target 5.2 first states a general theorem for an arbitrary finite-dimensional holomorphic submersion pi:M->B, a holomorphic horizontal splitting, a proper map F over B and continuous complete target transport. Its statement does not require Painleve moduli, Stokes data, an RH construction or scalar observers. At the pins, the splitting lives in the native hom bundle Hom(pi^* TB,TM), a fiberwise ContinuousLinearMap; its right-inverse law is (mfderiv pi x).comp(h x)=id. Holomorphicity is ContMDiff over C on the native hom-bundle section, and local flatness can be expressed by native mlieBracketWithin. Native Path, ContMDiffOn, HasMFDerivWithinAt and IsProperMap state path and lift conditions. The actual real-C1 transfer signature is in core_5_2_candidate.lean, with the complex-wrapper and exact native API comparison in core_5_2_blueprint.md; no opaque predicate or moduli stand-in is needed.

**Exact repair.** Audit the generic 5.2 theorem separately from its application. Independently elaborate the attached review-only candidate or its literal complex wrapper, then add the small genuine horizontal-splitting/path-lift/transport definitions and its general transfer theorem to Suggested.lean if the signature elaborates. If a concrete pin obstruction remains, identify the exact missing carrier/API rather than citing the absent Painleve moduli. Do not substitute a one-tactic compact-preimage lemma or weaken the theorem to one scalar ODE.

**Acceptance test.** Elaborate the full general signature and inspect #check @... against 5.2 when the Lean runtime works. Independently test the proper identity semiconjugacy and the nonproper y′=y^2 projection counterexample in the ledger. Current runtime unavailability prevents any claim that this test has passed.

**Status.** Concrete unelaborated signature candidate supplied; this is a defect in the blanket statability rationale, not a claim of a successful Lean declaration.

### C06 — P2: Splitting-type strata are not uniformly open substacks

**Location.** README.md:196; design/plan.json target 2.1 API law 3

**Claim under review.** Compare splitting-type charts with open substacks.

**Concrete witness.** The universal one-dimensional extension family 0->O(-1)->E_t->O(1)->0 has E_0=O(-1)+O(1) and E_t=O+O for t!=0. Thus the fixed (1,-1) splitting stratum pulls back to {0}, which is not open in A^1. These bundle jumps also occur inside meromorphic-connection parameter spaces: for structural polar degree 4, End(E_0) tensor Omega^1(P)=O(2)^2+O(4)+O(0), whose H^1 vanishes, allowing nearby relative logarithmic connections; the irreducible locus supplies stable examples after choosing generic residues and, if necessary, an etale parameter neighborhood.

**Exact repair.** Distinguish the open balanced/trivial-bundle locus from locally closed fixed splitting-type strata. State the chart comparison on each actual locus and give its inclusion/closure behavior; keep framed parameter charts separate from an assertion that every splitting stratum is open.

**Acceptance test.** Pull the proposed locus statement back along the extension family: the balanced locus is A^1 minus {0}, and the (1,-1) locus is {0}. Both must be represented correctly while the total connection family remains in the full moduli space.

**Status.** independent finding

### C07 — P3: The transport checks admit the always-identity wrong model

**Location.** README.md:439-447, target 5.3 Checks; design/plan.json target 5.3 checks

**Claim under review.** The reversal, contractible-loop and nonfixed-point checks adequately test the transport and descent construction.

**Concrete witness.** Always assigning identity transport satisfies reversal and every contractible-loop check. Its fixed-point set is the entire phase, so the conditional nonfixed-point check is vacuous. In contrast B=C*, H=qp/(2t), omega=dq wedge dp has q′=q/(2t), p′=-p/(2t). At initial (1,2) over t=1, a positive loop ends at (-1,-2), not (1,2); two loops return (1,2). The Jacobian is -Id with symplectic multiplier (-1)(-1)=1. The monodromy fixed-point set is exactly {(0,0)}.

**Exact repair.** Add this concrete nontrivial-monodromy model to both README and plan checks. Keep the abstract laws, but require the computed one-loop and two-loop endpoints, preservation of omega, and descent only for the origin in this model.

**Acceptance test.** On t=exp(u), compute q=q0 exp(u/2), p=p0 exp(-u/2). Under u->u+2pi*i both signs change. Initial (1,2) does not descend; (0,0) does. An always-identity transport implementation must fail.

**Status.** Concrete countermodel to adequacy of the existing checks; the mathematical transport/descent theorem itself passes.

## All-target adversarial ledger

`core_ledger.json` contains **21 rows**, one for every numbered core target, with `id`, `instances`, `computed_left`, `computed_right`, `result` and `scope`. The field values include actual matrices, residues, dimensions, monodromy values, ring equalities, or concrete countermodels. A “pass” below means that this adversarial instance is consistent with the stated construction target; it is not a proof that the future theorem has been implemented or established in full.

- **1.1:** C01: ambiguous trace-free carrier; the residue, ramified determinant and nonreduced tests otherwise fit the stated intrinsic construction.
- **1.2:** Pass as a planned intrinsic deformation construction; time normalization and moving-divisor behavior are concrete, not determined by a scalar family list.
- **1.3:** Pass: the determinant restriction prevents scalar irregularity from being hidden by projective Katz rank. Nonempty stable fiber remains a separate admission condition.
- **1.4:** C02: ten counts underlying unlabelled types; all ordered assignments total 17. The time-dimension count itself passes.
- **2.1:** C06: splitting-type locus must be locally closed, with only specified balanced loci open. Scalar rigidification and etale-cover universal-object strategy survive the nonreduced test.
- **2.2:** Pass as a construction target: its C-linear differential and full ramified cone avoid two concrete wrong implementations. The cochain test is a cone-control example, not a claim about a particular Painleve tangent dimension.
- **2.3:** C03: require positive rank. C04: the unfolding used for closedness requires a separately constructed early family. The positive-rank numerical formula and determinant subtraction pass.
- **2.4:** Pass: a concrete stable resonant reducible point must remain in the moduli; a generic ramified local factor gives a different irreducibility mechanism.
- **3.1:** Pass: the stated strong extension, kernel lattices and allowed pole forms exclude an explicit resonant weak extension. The time differential must be the actual Kahler differential over the auxiliary base.
- **3.2:** Pass as an explicitly owned theorem: mere right inverse is insufficient, and the I23 two-parameter proof tests the nonzero mixed term.
- **3.3:** Pass with an explicit proof burden: the projection formula defines the form but does not by itself prove closedness; I23 Corollary 11.8 supplies a trace-complex argument.
- **3.4:** Pass: naturality must retain the explicit time term; the equality tested is stronger than a pointwise phase-coordinate identification.
- **4.1:** Pass as a new analytic construction, with a required precise reading of overlap uniqueness. I23 Remark 9.8 explicitly records the small-sector ambiguity; no unconditional unique-normalized-solution claim is validated.
- **4.2:** Pass: ordinary characters and decorated representations have different roles, exponent lifts are necessary, and untwisted isotopy alone is not a ramified family theorem.
- **4.3:** Pass: the all-strata semiconjugacy does not demand a false global inverse or delete stable reducible flags. Construction remains an owned proof obligation.
- **4.4:** The draft correctly requires whole-family properness. The proposed four-stage proof is genuinely new beyond IS12 Theorem 5.1/Remark 6.3; its completion is not established by the cited generic results. No counterexample to the properly scoped all-strata theorem was found.
- **5.1:** Pass: local existence/uniqueness and joint holomorphic dependence are supplied by the named holomorphic-lift gap; smooth real flow alone is not a proof of the latter.
- **5.2:** Mathematical transfer mechanism passes. C05: the generic theorem has a native-carrier signature route independent of Painleve moduli and was not separately audited in Suggested.lean. No elaboration/runtime success is claimed.
- **5.3:** Transport/descent theorem passes this nontrivial witness. The existing three abstract checks admit the incorrect always-identity transport model; use this actual computation to strengthen them.
- **5.4:** Pass: explicit observer and lifting conditions prevent both rational base-point failure and the identically-infinite loophole.
- **5.5:** Pass in the classical one-complex-dimensional time setting with a genuinely admissible observer. A general higher-dimensional base must not inherit a curve-only isolated-pole statement.

The ledger covers API-level issues as well as headline statements. In particular: nonreduced residue variation and scalar stabilizers; trace versus projective data; full ramified-cone degrees; derivative/time-change signs; lattice preservation in resonance; the mixed nilpotent term in integrability; actual time-dependent gauge terms; sectorial ambiguity; exponent-lift properness; exceptional RH fibers; whole-family versus fiberwise properness; interval continuation; universal-cover descent; and rational observer indeterminacy.

### Selected computations and their implications

**Nonreduced strong extension.** On A=ℂ[ε]/(ε²), the actual Kähler relation is ε dε=0. For D=diag(1,0) and N=E₁₂, the connection Γ=D dz/z+N dε/z has dΓ=−N dz∧dε/z² and Γ∧Γ=+N dz∧dε/z². Thus it is flat, despite its forbidden logarithmic time pole. Merely asking for flatness and unchanged relative residue would accept it. The stated stronger time-pole and kernel-lattice condition excludes it, in agreement with I23 Definition 10.1. Moving the divisor to z−ε requires dz−dε, not dz. The mixed ring ℂ[ε₁,ε₂]/(ε₁²,ε₂²) retains ε₁ε₂; replacing it by the square-zero maximal ideal would erase precisely the term used to detect brackets.

**Stable reducible resonance.** On the trivial rank-two connection over ℙ¹ with four logarithmic points and zero residues, take four different flag lines and weights (0,αᵢ), with α=(1/5,3/10,2/5,3/5). The total parabolic slope is (Σαᵢ)/2=3/4. An invariant line is constant and can agree with at most one chosen flag, so its parabolic slope is at most 3/5<3/4. This is a concrete stable reducible point with identity monodromy. A blanket “stable implies irreducible” reduction would delete it. The draft retains it correctly. This differs from the genuinely ramified irreducibility mechanism: on z=w², the two exponential factors ±1/w are exchanged by deck action, so neither eigenline descends separately.

**Closed total form.** With H=p²/2, Ω=dq∧dp+dH∧dt has kernel generated by ∂t+p∂q, matching the chosen Hamiltonian sign. But an arbitrary integrable horizontal splitting plus fiberwise closed ω does not imply closedness of the projected total form: h=∂t+q∂q and ω=dq∧dp give Ω=dq∧dp+q dp∧dt and dΩ=dq∧dp∧dt≠0. Therefore §3.3 needs the isomonodromic trace-complex constancy argument in I23 Corollary 11.8, not just its displayed projection formula. That argument is a properly identified proof burden in the draft.

**Fiberwise properness is insufficient.** Let B=ℂ*, M=(ℂ*∖{1})×ℂ², π(z,q,p)=z², R=B×ℂ², and F(z,q,p)=(z²,q,p). Every F_t is a finite disjoint union of identity maps of ℂ² and hence proper; all source fibers are nonempty, and π is a submersion. Yet z_n=1−1/n with q=p=0 maps into the compact set [1/4,1]×{0} and has no convergent subsequence in M. The whole F is not proper. A source lift along the corresponding positive real base path approaches the deleted point. This supplies a direct falsification test for any attempt to replace §4.4's whole-family theorem by separate fiberwise properness statements.

**Exceptional fibers do not require an inverse.** For Bl₀ℂ²×B→ℂ²×B, the exceptional initial points [1:0] and [0:1] map to the same target point. They nevertheless have their own uniquely prescribed horizontal source lifts in a product family. Properness gives a compact trap P¹×[0,1]; it does not provide a global inverse. The draft's §4.3/§5.2 distinction is correct.

**Observers.** The rational observer [x:y] is undefined on the constant zero curve. A blowup creates many possible exceptional lifts, with values 1/2 at [1:2] and 0 at [0:1]; resolving the rational map alone does not canonically choose a lift of an identically indeterminate section. The draft correctly demands actual lift/non-indeterminacy data. The infinity chart transforms 1/t into t, and a pole of order three has inverse vanishing order three. These are curve statements: a higher-dimensional time base has polar divisors, not isolated pole points.

## Seeded source audit

The sampled IDs for this reviewer were obtained from `_strict_review/round1/seeded_source_sample.json`, with the recorded seed `PainleveEquationsAndFunctions:strict-review:round1:720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`. The table compares actual locators and assumptions, rather than accepting citation proximity as evidence.

| Target | Actual locator and source assertion | Comparison with the draft |
|---|---|---|
| 1.2 | HEU10 Theorem 1.1, printed pp.517–518 (PDF pp.4–5); Definitions 2.3 and 2.10 (PDF pp.10 and 12). The theorem assumes a contractible parameter space, an initial marked-curve isomorphism and an initial connection isomorphism. For chosen (f,F), Ψ is unique; (f,F) can fail uniqueness when the marked curve has automorphisms. The source's basic analytic connection lane is trace-free rank two. | The quotient by coordinate/curve automorphisms is required; raw coordinate tuples are not a universal base. The draft retains this quotient and owns the determinant lift. Odd-degree determinant connections are not supplied directly by a global SL₂ reading of HEU10. The time-change and moving-divisor ledger rows test the stated adapter. C01 must remove the ambiguous trace-free rank-two output. |
| 1.4 | VDPS09 §2.2 and Table 1, pp.18–19, enumerate ten underlying singularity patterns after normalizing positions; they compute position/irregular coefficient parameters modulo automorphisms. They use trace-zero matrix presentations and explain exceptional strong-RH bundle cases. | The numerical time dimension n+Σceil(rᵢ)−3=1 is correct for the ten underlying types. It does not turn ordered assignments into ten objects: C02 exhibits 17 ordered profiles. The full-bundle construction must not inherit a trivial-bundle restriction from the table's coordinates. |
| 2.3 | I23 Theorem 7.5 (PDF p.33) gives relative smoothness and the nonempty-fiber dimension 2r²(g−1)+2+r(r−1)degP. Theorem 8.1 (PDF p.35) gives the relative symplectic form; Proposition 8.3 (PDF p.38) proves closedness after the separately constructed unfolding family in Proposition 8.2. | Positive-rank values and removal of the 2g determinant directions agree. C03 requires an explicit positive-rank domain. Theorem 8.1's closedness proof needs the auxiliary coalescing-divisor/simple-connection moduli family, not only the existing fixed-profile stable moduli family: C04. |
| 3.1 | I23 Definition 10.1 and (10.1), Propositions 10.7/10.10, and (11.2). Definition 10.1 uses actual Kähler differentials on the dual-number deformation, explicit pole bounds and preserved kernels/factorized structure. Proposition 10.7 gives the unique global horizontal lift; Proposition 10.10 uses the two-parameter ring retaining ε₁ε₂. | The draft's strong extension, central identity and kernel-lattice conditions match the source's mechanism. A weak flat extension is not enough. The explicit Γ calculation above and ledger 3.1–3.2 test the missing-pole and mixed-term failure modes. This is not a theorem about arbitrary unqualified singular local types. |
| 4.1 | I23 §9 Theorem 9.7 and Corollary 9.11: under its admissible generic formal/factorized local data, integrable extension is equivalent to constant Stokes data, with a modified unramified pullback and Galois descent for the ramified case. The construction is made on analytic neighborhoods admitting the required formal trivialization. Remark 9.8 warns that uniqueness of normalized sectorial solutions depends on sufficiently large sectors. BY15 Remark 3 and Definitions 7/13 give intrinsic exponential local systems and twisted Stokes objects. | These results supply local analytic ingredients, not the full family RH moduli theorem. The draft explicitly owns sectorial gluing/descent and the global comparison. Interpret “overlap uniqueness” as uniqueness of the resulting transition morphism with fixed data, not arbitrary small-sector normalized solutions: Y(I+cE₂₁) yields the exponentially small ambiguity in ledger 4.1. Ramified deck action cannot be discarded. |
| 5.3 | IIS06 Definitions 2.1–2.2, p.4, define a transverse complex foliation and GPP. Definition 2.4, pp.4–5, defines return maps and states their homotopy dependence; §5 (especially Theorem 5.12, p.31) proves GPP for all PVI parameters using proper RH. This source is a PVI realization, not an all-profile irregular RH theorem. | Abstract transport and universal-cover descent follow from the general flat complete connection once §§3 and 5.2 are established. The nonlinear application is appropriately owned, while principal-bundle completeness from SmoothBundlesConnections B5 is not enough by itself. The explicit −Id monodromy calculation is necessary to improve the checks: C07. |
| 5.5 | IIS06 Lemma 2.12, p.8, uses a proper holomorphic quasi-conjugacy plus source local uniqueness to transfer GPP. Theorem 10.12, p.51, derives analytic Painlevé property for the PVI Hamiltonian charts from GPP and the algebraic phase-space realization. | The general observer pullback proof is correctly owned in §5.4–5.5, not imported as a six-family source theorem. The lemma's dense-open inverse and surjectivity are stronger than necessary for the transfer, while exceptional-point compatibility remains necessary. Scalar meromorphy additionally needs an actual admissible observer and one-dimensional time; geometric completeness alone cannot repair rational indeterminacy. |

## Supplier and dependency audit

The direct contracts were checked against the frozen supplier excerpts. This is a contract audit, not a certification that each supplier's entire proposed implementation is already proved.

- **FormalConnectionsOpers F2/F3:** ordinary form connections, Hom/dual/tensor operations, gauge transformation and sheaf gluing are appropriate inputs. F2 explicitly distinguishes the form connection from its vector-field presentation over non-smooth/nonreduced bases, where Ω¹ need not be projective. Hence the nonreduced core must use actual form/Kähler data. Its formal oper isomonodromy exports in F8 do not supply the nonlinear global Painlevé connection or analytic Stokes correspondence. The draft makes that ownership distinction.
- **PadicDifferentialEquationsAndRigidCohomology RD.6.52a:** despite the roadmap title, this exact target is characteristic-zero formal irregularity, finite-ramification decomposition, descent and good lattice pairs on algebraic curves. It supplies the formal slope floor used here. It does not supply sectorial analytic existence or global proper RH; the draft owns those separately.
- **SchemeAndStackFoundations 4.14 / AlgebraicModuli 5.1, 7.1, 8.2:** the inspected Quot contract is Noetherian-projective with fixed Hilbert polynomial; rigidification uses a closed flat finitely presented normal inertia subgroup and fppf stackification, including nonreduced base change. It cannot be replaced by a quotient of the section sets. Artin/versal algebraization contracts have effectivity and formal-gluing hypotheses. Section 2.1 can use its primary bounded Quot/equation construction before §2.2, so I do not establish a forced dependency cycle. If it chooses the Artin route, those hypotheses must be verified there rather than silently borrowed from the later tangent-complex theorem. C06 repairs the separate open-stratum overclaim.
- **ComplexComparisonPartII C−1.1 / ComplexCurveModuli D2.0:** the exact proposed contracts retain coherent ideal quotients, nonreduced analytic structures, local-ringed morphisms and genuine native-manifold comparison. D2.0 assumes a finite-dimensional Hausdorff second-countable native complex manifold and constructs the local-ringed analytic instance. Those are suitable comparison suppliers; a topological quotient or mere bijective total map would not substitute for them.
- **SmoothBundlesConnections B1.5/B5 / UniversalCovers:** B1.5 has local/maximal horizontal lifts for a general Ehresmann connection, and global fibration/transport from a proper submersion; its hypotheses do not make the nonproper Painlevé projection π complete. B5's global compact-interval existence is specific to principal group equations, expressly not arbitrary Ehresmann connections. The core correctly needs its own §5.2 compact-containment argument. The cover carrier and pointed/unpointed bookkeeping are supplied separately; the nonlinear monodromy action on the constructed fiber and its fixed-point descent criterion are application theorems here.
- **Named holomorphic-horizontal-lifts gap:** this is a precise supplier addition for local holomorphic existence/uniqueness and joint holomorphic dependence, taking a genuine finite-dimensional holomorphic integrable splitting as input. Smooth real-flow existence does not prove joint holomorphic dependence. The named gap is carried consistently in the core; its admitted status is a dependency, not an implementation result.
- **Early symplectic unfolding:** unlike the above named contracts, the coalescing-divisor moduli needed by I23 §8 is not an instance of Layer 1's fixed distinct marked-point profile. This is the unresolved early input identified by C04; later Layer 11 cannot supply it without a forward dependency.

## Generic §5.2 signature review

The separate `core_5_2_candidate.lean` contains a full **unelaborated** transfer signature on native finite-dimensional real manifolds, with genuine horizontal-splitting, piecewise-path, differential-lift and target-trajectory definitions. It states a C¹ generalization of the complex path-continuation theorem; integrability is unnecessary for lifting one prescribed path. `core_5_2_blueprint.md` maps each carrier and declaration to the inspected pins, explains the literal complex wrapper and the prefix-compatibility adapter, and lists the remaining validation gates.

This is a concrete counterexample to the reasoning in Suggested.lean that the generic headline cannot even be stated because the actual Painlevé moduli is absent. It is **not** proof that the candidate compiles. In particular, the hom/pullback bundle instances, notation and the nonautonomous path adapter must be checked. The native autonomous compact-containment theorem is only a proof ingredient; replacing the headline by that one theorem would fail the review standard.

## Remaining limits and disposition

All 21 target rows have concrete adversarial witnesses. No new P1 counterexample to the admitted classical continuation theorem was established. Six P2 repairs and the concrete P3 transport check are required for this frozen core. The repaired artifact must be frozen and rereviewed: this report cannot automatically approve later edits.

The proof inputs for the proposed all-strata RH theorem remain substantial future mathematical work: uniform local-lattice bounds, proper global factorization/flag presentation, semistable replacement with retained local structure and determinant, and analytic family gluing. The draft labels them as owned work and supplies a route, which is acceptable roadmap practice provided they are not claimed as already proved by IS12 or I23. No source inspected here proves that full general theorem. Package acceptance additionally requires successful elaboration and the remaining independent review scopes.
