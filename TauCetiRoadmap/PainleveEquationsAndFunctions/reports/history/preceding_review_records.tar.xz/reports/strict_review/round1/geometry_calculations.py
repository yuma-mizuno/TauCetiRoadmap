import sympy as s
import json
from pathlib import Path
T,Q,V,W,t,q,v,p,c=s.symbols('T Q V W t q v p c', nonzero=True)
a,b,g,d,h0,h1,hinf,alpha=s.symbols('a b g d theta0 theta1 theta_inf alpha')
R=s.Rational
checks={}
def rec(name,left,right,scope):
    residual=s.factor(s.together(left-right))
    checks[name]={'computed_left':str(left),'computed_right':str(right),'residual':str(residual),'scope':scope}
    return residual
def transform(F,tmap,qmap):
    dt=s.diff(tmap,T)
    qt=(s.diff(qmap,T)+s.diff(qmap,Q)*V)/dt
    rhs=F.subs({t:tmap,q:qmap,v:qt},simultaneous=True)
    W=(dt**2*rhs-s.diff(qmap,T,2)-2*s.diff(qmap,T,Q)*V-s.diff(qmap,Q,2)*V**2+s.diff(dt,T)/dt*(s.diff(qmap,T)+s.diff(qmap,Q)*V))/s.diff(qmap,Q)
    return s.factor(s.together(W))
def P3(A,B,G,D): return V**2/Q-V/T+(A*Q**2+B)/T+G*Q**3+D/Q
def P4(A,B): return V**2/(2*Q)+R(3,2)*Q**3+4*T*Q**2+2*(T**2-A)*Q+B/Q
def P5(A,B,G,D): return (1/(2*Q)+1/(Q-1))*V**2-V/T+(Q-1)**2*(A*Q+B/Q)/T**2+G*Q/T+D*Q*(Q+1)/(Q-1)
Fpv=(2*q-1)*v**2/(2*q*(q-1))-v/t+(h0**2*(q-1)**2-h1**2*q**2)/(2*q*(q-1)*t**2)+q*(q-1)*(2*q-1)/2+q*(q-1)*(hinf-1)/t
rec('PV corrected dictionary',transform(Fpv,T,Q/(Q-1)),P5(h1**2/2,-h0**2/2,1-hinf,-R(1,2)),'T!=0,Q!=0,1')
Fdpv=(2*q-1)*v**2/(2*q*(q-1))-v/t+2*(q-1)*h0**2/(q*t**2)-2*q*h1**2/((q-1)*t**2)+8*q*(q-1)
rec('degenerate PV dictionary',transform(Fdpv,s.sqrt(T),Q/(Q-1)),P5(h1**2/2,-h0**2/2,-2,0),'chosen t=sqrt(T), T!=0,Q!=0,1')
Fd6=v**2/q-v/t-4*h0/t+4*(hinf+1)*q**2/t+4*q**3-4/q
rec('D6 dictionary',transform(Fd6,T,Q),P3(4*(hinf+1),-4*h0,4,-4),'TQ!=0')
Fd7=v**2/q-v/t+(hinf+1)*q**2/t+q**3-2/t**2
rec('D7 dictionary',transform(Fd7,T**2,Q/T),P3(4*(hinf+1),-8,4,0),'t=T^2,TQ!=0')
Fd8=v**2/q-v/t+2*q**2/t**2-2/t
rec('D8 dictionary',transform(Fd8,T**2,T*Q),P3(8,-8,0,0),'t=T^2,TQ!=0')
Fp4=v**2/(2*q)+R(3,2)*q**3+t*q**2+(t**2+4*hinf+4)*q/8-h0**2/(8*q)
rec('PIV dictionary',transform(Fp4,2*T,Q/2),P4(-hinf-1,-2*h0**2),'Q!=0')
Fjm=2*q**3+t*q+(hinf+1)/2
rec('JM PII dictionary',transform(Fjm,T,Q),2*Q**3+T*Q+(hinf+1)/2,'all finite jets')
Fpi=6*q**2+2*t
pi=transform(Fpi,T/c,c**2*Q)
rec('PI dictionary before c^5=2',pi,6*Q**2+T,'c^5=2; numerator of residual divisible by c^5-2')
checks['PI root reduction']={'numerator_remainder':str(s.rem(s.fraction(s.together(pi-6*Q**2-T))[0],c**5-2,c))}
Ffn=v**2/(2*q)+4*q**2+2*t*q-h0**2/(2*q)
fn=transform(Ffn,-T/c,Q/c)
P34=V**2/(2*Q)+2*Q**2-T*Q-h0**2/(2*Q)
rec('FN scaling before c^3=2',fn,P34,'c^3=2,Q!=0; numerator residual divisible by c^3-2')
checks['FN root reduction']={'numerator_remainder':str(s.rem(s.fraction(s.together(fn-P34))[0],c**3-2,c))}
# P34 transformation and inverse, with a as chosen signed exponent.
def D(expr,F): return s.diff(expr,T)+s.diff(expr,Q)*V+s.diff(expr,V)*F
F34=V**2/(2*Q)+2*Q**2-T*Q-a**2/(2*Q)
y=(V-a)/(2*Q)
y1=s.factor(D(y,F34)); y2=s.factor(D(y1,F34))
rec('P34 to PII',y2,2*y**3+T*y+a-R(1,2),'U=Q!=0, a^2=theta0^2')
rec('P34 recovery identity',y1+y**2+T/2,Q,'U=Q!=0')
F2=2*Q**3+T*Q+a-R(1,2)
u=V+Q**2+T/2
u1=s.factor(D(u,F2));u2=s.factor(D(u1,F2))
rec('PII to P34 cleared residual',2*u*u2-u1**2-4*u**3+2*T*u**2+a**2,s.Integer(0),'identity all PII jets; original P34 only u!=0')
rec('PII recovery identity',(u1-a)-2*u*Q,s.Integer(0),'original division only u!=0')
# PVI Hamiltonian elimination, standard x, q. H from IIS06 (1).
k0,k1,k2,k3,k4=s.symbols('k0 k1 k2 k3 k4')
H=(q*(q-1)*(q-t)*p**2-(k1*(q-1)*(q-t)+k2*q*(q-t)+(k3-1)*q*(q-1))*p+k0*(k0+k4)*(q-t))/(t*(t-1))
A=s.diff(H,p);B=-s.diff(H,q)
pinv=s.solve(s.Eq(A,v),p)[0]
elim=s.factor((s.diff(A,t)+s.diff(A,q)*A+s.diff(A,p)*B).subs(p,pinv))
F6=(1/q+1/(q-1)+1/(q-t))*v**2/2-(1/t+1/(t-1)+1/(q-t))*v+q*(q-1)*(q-t)/(t**2*(t-1)**2)*(k4**2/2-k1**2*t/(2*q**2)+k2**2*(t-1)/(2*(q-1)**2)+(1-k3**2)*t*(t-1)/(2*(q-t)**2))
constraint={k0:(1-k1-k2-k3-k4)/2}
rec('PVI Hamiltonian dictionary',elim.subs(constraint),F6,'t!=0,1;q!=0,1,t;2k0+sum(k1..k4)=1')
# Source PV error numeric control
source_pprime=(2*q-1)*p**2/(q*(q-1)*t)+(h0**2*(q-1)**2-h1**2*q**2)/(4*q*(q-1)*t)+q*(q-1)*(2*q*t-t+2*hinf-2)/4
source_qprime=2*p/t
qsecond=s.diff(source_qprime,t)+s.diff(source_qprime,q)*source_qprime+s.diff(source_qprime,p)*source_pprime
witness={t:1,q:2,p:0,h0:0,h1:1,hinf:1}
printed=Fpv-(h0**2*(q-1)**2-h1**2*q**2)/(2*q*(q-1)*t**2)+h0**2/(2*q*t**2)+h1**2/(2*(q-1)*t**2)
checks['PV source negative control']={'compatible_system':str(qsecond.subs(witness)),'corrected_scalar':str(Fpv.subs({**witness,v:0})),'printed_scalar':str(printed.subs({**witness,v:0}))}
# All PIII zero patterns coverage
patterns=[]
import itertools
for vals in itertools.product([0,1],repeat=4):
 aa,bb,gg,dd=vals
 case='D6' if gg*dd else 'D7' if ((gg==0 and aa*dd) or (dd==0 and bb*gg)) else 'D8' if (gg==dd==0 and aa*bb) else 'elementary' if ((aa==gg==0) or (bb==dd==0)) else 'UNCLASSIFIED'
 patterns.append({'alpha_beta_gamma_delta':vals,'class':case})
checks['PIII zero-pattern coverage']=patterns
# PIII scaling t=lT,q=mQ: coefficients (lm alpha,l beta/m,l^2m^2 gamma,l^2delta/m^2)
l,m=s.symbols('l m', nonzero=True)
F3=v**2/q-v/t+(a*q**2+b)/t+g*q**3+d/q
rec('PIII scaling rule',transform(F3,l*T,m*Q),P3(l*m*a,l*b/m,l**2*m**2*g,l**2*d/m**2),'lmTQ!=0')
rec('PIII inversion rule',transform(F3,T,1/Q),P3(-b,-a,-d,-g),'TQ!=0')
# Degenerate first integrals using log-time s and q=t*y, alpha=gamma=0.
y,z,C=s.symbols('y z C', nonzero=True)
# y_s^2=C*y^2-2b*y-d -> y_ss=C*y-b -> w_ss=(y*y_ss-y_s^2)/y^2=b/y+d/y^2
rec('PIII elementary first integral derivative',(y*(C*y-b)-(C*y**2-2*b*y-d))/y**2,b/y+d/y**2,'q=t*y!=0,t!=0')
# PV gamma=delta=0 in x=log(t), y=q, z=dq/dx.
I=z**2/(y*(y-1)**2)-2*a*y+2*b/y
zdot=(1/(2*y)+1/(y-1))*z**2+(y-1)**2*(a*y+b/y)
rec('PV quadrature first integral derivative',s.diff(I,y)*z+s.diff(I,z)*zdot,s.Integer(0),'t!=0,q!=0,1; I=z^2/[q(q-1)^2]-2alpha*q+2beta/q')
# PII Hamiltonian and seeds
H2=p**2/2-(q**2+t/2)*p-(alpha+R(1,2))*q
A2=s.diff(H2,p);B2=-s.diff(H2,q)
rec('PII elimination',s.diff(A2,t)+s.diff(A2,q)*A2+s.diff(A2,p)*B2,2*q**3+t*q+alpha,'polynomial chart')
for name,av,qv,pv in [('zero',0,0,t/2),('rational',1,-1/t,2/t**2+t/2)]:
 rec('PII '+name+' q',s.diff(s.sympify(qv),t),A2.subs({alpha:av,q:qv,p:pv}), 't!=0 for rational seed')
 rec('PII '+name+' p',s.diff(pv,t),B2.subs({alpha:av,q:qv,p:pv}), 't!=0 for rational seed')
# Geometric line negative control and D4 affine matrix
M=-2*s.eye(5)
for j in range(1,5):M[0,j]=M[j,0]=1
null=s.Matrix([2,1,1,1,1])
checks['affine D4 boundary']={'matrix':M.tolist(),'multiplicity_kernel':list(M*null),'rank':M.rank(),'nullity':5-M.rank(),'finite_D4_minor_determinant':M[:4,:4].det()}
# central Weyl reflection in coefficient coordinates
K=s.Matrix([R(1,2),0,0,0,0])
S=s.eye(5);S[0,0]=-1
for j in range(1,5):S[j,0]=1
K1=S*K
checks['central PVI reflection']={'input':list(K),'output':list(K1),'input_constraint':2*K[0]+sum(K[1:]),'output_constraint':2*K1[0]+sum(K1[1:]),'square_matrix':(S*S).tolist()}
# P34 actual zero witness from Q=-1/T, a=3/2
up=2/T**2+T/2
checks['P34 zero-locus witness']={'Q':str(-1/T),'a':'3/2','U':str(up),'Uprime_at_Tcubed_minus4':'3/2','Q_for_opposite_a':'Q+3/(2U), pole at U=0','a0_U_identically0':'all Q satisfying Qprime=-Q^2-T/2 collapse to U=0'}
# Sigma controls
checks['PI sigma excluded branch']={'sigma':'a*t+2*a^3','sigma_equation_residual':'0','q':'-a','PI_residual':'-6*a^2-t'}
checks['PII sigma collapsed Riccati branch']={'c':'alpha+1/2=0','p':'0','sigma':'H=0','sigma_prime':'-p/2=0','sigma_second':'2*q*sigma_prime-c/2=0','reconstruction':'q=(2*sigma_second+c)/(4*sigma_prime) undefined','lost_fiber':'all initial q values on invariant p=0 curve'}
# all values stringify for JSON
out=Path('_strict_review/round1/geometry_calculations.json')
out.write_text(json.dumps(checks,indent=2,default=str)+'\n')
for k,val in checks.items():
 if isinstance(val,dict) and 'residual' in val: print(k+': '+val['residual'])
 else: print(k+': '+json.dumps(val,default=str))
