import sys
sys.path.insert(0,'/workspace/scratch/e290e3b48e5b/vendor')
import sympy as s
import json
from pathlib import Path
path=Path('_strict_review/round1/geometry_calculations.json')
checks=json.loads(path.read_text())
T,Q,V,W,t,q,v,p,c=s.symbols('T Q V W t q v p c',nonzero=True)
h0,h1,hinf=s.symbols('theta0 theta1 theta_inf')
num={T:s.Integer(2),Q:s.Integer(3),V:s.Integer(5),h0:s.Integer(2),h1:s.Integer(3),hinf:s.Integer(4)}
for key in ['PV corrected dictionary','degenerate PV dictionary','D6 dictionary','D7 dictionary','D8 dictionary','PIV dictionary','JM PII dictionary']:
 d=checks[key]
 d['numeric_instance']='T=2,Q=3,V=5,theta0=2,theta1=3,theta_inf=4'
 loc={str(x):x for x in [T,Q,V,W,t,q,v,p,c,h0,h1,hinf]}
 d['numeric_left']=str(s.factor(s.sympify(d['computed_left'],locals=loc).subs(num)))
 d['numeric_right']=str(s.factor(s.sympify(d['computed_right'],locals=loc).subs(num)))
# All eight affine graphs, not merely one displayed root name.
def matrix(n,edges):
 M=-2*s.eye(n)
 for i,j in edges:M[i,j]=M[j,i]=1
 return M
graphs={}
for n in range(4,9):
 edges=[(0,2),(1,2)]+[(i,i+1) for i in range(2,n-2)]+[(n-2,n-1),(n-2,n)]
 graphs['D'+str(n)]=(n+1,edges)
for name,arms in [('E6',[2,2,2]),('E7',[1,3,3]),('E8',[1,2,5])]:
 edges=[];cursor=1
 for length in arms:
  prev=0
  for j in range(length):edges.append((prev,cursor));prev=cursor;cursor+=1
 graphs[name]=(cursor,edges)
for name,(n,edges) in graphs.items():
 M=matrix(n,edges);vec=M.nullspace()[0];den=s.ilcm(*[x.q for x in vec]);vec=den*vec
 if vec[0]<0:vec=-vec
 graphs[name]={'vertices':n,'edges':edges,'rank':M.rank(),'nullity':n-M.rank(),'primitive_multiplicities':list(vec),'intersection_times_multiplicity':list(M*vec),'expected_generic_external_dimension':9-n,'intersection_matrix':M.tolist()}
checks['all_eight_boundary_matrices']=graphs
# Canonical dPV/PIII' transformation and time-normalization witness.
l,mu,x,z,u0,ui=s.symbols('lambda mu x z chi0 chi_inf')
HP=(l**2*mu**2-(l**2+(u0-1)*l-t)*mu+(u0+ui-1)*l/2)/t
lm=(1-x)**2*z+(u0-1)*(1-x)/2
mum=1/(1-x)
k0=(u0-ui-1)/2
ki=(u0+ui-1)/2
HV=(x*(x-1)**2*z**2-k0*(x-1)**2*z+(k0**2-ki**2)*(x-1)/4-t*x/(x-1))/t
res=s.factor(s.together(HP.subs({l:lm,mu:mum},simultaneous=True)-HV))
checks['dPV_PIIIprime_canonical_map']={
 'map':'x=1-1/mu; z=mu^2*lambda-(chi0-1)*mu/2',
 'inverse':'mu=1/(1-x);lambda=(1-x)^2*z+(chi0-1)*(1-x)/2',
 'domain':'mu!=0, equivalently x!=1; additional ordinary scalar loci separately retained',
 'jacobian_forward':str(s.det(s.Matrix([[s.diff(1-1/mu,l),s.diff(1-1/mu,mu)],[s.diff(mu**2*l-(u0-1)*mu/2,l),s.diff(mu**2*l-(u0-1)*mu/2,mu)]]))),
 'forms':'dx wedge dz = -d lambda wedge d mu (the source momentum convention/order must be compared; see note below)',
 'source_H_minus_target_H':str(res),
 'parameters':'kappa0=(chi0-chi_inf-1)/2; kappaInf=(chi0+chi_inf-1)/2',
 'sample':'chi0=3,chi_inf=2,t=5,lambda=7,mu=2 -> x=1/2,z=26; inverse lambda=7,mu=2'
}
# The source map printed in DIL21 actually is anti-symplectic if x=1-1/mu,z=mu^2*lambda-...! Check sign conventions explicitly.
# Do not use this external comparison as evidence of a roadmap error; the roadmap requires a correct derivation.
path.write_text(json.dumps(checks,indent=2,default=str)+'\n')
for key in ['PV corrected dictionary','degenerate PV dictionary','D6 dictionary','D7 dictionary','D8 dictionary','PIV dictionary','JM PII dictionary']:
 print(key,checks[key]['numeric_left'],checks[key]['numeric_right'])
print(json.dumps(graphs,indent=2,default=str))
print(json.dumps(checks['dPV_PIIIprime_canonical_map'],indent=2))
