# Independent geometric and coordinate review — round 1

## Verdict and scope

**No additional established P1, P2, or P3 defect was found in the eleven assigned targets of this immutable draft.** This is a scoped mathematical roadmap review, not acceptance of the complete roadmap or a claim that its owned theorems have been proved. Findings from the other reviewers are independent of this conclusion.

Reviewed README SHA-256: `720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`.

The complete 1084-line README was read for interfaces. The deep audit covers **§§6.1–6.3, §§7.1–7.3, and §§9.1–9.5: all eleven targets**, including their API bullets, checks, source attributions, dependency ownership, formula conventions, exceptional loci, and classification converses. The artifact was read only. No Worker, GitHub mutation, subagent, or Lean build was run by this reviewer. Previous review reports were not used as mathematical evidence.

The actual rubric was read from `_research/worker_contract_sources/prompts/review.md`, `redteam.md`, and `sections/adversarial.md`, `defect-classes.md`, and `gaps-and-order.md`. An explicitly owned construction/proof target is permitted. Its mere difficulty is not a defect, but a theorem cannot be treated as supplied by a source that only conjectures it. I tested both the claims and the stronger claims that the text expressly excludes. The ledger records actual values and countermodels rather than “checked” assertions.

**Official package acceptance is not established.** The parent reports that the available Lean launcher still fails with `failed to locate application`, including with the ordinary `LEAN_SYSROOT` setting. This reviewer did not obtain a compiler certificate or an independent model-family review. Exact symbolic calculations below are mathematical evidence for identities, not Lean certificates or proofs of global moduli theorems.

## Evidence files

- `geometry_ledger.json`: all eleven targets, each with instances, computed left and right sides, result, scope, and sources.
- `geometry_calculations.json`: exact rational-function residuals, all eight affine boundary matrices, coefficient-pattern enumeration, source counterexamples, and further comparison computations.
- `geometry_calculations.py` and `geometry_extended_calculations.py`: main reproducible symbolic calculations. The final repaired dPV/PIII-prime comparison is additionally recorded explicitly in the JSON and below.
- `geometry_findings.json`: final scoped finding list, plus nonblocking tested refinements.

## Source and hypothesis verification

The seeded sample assigned four rows to this audit: **6.1, 6.2, 7.1, and 9.2**. Their locators were checked against actual primary source text extracted from the saved PDFs, not merely a bibliography or another review. Other primary sources required by the assigned targets were also read.

| Target | Exact source locus compared | Source hypothesis/conclusion | Comparison with this draft |
|---|---|---|---|
| 6.1, seeded | STT02 Definitions 1.1 and 1.3; Proposition 1.2; Tables 2–3 | Rational smooth projective surface, anticanonical divisor with componentwise zero intersections; additive/multiplicative/elliptic Picard type; nonfibered excludes a fiber **nY for every n≥1**. The SNC additive classification excludes Kodaira II/III/IV and retains the eight affine D/E diagrams. The older affine-plane requirement excludes D8. | Lines 486–501 retain each restriction. The draft does not import the older affine-plane requirement. The relative nonreduced Picard construction is owned rather than supplied by a smooth-curve Jacobian theorem. |
| 6.2, seeded | STT02 Proposition 1.2/Tables 2–3; VDPS09 introduction and §2.2/Table 1, pp.18–19; IIS06 §10, especially Theorems 10.6, 10.10, 10.13 | STT classifies pair boundaries. VDPS lists ten profiles and conjectures the general global Okamoto comparison; its chosen trivial-bundle calculations give an affine Zariski open. For D8 and PI its initial construction even restricts to modules satisfying the strong RH problem. IIS supplies the much stronger PVI comparison, using multiple charts; its Wronskian chart is only on the designated open. | Lines 505–521 explicitly own the full compactification, overlaps, exceptional/nontrivial-bundle coverage and form/distribution comparison. They do not treat VDPS's conjecture or a generic chart as a global theorem. The eight matrices and all ten rows match Table 1. |
| 7.1, seeded | IIS06 Definition 3.5 and §7; I23 Definition 10.1, with local decorations from §§2–4 | IIS's elementary transformation is the kernel of the invariant-flag quotient. It changes determinant and local exponents. I23's strong extension is a total integrable connection preserving specified logarithmic/unramified/ramified filtration data; it is more than an arbitrary relative logarithmic modification. | Lines 555–570 retain invariant flags, determinant/exponent/stability changes, inverse data, and preservation of the strong total connection. General preservation is an owned proof target; no assertion that the logarithmic kernel example proves the ramified statement was found. |
| 9.2, seeded | VDPS09 §2.2/Table 1 and §4; IIS06 Theorems 10.6/10.10/10.13; AHT17 introduction and §§2–3; DLMF 32.2.1–32.2.6 | Ten formal presentations, eight surfaces, noncanonical chart and determinant conventions. AHT distinguishes scalar dPV/PIII equivalence from an isomorphism of the distinct isomonodromy families. VDPS has the PV and extended-form sign defects independently reproduced below. | Lines 742–804 retain ten presentations, specify coordinate/time/parameter dictionaries, require inverse and overlap domains, and do not infer a moduli isomorphism from a common scalar equation. All displayed scalar dictionaries pass exact differentiation after the stated source corrections. |
| 6.3 | TER02 Theorem 2.1 and Proposition 2.1; Conjecture 2.1; STT02 Theorem 3.1; ST04 Theorem 2.1 and Appendix A | For the admitted nonfibered additive pair, the first boundary layer is one-dimensional and injects into local cohomology. The entire supported-cohomology dimension is a separate conjecture/restricted theorem. In the semiversal family the time tangent has the indicated KS image. | Lines 525–541 make this distinction and explicitly own the relative constant-rank/base-change/KS proof. No canonical nonzero vector is asserted without normalized time. |
| 7.2 | IIS06 Theorem 7.4, Remark 7.5(2), Theorem 10.13; STT02 marked deformation construction and tables | PVI has the cited symmetry theorem. The central reflection is not a local gauge modification; the source discusses the additional Fourier route. A boundary table does not construct effective marked-surface transformations for all profiles. | Line 576 explicitly chooses and owns the marked-pair construction, effective domains, Coxeter relations, symplectic/horizontal transport, and extension. The PVI theorem is explicitly not promoted to all profiles. |
| 7.3 | ST04 §2.4, Proposition 2.1, Remark 2.4, Definition 2.3, Theorem 3.1, §6.2; IIS06 Theorem 5.15 | Local deformation/invariance of an interior (-2)-curve uses the time direction in the admitted family; the Hilbert component can require a finite cover and can have nontrivial continuation. The nodal configurations exclude E8/D7/D8. Rational solutions need not be Riccati solutions. IIS06 Theorem 5.16 has analytic-Painlevé assumptions. | Lines 594–612 keep base change, descent, projective-versus-linear lifting, scope of reducibility comparisons and the non-completeness distinction. Theorem 5.16 is not used as an independent premise. |
| 9.3 | FM19 §1.1 equation (2); DIL21 §§5.2–5.3 and Appendix B.3; DLMF 32.9.6 and 32.9.12 | PIII four coefficient classes, elementary alternatives included; ordinary/degenerate/quadrature PV cases; quadratures on appropriate domains. Source first integrals do not by themselves justify all stationary converse branches. | Lines 806–822 request all tuples, nonzero normalizations, actual elementary integrations and original-domain checks. No unqualified converse from a squared first integral is stated. |
| 9.4–9.5 | VDPS09 §4.1 and equations (2),(3),(5),(44),(46),(47), §§4.10–4.11; DLMF 32.6–32.7 and 32.9 | Sign conventions and special-solution formulas must be compared. Sigma reconstruction has exceptional derivative loci. | The explicit source corrections and PI sigma branch analysis are correct. PII gives a further collapsed-family negative control, already within line 826's requirement to restrict converses and track exceptional derivatives. |

DLMF's actual equation pages were consulted at `https://dlmf.nist.gov/32.2`, `https://dlmf.nist.gov/32.6`, `https://dlmf.nist.gov/32.7`, and `https://dlmf.nist.gov/32.9`. Primary PDF/text files used were STT02, TER02, ST04, IIS06, I23, VDPS09, AHT17, FM19 and DIL21. BERT17/Layer 8 was read at the interface level here; its detailed source validity is the tau reviewer's assigned scope. No all-profile surface theorem, all-profile marked-Weyl theorem, or general relative boundary-line theorem was found ready-made in the cited sources. Those facts are proof debt of the explicitly owned targets, not verified source theorems.

## Layer 6: geometric definitions, full complement, and the time line

### 6.1 — the exclusions are substantive

The definition at line 486 is intrinsic. It does not define a surface by membership in a six-equation case list. The list of eight boundary diagrams is a subsequent classification.

A smooth cubic in the plane blown up at nine points has strict transform Y with Y²=9−9=0 and K+Y=0. Its Picard identity component is an elliptic curve; dimension one alone would not make it additive. An SNC cycle of n rational curves has normalization (P1)^n and circular dual graph: the normalization/units sequence gives Pic⁰=Gm. Both are excluded by the actual additive condition.

Additivity alone also fails. For example, the rational elliptic surface `y²=x³+t²x+t³` has I0* fibers at 0 and infinity. At an I0* fiber the multiplicity vector is (2,1,1,1,1), every component has self-intersection −2, Mδ=0, and Pic⁰(Y)=Ga. Nevertheless Y is a fiber with n=1, so the nonfibered condition excludes it. This tests the second restriction independently of the first.

The relative Picard supplier is not being applied blindly. Line 501 owns universal O_B→p_*O_Y, H²(O_Y)=0, smoothness and constant dimension, including formal smoothness over a nonreduced base. These are the relevant hypotheses for ComplexComparisonPartII C3.2d.2/C3.2f.1–2. Its identity-component theorem does not allow geometric smoothness and fiber dimension to be substituted for formal smoothness over nilpotents.

### 6.2 — all eight intersection calculations, and the missing-curve test

I constructed every affine graph independently, with diagonal −2 and off-diagonal +1 for an edge. In each case Mδ=0 for the following primitive positive vector, and the rank is r−1.

| Boundary | r | Primitive multiplicities in the ledger's vertex order | Rank | 9−r external parameters |
|---|---:|---|---:|---:|
| D4 | 5 | (1,1,2,1,1) | 4 | 4 |
| D5 | 6 | (1,1,2,2,1,1) | 5 | 3 |
| D6 | 7 | (1,1,2,2,2,1,1) | 6 | 2 |
| D7 | 8 | (1,1,2,2,2,2,1,1) | 7 | 1 |
| D8 | 9 | (1,1,2,2,2,2,2,1,1) | 8 | 0 |
| E6 | 7 | (3,2,1,2,1,2,1) | 6 | 2 |
| E7 | 8 | (4,2,3,2,1,3,2,1) | 7 | 1 |
| E8 | 9 | (6,3,4,2,5,4,3,2,1) | 8 | 0 |

These computations test the proposed intersection and dimension data. They are not themselves a proof that arbitrary connection moduli admit the asserted compactification. That construction is owned at lines 505–521.

The source restriction matters concretely. If C is an interior Riccati curve in an E7 phase and U=(S\\D)\\C, the identity on U preserves the same form and distribution. Yet the inclusion U→S\\D has empty preimage at every x∈C. Thus generic coordinate agreement, even symplectic and horizontal agreement, cannot establish the full open-complement assertion. Lines 507, 512 and 519 explicitly demand the missing coverage theorem. VDPS09's chosen trivial-bundle charts cannot be silently substituted for it.

The two D6 profiles `(0,0,1/2)` and `(1,-,1)` have different formal local data; the two E7 profiles likewise differ. Their repeated boundary labels do not supply a moduli equivalence. Line 517 and the subsequent coordinate-comparison scope preserve this distinction.

### 6.3 — line, generator, injection, and relative base change

For central-first affine D4, δ=(2,1,1,1,1), Mδ=0, rank(M)=4, and ker(M) is one-dimensional. Replacing δ by 3δ=(6,3,3,3,3) changes a generator, not the line. Conversely the injection C→C², z↦(z,0), has one-dimensional source but two-dimensional target. This directly defeats the inference from the boundary-layer injection to dim H¹_D=1. TER02 does not prove that stronger assertion in its Theorem 2.1; line 527 correctly separates it from Conjecture 2.1 and restricted ST04 Appendix A results.

A concrete nonreduced negative control is A=C[ε]/(ε²) and the free complex A --ε--> A. Every geometric fiber has zero differential and a one-dimensional kernel. But ker(ε)=(ε)≅C is not locally free over A, and the natural map `(ker ε)⊗_A C → ker(ε⊗_A C)` is the **zero map C→C**, not an isomorphism. The corrected constant-rank-zero model A --0--> A has kernel A and identity base-change map C→C. This is a tested repair of the inference, not an assertion that the bad complex comes from an actual Okamoto family.

Line 539 explicitly disallows the bad inference. Line 541 owns constant-rank, family/base-change and KS comparison for this particular boundary complex. An implementation still needs the intrinsic connecting-map/intersection-matrix proof, cohomology comparison, and actual identification with the time direction; pointwise dimensions do not complete that work. I did not find those ingredients treated as supplied by an unrelated theorem or replaced with a scalar case split.

## Layer 7: transformations and Riccati curves

### 7.1 — kernel, determinant, pole order, and inverse

Take a diagonal logarithmic connection on Oe1⊕Oe2 with residues λ1,λ2 and invariant flag Ce1. The negative elementary transform is Oe1⊕O(ze2), has residues λ1,λ2+1, decreases degree by one, and changes determinant to det(E)(−D). Tensoring a rank-two bundle by a line L instead changes determinant by L² and degree by 2deg(L); it cannot undo an odd degree shift by choosing an integral-degree “square root.” These agree with lines 566–568.

Flag invariance is necessary. With residues 0 and 1 and the flag C(e1+e2), the transformed frame g1=e1+e2, g2=ze2 gives ∇g1=g2 dz/z²: a double pole appears. This is not the admitted logarithmic modification. Applying the same negative construction twice using the new flag gives E(−D); recovering E requires the appropriate inverse operation/twist. It is not a bare involution on unchanged flags and determinants.

The draft's functors carry determinant, exponent, stability and local decoration changes. Preservation of a strong total connection through the ramified filtrations is a further theorem owned here, not proved by the elementary logarithmic calculation. This respects the actual I23 Definition 10.1 interface.

### 7.2 — central reflection and the limits of a lattice calculation

At κ=(1/2,0,0,0,0), the central reflection must give `(-1/2,1/2,1/2,1/2,1/2)`. The relation 2κ0+Σκj=1 is preserved. If κ0 were incorrectly left fixed while the four outer parameters shifted, the result would satisfy 2κ0+Σκj=3 instead. The correct transformation squares to the identity on parameters.

On the scalar open p≠0, q↦q+κ0/p preserves dq∧dp. At q=2,p=3,κ0=1/2 it gives 13/6; using the transformed κ0=−1/2 on the second step returns 2. Reusing the old κ0 incorrectly gives 7/3. At p=0 and κ0≠0 the scalar formula is undefined, so a curve-preservation or global-automorphism claim needs a separate extension.

Line 586 does not explicitly print κ0↦−κ0, but it does not assert that κ0 stays fixed. The sign is forced by its constraint, the reflection requirement, and the cited source. Adding it would make the check more self-contained; I do **not** classify the omitted redundant formula as a false transformation.

For a root α with α²=−2, the abstract formula rα(v)=v+(v·α)α satisfies rα²(v)=v and preserves the pairing. This alone does not construct an effective marked surface, a birational map of connection moduli, or a horizontal/symplectic map. STT02's tables do not fill those gaps. However line 576 explicitly owns the additional marked-pair construction, its effectivity conditions, Coxeter relations, connection-moduli transport, form/distribution comparison and complement extensions. An explicit period/Torelli or Cremona realization must be part of that construction. The draft has not falsely cited the PVI theorem as accomplishing it for all profiles.

### 7.3 — projective regularity, actual invariance, and continuation

For the trace-zero matrix `M=[[b/2,c],[-a,-b/2]]`, a horizontal vector u satisfies `(u1/u2)'=a q²+b q+c`. Under r=1/q, the equation becomes r′=−a−br−cr², holomorphic at r=0. By contrast q′=q³ becomes r′=−1/r and is singular there. This computes the degree-two bound in line 605 and the actual projective linearization.

For a (-2)-curve C≅P1, N_C≅O(−2), hence h⁰(N_C)=0 and h¹(N_C)=1. Lifting the time direction requires its normal deformation obstruction to vanish. ST04's logarithmic deformation construction supplies the geometric route under its stated family hypotheses; rationality alone does not. The PII affine locus p=0 has p′=0 at α=−1/2 but p′=1/2 at α=0. Thus the same equation defining an affine curve does not prove invariance at all parameters.

ST04 Remark 2.4 retains a finite Hilbert cover. If continuation sends labels (C1,C2) to (C2,C1), neither chosen label descends as a global subfamily on the original base. Lines 594 and 607 retain exactly this possibility. A projective linear connection also need not have a chosen global rank-two lift until the lifting obstruction is resolved; the draft only asserts a local lift automatically.

The nonexistence types E8, D7 and D8 agree with ST04 Theorem 3.1. Reducibility/RH-exceptional identifications are presentation-specific: ramified generic local data force global irreducibility without eliminating the E7 Riccati locus. The draft does not use the false presentation-independent equivalence or classify all rational solutions from Riccati curves.

## Layer 9: coordinate dictionaries, degenerations, and exceptional branches

### 9.1 — first jets really need an inverse open

Differentiating q′=A(t,q,p), p′=B(t,q,p) gives q″=A_t+A A_q+B A_p. With A=p and B=q at q=2,p=3, both this expression and the scalar right side are 2, with inverse p=v.

Nonzero A_p is only a local condition. With A=p² and B=1, the points p=1 and p=−1 have the same velocity v=1, while A_p=2 and −2 and q″=2 and −2 respectively. A single-valued scalar right side on their combined image does not exist. A branch/open-set choice repairs the issue. With A=q, points p=0 and p=1 over q=2 have the same first jet (q,v)=(2,2), so momentum is completely lost. Lines 720–738 impose the actual inverse-open condition and explicitly include both failure modes.

### 9.2 — every displayed dictionary was differentiated

I used the chain rule with the stated time and dependent-variable changes, then compared the resulting rational function to the standard scalar equation. No numeric tolerance was used. At the shared test values T=2, Q=3, Q′=5, θ0=2, θ1=3, θ∞=4, the exact values are:

| Presentation | Transformed source right side | Standard right side | Exact residual |
|---|---:|---:|---:|
| PV, corrected source | 39/2 | 39/2 | 0 |
| Degenerate PV | 24 | 24 | 0 |
| PIII D6 | 397/2 | 397/2 | 0 |
| PIII D7 | 1199/6 | 1199/6 | 0 |
| PIII D8 | 227/6 | 227/6 | 0 |
| PIV | 168 | 168 | 0 |
| Jimbo–Miwa PII | 125/2 | 125/2 | 0 |
| PI, c⁵=2 | 56 | 56 | 0 modulo c⁵−2 |
| Flaschka–Newell/P34, c³=2 | 31/2 | 31/2 | 0 modulo c³−2 |
| PVI, κ1=…=κ4=0 and κ0=1/2 | 143/12 | 143/12 | 0 |

The PI residual before imposing c⁵=2 is `−T(c⁵−2)/c⁵`. The FN residual before c³=2 is `−U(2U−T)(c³−2)/c³`. Thus these are simultaneous time-and-dependent-variable normalizations, not a rescaling of time alone.

Raw source momentum inverses were also checked: PV p=tv/2, dPV p=tv/4, D6 p=(tv−q)/4, D7 p=tv/2, D8 p=(tv−q)/2, PIV p=v, FN p=v/2, JM p=v, PI p=v/2. PVI has denominator 2q(q−1)(q−t), and its time coefficients require t(t−1)≠0. These are source-chart formulas; transformed Darboux momenta and the full complement still require the draft's form/overlap comparisons.

For P34, with a²=θ0² and U≠0, the identities

`Q=(U′−a)/(2U), alpha=a−1/2, U=Q′+Q²+T/2`

have zero forward residual, zero recovery residual, and zero reverse cleared residual. The original P34 equation remains restricted to U≠0. A concrete zero is supplied by Q=−1/T at alpha=1: U=T/2+2/T². At any T0³=−4, U(T0)=0 and U′(T0)=3/2. The branch a=3/2 has finite Q=−1/T; choosing a=−3/2 instead gives Q_new=Q+3/(2U), with a simple pole. At a=0 the branch U≡0 corresponds to the whole alpha=−1/2 Riccati family and cannot be inverted by division. This tests the actual exceptional locus demanded by line 795, rather than treating a cleared identity as a global bijection.

### 9.3 — sufficient normalizations, not only necessary case budgets

All sixteen PIII zero/nonzero patterns were enumerated: four fall in D6, four in D7, one in D8 and seven in the merged elementary alternatives. The classifications cover every pattern exactly once after merging the two overlapping elementary conditions.

Under t=lT and q=mQ with lm≠0, parameters transform as

`(alpha,beta,gamma,delta) -> (lm alpha, l beta/m, l²m² gamma, l² delta/m²)`.

Inversion q=1/Q gives `(-beta,-alpha,-delta,-gamma)`. These exact identities supply sufficient normalizations:

- D6: choose m⁴=−delta/gamma and l²=4/(m²gamma); the last two coefficients become (4,−4).
- D7 with delta=0: choose m⁴=beta²/(16gamma) and l=−8m/beta; beta becomes −8 and gamma becomes 4. Inversion handles the other non-elementary one-sided case.
- D8: choose l²=−64/(alpha beta) and m=8/(l alpha); (alpha,beta) becomes (8,−8).
- PV: t=lT gives `(alpha,beta,l gamma,l² delta)`. Choose l²=−1/(2delta) for ordinary PV, or l=−2/gamma for the degenerate case.

These choices are nonzero under the corresponding case hypotheses and exist over C with explicitly chosen roots. A nonzero scaling cannot turn (gamma,delta)=(4,−4) into (0,0).

For elementary PIII with alpha=gamma=0, setting x=log t and y=q/t gives the first integral `y_x²=C y²−2 beta y−delta`. For PV with gamma=delta=0 one obtains `q_x²=(q−1)²(2 alpha q²+C q−2 beta)`. Their derivatives along the original flows vanish exactly. The all-zero PIII solution is q=C exp(mu log t), C≠0, on the logarithmic cover; a generic complex power is not a single-valued entire function on the punctured plane.

The reverse direction requires an extra equilibrium check. In elementary PIII, alpha=gamma=delta=0, beta=1, C=2, y=1 gives the first integral 0=0 but q=t has original-equation residual −1/t. For PV, alpha=1, beta=gamma=delta=0, C=−4, q=2 gives 0=0 but original residual −2/t². These are stationary branches introduced by a squared first integral, even though none of the ordinary scalar denominators vanish. Checking the original second-order equation rejects both. Line 820 owns actual integration with domains, branches and constants; it does not state the false unconditional reverse implication. These are useful additional required controls when that target is implemented.

### 9.4 — both printed-source corrections pass; PII sigma loses an entire family

With source convention p′=F H_q and q′=−F H_p, the correct kernel form is dp∧dq/F+dH∧dt. For F=1,H=p²/2 and h=∂t−p∂q, its contraction is zero. The printed minus form contracts to 2p dp, or **4 dp at p=2**. With Q=q, P=p/F(q), K=−H(F(Q)P,Q,t), the canonical extended form is exactly the negative of the corrected source form. Line 828 has the correct sign and argument order.

The PV witness at t=1,q=2,p=0,θ0=0,θ1=1,θ∞=1 gives q″=2 from the compatible system and the corrected scalar equation, but 7/2 from the printed scalar equation. The corrected exponent numerator in line 830 is exactly what differentiation gives.

The PI sigma branch σ=at+2a³ satisfies the displayed sigma relation identically. Its reconstruction q=−a has PI residual −6a²−t and cannot solve PI on an open time domain. On σ″ not identically zero, differentiation gives `2σ″(σ‴+6σ′²+t)=0`; analyticity extends the remaining factor across isolated zeros. Line 832's branch restriction and extension argument are correct.

PII supplies a different exceptional behavior. Set c=alpha+1/2 and σ=H. Then

`σ′=−p/2, σ″=2qσ′−c/2, q=(2σ″+c)/(4σ′)`.

Its sigma relation is `σ″²+4σ′³+2tσ′²−2σσ′−c²/4=0`. At c=0,p=0, **every solution of the Riccati family maps to σ≡0**. Thus one loses a one-parameter phase family, not merely a spurious linear sigma branch. Moreover any constant σ=C satisfies the scalar sigma relation when c=0, while C≠0 cannot be the Hamiltonian value of a p=0 phase. A scalar sigma bijection across σ′=0 would therefore be false.

The current text does not assert that bijection: line 826 restricts converse lemmas to proved reconstruction loci and explicitly requires exceptional derivatives. Adding this exact PII control would strengthen reviewability, but no missing unconditional hypothesis was found in the present statement. Lax-pair compatibility must still be derived from the actual total connection, and tau identifications retain the independent hypotheses of §§8.3–8.4.

### 9.5 — both Hamilton equations and projective extension

For PI, H=p²/2−2q³−tq gives q′=p and p′=6q²+t. For PII, the stated H gives q′=p−q²−t/2 and p′=2qp+alpha+1/2. Eliminating p with p=q′+q²+t/2 gives precisely q″=2q³+tq+alpha.

At alpha=0, (q,p)=(0,t/2) has both sides (q′,p′)=(0,1/2). At alpha=1, (q,p)=(−1/t,2/t²+t/2) has both sides `(1/t²,−4/t³+1/2)`. At alpha=−1/2, p=0 is invariant and q′=−q²−t/2. Substitution q=u′/u gives u″=−tu/2. A nonzero linear solution cannot have both u(t0)=u′(t0)=0 by uniqueness, so its zeros are simple; q has a pole there and the projective solution continues. This verifies the whole projective curve interpretation without pretending q remains finite.

Adding c(t) to H leaves H_p and H_q unchanged. If the normalized comparison is d log tau=H dt, the tau ratio is an exponential primitive of c(t), up to a multiplicative constant. Line 845 conditions this on the actual §8.4 comparison. Lines 847–849 do not promote the seed orbit into a complete classification of rational/algebraic solutions or a Hastings–McLeod construction.

## Additional source-only pitfall: the dPV/PIII-prime momentum sign

DIL21 Remark 5.1 prints a transformation of the form

`x=1−1/mu, z=mu² lambda−(chi0−1)mu/2`.

Relative to the ordered canonical forms dλ∧dμ and dx∧dz, its Jacobian is **−1**. Its Hamiltonians differ only by the time function `1−(chi0−1)²/(4t)`, so importing the printed map as a symplectic conjugacy with unchanged flow sign would be wrong.

An explicitly tested repair is

`x=1−1/mu, Z=−mu² lambda+(chi0−1)mu/2`,

with inverse `mu=1/(1−x), lambda=−(1−x)²Z+(chi0−1)(1−x)/2`, together with `kappa0=−(chi0−chiInf−1)/2` and `kappaInf=(chi0+chiInf−1)/2`. The Jacobian is +1, the Hamiltonian difference is the same time function, and both pushed-forward Hamiltonian-equation residuals are exactly zero. This changes a signed parameter while preserving the relevant squares. The domain requires mu≠0, equivalently x≠1, and t≠0, with scalar exclusions retained separately.

This is **not a new draft finding**: the README does not print that source map or claim its unchecked canonicity; §9.2 demands an actual transformation with inverse, form and domain proof. It is recorded because blindly implementing the cited source would otherwise introduce a defect. The repaired computation is stored in `geometry_calculations.json`.

## Supplier and native-library dependencies

The actual supplier READMEs in `_research/roadmap_sources/TauCetiRoadmap` and `_research/roadmap_proposed` were inspected at the demanded interfaces:

- **SchemeAndStackFoundations:** §§2.6–2.7 for sheaves/support, 2.20 for the relevant cohomological interface, 3.4 for Picard objects, 4.11/4.14/4.17 for schemes/Hilbert/blowups, and 5.9–5.10 for intersection/adjunction/Riemann–Roch. Its intersection theory is not already a theorem about arbitrary relative marked Okamoto compactifications; that adapter stays owned by Layer 6.
- **ComplexComparisonPartII C3.2d.2/C3.2f.1–2:** universal functions and correct relative Picard/identity-component hypotheses, including the distinction between reduced bases and formal smoothness over nonreduced ones. Line 501 explicitly retains them.
- **JacobianChallenge Layer C:** proper coherent cohomology and base change. Constant geometric fiber dimensions over a nonreduced base do not alone supply a locally free kernel; the dual-number witness above explains why line 541's owned constant-rank argument matters.
- **AlgebraicVectorBundles L0/L1 and FormalConnectionsOpers:** genuine bundle/kernel/determinant and decorated-connection carriers. These supply objects and operations, not a proof that every operation preserves every stability chamber or strong extension.
- **ComplexKahlerGeometry K1/K3/K4:** analytic chart/local-function interfaces and the actual holomorphic connection carrier, with gauge transformations, curvature, pullback, local parallel frames, and the distinction between a projective connection and a chosen global rank-two lift. K4 does not assert that all projective connections globally lift; §7.3 retains the obstruction.

The native libraries were searched in `_validation/mathlib` and `_validation/tauceti`. The nearby theorem `TauCeti.NumericalType.exists_chain_or_fork_or_exceptional` in `TauCeti/AlgebraicGeometry/Curves/StableReduction/NumericalType/Classification.lean` concerns a proper connected subset in a numerical component classification. It does not supply the whole affine boundary classification, the relative compactification, the local-cohomology time line, or the marked-pair action. No unsupported claim of a native finished Painlevé theorem or duplication was made in this audit. These library inspections were textual; compilation was unavailable as stated above.

## Completion conditions that remain real proof work

The following are not certified by this review, and must not disappear when implementation starts:

1. The all-profile full-complement compactification and comparison, including omitted exceptional and nontrivial-bundle charts (§6.2).
2. The intrinsic intersection/connecting-map identity, the relative boundary-line theorem over admitted bases, and its KS/horizontal-distribution comparison (§6.3).
3. The actual marked-pair reflection construction, effective domains, all relations, and horizontal/symplectic extensions for each asserted profile (§7.2).
4. Local curve deformation, permitted base change, descent and global lift obstructions in the precise admitted family (§7.3).
5. Actual moduli charts and all inverse/overlap/reconstruction domains, including P34 zeros, stationary quadrature branches, sigma collapse and Hamiltonian sign conventions (§§9.1–9.5).

Each item has a stated owner in the immutable draft. The audit did not treat these planned proofs as already established, and did not turn their stated ownership into a proof. Within the assigned eleven targets, no additional false statement, vacuous definition, unowned bridge, or source-scope overclaim survived the concrete tests.
