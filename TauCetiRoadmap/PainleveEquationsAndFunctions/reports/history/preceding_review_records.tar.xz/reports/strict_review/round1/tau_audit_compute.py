from pathlib import Path
from fractions import Fraction as Q
import hashlib, json, math

ROOT=Path('/workspace/scratch/58443e4fc6da')
OUT=ROOT/'_strict_review/round1'
ART=OUT/'artifact'
sha=hashlib.sha256((ART/'README.md').read_bytes()).hexdigest()
assert sha=='720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731'
plan=json.loads((ART/'design/plan.json').read_text())
targets={t['id']:t for l in plan['layers'] if l['key'] in ['8','10','11'] for t in l['targets']}

# Exact Q(i) arithmetic for the nontrivial ILP eta-periodicity witness.
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[0],-a[1])
def sub(a,b):return add(a,neg(b))
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def inv(a):
 d=a[0]*a[0]+a[1]*a[1]
 return (a[0]/d,-a[1]/d)
def div(a,b):return mul(a,inv(b))
def sq(a):return mul(a,a)
one=(Q(1),Q(0));ii=(Q(0),Q(1))
s1=(Q(1,5),Q(0));s3=(Q(0),Q(1,3))
s2=div(add(s1,s3),sub(one,mul(s1,s3)))
assert s2==(Q(20,113),Q(39,113))
assert add(sub(s1,s2),add(s3,mul(mul(s1,s2),s3)))==(Q(0),Q(0))
u=inv(sub(one,mul(s1,s3)));v=neg(mul(ii,s2));w=(Q(3),Q(0))
assert u==(Q(225,226),Q(15,226))
assert v==(Q(39,113),Q(-20,113))
assert sub(w,v)==mul(u,sub(w,inv(w)))
R=div(sq(sub(w,v)),mul(sq(u),sq(sub(w,inv(w)))))
assert R==one
assert Q(2,3)*Q(3,5)==Q(2,5)
assert -Q(16,2)-Q(4,4)+Q(16)/(Q(2)-Q(1,4))==Q(1,7)
assert Q(1)/(Q(2)**2*(Q(2)-Q(1,4)))==Q(1,7)
assert (Q(3,4)+Q(4,8))==Q(5,4)
assert Q(1)/(Q(1,20)-Q(1,10))-Q(1)/Q(1,20)==-40

rows=[]
def row(id, cases, apis, test_cases, result, scope, sources, findings=()):
 t=targets[id]
 assert len(apis)==len(t['api']), (id,len(apis),len(t['api']))
 assert len(test_cases)==len(t['tests']), (id,len(test_cases),len(t['tests']))
 assert all(1<=x<=len(cases) for x in test_cases)
 rows.append({
  'id':id, 'name':t['name'],
  'instances':[{'case':f'{id}:{n}', 'input':c[0]} for n,c in enumerate(cases,1)],
  'computed_left':[c[1] for c in cases],
  'computed_right':[c[2] for c in cases],
  'instance_results':[c[3] for c in cases],
  'result':result,'scope':scope,'findings':list(findings),
  'api_audit':[{'name':a['name'],'statement':a['statement'],'audit':d} for a,d in zip(t['api'],apis)],
  'check_audit':[{'name':a['name'],'statement':a['statement'],'witness':f'{id}:{n}'} for a,n in zip(t['tests'],test_cases)],
  'dependency_contracts':t['prerequisites'],'source_comparison':sources
 })

row('8.1',[
 ('T_s:C->C is multiplication by s; F=C, a=1, K frame (-1,s).','projection K->F = s; det(K*) tensor det(F) has section coordinate s','det(T_s)=s, not 1/s','equality; fixes direction and sign in the selected frames'),
 ('T_s=s^2; pull back by s=u^2.','tau=s^2; ord_0(tau)=2; dim ker(T_0)=dim coker(T_0)=1; pulled-back tau=u^4','multiplicity 2 != kernel dimension 1; base-change multiplicity 4','the stated negative control and base-change law survive'),
 ('Constant scalar T=2 and T=0.','T=2: tau=2, ker=coker=0. T=0: tau=0, ker=coker=C, index=0','both determinant lines are C; only the first section is nonzero','line existence does not imply generic nonvanishing'),
 ('Scalar stabilizers a=2,b=3,c=5, with K_a frame (-1,s/a).','tau_a=s/2, tau_b=s/3, tau_c=s/5; g_ab=2/3,g_bc=3/5','g_ab*g_bc=2/5=g_ac; tau_b=g_ab*tau_a','exact refinement cocycle in a finite-dimensional model')],
 [
 'The scalar projection is s, establishing the dual-convention adapter. HeegaardFloer F0.0 itself is real and uses the opposite determinant convention; the complex holomorphic F0.0C is an explicitly named uncompleted supplier gap.',
 'The 2/3,3/5,2/5 refinement computation and s=u^2 pullback test the actual gluing/base-change obligations; holomorphic construction is owned by F0.0C, not inferred from closed curvature.',
 'For operator trivializations T_new=P1*T*P0^-1, finite determinants transform by det(P1)/det(P0); composition multiplies these ratios. The bundle-valued version needs precisely the retained operator-isomorphism comparisons.',
 'T=2 and T=0 distinguish invertibility, generic nonvanishing and existence of the line; no genericity is hidden in the index-zero hypothesis.'
 ],[1,2,3], 'conditional_contract_survives; no new defect found',
 'Fixed complex Hilbert spaces and holomorphic Fredholm index-zero family. The proposed supplier F0.0C is not implemented or assumed proven; its construction and complex trivialization/gluing are explicit prerequisites.',
 ['MAL04 §2 pp.1372–1374: holomorphic loop group, Fredholm determinant extension, invertible finite-rank perturbations and transition determinants.','BERT17 §1: smooth closed contour, holomorphic invertible jump in a fixed neighborhood, determinant winding zero; generic zero partial indices are a separate hypothesis for a proper divisor.','HeegaardFloer F0.0: real stabilization/exact-sequence determinant and orientation line. ComplexComparisonPartII C0.3: finite-rank holomorphic bundle tensor/dual/determinant/gluing only, not the analytic Fredholm-family theorem.'])

row('8.2',[
 ('E=O(-1) direct-sum O on P1, degree d=-1.','chi(E(-1))=-1; chi(E(k))=2*k+1','for integer k, 2*k+1 is never 0','the odd-degree index obstruction is real and explicitly retained'),
 ('Unit circle jump M=diag(z,z^-1), with Bertola symbol S=M^-1.','wind(det M)=0; dim ker(T_S)=1; dim coker(T_S)=1; index=0','identity jump has index=0 but ker=coker=0','index zero does not imply solvability; normalized partial indices still matter'),
 ('Cohomology of E=O(1) direct-sum O(-1), twisted by -1; automorphism diag(lambda,mu).','H0=C in O(0), H1=C in O(-2); determinant-line weight lambda^-1*mu','scalar lambda=mu gives 1; lambda=2,mu=1/2 gives 1/4','Euler weight zero tests only scalars; full stabilizer action remains necessary'),
 ('BERT17 Theorem3.3 jump M=[[z-v,-1/2],[2,0]], with the zero v of a between the two factorization contours.','det M=1; ord_v(a)=1; c(v)=2; tau_tilde/tau=2^-1=1/2','nonzero transition 1/2, not literal equality 1','actual factorization comparison has a unit multiplier'),
 ('Adjoin an auxiliary complex [C --s--> C] to an invertible normalized problem.','extra determinant factor=s; extra complex acyclic only when s!=0','new section has an additional zero at s=0; s is not a unit there','arbitrary modification cannot be treated as stable equivalence across s=0')],
 [
 'The zero-winding operator construction has a genuine operator and the explicit index formula; the odd-degree case still requires the owned modification/sewing adapter. The core phase degree is not forced to zero.',
 'The factorization ratio 1/2 and the nonacyclic added complex distinguish proved equivalences from arbitrary reference changes. Identity and composition must be constructed for the actual Fredholm/chain equivalences.',
 'The weight lambda^-1*mu is a nontrivial stabilizer character even when scalar weight is zero. SchemeAndStackFoundations §1.22 supplies algebraic QCoh presentation descent, not an automatic analytic coarse-descent theorem; the analytic equivariance/coarse criterion is owned here with C0.3.',
 'The initial closed-contour stratum is precisely sourced; ramified/resonant sectorial sewing and normalization remain explicit new construction targets. No cited generic theorem supplies them automatically.'
 ],[1,3,4], 'conditional_contract_survives; no new defect beyond explicitly owned adapter constructions',
 'The examples test the determinant/RHP and stack mechanisms. The nontrivial stabilizer example is a determinant-complex negative control, not an assertion that every stable Painleve object has that stabilizer. Analytic stack descent and ramified sewing are roadmap constructions.',
 ['MAL04 §2: sewn E is trivial iff its Toeplitz/Fredholm problem is invertible; degree zero iff index zero.','BERT17 §1, Theorem2.2 and Theorem3.3: S=M^-1 convention, normalized solvability, contour-factorization transition product of c(v)^(-ord a).','ToeplitzOperators T3: continuous matrix symbol invertible iff Fredholm, index=-wind(det symbol); scalar Coburn does not give block invertibility.','SchemeAndStackFoundations §3.3: chi(E)=deg(E)+rank(E)(1-g), and deg(E(k))=d+2k on P1. §1.22: algebraic QCoh descent. OI-B23/B30: completed complex trace-class carrier; C0.3: finite-rank analytic gluing.'])

row('8.3',[
 ('Scalar trace-class K(s)=1-s^2, s!=0.','-Tr((1-K)^-1*dK)=-(1/s^2)*(-2s ds)=2 ds/s','d log det(1-K)=d log(s^2)=2 ds/s','exact trace identity; the pole residue is 2 and not dim ker=1'),
 ('Bundle extension 0->O(-1)->E_s->O(1)->0 with extension class s; twist by -1.','connecting map H0(O)=C -> H1(O(-2))=C is multiplication by s; cohomology complex [C --s--> C]','tau=s; E_s remains a bundle family at s=0 while its selected normalized cohomology problem fails','bundle-chart failure does not equal loss of the geometric family; actual horizontal continuation is still supplied by Layer5'),
 ('One three-valent vertex with M1=I+xE12,M2=I+yE21,M3=(M1M2)^-1.','at x=y=0 the three ordered pair traces are +dx^dy,-dx^dy,+dx^dy; sum=dx^dy','eta_v=-dx^dy/(4*pi*i) !=0; theta_v=-x dy/(4*pi*i) has dtheta_v=eta_v for this local family','nonzero vertex correction explicitly survives; closed contours cannot erase it without a sewing comparison'),
 ('A(z)=[[0,z^-2],[z^-1,0]] dz, cover z=w^2 and gauge diag(1,w).','pulled/gauged coefficient=[[0,2/w^2],[2/w^2,1/w]]; leading eigenvalues ±2/w^2','original minimal slope=1/2, outside BERT10 Assumption3.1 and logarithmic MAL04 Theorem5.12','no stated ramified JMU differential, descent factor or H coefficient is supplied for the promised comparison'),
 ('Frame multiplier f=e^(3t) on a regular time leaf.','tau_new=f*tau; dlog tau_new=dlog tau+3dt','the Fredholm-to-Malgrange formula needs the same exact frame correction','frame change has an explicit nonzero derivative, even on a fixed-monodromy leaf')],
 [
 'The C--s-->C complex and s^2 test divisor support and multiplicity. Effective Cartier divisor needs a nonzero section on the stated reduced connected smooth chart; it is not supplied for an identically zero section.',
 'The trace derivative and e^(3t) frame calculation are correct on the invertible trace-class locus. BERT17 (3.6) adds a factorization correction; it does not identify the scalar determinant with the raw Malgrange primitive without that term.',
 'The generic comparison matches BERT10/BERT16 hypotheses. The requested extra ramified/resonant comparison has no separate exact target or formula: TAU-R1-05.'
 ],[2,1,3], 'needs_changes: TAU-R1-05; generic determinant and corrected-form subclaims survive',
 'General Fredholm identity on constructed admissible RHP charts; JMU comparison only generic unramified semisimple-leading and logarithmically nonresonant inputs. The vertex calculation is local and does not assume that all other vertices or bulk terms vanish.',
 ['Seeded source sample: BERT17 Theorem2.2 (RHP solvability), Proposition2.3 (integrable-kernel variation), formula(3.6) (dlog tau=omega_M+factorization correction), Theorem3.3/§3.1.2 (transition law).','BERT10 Assumption3.1 and §5.1 Proposition5.1: unramified diagonal formal type with distinct leading eigenvalues and nonresonant logarithmic exponents, on the fixed-monodromy time directions.','BERT16 Definition2.1 corrects the sign; Theorem2.1 equations(2.4)–(2.6) supply eta_V; Theorem2.2 supplies theta_V on a local monodromy chart and replaces the earlier Theorem5.1.','RandomMatrices §8.3 owns trace-class determinant/trace foundations; the generic holomorphic derivative and integrable-kernel comparison are explicitly proved here.'],['TAU-R1-05'])

row('8.4',[
 ('H=t, tau(0)=1; add c(t)=3.','tau=e^(t^2/2); tau_new=e^(t^2/2+3t)','dlog tau_new=(t+3)dt and tau_new(0)=1','time-only correction and normalization agree'),
 ('Time u=2t for the same one-form Hdt=t dt.','Hdt=(u/2)*(du/2)=u du/4','at u=2 the coefficient is 1/2, whereas the untransformed H is 1','the time coefficient must transform'),
 ('tau_1=e^t and tau_2=7e^t; base point t=0.','dlog tau_1=dlog tau_2=dt; tau_1(0)=1,tau_2(0)=7','equal logarithmic derivatives do not fix the scalar until the base values agree','normalization test survives'),
 ('Regular leaf C* with alpha=(1/2)dt/t.','universal-cover t=e^u: tau=e^(u/2); u->u+2*pi*i multiplies tau by -1','a nonzero base value does not remove this holonomy obstruction','the stated simply-connected restriction is substantive'),
 ('Full parameter plane C^2 with alpha=x dy.','dalpha=dx^dy !=0','C^2 is simply connected but no nonzero scalar tau has dlog tau=alpha','simple connectedness does not cure curvature'),
 ('Slope-1/2 connection of 8.3:4, or an arbitrary phase-dependent frame tau_new=e^(tq)*tau.','for a horizontal field with q constant, d_t log(tau_new/tau)=q and d_phase q=dq','for zero phase dynamics, a Hamiltonian has d_phase H=0; q is not such a Hamiltonian without the explicit frame correction','Fredholm coefficient alone cannot replace the missing extended Hamiltonian comparison')],
 [
 'The exact phase Hamiltonian, numerical coefficient, gauge/frame and time-only terms must be independently fixed; the e^(tq) example shows why a trace derivative cannot simply be renamed the dynamics Hamiltonian. TAU-R1-05 affects the undefined extended locus.',
 'The u=2t and e^(3t) computations verify the time and frame laws. Time-dependent symplectic-chart corrections must come from the actual chart transformation, as the target requires.',
 'Closed scalar form plus base value gives uniqueness on the stated simply-connected regular leaf; C* half-monodromy and C^2 curvature test the two separate obstructions.'
 ],[1,2,3], 'needs_changes: TAU-R1-05; normalization and transformation laws otherwise survive',
 'MAL04 Theorem5.12 is logarithmic Schlesinger and nonresonant; BERT10 Proposition5.1 with BERT16 is generic unramified. The frozen artifact does not supply the extended ramified/resonant H identity. Local complex primitives and frame calculus remain consumed, not proven by the supplied scalar examples.',
 ['Seeded source sample: MAL04 §5 and Theorem5.12 use the Schlesinger family and nonintegral residue-eigenvalue differences; fixed-monodromy leaf restriction is essential.','BERT10 §5.1 Proposition5.1 and BERT16 correction preserve the generic formal-normalization restrictions; BERT17 (3.6) includes a nontrivial frame/factorization one-form.','ComplexKahlerGeometry K1/K3.0/K4/K7.1 provides complex charts, analytic comparison and line-bundle/connection calculus, not an all-strata Painleve H identification.'],['TAU-R1-05'])

row('10.1',[
 ('Functions y_c(t)=c e^-t in a closed proper subsector of |arg t|<pi/2.','c=1 and c=2 have identical zero power-series asymptotic expansion; y_2-y_1=e^-t !=0','for every N, |t|^N e^-Re(t)->0 in such a subsector','formal asymptotic series alone does not select c'),
 ('Local resolution model Bl_0(C^2)->C^2.','two points (0,[1:0]) and (0,[0:1]) both map to (0,0)','the exceptional fiber is P1, so the base point does not determine its lift','structural negative control for coarse-RH uniqueness; not an assertion that every RH fiber is exceptional'),
 ('Asymptotic leading coefficients C_-=2,C_+=3 of one chosen tau frame; multiply that frame representative by 5.','new leading coefficients are 10 and 15','individual coefficients change, while the consistently normalized ratio remains 15/10=3/2','normalization changes must be tracked without falsely changing a common-scale-invariant ratio'),
 ('A branch change log(t)->log(t)+2*pi*i in t^a, a=1/2.','t^(1/2) is multiplied by exp(pi*i)=-1','two unrecorded branches can give opposite leading constants','branch restriction and continuation path belong to the boundary record')],
 [
 'Restriction of e^-t to a smaller subsector preserves its coefficient c; the square-root branch example computes a nontrivial branch transformation. Actual geometric comparison maps, rather than a free equivalence relation, remain required.',
 'The boundary record contains no solution. A normalized RHP with the specified lift must be constructed by 10.2 and the Layers4–5 comparisons; the exceptional-fiber example prevents silently importing a coarse inverse.',
 'Uniqueness is only for the selected normalized problem and lift; exp-small freedom and the exceptional fiber demonstrate why the stronger statement would fail. The analytic realization remains an owned target.',
 'Connection constants compare two specified asymptotic normalizations of the same continued section. The 2,3 ->10,15 example checks common scaling while the branch sign checks path/branch dependence.'
 ],[1,2,3], 'definition_and_scoped_contract_survive; dependent on repaired 10.2 for realization',
 'These are negative controls on boundary specifications, not substituted Painleve existence theorems. The underlying formal exponential/sector data, RHP normalization and lifted phase point are separate inputs/constructions.',
 ['Seeded source sample: ILP18 §1.4 specifies homogeneous PII Stokes data, real-ray endpoints and tau branches; §§3.3–3.4 use matched local parametrices and a normalized Fuchsian RHP for PVI.','ILP18 Lemma3.3 uses the strict exponent-spread condition s=max|Re(sigma_j-sigma_k)|<1 and successive residual estimates O(t^(1-s)), then O(t^(2-s)/(1+|z|)); this is a specific sectorial realization, not a general uniqueness assertion from a formal series.','ILP18 §§4.2–4.3 construct the PII asymptotics in their specified Stokes/branch charts. These exact models do not remove the need for lift data in other resonant or exceptional strata.'])

row('10.2',[
 ('Identity jump on Sigma=[0,1], w=0.','C_w=0, C_-w=0, Neumann solution nu=0, mu=I and constructed Cauchy solution R=I','R-I=0 and residual norm=0','existence and error estimate for the constructed solution survive'),
 ('Same identity jump; R_1=I+(exp(-1/z)/z)E12.','det R_1=1, R_1+=R_1-, R_1=I+O(1/z); boundary correction norm^2=e^-2/2','at z=-r its correction magnitude=e^(1/r)/r; an L2 Cauchy transform is bounded by C*sqrt(1/r-1/(1+r))','R_1 satisfies the written jump/holomorphy/normalization and L2 traces, but is excluded only by an unstated endpoint/growth class'),
 ('Abstract one-dimensional resolvent model A=rho I, b=1.','(I-A)^-1 b=1/(1-rho); rho=1/2 gives 2 and rho=9/10 gives 10','bound ||b||/(1-rho) gives exactly 2 and 10; at rho=1 invertibility fails','sharp Neumann loss; this tests the bounded-operator estimate, not an additional RHP existence claim'),
 ('Unit-circle jump diag(2,1/2).','w=diag(1,-1/2) has L-infinity norm 1; R_+=diag(2,1/2), R_-=I solves the normalized RHP','failure of strict smallness does not imply nonsolvability','explicit determinant-one normalized solution outside the simplest strict-smallness sufficient bound'),
 ('Repair: require R-I=C(h), h=R_+-R_- in L2, with the actual Plemelj reconstruction and local parametrix endpoint conditions.','identity jump implies h=0, so C(h)=0 and R=I','the endpoint ghost has h=0 but R_1-I!=0, so it fails the repaired class','repair excludes the witness; L2 boundary traces alone do not')],
 [
 'Neumann construction in nu avoids placing I in L2 on an unbounded contour. Uniform rho<1 gives locally normally convergent Banach-holomorphic inverses; their derivative is (I-A)^-1*(DA)*(I-A)^-1. The 2 and 10 examples test quantitative dependence.',
 'The 2 and 10 resolvent values test the required 1/(1-rho) loss. Moment estimates and undoing the actual parametrix are independent obligations before extracting a connection coefficient.',
 'Sector-overlap equality requires that both reconstructions satisfy the same explicitly stated normalized Cauchy/endpoint class; TAU-R1-01 prevents that uniqueness argument as written. With the repaired class the identity ghost is excluded, then the actual reconstructed phase point continues through Layer5.',
 'An invertible normalized RHP determines its marked lifted object through the actual reconstruction adapter. It does not invert an unaugmented coarse RH map: the P1 exceptional-fiber negative control in 10.1:2 supplies two distinct lifts of one coarse point. Retaining lattice/resolution data is necessary.'
 ],[1,3,4], 'needs_changes: TAU-R1-01',
 'Bounded Cauchy operators and L2∩L-infinity residual jump are sufficient for the singular-integral equation, but the frozen RHP solution class is undefined. The repaired class must also establish determinant removability/invertibility and the needed endpoint behavior.',
 ['ILP18 §§3.3–3.4 and §§4.2–4.3 provide concrete matched-parametrix RHPs and invoke singular-integral theory with specific endpoint/contour behavior.','OI-B23/B30 supply operator-ideal completeness/norm infrastructure, while Toeplitz T3 treats closed-contour matrix symbols; neither defines the full arbitrary endpoint solution class written here.','The local Cauchy-class uniqueness/reconstruction and necessary moment/endpoint theorem are explicitly new targets, but need an unambiguous domain.'],['TAU-R1-01'])

row('10.3',[
 ('PVI theta_0=0; homogeneous PII source alpha=0.','2*theta_0=0 is an integer; changing alpha to 1 changes q-double-prime=tq+2q^3 to tq+2q^3+1','PVI TheoremA excludes the first input; PII TheoremB does not claim the alpha=1 equation','the two advertised exclusions match the exact source'),
 ('PII Stokes triple (s1,s2,s3)=(i,i,0).','s1-s2+s3+s1*s2*s3=0; 1-s1*s3=1; epsilon=-1; i*epsilon*s2=1; mu=nu=0','equation exp(i*pi*eta)=-i*epsilon/s3 requires division by 0','allowed generic Stokes input does not lie in the literal eta chart; a continued formula is genuinely additional'),
 ('HM Stokes triple (-i,0,i), versus rotated (0,-i,-i).','HM: 1-s1*s3=0 and s2 real. Rotated: epsilon=1,mu=nu=eta=0','the first fails (1.25); the rotated input gives Upsilon_0=2^(1/24)*exp(zeta-prime(-1)+i*pi/24)','HM is a boundary calibration, not an instance of the unrotated generic theorem'),
 ('Nontrivial generic triple s1=1/5,s3=i/3,s2=(20+39i)/113, epsilon=-1.','u=exp(2*pi*i*mu)=(225+15i)/226; v=exp(i*pi*nu)=(39-20i)/113; w=exp(i*pi*eta)=3; w-v=(300+20i)/113=u*(8/3)','Barnes recurrence gives Upsilon(eta+2)/Upsilon(eta)=(w-v)^2/[u^2*(w-w^-1)^2]=1 exactly','an actual complex rational Stokes triple passes the eta-periodicity identity'),
 ('Barnes normalization and zero domain.','G(1)=G(2)=G(3)=1,G(4)=2,G(5)=12; ord_(z=-n)G(z)=n+1','G(1)=1, whereas a totalized Gamma(0)*G(0)=0; recurrence cannot be used there','the supplier excludes the Gamma-pole locus and supplies the required zero orders'),
 ('Absolute HM calibration uses arcs arg z in [-pi/3,0] and [2pi/3,pi].','exp(-z^2) is entire and flat at both real ends, but |exp(-R^2 exp(-2*pi*i/3))|=exp(R^2/2)','pole-freeness plus real-ray asymptotics gives no vanishing large-arc integral','uniform sectorial (4.74) remainder/arc estimates are missing from the frozen named calibration inputs'),
 ('Homogeneous PII phase chart H9=1/2 p^2-(q^2+t/2)p-q/2, p=q-prime+q^2+t/2.','H_ILP=q-prime^2-q^4-tq^2=2*H9+q+t^2/4; at (q,q-prime,t)=(1,2,0): p=3,H9=1,H_ILP=3','2*1+1+0=3, not H9=1','coefficient and correction terms are indispensable to the normalization dictionary')],
 [],[1,1,2,3], 'needs_changes: TAU-R1-06; source branches, exclusions, Barnes and eta-periodicity survive',
 'PVI TheoremA exactly on (1.13)/(1.17), with its specified cubic relation, branches and auxiliary-chart denominators. PII TheoremB only alpha=0 and (1.25). No exceptional-chart formula is declared proved; continuation remains an identified additional local target. HM complex-sector calibration needs the extra uniform input.',
 ['Seeded source sample: ILP18 TheoremA: 2theta_nu notin Z; sigma,rho nonzero and 0<=Re(sigma),Re(rho)<1/2; all four signed exponent sets in (1.17) avoid Z; logarithmic and tau branches fixed. Formula(1.19) also uses (1.20)–(1.21), whose denominators/roots require their chart.', 'ILP18 TheoremB: Stokes cubic s1-s2+s3+s1*s2*s3=0; 1-s1*s3 nonzero with Arg in (-pi,pi); s2 not real; epsilon=sign(Re(i*s2)); branch Arg(i*epsilon*s2) in (-pi/2,pi/2); definitions(1.27) and eta formula/formula(1.28).','ILP18 §4.5 (4.74) explicitly needs uniform complex-sector HM Hamiltonian asymptotics, cites FIKN, and uses them to discard large arcs before (4.76). DIK08 Theorem1 provides chi=log(2)/24+zeta-prime(-1) for the real Airy determinant. HXZ16 Theorem2.1 provides sector pole-freeness, not the missing uniform asymptotic estimates.','AnalyticNumberTheoryPartII §§4.3–4.3a owns the canonical Barnes product, recurrence away from Gamma poles, zero multiplicities and sectorial asymptotics. RandomMatrices §8.5 owns the HM solution and determinant/TW identities.'],['TAU-R1-06'])

row('10.4',[
 ('alpha=0 chart, arbitrary real jet q(t0)=a,q-prime(t0)=b, p=b+a^2+t0/2.','q-prime=p-q^2-t/2=b; p-prime=2q*p+1/2','q-double-prime=(2q*p+1/2)-2q*(p-q^2-t/2)-1/2=2q^3+tq','the first-jet inverse reconstructs the correct scalar equation'),
 ('Concrete jet a=1,b=2,t0=0.','p=3; p-prime=13/2; q-double-prime=13/2-4-1/2=2','2*a^3+t0*a=2','exact phase/scalar adapter computation'),
 ('Supplier Airy boundary normalization, change k=1 to k=2.','lim q/Ai=1 versus lim (2q)/Ai=2','2 !=1; furthermore scaling q by 2 does not preserve homogeneous PII in general','the HM normalization cannot be changed silently'),
 ('Initialize the same supplied solution at two regular times a and b, then compare on a common connected domain.','both jets reconstruct p=q-prime+q^2+t/2; their evaluated (q,q-prime) coincide at the transported overlap','first-jet injectivity and uniqueness identify the same intrinsic horizontal germ, hence its continuation','structural equality, conditional on the actual 9.1/9.5 inverse and Layers5.1–5.3 uniqueness'),
 ('Logical negative control for real-to-complex pole-freeness: f(z)=1/(z-i).','f has no real pole; it has a simple pole at z=i','real pole-freeness != complex pole-freeness','does not assert that f is a Painleve/HM solution; tests the inference being disallowed')],
 [
 'The explicit p=b+a^2+t0/2 construction is an actual first-jet map; the supplied HM jet selects its point. RandomMatrices remains owner of existence and boundary behavior.',
 'The scalar differential identity and two-initial-time equality verify the bridge/continuation contract. The needed first-jet inverse is 9.1 specialized by 9.5, not an invented unconstrained lift.',
 'Reality and real pole-freeness transport through scalar evaluation; the Airy coefficient remains one. The rational-function negative control rules out inferring a global complex pole-free statement from reality alone.'
 ],[3,4,5], 'conditional_bridge_contract_survives; no duplicate HM existence theorem',
 'The phase computation is general and does not compute the HM jet numerically. Actual existence/uniqueness, Airy normalization, real pole-freeness and Fredholm/TW identities are consumed from RandomMatrices §8.5. Complex analytic lifting and continuation remain the Layer5 supplier route.',
 ['RandomMatrices §§8.4–8.5: Airy floor and the normalized real Hastings–McLeod solution, real pole-freeness, uniqueness and determinant identities.','VDPS09 §4.10 is a phase chart comparison, not the HM existence source; the frozen artifact explicitly translates it to the 9.5 momentum/Hamiltonian convention.','Suggested.lean accurately lists missing intrinsic carriers and contains zero theorem declarations; it does not claim a formalized bridge.'])

row('11.1',[
 ('Finite flat algebra A_epsilon=C[z]/(z*(z-epsilon)).','basis (1,z), relation z^2=epsilon*z; for epsilon!=0 idempotents z/epsilon and 1-z/epsilon','generic fiber C x C; special fiber C[z]/z^2','length two is preserved while multiplication changes'),
 ('Diverging-residue collision -B/(epsilon*z)+B/[epsilon*(z-epsilon)]+C/z.','coefficient=B/[z*(z-epsilon)]+C/z ->B/z^2+C/z','bounded colliding residues would instead produce only their summed simple-pole residue','divergent Laurent scaling is necessary for this irregular limit'),
 ('GMR23 printed Theorem2, r=1,t1=1,C=W/epsilon,A0=-W/epsilon,A1=W.','B1=t1*A1=W; A_epsilon=W/z^2+W/[z*(z-epsilon)] ->2W/z^2','the required next-rank z^-3 coefficient is 0; printed Btilde_2 sum is empty and W[-2] is unsupplied','printed rank-raising induction does not raise the rank'),
 ('Corrected actual-coefficient step, r=1: C=W/epsilon^2,P=t1*epsilon+t2*epsilon^2,B0=-W/epsilon^2,B1=-t1*W/epsilon.','B0+C=0; B1+C*P=t2*W; C*P^2->t1^2*W','limit=t2*W/z^2+t1^2*W/z^3; t1=1,t2=0 gives exact W/[z^2*(z-epsilon)]','repair succeeds; at epsilon=1/4,z=2 both expressions have scalar coefficient 1/7'),
 ('Three limits of the same two-point collision pattern.','B=diag(1,-1): slope1. B=E12,C=E21: after z=w^2,g=diag(1,w), leading2(E12+E21)/w^2, original slope1/2. B=E12,C=0: g=I+E12/z gives A^g=0','three different minimal formal slopes 1,1/2,0 from identical pole collision/count data','no unique target/admitted-arrow class follows without orbit and surviving-coefficient data'),
 ('Sign witness X=E12,Y=E21,nu_source=diag(1,-1)/2.','Tr(nu_source*[X,Y])=1; G4.6A/R2 bracket +1, GMR bracket -1','nu_ours=-nu_source gives positive bracket -1={-ell_X,-ell_Y}_GMR; d+A_ours=d-A_source','fiber negation repairs the missing Poisson and connection sign adapter'),
 ('Time matrix for rank2: M=[[t1,t2],[0,t1^2]].','det(M)=t1^3; t1=0 gives determinant0','Hamiltonian formula M^-1*S is defined only on t1!=0','the nonzero time-scale domain is indispensable'),
 ('Leading semisimple coefficient epsilon*diag(1,-1)/z^2.','for epsilon!=0 slope1; at epsilon=0 the irregular part vanishes','special fiber must leave that fixed generic irregular stratum','the advertised vanishing-leading-coefficient boundary check survives')],
 [
 'The finite-flat algebra is explicit. Its determinant/local structures, ramification and minimal formal slopes are not determined by the divisor alone; the admitted class needs definition: TAU-R1-03.',
 'The source uses negative Lie-Poisson and d-A_source, while the suppliers use positive. The E12/E21 trace test exhibits the needed fiber-negation transport: TAU-R1-04. Complex reduction is owned here; real R2/R3 alone is not used as a complex theorem.',
 'The prescribed Laurent coefficient limit must be corrected before citing the source for horizontal-field limits: TAU-R1-02. The actual-coefficient cancellation demonstrates a valid owned replacement, but does not by itself prove orbit/reduction/flow compatibility.',
 'The slope1,1/2,0 examples show that profile objects and pole counts cannot define all selected classical/ramified arrows. GMR23 §5.1 excludes ramification; it cannot fill the missing target contract.'
 ],[1,2,8], 'needs_changes: TAU-R1-02, TAU-R1-03, TAU-R1-04',
 'The rank-raising counterexample is to the printed source induction and its use as a next-rank recipe, not a claim that its degenerate formal sum has no limit. The corrected coefficient identity is tested only algebraically; Poisson, orbit, stability, determinant and flatness comparisons still need their actual owned construction.',
 ['GMR23 pp.1391–1392 Theorem2 (12)–(15): C starts at epsilon^-r, P_r has r coefficients; the new top coefficient vanishes, output last sum is empty, and W[-r-1] is undefined. Theorem13 proof on p.1436 uses the rank-raising P_(r+1) pattern; it cannot silently repair the printed target.','GMR23 Definitions3–4 and Theorem12 §4.2 provide the ordered cascade/Takiff coefficients; Theorem13 §4.3 uses the inverse time matrix, hence its nonzero determinant domain.','GMR23 §2.1 and (96)–(97): negative trace Lie-Poisson; the source explicitly realizes d-A. §5.1 p.1441 says only the nonramified case is considered and postpones ramification.','LieGroupoidsPoisson G4.6A explicitly owns positive linear Poisson, the minus structure and fiber-negation comparison. HamiltonianReduction R2/R3 owns real KKS/regular-free-proper reduction; the complex Takiff/reduction adapter is a new construction here.'],['TAU-R1-02','TAU-R1-03','TAU-R1-04'])

row('11.2',[
 ('F0=0,F_epsilon=epsilon, gamma=[0,2], equal initial value0, L=0.','sup|x_epsilon-x0|=2*|epsilon|; epsilon=1/8 gives 1/4','(initial error+ell*delta)*exp(L*ell)=(0+2/8)*1=1/4','exact equality; a tube margin1/2 is respected for this epsilon'),
 ('Same field F(x)=x for both systems, initial error epsilon, length ell.','|x_epsilon(ell)-x0(ell)|=|epsilon|*exp(ell)','bound with delta=0,L=1 is |epsilon|*exp(ell)','the exponential loss cannot generally be discarded'),
 ('Identical zero fields with initial points (-1)^n.','x_n(t)=(-1)^n for every t','sequence has subsequences +1 and -1, so no pointwise or uniform convergence','matched initial convergence is necessary'),
 ('Field x-prime=x^2, initial x(0)=1.','x(t)=1/(1-t); x(t)->infinity as t approaches1','no fixed compact common chart tube with positive margin contains the trajectory through t=1','coefficient convergence alone cannot replace the no-exit/compactness input'),
 ('F_epsilon=epsilon on the unbounded ray t>=0.','x_epsilon(t)=epsilon*t; compact [0,T] error=epsilon*T','sup_(t>=0)|epsilon*t|=infinity for every epsilon>0','compact-path convergence does not give endpoint/unbounded-ray convergence'),
 ('Complex path gamma(s), pulled field G_epsilon(s,x)=gamma-prime(s)*F_epsilon(gamma(s),x), underlying real vector space.','phase Lipschitz bound=|gamma-prime|*L; defect bound=|gamma-prime|*delta; integral |gamma-prime| ds=ell','Gronwall exponent=L*ell and forcing integral<=delta*ell','realification/path adapter gives the displayed complex-time bound, using the integral equation and finite subdivision')],
 [],[3,4,5], 'conditional_compact_path_theorem_survives; source-to-real-ODE adapter and no-exit proof are explicit new work',
 'A compact piecewise-C1 time path, fixed comparison tube with positive margin, uniform field convergence/Lipschitz control and convergent initial points are required. Apply real Gronwall only while tube membership holds, then prove no exit and continuation; do not assume the conclusion to invoke the library theorem.',
 ['Pinned Mathlib Analysis.ODE.Gronwall: norm_le_gronwallBound_of_norm_deriv_right_le needs continuity on Icc, right derivatives on Ico, initial bound and derivative inequality; dist_le_of_approx_trajectories_ODE_of_mem additionally requires actual tube membership for both trajectories.','Pinned Tau Ceti integral-curve extension uses a real-time autonomous C1 vector field, complete model space and an endpoint cluster point (with manifold/separation hypotheses). It is not a ready-made complex-time parameter theorem.','The frozen roadmap explicitly owns realification/common-chart/no-exit transfer and consumes gap:holomorphic-horizontal-lifts via 5.1 for local complex existence; GMR23 only supplies the scoped field limit.'])

row('11.3',[
 ('Two purported arrows with time coordinates t and u=2t, same scalar observable.','first-jet velocity b=dq/dt becomes dq/du=b/2; b=2 becomes1','comparing raw pairs (q,2) and (q,1) as identical phase jets is false','time and first-jet maps must be part of the arrow'),
 ('Phase coordinates (x,p), zero Hamiltonian, observable q=x^2.','distinct phase points (1,0) and (-1,0) both have (q,q-prime)=(1,0)','scalar equation q-prime=0 does not provide an inverse first-jet map','scalar limiting equations alone do not identify phase points'),
 ('Positive-parameter normalization f(epsilon,delta)=epsilon/(epsilon+delta).','lim_delta->0 lim_epsilon->0 f=0','lim_epsilon->0 lim_delta->0 f=1','successive limits need not commute without common uniform estimates'),
 ('Collision limits from 11.1:5.','same two-pole pattern produces slopes1,1/2,0','no list or invariant predicate in the frozen targets selects the source/target arrow, scale domain and surviving local data','admitted arrow remains undefined; Layer1 profile list does not supply it')],
 [],[1,2,3], 'needs_changes: TAU-R1-03 (and source induction TAU-R1-02)',
 'The first three cases are explicit general negative controls for the claimed functorial/limit mechanism, not claimed new Painleve confluence arrows. The target must first define actual admitted collision data and use Layer9 inverse charts before a scalar cascade can be assessed.',
 ['GMR23 Definitions3–4 and Theorems2/12/13 specify a concrete ordered Laurent/Takiff cascade, not every retained Painleve profile map.','GMR23 §5.1 limits its Painleve realizations to the nonramified case. Layer1/9 profile objects do not by themselves fix a morphism, limit domain, branch, ramified orbit or first-jet inverse.','The owned maps of 11.1 and Layer9 can supply this after the admitted class is stated; they are not determined by the phrase for each admitted arrow.'],['TAU-R1-03','TAU-R1-02'])

row('11.4',[
 ('tau_epsilon=e^(1/epsilon), tau0=1, epsilon>0.','dlog tau_epsilon=dlog tau0=0','tau_epsilon diverges; after base-point renormalization to1 it becomes identically1','matching log derivatives without matching fiber values is insufficient'),
 ('tau_epsilon(z)=exp(epsilon*z), normalized at z=0.','alpha_epsilon=epsilon dz; on paths of length<=L, |log(tau_epsilon/tau0)|<=|epsilon|L','|tau_epsilon/tau0-1|<=exp(|epsilon|L)-1 ->0','the corrected-form integration route gives a concrete locally uniform bound'),
 ('tau_epsilon(z)=z-epsilon, realized by scalar K_epsilon(z)=1-z+epsilon.','trace-norm difference ||K_epsilon-K0||_1=|epsilon|; det(I-K_epsilon)=z-epsilon','on |z|=1, |epsilon|<1 gives one zero; the zero epsilon tends to0 with multiplicity1','trace-norm route includes zeros when the boundary determinant is nonzero'),
 ('Same tau family, epsilon=1/10,z=1/20.','(dlog tau_epsilon-dlog tau0)/dz=1/(1/20-1/10)-1/(1/20)=-40','general z=epsilon/2 gives -4/epsilon; no uniform log-derivative convergence in a neighborhood of0','scalar determinant convergence and log-derivative convergence have different domains'),
 ('Rank-one constant kernel c=1/4 on L2([0,L]), L=2; identify with L2([0,1]) by Uf(u)=sqrt(L)f(Lu).','transformed kernel=L*c=1/2 and determinant=1-c*L=1/2','omitting the measure/Jacobian factor gives determinant1-c=3/4','controlled Hilbert-space identification must include the stated measure factors'),
 ('tau_epsilon(t)=exp(epsilon*t) on t>=0.','tau_epsilon->1 on each compact time interval','for every epsilon>0 the large-time value grows without bound','compact convergence alone cannot identify an endpoint connection constant')],
 [
 'The rank-one L=2 example checks the moving-domain measure factor and the uncontrolled constant checks the line/frame normalization. Actual collision-line isomorphisms are an owned construction, not obtained from field convergence alone.',
 'The exp(epsilon*z) integrated bound and z-epsilon trace-norm model verify the two distinct convergence routes on their actual domains; the trace-class determinant continuity is supplied by RandomMatrices §8.3.',
 'Boundary |z|=1 and |epsilon|<1 give the separate one-variable zero count. The exp(epsilon*t) example blocks an unsupported endpoint conclusion without the additional sectorial uniformity.'
 ],[1,3,6], 'conditional_tau_convergence_contract_survives; endpoint conclusions depend on repaired sectorial inputs',
 'Corrected forms and matched base values off the divisor, or actual common-Hilbert-space trace-norm convergence including zeros. Zero counts need a nonzero boundary limit and nonidentically zero limit. No global endpoint constant is inferred from compact-path convergence.',
 ['BERT17 Proposition2.3/(3.6)/Theorem3.3/§3.1.2 provide local variational and frame-transition identities; BERT16 Theorem2.2 fixes the corrected form.','RandomMatrices §8.3 supplies trace-norm Fredholm determinant continuity. Analytic zero-count stability is a separate consequence, valid here on one-dimensional time domains with the stated boundary condition.','The actual determinant-line collision comparison is new work owned by 11.4, and endpoint asymptotics require 10.2/10.3 sectorial control in addition to 11.2.'])

assert len(rows)==12
assert sum(len(x['api_audit']) for x in rows)==32
assert sum(len(x['check_audit']) for x in rows)==37
source_paths=[f'_research/sources/{n}.txt' for n in ['MAL04','BERT10','BERT16','BERT17','ILP18','DIK08','HXZ16','GMR23','VDPS09']]
source_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in source_paths}
ledger={
 'snapshot':str(ART),'readme_sha256':sha,'status':'complete','verdict':'needs_changes',
 'target_count':12,'api_count':32,'check_count':37,
 'method':'Fresh read-only adversarial review; exact rational arithmetic and matrix/series/ODE calculations; primary-source hypotheses and selected proof steps inspected; no old review reports used.',
 'official_worker_acceptance':False,
 'limitations':['Worker was not executed.','No distinct-model-family review was obtained.','No successful Lean compile: parent reports lean --version failed to locate application even with ordinary LEAN_SYSROOT; this reviewer did not obtain an independent compiler success.','The examples test theorem contracts and expose missing hypotheses; they are not formal proofs of the proposed roadmap.','The full FIKN book and all literature cited transitively by the primary papers were not retrieved or verified.'],
 'pinned_libraries':{'mathlib':'f6090c7095e1e56b3464c1daba5f24631f1290d2','tauceti':'358314d4ab97483df4fc4cb8adcc02e74a8d9f5a'},
 'source_text_sha256':source_hashes,
 'computed_supplement':{'PII_eta_shift_ratio_exact':['1','0'],'RHP_ghost_L2_norm_squared':math.exp(-2)/2,'RHP_ghost_L2_norm_squared_exact':'exp(-2)/2','corrected_Laurent_r1_at_epsilon_1_over_4_z_2':'1/7','jacobian_determinant_example':'1/2 (correct), 3/4 (omitted Jacobian)'},
 'rows':rows
}
(OUT/'tau_ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
findings=json.loads((OUT/'tau_findings.json').read_text())
findings.update(status='complete',verdict='needs_changes',coverage={'targets':list(targets),'target_count':12,'api_count':32,'check_count':37},official_worker_acceptance=False,limitations=ledger['limitations'])
for f in findings['findings']:
 if f['id']=='TAU-R1-01' and 'Exactly, its boundary L2 norm squared' not in f['witness']:
  f['witness']+=' Exactly, its boundary L2 norm squared is exp(-2)/2. At z=-r its magnitude is exp(1/r)/r, whereas any L2 Cauchy-transform correction is O(r^-1/2); this supplies a quantitative exclusion by the repaired class.'
 if f['id']=='TAU-R1-02':
  f['repair']='Own a corrected local lemma in the actual coefficients: let P(epsilon)=t1*epsilon+t2*epsilon^2+..., C=O(epsilon^(-r-1)), and B_j=-[C*P^j]_{<0}+D_j(epsilon) for 0<=j<=r. The limit coefficient of z^(-j-1) is D_j(0)+[C*P^j]_0 and the next coefficient is t1^(r+1)*W when C has leading term W*epsilon^(-r-1). State the Laurent/holomorphic remainder hypotheses, time-domain nonzeros and source sign separately. Do not silently reuse the printed indices of GMR23 Theorem2.'
 if f['id']=='TAU-R1-05':
  f['general_extension_advice']='An all-constructed-admissible-RHP trace derivative -Tr((I-K)^-1 DK[v]) is precise and valid without a JMU name. Calling it the independently constructed dynamics Hamiltonian requires a proved correction identity. A dense-open continuation lemma can extend that identity only on a constructed common analytic family on which both meromorphic forms and corrections extend; it does not automatically cover an isolated ramified stratum.'
(OUT/'tau_findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n')

# Produce the complete readable report from the same ledger and findings.
report=[]
report += ['# Independent tau, RHP and confluence review — round 1','',
 '**Substantive verdict: needs_changes.** Six P2 defects remain in the frozen snapshot. This is an independent Worker-style adversarial review, not official Worker acceptance. No Worker execution, snapshot edit or GitHub mutation was performed.','',
 f'- Snapshot: `{ART}`',f'- README SHA-256: `{sha}`',
 '- Coverage: all 12 targets in Layers 8, 10 and 11; all 32 explicit API entries and all 37 checks in their plan records, including targets that put the construction directly in the statement instead of an API list.',
 '- Context: full README; Suggested.lean; the relevant plan, scope/gap and supplier contracts; the five prescribed Worker review/red-team/adversarial/defect/gaps-order documents. The seeded sample includes 8.3, 8.4, 10.1 and 10.3; their exact source hypotheses are compared below.',
 '- Runtime status: the pinned library hashes were verified. No successful Lean compilation was obtained. The parent reports `lean --version` failed with “failed to locate application”; this is distinct from a mathematical rejection. A distinct-model-family review was not obtained.',
 '- Evidence files: `tau_findings.json` records the six defects and repairs; `tau_ledger.json` records the twelve target rows, all 32 API dispositions, all 37 check-to-witness links, primary-source comparisons and exact source-text hashes. `tau_audit_compute.py` regenerates the numerical/algebraic evidence and reports.','',
 '## Adversarial target table','',
 '| Target | Concrete computation or structural witness | Disposition |',
 '|---|---|---|']
brief={
 '8.1':('Projection on K=(-1,s) is s; s² has order2 but kernel dimension1; (2/3)(3/5)=2/5; s=u² gives u⁴.','Contract survives conditionally on the named complex determinant supplier gap.'),
 '8.2':('For degree−1, χ(E(k))=2k+1≠0; diag(z,z⁻¹) has index0 and kernel/cokernel dimensions1; a full stabilizer acts by 1/4; factorization ratio1/2.','Odd degree, arbitrary modifications and descent are correctly guarded; analytic sewing remains owned construction.'),
 '8.3':('−Tr((1−K)⁻¹dK)=2ds/s for K=1−s²; three-arc vertex pair traces sum to dx∧dy; ramified test has slope1/2.','TAU-R1-05: the additional ramified/resonant variational identity is unspecified.'),
 '8.4':('u=2t changes tdt to udu/4; half-log form on C* has holonomy−1; d(xdy)=dx∧dy.','TAU-R1-05: generic normalization is sound but the extra Hamiltonian domain/formula is missing.'),
 '10.1':('e⁻ᵗ and 2e⁻ᵗ have the same zero formal series; exceptional resolution points share one base point; common scale5 changes (2,3) to(10,15) but preserves ratio3/2.','Definition and its restricted uniqueness contract survive; realization still depends on 10.2.'),
 '10.2':('Identity jump admits endpoint ghost I+e⁻¹/ᶻz⁻¹E₁₂ with boundary norm²=e⁻²/2; Neumann values at ρ=1/2,9/10 are2,10.','TAU-R1-01: endpoint/growth solution class is not stated.'),
 '10.3':('(i,i,0) satisfies the generic Stokes restrictions but η divides by0; an exact Q(i) triple gives η-shift ratio1; HM rotated calibration has phase+iπ/24.','TAU-R1-06: absolute calibration additionally needs uniform complex-sector arc estimates.'),
 '10.4':('p=b+a²+t/2 gives q″=2q³+tq; at(a,b,t)=(1,2,0), p=3,p′=13/2,q″=2.','Bridge survives conditionally on actual supplied HM and intrinsic lift; no duplicate existence theorem.'),
 '11.1':('Printed r=1 step tends to2W/z², not a triple pole; corrected step is W/[z²(z−ε)]; E₁₂/E₂₁ trace brackets are+1 vs−1; one collision pattern gives slopes1,1/2,0.','TAU-R1-02/03/04: source induction, admitted collision scope and sign adapter need repair.'),
 '11.2':('Constant perturbation on length2 has error2|ε|, exactly the bound; zero fields with initial(−1)ⁿ do not converge; realification gives |γ′|L.','Conditional compact-path theorem and its declared no-exit proof route survive.'),
 '11.3':('Time doubling halves the first-jet velocity; q=x² collapses two phase points; ε/(ε+δ) has iterated limits0 and1.','TAU-R1-03 and source TAU-R1-02: admitted arrows are not defined by the profile list.'),
 '11.4':('τ=z−ε converges with trace norm error|ε| and one zero; log-derivative difference at z=ε/2 is−4/ε; a missing contour Jacobian changes det1/2 to3/4.','The conditional form/trace-norm routes survive; endpoint limits require separate uniform estimates.')}
for r in rows:
 a,b=brief[r['id']];report.append(f"| {r['id']} | {a} | {b} |")
report += ['', '## Established findings and repairs','']
for f in findings['findings']:
 report += [f"### {f['id']} — {f['priority']} — {f['title']}",'',f"**Location:** {f['location']}. **Targets:** {', '.join(f['targets'])}.",'',f"**Witness.** {f['witness']}",'',f"**Exact repair.** {f['repair']}",'',f"**Repair tested against the witness.** {f['repair_test']}",'']
report += ['## Precise source comparison for the seeded sample','']
for id in ['8.3','8.4','10.1','10.3']:
 r=next(r for r in rows if r['id']==id)
 report += [f'### Target {id}','',*['- '+s for s in r['source_comparison']],'']
report += ['## Detailed target audit and dependency boundaries','',
 'The following entries are contract audits. “Survives” means no further counterexample was established after checking the supplied hypotheses and the explicit construction route; it does not mean the proposed theorem has been formalized. A local computation is not substituted for an unbuilt intrinsic carrier. The complete API/check mapping is in the JSON ledger.','']
for r in rows:
 report += [f"### {r['id']} — {r['name']}",'',f"**Scope:** {r['scope']}",'']
 for n,(i,left,right,res) in enumerate(zip(r['instances'],r['computed_left'],r['computed_right'],r['instance_results']),1):
  report += [f"- **{i['case']}.** {i['input']} Computed: {left}. Comparison: {right}. Outcome: {res}."]
 report += ['']
 if r['api_audit']:
  report += ['**API/dependency assessment.**','']
  for a in r['api_audit']:report.append('- '+a['audit'])
  report += ['']
 if r['id'] not in ['8.3','8.4','10.1','10.3']:
  report += ['**Source and supplier boundaries.**','',*['- '+s for s in r['source_comparison']],'']
report += ['## What an extended tau target can actually claim','',
 'For each constructed admissible RHP chart, fix the contour and Cauchy/Smirnov solution class, the holomorphic jump, its explicit integrable-kernel factorization, a holomorphic trace-class family K on a fixed Hilbert space and the actual determinant-line/frame comparison. On the invertible locus the precise formula is αχ(v)=−Tr((I−K)⁻¹(DK)[v]). The construction and variational calculation do not require that the original spectral singularity be unramified or nonresonant; their domain is the proved RHP adapter. This is a meaningful general theorem because K and its connection comparison must be constructed from the geometric input.',
 '',
 'This does not establish that αχ(X) is the independently constructed dynamics Hamiltonian. Multiplying the representative by exp(tq), for a horizontal field keeping q fixed, adds q to its time derivative; the added phase differential is dq, although the underlying phase dynamics may be zero. The exact correction must therefore be computed from the chosen gauge/factorization/frame, not defined as the difference between the desired two sides. An extended Hamiltonian target needs a separately fixed H, coefficient and correction identity, or a proof that the corrected coefficient has phase differential ι_Xω with its time-only ambiguity normalized.',
 '',
 'A dense-open continuation lemma is valid on a specified reduced connected common analytic family when both constructed meromorphic forms and every correction extend: equality on the dense generic open set then implies equality wherever both sides are defined. This may cover particular resonant or discriminant limits after those extensions are built. It does not automatically cover an isolated ramified stratum or provide the missing cover/descent normalization. The defensible frozen-snapshot repair is a general Fredholm identity with generic-only cited JMU/Hamiltonian comparison, unless additional exact adapters and formulas are stated.',
 '',
 '## Source and execution limitations','',
 '- This pass read the entire frozen README and Suggested.lean. Suggested.lean has only `import Mathlib`, explanatory comments and an empty namespace: zero declarations, definitions, axioms or admitted conclusions. It honestly records unavailable intrinsic signatures. No Lean proof success is asserted.',
 '- Primary sources inspected: MAL04 §2 and the Schlesinger/Theorem5.12 context; BERT10 Assumption3.1/§5.1; BERT16 definitions, vertex curvature and corrected primitive; BERT17 §§1–3 and transition theorem; ILP18 TheoremsA/B, local parametrix proof steps and HM calibration; DIK08 Theorem1; HXZ16 Theorem2.1 and its proof dependencies; GMR23 collision/cascade/Hamiltonian formulas, signs and nonramified scope; VDPS09 relevant PII chart. This is not an audit of every proof in every paper.',
 '- HXZ16 itself imports sectorial facts: its positive-sector part uses the cited Bertola result, and its asymptotic input cites FIKN. ILP18 also cites FIKN for the sectorial expansions used in calibration. The full book and every transitive source were not retrieved; those gaps are disclosed rather than silently treated as independently checked proofs.',
 '- The explicitly named complex holomorphic determinant-family and holomorphic-horizontal-lift gaps are still unimplemented supplier targets. They are sufficiently identified ownership boundaries in this roadmap; the review does not convert them into already available theorems. Conversely, the six findings identify a specific missing domain, false source recipe, or unowned precise proof input that cannot be repaired merely by saying “owned obligation.”',
 '- Mathematical computations were checked with rational arithmetic where possible: the nonabelian sign is ±1, the corrected Laurent value at ε=1/4,z=2 is1/7 on both sides, the ILP η-periodicity ratio is exactly1 in Q(i), and the tau logarithmic-derivative difference is−40 at the stated rational arguments. Analytic estimates and structural equalities are written explicitly in the ledger.',
 '- Exact pinned heads: Mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2`; Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`. No compile or distinct-model-family check was obtained. No official Worker invocation or official accepted status is claimed.',
 '- Review remains against README SHA `'+sha+'`. Canonical author repairs made after this snapshot are deliberately not credited in this round; they require a separate frozen re-review.','']
(OUT/'tau_report.md').write_text('\n'.join(report))
print(json.dumps({'verdict':'needs_changes','targets':len(rows),'api_entries':32,'checks':37,'findings':len(findings['findings']),'readme_sha256':sha,'report_bytes':(OUT/'tau_report.md').stat().st_size,'ledger_bytes':(OUT/'tau_ledger.json').stat().st_size}))
