# Independent tau, RHP and confluence review — round 1

**Substantive verdict: needs_changes.** Six P2 defects remain in the frozen snapshot. This is an independent Worker-style adversarial review, not official Worker acceptance. No Worker execution, snapshot edit or GitHub mutation was performed.

- Snapshot: `/workspace/scratch/58443e4fc6da/_strict_review/round1/artifact`
- README SHA-256: `720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`
- Coverage: all 12 targets in Layers 8, 10 and 11; all 32 explicit API entries and all 37 checks in their plan records, including targets that put the construction directly in the statement instead of an API list.
- Context: full README; Suggested.lean; the relevant plan, scope/gap and supplier contracts; the five prescribed Worker review/red-team/adversarial/defect/gaps-order documents. The seeded sample includes 8.3, 8.4, 10.1 and 10.3; their exact source hypotheses are compared below.
- Runtime status: the pinned library hashes were verified. No successful Lean compilation was obtained. The parent reports `lean --version` failed with “failed to locate application”; this is distinct from a mathematical rejection. A distinct-model-family review was not obtained.
- Evidence files: `tau_findings.json` records the six defects and repairs; `tau_ledger.json` records the twelve target rows, all 32 API dispositions, all 37 check-to-witness links, primary-source comparisons and exact source-text hashes. `tau_audit_compute.py` regenerates the numerical/algebraic evidence and reports.

## Adversarial target table

| Target | Concrete computation or structural witness | Disposition |
|---|---|---|
| 8.1 | Projection on K=(-1,s) is s; s² has order2 but kernel dimension1; (2/3)(3/5)=2/5; s=u² gives u⁴. | Contract survives conditionally on the named complex determinant supplier gap. |
| 8.2 | For degree−1, χ(E(k))=2k+1≠0; diag(z,z⁻¹) has index0 and kernel/cokernel dimensions1; a full stabilizer acts by 1/4; factorization ratio1/2. | Odd degree, arbitrary modifications and descent are correctly guarded; analytic sewing remains owned construction. |
| 8.3 | −Tr((1−K)⁻¹dK)=2ds/s for K=1−s²; three-arc vertex pair traces sum to dx∧dy; ramified test has slope1/2. | TAU-R1-05: the additional ramified/resonant variational identity is unspecified. |
| 8.4 | u=2t changes tdt to udu/4; half-log form on C* has holonomy−1; d(xdy)=dx∧dy. | TAU-R1-05: generic normalization is sound but the extra Hamiltonian domain/formula is missing. |
| 10.1 | e⁻ᵗ and 2e⁻ᵗ have the same zero formal series; exceptional resolution points share one base point; common scale5 changes (2,3) to(10,15) but preserves ratio3/2. | Definition and its restricted uniqueness contract survive; realization still depends on 10.2. |
| 10.2 | Identity jump admits endpoint ghost I+e⁻¹/ᶻz⁻¹E₁₂ with boundary norm²=e⁻²/2; Neumann values at ρ=1/2,9/10 are2,10. | TAU-R1-01: endpoint/growth solution class is not stated. |
| 10.3 | (i,i,0) satisfies the generic Stokes restrictions but η divides by0; an exact Q(i) triple gives η-shift ratio1; HM rotated calibration has phase+iπ/24. | TAU-R1-06: absolute calibration additionally needs uniform complex-sector arc estimates. |
| 10.4 | p=b+a²+t/2 gives q″=2q³+tq; at(a,b,t)=(1,2,0), p=3,p′=13/2,q″=2. | Bridge survives conditionally on actual supplied HM and intrinsic lift; no duplicate existence theorem. |
| 11.1 | Printed r=1 step tends to2W/z², not a triple pole; corrected step is W/[z²(z−ε)]; E₁₂/E₂₁ trace brackets are+1 vs−1; one collision pattern gives slopes1,1/2,0. | TAU-R1-02/03/04: source induction, admitted collision scope and sign adapter need repair. |
| 11.2 | Constant perturbation on length2 has error2|ε|, exactly the bound; zero fields with initial(−1)ⁿ do not converge; realification gives |γ′|L. | Conditional compact-path theorem and its declared no-exit proof route survive. |
| 11.3 | Time doubling halves the first-jet velocity; q=x² collapses two phase points; ε/(ε+δ) has iterated limits0 and1. | TAU-R1-03 and source TAU-R1-02: admitted arrows are not defined by the profile list. |
| 11.4 | τ=z−ε converges with trace norm error|ε| and one zero; log-derivative difference at z=ε/2 is−4/ε; a missing contour Jacobian changes det1/2 to3/4. | The conditional form/trace-norm routes survive; endpoint limits require separate uniform estimates. |

## Established findings and repairs

### TAU-R1-01 — P2 — The RHP uniqueness target does not specify its endpoint/growth solution class

**Location:** README.md:882. **Targets:** 10.2.

**Witness.** On Sigma=[0,1], w=0 and C_w=0. Y_0=I and Y_1=I+(exp(-1/z)/z) E_12 are holomorphic on C\[0,1], have determinant 1, the identical jump I, and normalization I+O(1/z) at infinity. The boundary correction exp(-1/x)/x belongs to L2(0,1), including at x=0, but Y_1 has an essential endpoint singularity. Thus the actual stated analytic and jump data do not distinguish Y_1 from Y_0; the undefined phrase normalized growth class is doing essential work. Exactly, its boundary L2 norm squared is exp(-2)/2. At z=-r its magnitude is exp(1/r)/r, whereas any L2 Cauchy-transform correction is O(r^-1/2); this supplies a quantitative exclusion by the repaired class.

**Exact repair.** Specify the normalized solution class explicitly, e.g. a Cauchy/Smirnov E2 class with the relevant Plemelj reconstruction and precise endpoint behavior after removal of the prescribed local parametrix. State which contour hypotheses establish that reconstruction and exclude endpoint-supported homogeneous solutions.

**Repair tested against the witness.** In the Cauchy-transform class Y-I=C(h) with h=Y_+-Y_- in L2 and no additional endpoint term, the identity jump gives h=0 and hence Y=I, excluding Y_1. Merely requiring L2 boundary traces fails on this witness.

### TAU-R1-02 — P2 — The cited Laurent induction is printed with indices that cannot raise the pole order

**Location:** README.md:954;991; bibliography GMR23 Theorem 2. **Targets:** 11.1, 11.3.

**Witness.** GMR23 Theorem 2 (pp.1391–1392, formulas (12)–(15)) uses C=O(epsilon^(-r)) and v-u=P_r=O(epsilon), while calling this the induction to rank r+1. The coefficient of z^(-r-2) from C/(z-P_r) is C P_r^(r+1)=O(epsilon), so tends to 0. At r=1, take t1=1, W=diag(1,-1), C=W/epsilon, A0=-W/epsilon, A1=W. Then A_epsilon=W/z^2+W/[z(z-epsilon)] tends to 2W/z^2: the triple-pole coefficient is 0. The printed output sum for Btilde_(r+1) is empty, and W[-r-1] is not among the supplied expansion coefficients.

**Exact repair.** Own a corrected local lemma in the actual coefficients: let P(epsilon)=t1*epsilon+t2*epsilon^2+..., C=O(epsilon^(-r-1)), and B_j=-[C*P^j]_{<0}+D_j(epsilon) for 0<=j<=r. The limit coefficient of z^(-j-1) is D_j(0)+[C*P^j]_0 and the next coefficient is t1^(r+1)*W when C has leading term W*epsilon^(-r-1). State the Laurent/holomorphic remainder hypotheses, time-domain nonzeros and source sign separately. Do not silently reuse the printed indices of GMR23 Theorem2.

**Repair tested against the witness.** Use the actual coefficients B_j. At r=1, choose C=W/epsilon^2, P=t1*epsilon+t2*epsilon^2, B0=-W/epsilon^2, B1=-t1*W/epsilon. Then the limit is t2*W/z^2+t1^2*W/z^3. At t1=1,t2=0 the entire connection coefficient is exactly W/[z^2*(z-epsilon)], with limit W/z^3. In source variables B1=t1*A1 this is A1=-W/epsilon, which explicitly tracks the time matrix.

### TAU-R1-03 — P2 — The admitted confluence arrows and ramified targets are never defined

**Location:** README.md:961;991; design/plan.json targets 11.1/11.3. **Targets:** 11.1, 11.3.

**Witness.** Neither target 11.1/11.3 nor the plan lists arrows or gives an invariant predicate selecting them. The ten profiles in Layer 1/9 are objects, not morphisms. A collision A_epsilon=-B/(epsilon*z)+B/[epsilon*(z-epsilon)]+C/z tends to B/z^2+C/z. With B=diag(1,-1), the slope is 1. With B=E12 and C=E21, after z=w^2 and gauge diag(1,w) the leading coefficient is 2(E12+E21)/w^2, so the original slope is 1/2. With B=E12,C=0, gauge I+E12/z removes the pole, giving slope 0. Thus collision/pole-count data alone do not select any of these different target profiles. GMR23 §5.1 p.1441 explicitly treats only the nonramified case and postpones ramification.

**Exact repair.** Supply either a finite source/target arrow table with scaling polynomial, determinant/exponent map, orbit/ramification data, domain and nonzero scales, or an invariant definition of admissible collision data that determines these. Identify which ramified and vanishing-leading-coefficient arrows are claimed and give their actual adapter targets.

**Repair tested against the witness.** A contract recording the leading matrix orbit and first surviving lower coefficient distinguishes the three witness cases: semisimple B gives slope 1; N with C21 nonzero gives slope 1/2; N with C21=0 can leave the irregular stratum. Merely listing the ten phase-profile objects does not distinguish these morphisms.

### TAU-R1-04 — P2 — The source-to-supplier Poisson sign adapter is missing

**Location:** README.md:952-969; GMR23 (96)-(97); LieGroupoidsPoisson G4.6A. **Targets:** 11.1.

**Witness.** GMR23 uses dY/dlambda=A_source Y, hence connection d-A_source, and (96)-(97) give negative Lie-Poisson brackets. The roadmap uses d+A_ours and cites G4.6A/R2, which use positive Lie-Poisson. At X=E12,Y=E21, nu=diag(1,-1)/2, tr(nu[X,Y])=1: the supplier bracket is +1 and the GMR bracket is -1. An identity comparison of displayed coefficients is not Poisson.

**Exact repair.** State A_ours=-A_source (all Takiff coefficients and exponent/residue parameters negated), invoke G4.6A fiber negation, and transport the residue pairing, KKS form, reduction and Hamiltonian conventions through that map before asserting the collision comparisons.

**Repair tested against the witness.** At nu_source=H/2, nu_ours=-H/2, the positive bracket at nu_ours is -1. Pullback of the two linear functions gives {-ell_X,-ell_Y}_negative=-1 at nu_source, so the corrected map agrees. The connection identity d+A_ours=d-A_source and monodromy exp(-2pi*i*lambda_ours)=exp(2pi*i*lambda_source) agree as well.

### TAU-R1-05 — P2 — The promised additional ramified/resonant variational comparison has no stated domain and identity

**Location:** README.md:678;690; design/plan.json targets 8.3/8.4. **Targets:** 8.3, 8.4.

**Witness.** 8.3 Law3 requires each additional ramified/resonant comparison to be a separately stated proof target. No such target appears: 8.4 says that extensions require their adapters and variational proof, while its hypotheses only give a time/symplectic chart, corrected form/frame and base value. For A(z)=[[0,z^-2],[z^-1,0]] dz the twofold-cover leading term is semisimple but the original formal exponent has slope 1/2; it is outside BERT10 Assumption3.1 and outside MAL04 Theorem5.12. An index-zero RHP realization does not specify the ramified JMU differential, its descent factor, or its relation to the chosen Hamiltonian. The artifact cannot decide which extended comparison is promised for this retained profile.

**Exact repair.** Either restrict 8.4 explicitly to 8.3's unramified/nonresonant comparison locus and mark further comparisons as excluded from the delivered targets, or add separately identified targets fixing the retained ramified/resonant formal model, cover/logarithmic lattice, variational differential, descent/frame correction and Hamiltonian coefficient. Keep the general Fredholm logarithmic derivative distinct from this extension.

**Repair tested against the witness.** With the first repair the displayed slope-1/2 connection is explicitly outside the JMU/Hamiltonian comparison scope while retaining its general RHP determinant section. With the second, the supplied identity must be evaluable after z=w^2 and after the deck change w->-w; naming the required proof without defining that differential still fails.

### TAU-R1-06 — P2 — Absolute calibration also needs uniform complex-sector asymptotics and vanishing arc estimates

**Location:** README.md:909,918; ILP18 §4.5 (4.74) and p.50 arc step. **Targets:** 10.3.

**Witness.** ILP18 §4.5 uses the Hamiltonian expansions (4.74) throughout arg t in [-pi/3,0] and [2pi/3,pi], cites FIKN for their continuation, and explicitly invokes (4.74) plus Jordan-type estimates to make both large-circle arc integrals vanish. DIK08 gives a real determinant constant and HXZ16 gives pole-freeness; neither named contract states these uniform expansions/arc estimates. The generic real-ray endpoint estimates in (1.26) do not provide them. As a logical negative control, exp(-z^2) is entire and flat on both real ends but grows like exp(R^2/2) on arg z=-pi/3, so pole-freeness plus real-ray decay does not justify dropping the arcs.

**Exact repair.** Add an explicit supporting calibration target for ILP18 (4.74), with uniform sector/boundary remainder and weighted integral bounds that prove both arc integrals vanish. Give a proof route through the HM normalized RHP/parametrices and 10.2, or a named supplier with that exact sectorial contract; include the FIKN dependency used by the source rather than claiming only the two stated additional inputs suffice.

**Repair tested against the witness.** The repaired target must control the arcs |z|=R, arg z in [-pi/3,0] and [2pi/3,pi] after subtracting z^2/4-1/(8z) on the latter. It excludes the exp(-z^2) negative control by its uniform sector estimate. With the arc terms proved zero, the remaining logarithmic contour contribution is +i*pi/24 and the calibration is exp(chi+i*pi/24), as ILP18 (4.76).

## Precise source comparison for the seeded sample

### Target 8.3

- Seeded source sample: BERT17 Theorem2.2 (RHP solvability), Proposition2.3 (integrable-kernel variation), formula(3.6) (dlog tau=omega_M+factorization correction), Theorem3.3/§3.1.2 (transition law).
- BERT10 Assumption3.1 and §5.1 Proposition5.1: unramified diagonal formal type with distinct leading eigenvalues and nonresonant logarithmic exponents, on the fixed-monodromy time directions.
- BERT16 Definition2.1 corrects the sign; Theorem2.1 equations(2.4)–(2.6) supply eta_V; Theorem2.2 supplies theta_V on a local monodromy chart and replaces the earlier Theorem5.1.
- RandomMatrices §8.3 owns trace-class determinant/trace foundations; the generic holomorphic derivative and integrable-kernel comparison are explicitly proved here.

### Target 8.4

- Seeded source sample: MAL04 §5 and Theorem5.12 use the Schlesinger family and nonintegral residue-eigenvalue differences; fixed-monodromy leaf restriction is essential.
- BERT10 §5.1 Proposition5.1 and BERT16 correction preserve the generic formal-normalization restrictions; BERT17 (3.6) includes a nontrivial frame/factorization one-form.
- ComplexKahlerGeometry K1/K3.0/K4/K7.1 provides complex charts, analytic comparison and line-bundle/connection calculus, not an all-strata Painleve H identification.

### Target 10.1

- Seeded source sample: ILP18 §1.4 specifies homogeneous PII Stokes data, real-ray endpoints and tau branches; §§3.3–3.4 use matched local parametrices and a normalized Fuchsian RHP for PVI.
- ILP18 Lemma3.3 uses the strict exponent-spread condition s=max|Re(sigma_j-sigma_k)|<1 and successive residual estimates O(t^(1-s)), then O(t^(2-s)/(1+|z|)); this is a specific sectorial realization, not a general uniqueness assertion from a formal series.
- ILP18 §§4.2–4.3 construct the PII asymptotics in their specified Stokes/branch charts. These exact models do not remove the need for lift data in other resonant or exceptional strata.

### Target 10.3

- Seeded source sample: ILP18 TheoremA: 2theta_nu notin Z; sigma,rho nonzero and 0<=Re(sigma),Re(rho)<1/2; all four signed exponent sets in (1.17) avoid Z; logarithmic and tau branches fixed. Formula(1.19) also uses (1.20)–(1.21), whose denominators/roots require their chart.
- ILP18 TheoremB: Stokes cubic s1-s2+s3+s1*s2*s3=0; 1-s1*s3 nonzero with Arg in (-pi,pi); s2 not real; epsilon=sign(Re(i*s2)); branch Arg(i*epsilon*s2) in (-pi/2,pi/2); definitions(1.27) and eta formula/formula(1.28).
- ILP18 §4.5 (4.74) explicitly needs uniform complex-sector HM Hamiltonian asymptotics, cites FIKN, and uses them to discard large arcs before (4.76). DIK08 Theorem1 provides chi=log(2)/24+zeta-prime(-1) for the real Airy determinant. HXZ16 Theorem2.1 provides sector pole-freeness, not the missing uniform asymptotic estimates.
- AnalyticNumberTheoryPartII §§4.3–4.3a owns the canonical Barnes product, recurrence away from Gamma poles, zero multiplicities and sectorial asymptotics. RandomMatrices §8.5 owns the HM solution and determinant/TW identities.

## Detailed target audit and dependency boundaries

The following entries are contract audits. “Survives” means no further counterexample was established after checking the supplied hypotheses and the explicit construction route; it does not mean the proposed theorem has been formalized. A local computation is not substituted for an unbuilt intrinsic carrier. The complete API/check mapping is in the JSON ledger.

### 8.1 — complexDeterminantFamilyAdapter

**Scope:** Fixed complex Hilbert spaces and holomorphic Fredholm index-zero family. The proposed supplier F0.0C is not implemented or assumed proven; its construction and complex trivialization/gluing are explicit prerequisites.

- **8.1:1.** T_s:C->C is multiplication by s; F=C, a=1, K frame (-1,s). Computed: projection K->F = s; det(K*) tensor det(F) has section coordinate s. Comparison: det(T_s)=s, not 1/s. Outcome: equality; fixes direction and sign in the selected frames.
- **8.1:2.** T_s=s^2; pull back by s=u^2. Computed: tau=s^2; ord_0(tau)=2; dim ker(T_0)=dim coker(T_0)=1; pulled-back tau=u^4. Comparison: multiplicity 2 != kernel dimension 1; base-change multiplicity 4. Outcome: the stated negative control and base-change law survive.
- **8.1:3.** Constant scalar T=2 and T=0. Computed: T=2: tau=2, ker=coker=0. T=0: tau=0, ker=coker=C, index=0. Comparison: both determinant lines are C; only the first section is nonzero. Outcome: line existence does not imply generic nonvanishing.
- **8.1:4.** Scalar stabilizers a=2,b=3,c=5, with K_a frame (-1,s/a). Computed: tau_a=s/2, tau_b=s/3, tau_c=s/5; g_ab=2/3,g_bc=3/5. Comparison: g_ab*g_bc=2/5=g_ac; tau_b=g_ab*tau_a. Outcome: exact refinement cocycle in a finite-dimensional model.

**API/dependency assessment.**

- The scalar projection is s, establishing the dual-convention adapter. HeegaardFloer F0.0 itself is real and uses the opposite determinant convention; the complex holomorphic F0.0C is an explicitly named uncompleted supplier gap.
- The 2/3,3/5,2/5 refinement computation and s=u^2 pullback test the actual gluing/base-change obligations; holomorphic construction is owned by F0.0C, not inferred from closed curvature.
- For operator trivializations T_new=P1*T*P0^-1, finite determinants transform by det(P1)/det(P0); composition multiplies these ratios. The bundle-valued version needs precisely the retained operator-isomorphism comparisons.
- T=2 and T=0 distinguish invertibility, generic nonvanishing and existence of the line; no genericity is hidden in the index-zero hypothesis.

**Source and supplier boundaries.**

- MAL04 §2 pp.1372–1374: holomorphic loop group, Fredholm determinant extension, invertible finite-rank perturbations and transition determinants.
- BERT17 §1: smooth closed contour, holomorphic invertible jump in a fixed neighborhood, determinant winding zero; generic zero partial indices are a separate hypothesis for a proper divisor.
- HeegaardFloer F0.0: real stabilization/exact-sequence determinant and orientation line. ComplexComparisonPartII C0.3: finite-rank holomorphic bundle tensor/dual/determinant/gluing only, not the analytic Fredholm-family theorem.

### 8.2 — isomonodromicTauLine

**Scope:** The examples test the determinant/RHP and stack mechanisms. The nontrivial stabilizer example is a determinant-complex negative control, not an assertion that every stable Painleve object has that stabilizer. Analytic stack descent and ramified sewing are roadmap constructions.

- **8.2:1.** E=O(-1) direct-sum O on P1, degree d=-1. Computed: chi(E(-1))=-1; chi(E(k))=2*k+1. Comparison: for integer k, 2*k+1 is never 0. Outcome: the odd-degree index obstruction is real and explicitly retained.
- **8.2:2.** Unit circle jump M=diag(z,z^-1), with Bertola symbol S=M^-1. Computed: wind(det M)=0; dim ker(T_S)=1; dim coker(T_S)=1; index=0. Comparison: identity jump has index=0 but ker=coker=0. Outcome: index zero does not imply solvability; normalized partial indices still matter.
- **8.2:3.** Cohomology of E=O(1) direct-sum O(-1), twisted by -1; automorphism diag(lambda,mu). Computed: H0=C in O(0), H1=C in O(-2); determinant-line weight lambda^-1*mu. Comparison: scalar lambda=mu gives 1; lambda=2,mu=1/2 gives 1/4. Outcome: Euler weight zero tests only scalars; full stabilizer action remains necessary.
- **8.2:4.** BERT17 Theorem3.3 jump M=[[z-v,-1/2],[2,0]], with the zero v of a between the two factorization contours. Computed: det M=1; ord_v(a)=1; c(v)=2; tau_tilde/tau=2^-1=1/2. Comparison: nonzero transition 1/2, not literal equality 1. Outcome: actual factorization comparison has a unit multiplier.
- **8.2:5.** Adjoin an auxiliary complex [C --s--> C] to an invertible normalized problem. Computed: extra determinant factor=s; extra complex acyclic only when s!=0. Comparison: new section has an additional zero at s=0; s is not a unit there. Outcome: arbitrary modification cannot be treated as stable equivalence across s=0.

**API/dependency assessment.**

- The zero-winding operator construction has a genuine operator and the explicit index formula; the odd-degree case still requires the owned modification/sewing adapter. The core phase degree is not forced to zero.
- The factorization ratio 1/2 and the nonacyclic added complex distinguish proved equivalences from arbitrary reference changes. Identity and composition must be constructed for the actual Fredholm/chain equivalences.
- The weight lambda^-1*mu is a nontrivial stabilizer character even when scalar weight is zero. SchemeAndStackFoundations §1.22 supplies algebraic QCoh presentation descent, not an automatic analytic coarse-descent theorem; the analytic equivariance/coarse criterion is owned here with C0.3.
- The initial closed-contour stratum is precisely sourced; ramified/resonant sectorial sewing and normalization remain explicit new construction targets. No cited generic theorem supplies them automatically.

**Source and supplier boundaries.**

- MAL04 §2: sewn E is trivial iff its Toeplitz/Fredholm problem is invertible; degree zero iff index zero.
- BERT17 §1, Theorem2.2 and Theorem3.3: S=M^-1 convention, normalized solvability, contour-factorization transition product of c(v)^(-ord a).
- ToeplitzOperators T3: continuous matrix symbol invertible iff Fredholm, index=-wind(det symbol); scalar Coburn does not give block invertibility.
- SchemeAndStackFoundations §3.3: chi(E)=deg(E)+rank(E)(1-g), and deg(E(k))=d+2k on P1. §1.22: algebraic QCoh descent. OI-B23/B30: completed complex trace-class carrier; C0.3: finite-rank analytic gluing.

### 8.3 — tauDivisorAndVariationalComparison

**Scope:** General Fredholm identity on constructed admissible RHP charts; JMU comparison only generic unramified semisimple-leading and logarithmically nonresonant inputs. The vertex calculation is local and does not assume that all other vertices or bulk terms vanish.

- **8.3:1.** Scalar trace-class K(s)=1-s^2, s!=0. Computed: -Tr((1-K)^-1*dK)=-(1/s^2)*(-2s ds)=2 ds/s. Comparison: d log det(1-K)=d log(s^2)=2 ds/s. Outcome: exact trace identity; the pole residue is 2 and not dim ker=1.
- **8.3:2.** Bundle extension 0->O(-1)->E_s->O(1)->0 with extension class s; twist by -1. Computed: connecting map H0(O)=C -> H1(O(-2))=C is multiplication by s; cohomology complex [C --s--> C]. Comparison: tau=s; E_s remains a bundle family at s=0 while its selected normalized cohomology problem fails. Outcome: bundle-chart failure does not equal loss of the geometric family; actual horizontal continuation is still supplied by Layer5.
- **8.3:3.** One three-valent vertex with M1=I+xE12,M2=I+yE21,M3=(M1M2)^-1. Computed: at x=y=0 the three ordered pair traces are +dx^dy,-dx^dy,+dx^dy; sum=dx^dy. Comparison: eta_v=-dx^dy/(4*pi*i) !=0; theta_v=-x dy/(4*pi*i) has dtheta_v=eta_v for this local family. Outcome: nonzero vertex correction explicitly survives; closed contours cannot erase it without a sewing comparison.
- **8.3:4.** A(z)=[[0,z^-2],[z^-1,0]] dz, cover z=w^2 and gauge diag(1,w). Computed: pulled/gauged coefficient=[[0,2/w^2],[2/w^2,1/w]]; leading eigenvalues ±2/w^2. Comparison: original minimal slope=1/2, outside BERT10 Assumption3.1 and logarithmic MAL04 Theorem5.12. Outcome: no stated ramified JMU differential, descent factor or H coefficient is supplied for the promised comparison.
- **8.3:5.** Frame multiplier f=e^(3t) on a regular time leaf. Computed: tau_new=f*tau; dlog tau_new=dlog tau+3dt. Comparison: the Fredholm-to-Malgrange formula needs the same exact frame correction. Outcome: frame change has an explicit nonzero derivative, even on a fixed-monodromy leaf.

**API/dependency assessment.**

- The C--s-->C complex and s^2 test divisor support and multiplicity. Effective Cartier divisor needs a nonzero section on the stated reduced connected smooth chart; it is not supplied for an identically zero section.
- The trace derivative and e^(3t) frame calculation are correct on the invertible trace-class locus. BERT17 (3.6) adds a factorization correction; it does not identify the scalar determinant with the raw Malgrange primitive without that term.
- The generic comparison matches BERT10/BERT16 hypotheses. The requested extra ramified/resonant comparison has no separate exact target or formula: TAU-R1-05.

### 8.4 — normalizedHamiltonianTauComparison

**Scope:** MAL04 Theorem5.12 is logarithmic Schlesinger and nonresonant; BERT10 Proposition5.1 with BERT16 is generic unramified. The frozen artifact does not supply the extended ramified/resonant H identity. Local complex primitives and frame calculus remain consumed, not proven by the supplied scalar examples.

- **8.4:1.** H=t, tau(0)=1; add c(t)=3. Computed: tau=e^(t^2/2); tau_new=e^(t^2/2+3t). Comparison: dlog tau_new=(t+3)dt and tau_new(0)=1. Outcome: time-only correction and normalization agree.
- **8.4:2.** Time u=2t for the same one-form Hdt=t dt. Computed: Hdt=(u/2)*(du/2)=u du/4. Comparison: at u=2 the coefficient is 1/2, whereas the untransformed H is 1. Outcome: the time coefficient must transform.
- **8.4:3.** tau_1=e^t and tau_2=7e^t; base point t=0. Computed: dlog tau_1=dlog tau_2=dt; tau_1(0)=1,tau_2(0)=7. Comparison: equal logarithmic derivatives do not fix the scalar until the base values agree. Outcome: normalization test survives.
- **8.4:4.** Regular leaf C* with alpha=(1/2)dt/t. Computed: universal-cover t=e^u: tau=e^(u/2); u->u+2*pi*i multiplies tau by -1. Comparison: a nonzero base value does not remove this holonomy obstruction. Outcome: the stated simply-connected restriction is substantive.
- **8.4:5.** Full parameter plane C^2 with alpha=x dy. Computed: dalpha=dx^dy !=0. Comparison: C^2 is simply connected but no nonzero scalar tau has dlog tau=alpha. Outcome: simple connectedness does not cure curvature.
- **8.4:6.** Slope-1/2 connection of 8.3:4, or an arbitrary phase-dependent frame tau_new=e^(tq)*tau. Computed: for a horizontal field with q constant, d_t log(tau_new/tau)=q and d_phase q=dq. Comparison: for zero phase dynamics, a Hamiltonian has d_phase H=0; q is not such a Hamiltonian without the explicit frame correction. Outcome: Fredholm coefficient alone cannot replace the missing extended Hamiltonian comparison.

**API/dependency assessment.**

- The exact phase Hamiltonian, numerical coefficient, gauge/frame and time-only terms must be independently fixed; the e^(tq) example shows why a trace derivative cannot simply be renamed the dynamics Hamiltonian. TAU-R1-05 affects the undefined extended locus.
- The u=2t and e^(3t) computations verify the time and frame laws. Time-dependent symplectic-chart corrections must come from the actual chart transformation, as the target requires.
- Closed scalar form plus base value gives uniqueness on the stated simply-connected regular leaf; C* half-monodromy and C^2 curvature test the two separate obstructions.

### 10.1 — sectorialBoundarySpecification

**Scope:** These are negative controls on boundary specifications, not substituted Painleve existence theorems. The underlying formal exponential/sector data, RHP normalization and lifted phase point are separate inputs/constructions.

- **10.1:1.** Functions y_c(t)=c e^-t in a closed proper subsector of |arg t|<pi/2. Computed: c=1 and c=2 have identical zero power-series asymptotic expansion; y_2-y_1=e^-t !=0. Comparison: for every N, |t|^N e^-Re(t)->0 in such a subsector. Outcome: formal asymptotic series alone does not select c.
- **10.1:2.** Local resolution model Bl_0(C^2)->C^2. Computed: two points (0,[1:0]) and (0,[0:1]) both map to (0,0). Comparison: the exceptional fiber is P1, so the base point does not determine its lift. Outcome: structural negative control for coarse-RH uniqueness; not an assertion that every RH fiber is exceptional.
- **10.1:3.** Asymptotic leading coefficients C_-=2,C_+=3 of one chosen tau frame; multiply that frame representative by 5. Computed: new leading coefficients are 10 and 15. Comparison: individual coefficients change, while the consistently normalized ratio remains 15/10=3/2. Outcome: normalization changes must be tracked without falsely changing a common-scale-invariant ratio.
- **10.1:4.** A branch change log(t)->log(t)+2*pi*i in t^a, a=1/2. Computed: t^(1/2) is multiplied by exp(pi*i)=-1. Comparison: two unrecorded branches can give opposite leading constants. Outcome: branch restriction and continuation path belong to the boundary record.

**API/dependency assessment.**

- Restriction of e^-t to a smaller subsector preserves its coefficient c; the square-root branch example computes a nontrivial branch transformation. Actual geometric comparison maps, rather than a free equivalence relation, remain required.
- The boundary record contains no solution. A normalized RHP with the specified lift must be constructed by 10.2 and the Layers4–5 comparisons; the exceptional-fiber example prevents silently importing a coarse inverse.
- Uniqueness is only for the selected normalized problem and lift; exp-small freedom and the exceptional fiber demonstrate why the stronger statement would fail. The analytic realization remains an owned target.
- Connection constants compare two specified asymptotic normalizations of the same continued section. The 2,3 ->10,15 example checks common scaling while the branch sign checks path/branch dependence.

### 10.2 — smallNormRiemannHilbertEngine

**Scope:** Bounded Cauchy operators and L2∩L-infinity residual jump are sufficient for the singular-integral equation, but the frozen RHP solution class is undefined. The repaired class must also establish determinant removability/invertibility and the needed endpoint behavior.

- **10.2:1.** Identity jump on Sigma=[0,1], w=0. Computed: C_w=0, C_-w=0, Neumann solution nu=0, mu=I and constructed Cauchy solution R=I. Comparison: R-I=0 and residual norm=0. Outcome: existence and error estimate for the constructed solution survive.
- **10.2:2.** Same identity jump; R_1=I+(exp(-1/z)/z)E12. Computed: det R_1=1, R_1+=R_1-, R_1=I+O(1/z); boundary correction norm^2=e^-2/2. Comparison: at z=-r its correction magnitude=e^(1/r)/r; an L2 Cauchy transform is bounded by C*sqrt(1/r-1/(1+r)). Outcome: R_1 satisfies the written jump/holomorphy/normalization and L2 traces, but is excluded only by an unstated endpoint/growth class.
- **10.2:3.** Abstract one-dimensional resolvent model A=rho I, b=1. Computed: (I-A)^-1 b=1/(1-rho); rho=1/2 gives 2 and rho=9/10 gives 10. Comparison: bound ||b||/(1-rho) gives exactly 2 and 10; at rho=1 invertibility fails. Outcome: sharp Neumann loss; this tests the bounded-operator estimate, not an additional RHP existence claim.
- **10.2:4.** Unit-circle jump diag(2,1/2). Computed: w=diag(1,-1/2) has L-infinity norm 1; R_+=diag(2,1/2), R_-=I solves the normalized RHP. Comparison: failure of strict smallness does not imply nonsolvability. Outcome: explicit determinant-one normalized solution outside the simplest strict-smallness sufficient bound.
- **10.2:5.** Repair: require R-I=C(h), h=R_+-R_- in L2, with the actual Plemelj reconstruction and local parametrix endpoint conditions. Computed: identity jump implies h=0, so C(h)=0 and R=I. Comparison: the endpoint ghost has h=0 but R_1-I!=0, so it fails the repaired class. Outcome: repair excludes the witness; L2 boundary traces alone do not.

**API/dependency assessment.**

- Neumann construction in nu avoids placing I in L2 on an unbounded contour. Uniform rho<1 gives locally normally convergent Banach-holomorphic inverses; their derivative is (I-A)^-1*(DA)*(I-A)^-1. The 2 and 10 examples test quantitative dependence.
- The 2 and 10 resolvent values test the required 1/(1-rho) loss. Moment estimates and undoing the actual parametrix are independent obligations before extracting a connection coefficient.
- Sector-overlap equality requires that both reconstructions satisfy the same explicitly stated normalized Cauchy/endpoint class; TAU-R1-01 prevents that uniqueness argument as written. With the repaired class the identity ghost is excluded, then the actual reconstructed phase point continues through Layer5.
- An invertible normalized RHP determines its marked lifted object through the actual reconstruction adapter. It does not invert an unaugmented coarse RH map: the P1 exceptional-fiber negative control in 10.1:2 supplies two distinct lifts of one coarse point. Retaining lattice/resolution data is necessary.

**Source and supplier boundaries.**

- ILP18 §§3.3–3.4 and §§4.2–4.3 provide concrete matched-parametrix RHPs and invoke singular-integral theory with specific endpoint/contour behavior.
- OI-B23/B30 supply operator-ideal completeness/norm infrastructure, while Toeplitz T3 treats closed-contour matrix symbols; neither defines the full arbitrary endpoint solution class written here.
- The local Cauchy-class uniqueness/reconstruction and necessary moment/endpoint theorem are explicitly new targets, but need an unambiguous domain.

### 10.3 — scopedConnectionFormulaRealizations

**Scope:** PVI TheoremA exactly on (1.13)/(1.17), with its specified cubic relation, branches and auxiliary-chart denominators. PII TheoremB only alpha=0 and (1.25). No exceptional-chart formula is declared proved; continuation remains an identified additional local target. HM complex-sector calibration needs the extra uniform input.

- **10.3:1.** PVI theta_0=0; homogeneous PII source alpha=0. Computed: 2*theta_0=0 is an integer; changing alpha to 1 changes q-double-prime=tq+2q^3 to tq+2q^3+1. Comparison: PVI TheoremA excludes the first input; PII TheoremB does not claim the alpha=1 equation. Outcome: the two advertised exclusions match the exact source.
- **10.3:2.** PII Stokes triple (s1,s2,s3)=(i,i,0). Computed: s1-s2+s3+s1*s2*s3=0; 1-s1*s3=1; epsilon=-1; i*epsilon*s2=1; mu=nu=0. Comparison: equation exp(i*pi*eta)=-i*epsilon/s3 requires division by 0. Outcome: allowed generic Stokes input does not lie in the literal eta chart; a continued formula is genuinely additional.
- **10.3:3.** HM Stokes triple (-i,0,i), versus rotated (0,-i,-i). Computed: HM: 1-s1*s3=0 and s2 real. Rotated: epsilon=1,mu=nu=eta=0. Comparison: the first fails (1.25); the rotated input gives Upsilon_0=2^(1/24)*exp(zeta-prime(-1)+i*pi/24). Outcome: HM is a boundary calibration, not an instance of the unrotated generic theorem.
- **10.3:4.** Nontrivial generic triple s1=1/5,s3=i/3,s2=(20+39i)/113, epsilon=-1. Computed: u=exp(2*pi*i*mu)=(225+15i)/226; v=exp(i*pi*nu)=(39-20i)/113; w=exp(i*pi*eta)=3; w-v=(300+20i)/113=u*(8/3). Comparison: Barnes recurrence gives Upsilon(eta+2)/Upsilon(eta)=(w-v)^2/[u^2*(w-w^-1)^2]=1 exactly. Outcome: an actual complex rational Stokes triple passes the eta-periodicity identity.
- **10.3:5.** Barnes normalization and zero domain. Computed: G(1)=G(2)=G(3)=1,G(4)=2,G(5)=12; ord_(z=-n)G(z)=n+1. Comparison: G(1)=1, whereas a totalized Gamma(0)*G(0)=0; recurrence cannot be used there. Outcome: the supplier excludes the Gamma-pole locus and supplies the required zero orders.
- **10.3:6.** Absolute HM calibration uses arcs arg z in [-pi/3,0] and [2pi/3,pi]. Computed: exp(-z^2) is entire and flat at both real ends, but |exp(-R^2 exp(-2*pi*i/3))|=exp(R^2/2). Comparison: pole-freeness plus real-ray asymptotics gives no vanishing large-arc integral. Outcome: uniform sectorial (4.74) remainder/arc estimates are missing from the frozen named calibration inputs.
- **10.3:7.** Homogeneous PII phase chart H9=1/2 p^2-(q^2+t/2)p-q/2, p=q-prime+q^2+t/2. Computed: H_ILP=q-prime^2-q^4-tq^2=2*H9+q+t^2/4; at (q,q-prime,t)=(1,2,0): p=3,H9=1,H_ILP=3. Comparison: 2*1+1+0=3, not H9=1. Outcome: coefficient and correction terms are indispensable to the normalization dictionary.

### 10.4 — hastingsMcLeodIntrinsicBridge

**Scope:** The phase computation is general and does not compute the HM jet numerically. Actual existence/uniqueness, Airy normalization, real pole-freeness and Fredholm/TW identities are consumed from RandomMatrices §8.5. Complex analytic lifting and continuation remain the Layer5 supplier route.

- **10.4:1.** alpha=0 chart, arbitrary real jet q(t0)=a,q-prime(t0)=b, p=b+a^2+t0/2. Computed: q-prime=p-q^2-t/2=b; p-prime=2q*p+1/2. Comparison: q-double-prime=(2q*p+1/2)-2q*(p-q^2-t/2)-1/2=2q^3+tq. Outcome: the first-jet inverse reconstructs the correct scalar equation.
- **10.4:2.** Concrete jet a=1,b=2,t0=0. Computed: p=3; p-prime=13/2; q-double-prime=13/2-4-1/2=2. Comparison: 2*a^3+t0*a=2. Outcome: exact phase/scalar adapter computation.
- **10.4:3.** Supplier Airy boundary normalization, change k=1 to k=2. Computed: lim q/Ai=1 versus lim (2q)/Ai=2. Comparison: 2 !=1; furthermore scaling q by 2 does not preserve homogeneous PII in general. Outcome: the HM normalization cannot be changed silently.
- **10.4:4.** Initialize the same supplied solution at two regular times a and b, then compare on a common connected domain. Computed: both jets reconstruct p=q-prime+q^2+t/2; their evaluated (q,q-prime) coincide at the transported overlap. Comparison: first-jet injectivity and uniqueness identify the same intrinsic horizontal germ, hence its continuation. Outcome: structural equality, conditional on the actual 9.1/9.5 inverse and Layers5.1–5.3 uniqueness.
- **10.4:5.** Logical negative control for real-to-complex pole-freeness: f(z)=1/(z-i). Computed: f has no real pole; it has a simple pole at z=i. Comparison: real pole-freeness != complex pole-freeness. Outcome: does not assert that f is a Painleve/HM solution; tests the inference being disallowed.

**API/dependency assessment.**

- The explicit p=b+a^2+t0/2 construction is an actual first-jet map; the supplied HM jet selects its point. RandomMatrices remains owner of existence and boundary behavior.
- The scalar differential identity and two-initial-time equality verify the bridge/continuation contract. The needed first-jet inverse is 9.1 specialized by 9.5, not an invented unconstrained lift.
- Reality and real pole-freeness transport through scalar evaluation; the Airy coefficient remains one. The rational-function negative control rules out inferring a global complex pole-free statement from reality alone.

**Source and supplier boundaries.**

- RandomMatrices §§8.4–8.5: Airy floor and the normalized real Hastings–McLeod solution, real pole-freeness, uniqueness and determinant identities.
- VDPS09 §4.10 is a phase chart comparison, not the HM existence source; the frozen artifact explicitly translates it to the 9.5 momentum/Hamiltonian convention.
- Suggested.lean accurately lists missing intrinsic carriers and contains zero theorem declarations; it does not claim a formalized bridge.

### 11.1 — geometricConfluenceFamily

**Scope:** The rank-raising counterexample is to the printed source induction and its use as a next-rank recipe, not a claim that its degenerate formal sum has no limit. The corrected coefficient identity is tested only algebraically; Poisson, orbit, stability, determinant and flatness comparisons still need their actual owned construction.

- **11.1:1.** Finite flat algebra A_epsilon=C[z]/(z*(z-epsilon)). Computed: basis (1,z), relation z^2=epsilon*z; for epsilon!=0 idempotents z/epsilon and 1-z/epsilon. Comparison: generic fiber C x C; special fiber C[z]/z^2. Outcome: length two is preserved while multiplication changes.
- **11.1:2.** Diverging-residue collision -B/(epsilon*z)+B/[epsilon*(z-epsilon)]+C/z. Computed: coefficient=B/[z*(z-epsilon)]+C/z ->B/z^2+C/z. Comparison: bounded colliding residues would instead produce only their summed simple-pole residue. Outcome: divergent Laurent scaling is necessary for this irregular limit.
- **11.1:3.** GMR23 printed Theorem2, r=1,t1=1,C=W/epsilon,A0=-W/epsilon,A1=W. Computed: B1=t1*A1=W; A_epsilon=W/z^2+W/[z*(z-epsilon)] ->2W/z^2. Comparison: the required next-rank z^-3 coefficient is 0; printed Btilde_2 sum is empty and W[-2] is unsupplied. Outcome: printed rank-raising induction does not raise the rank.
- **11.1:4.** Corrected actual-coefficient step, r=1: C=W/epsilon^2,P=t1*epsilon+t2*epsilon^2,B0=-W/epsilon^2,B1=-t1*W/epsilon. Computed: B0+C=0; B1+C*P=t2*W; C*P^2->t1^2*W. Comparison: limit=t2*W/z^2+t1^2*W/z^3; t1=1,t2=0 gives exact W/[z^2*(z-epsilon)]. Outcome: repair succeeds; at epsilon=1/4,z=2 both expressions have scalar coefficient 1/7.
- **11.1:5.** Three limits of the same two-point collision pattern. Computed: B=diag(1,-1): slope1. B=E12,C=E21: after z=w^2,g=diag(1,w), leading2(E12+E21)/w^2, original slope1/2. B=E12,C=0: g=I+E12/z gives A^g=0. Comparison: three different minimal formal slopes 1,1/2,0 from identical pole collision/count data. Outcome: no unique target/admitted-arrow class follows without orbit and surviving-coefficient data.
- **11.1:6.** Sign witness X=E12,Y=E21,nu_source=diag(1,-1)/2. Computed: Tr(nu_source*[X,Y])=1; G4.6A/R2 bracket +1, GMR bracket -1. Comparison: nu_ours=-nu_source gives positive bracket -1={-ell_X,-ell_Y}_GMR; d+A_ours=d-A_source. Outcome: fiber negation repairs the missing Poisson and connection sign adapter.
- **11.1:7.** Time matrix for rank2: M=[[t1,t2],[0,t1^2]]. Computed: det(M)=t1^3; t1=0 gives determinant0. Comparison: Hamiltonian formula M^-1*S is defined only on t1!=0. Outcome: the nonzero time-scale domain is indispensable.
- **11.1:8.** Leading semisimple coefficient epsilon*diag(1,-1)/z^2. Computed: for epsilon!=0 slope1; at epsilon=0 the irregular part vanishes. Comparison: special fiber must leave that fixed generic irregular stratum. Outcome: the advertised vanishing-leading-coefficient boundary check survives.

**API/dependency assessment.**

- The finite-flat algebra is explicit. Its determinant/local structures, ramification and minimal formal slopes are not determined by the divisor alone; the admitted class needs definition: TAU-R1-03.
- The source uses negative Lie-Poisson and d-A_source, while the suppliers use positive. The E12/E21 trace test exhibits the needed fiber-negation transport: TAU-R1-04. Complex reduction is owned here; real R2/R3 alone is not used as a complex theorem.
- The prescribed Laurent coefficient limit must be corrected before citing the source for horizontal-field limits: TAU-R1-02. The actual-coefficient cancellation demonstrates a valid owned replacement, but does not by itself prove orbit/reduction/flow compatibility.
- The slope1,1/2,0 examples show that profile objects and pole counts cannot define all selected classical/ramified arrows. GMR23 §5.1 excludes ramification; it cannot fill the missing target contract.

**Source and supplier boundaries.**

- GMR23 pp.1391–1392 Theorem2 (12)–(15): C starts at epsilon^-r, P_r has r coefficients; the new top coefficient vanishes, output last sum is empty, and W[-r-1] is undefined. Theorem13 proof on p.1436 uses the rank-raising P_(r+1) pattern; it cannot silently repair the printed target.
- GMR23 Definitions3–4 and Theorem12 §4.2 provide the ordered cascade/Takiff coefficients; Theorem13 §4.3 uses the inverse time matrix, hence its nonzero determinant domain.
- GMR23 §2.1 and (96)–(97): negative trace Lie-Poisson; the source explicitly realizes d-A. §5.1 p.1441 says only the nonramified case is considered and postpones ramification.
- LieGroupoidsPoisson G4.6A explicitly owns positive linear Poisson, the minus structure and fiber-negation comparison. HamiltonianReduction R2/R3 owns real KKS/regular-free-proper reduction; the complex Takiff/reduction adapter is a new construction here.

### 11.2 — compactPathSolutionConvergence

**Scope:** A compact piecewise-C1 time path, fixed comparison tube with positive margin, uniform field convergence/Lipschitz control and convergent initial points are required. Apply real Gronwall only while tube membership holds, then prove no exit and continuation; do not assume the conclusion to invoke the library theorem.

- **11.2:1.** F0=0,F_epsilon=epsilon, gamma=[0,2], equal initial value0, L=0. Computed: sup|x_epsilon-x0|=2*|epsilon|; epsilon=1/8 gives 1/4. Comparison: (initial error+ell*delta)*exp(L*ell)=(0+2/8)*1=1/4. Outcome: exact equality; a tube margin1/2 is respected for this epsilon.
- **11.2:2.** Same field F(x)=x for both systems, initial error epsilon, length ell. Computed: |x_epsilon(ell)-x0(ell)|=|epsilon|*exp(ell). Comparison: bound with delta=0,L=1 is |epsilon|*exp(ell). Outcome: the exponential loss cannot generally be discarded.
- **11.2:3.** Identical zero fields with initial points (-1)^n. Computed: x_n(t)=(-1)^n for every t. Comparison: sequence has subsequences +1 and -1, so no pointwise or uniform convergence. Outcome: matched initial convergence is necessary.
- **11.2:4.** Field x-prime=x^2, initial x(0)=1. Computed: x(t)=1/(1-t); x(t)->infinity as t approaches1. Comparison: no fixed compact common chart tube with positive margin contains the trajectory through t=1. Outcome: coefficient convergence alone cannot replace the no-exit/compactness input.
- **11.2:5.** F_epsilon=epsilon on the unbounded ray t>=0. Computed: x_epsilon(t)=epsilon*t; compact [0,T] error=epsilon*T. Comparison: sup_(t>=0)|epsilon*t|=infinity for every epsilon>0. Outcome: compact-path convergence does not give endpoint/unbounded-ray convergence.
- **11.2:6.** Complex path gamma(s), pulled field G_epsilon(s,x)=gamma-prime(s)*F_epsilon(gamma(s),x), underlying real vector space. Computed: phase Lipschitz bound=|gamma-prime|*L; defect bound=|gamma-prime|*delta; integral |gamma-prime| ds=ell. Comparison: Gronwall exponent=L*ell and forcing integral<=delta*ell. Outcome: realification/path adapter gives the displayed complex-time bound, using the integral equation and finite subdivision.

**Source and supplier boundaries.**

- Pinned Mathlib Analysis.ODE.Gronwall: norm_le_gronwallBound_of_norm_deriv_right_le needs continuity on Icc, right derivatives on Ico, initial bound and derivative inequality; dist_le_of_approx_trajectories_ODE_of_mem additionally requires actual tube membership for both trajectories.
- Pinned Tau Ceti integral-curve extension uses a real-time autonomous C1 vector field, complete model space and an endpoint cluster point (with manifold/separation hypotheses). It is not a ready-made complex-time parameter theorem.
- The frozen roadmap explicitly owns realification/common-chart/no-exit transfer and consumes gap:holomorphic-horizontal-lifts via 5.1 for local complex existence; GMR23 only supplies the scoped field limit.

### 11.3 — classicalConfluenceCascadeComparison

**Scope:** The first three cases are explicit general negative controls for the claimed functorial/limit mechanism, not claimed new Painleve confluence arrows. The target must first define actual admitted collision data and use Layer9 inverse charts before a scalar cascade can be assessed.

- **11.3:1.** Two purported arrows with time coordinates t and u=2t, same scalar observable. Computed: first-jet velocity b=dq/dt becomes dq/du=b/2; b=2 becomes1. Comparison: comparing raw pairs (q,2) and (q,1) as identical phase jets is false. Outcome: time and first-jet maps must be part of the arrow.
- **11.3:2.** Phase coordinates (x,p), zero Hamiltonian, observable q=x^2. Computed: distinct phase points (1,0) and (-1,0) both have (q,q-prime)=(1,0). Comparison: scalar equation q-prime=0 does not provide an inverse first-jet map. Outcome: scalar limiting equations alone do not identify phase points.
- **11.3:3.** Positive-parameter normalization f(epsilon,delta)=epsilon/(epsilon+delta). Computed: lim_delta->0 lim_epsilon->0 f=0. Comparison: lim_epsilon->0 lim_delta->0 f=1. Outcome: successive limits need not commute without common uniform estimates.
- **11.3:4.** Collision limits from 11.1:5. Computed: same two-pole pattern produces slopes1,1/2,0. Comparison: no list or invariant predicate in the frozen targets selects the source/target arrow, scale domain and surviving local data. Outcome: admitted arrow remains undefined; Layer1 profile list does not supply it.

**Source and supplier boundaries.**

- GMR23 Definitions3–4 and Theorems2/12/13 specify a concrete ordered Laurent/Takiff cascade, not every retained Painleve profile map.
- GMR23 §5.1 limits its Painleve realizations to the nonramified case. Layer1/9 profile objects do not by themselves fix a morphism, limit domain, branch, ramified orbit or first-jet inverse.
- The owned maps of 11.1 and Layer9 can supply this after the admitted class is stated; they are not determined by the phrase for each admitted arrow.

### 11.4 — normalizedTauConfluence

**Scope:** Corrected forms and matched base values off the divisor, or actual common-Hilbert-space trace-norm convergence including zeros. Zero counts need a nonzero boundary limit and nonidentically zero limit. No global endpoint constant is inferred from compact-path convergence.

- **11.4:1.** tau_epsilon=e^(1/epsilon), tau0=1, epsilon>0. Computed: dlog tau_epsilon=dlog tau0=0. Comparison: tau_epsilon diverges; after base-point renormalization to1 it becomes identically1. Outcome: matching log derivatives without matching fiber values is insufficient.
- **11.4:2.** tau_epsilon(z)=exp(epsilon*z), normalized at z=0. Computed: alpha_epsilon=epsilon dz; on paths of length<=L, |log(tau_epsilon/tau0)|<=|epsilon|L. Comparison: |tau_epsilon/tau0-1|<=exp(|epsilon|L)-1 ->0. Outcome: the corrected-form integration route gives a concrete locally uniform bound.
- **11.4:3.** tau_epsilon(z)=z-epsilon, realized by scalar K_epsilon(z)=1-z+epsilon. Computed: trace-norm difference ||K_epsilon-K0||_1=|epsilon|; det(I-K_epsilon)=z-epsilon. Comparison: on |z|=1, |epsilon|<1 gives one zero; the zero epsilon tends to0 with multiplicity1. Outcome: trace-norm route includes zeros when the boundary determinant is nonzero.
- **11.4:4.** Same tau family, epsilon=1/10,z=1/20. Computed: (dlog tau_epsilon-dlog tau0)/dz=1/(1/20-1/10)-1/(1/20)=-40. Comparison: general z=epsilon/2 gives -4/epsilon; no uniform log-derivative convergence in a neighborhood of0. Outcome: scalar determinant convergence and log-derivative convergence have different domains.
- **11.4:5.** Rank-one constant kernel c=1/4 on L2([0,L]), L=2; identify with L2([0,1]) by Uf(u)=sqrt(L)f(Lu). Computed: transformed kernel=L*c=1/2 and determinant=1-c*L=1/2. Comparison: omitting the measure/Jacobian factor gives determinant1-c=3/4. Outcome: controlled Hilbert-space identification must include the stated measure factors.
- **11.4:6.** tau_epsilon(t)=exp(epsilon*t) on t>=0. Computed: tau_epsilon->1 on each compact time interval. Comparison: for every epsilon>0 the large-time value grows without bound. Outcome: compact convergence alone cannot identify an endpoint connection constant.

**API/dependency assessment.**

- The rank-one L=2 example checks the moving-domain measure factor and the uncontrolled constant checks the line/frame normalization. Actual collision-line isomorphisms are an owned construction, not obtained from field convergence alone.
- The exp(epsilon*z) integrated bound and z-epsilon trace-norm model verify the two distinct convergence routes on their actual domains; the trace-class determinant continuity is supplied by RandomMatrices §8.3.
- Boundary |z|=1 and |epsilon|<1 give the separate one-variable zero count. The exp(epsilon*t) example blocks an unsupported endpoint conclusion without the additional sectorial uniformity.

**Source and supplier boundaries.**

- BERT17 Proposition2.3/(3.6)/Theorem3.3/§3.1.2 provide local variational and frame-transition identities; BERT16 Theorem2.2 fixes the corrected form.
- RandomMatrices §8.3 supplies trace-norm Fredholm determinant continuity. Analytic zero-count stability is a separate consequence, valid here on one-dimensional time domains with the stated boundary condition.
- The actual determinant-line collision comparison is new work owned by 11.4, and endpoint asymptotics require 10.2/10.3 sectorial control in addition to 11.2.

## What an extended tau target can actually claim

For each constructed admissible RHP chart, fix the contour and Cauchy/Smirnov solution class, the holomorphic jump, its explicit integrable-kernel factorization, a holomorphic trace-class family K on a fixed Hilbert space and the actual determinant-line/frame comparison. On the invertible locus the precise formula is αχ(v)=−Tr((I−K)⁻¹(DK)[v]). The construction and variational calculation do not require that the original spectral singularity be unramified or nonresonant; their domain is the proved RHP adapter. This is a meaningful general theorem because K and its connection comparison must be constructed from the geometric input.

This does not establish that αχ(X) is the independently constructed dynamics Hamiltonian. Multiplying the representative by exp(tq), for a horizontal field keeping q fixed, adds q to its time derivative; the added phase differential is dq, although the underlying phase dynamics may be zero. The exact correction must therefore be computed from the chosen gauge/factorization/frame, not defined as the difference between the desired two sides. An extended Hamiltonian target needs a separately fixed H, coefficient and correction identity, or a proof that the corrected coefficient has phase differential ι_Xω with its time-only ambiguity normalized.

A dense-open continuation lemma is valid on a specified reduced connected common analytic family when both constructed meromorphic forms and every correction extend: equality on the dense generic open set then implies equality wherever both sides are defined. This may cover particular resonant or discriminant limits after those extensions are built. It does not automatically cover an isolated ramified stratum or provide the missing cover/descent normalization. The defensible frozen-snapshot repair is a general Fredholm identity with generic-only cited JMU/Hamiltonian comparison, unless additional exact adapters and formulas are stated.

## Source and execution limitations

- This pass read the entire frozen README and Suggested.lean. Suggested.lean has only `import Mathlib`, explanatory comments and an empty namespace: zero declarations, definitions, axioms or admitted conclusions. It honestly records unavailable intrinsic signatures. No Lean proof success is asserted.
- Primary sources inspected: MAL04 §2 and the Schlesinger/Theorem5.12 context; BERT10 Assumption3.1/§5.1; BERT16 definitions, vertex curvature and corrected primitive; BERT17 §§1–3 and transition theorem; ILP18 TheoremsA/B, local parametrix proof steps and HM calibration; DIK08 Theorem1; HXZ16 Theorem2.1 and its proof dependencies; GMR23 collision/cascade/Hamiltonian formulas, signs and nonramified scope; VDPS09 relevant PII chart. This is not an audit of every proof in every paper.
- HXZ16 itself imports sectorial facts: its positive-sector part uses the cited Bertola result, and its asymptotic input cites FIKN. ILP18 also cites FIKN for the sectorial expansions used in calibration. The full book and every transitive source were not retrieved; those gaps are disclosed rather than silently treated as independently checked proofs.
- The explicitly named complex holomorphic determinant-family and holomorphic-horizontal-lift gaps are still unimplemented supplier targets. They are sufficiently identified ownership boundaries in this roadmap; the review does not convert them into already available theorems. Conversely, the six findings identify a specific missing domain, false source recipe, or unowned precise proof input that cannot be repaired merely by saying “owned obligation.”
- Mathematical computations were checked with rational arithmetic where possible: the nonabelian sign is ±1, the corrected Laurent value at ε=1/4,z=2 is1/7 on both sides, the ILP η-periodicity ratio is exactly1 in Q(i), and the tau logarithmic-derivative difference is−40 at the stated rational arguments. Analytic estimates and structural equalities are written explicitly in the ledger.
- Exact pinned heads: Mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2`; Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`. No compile or distinct-model-family check was obtained. No official Worker invocation or official accepted status is claimed.
- Review remains against README SHA `720764eca860c616fd22119e72d17bc67a68a11c835cb716567cce1666bb4731`. Canonical author repairs made after this snapshot are deliberately not credited in this round; they require a separate frozen re-review.
