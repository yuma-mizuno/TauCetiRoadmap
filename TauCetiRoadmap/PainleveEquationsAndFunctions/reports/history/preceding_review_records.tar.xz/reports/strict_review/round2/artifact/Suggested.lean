import Mathlib

/-!
# Painlevé equations and functions: target signatures

The roadmap is README.md. This file records the status of its intrinsic headline
theorems against the pinned Mathlib and Tau Ceti APIs; it does not replace that
roadmap.

The general proper-semiconjugacy continuation theorem in Section 5.2 is stated
below on native real manifolds, tangent and hom bundles, derivatives and proper
maps. It uses a C¹ horizontal splitting; complex holomorphic splittings give
the intended application after restriction of scalars. Integrability enters the
later homotopy-invariance theorem, not lifting one prescribed path.

The following intrinsic application headlines still require carriers whose
construction is part of the roadmap or of its named suppliers:

* Intrinsic construction and classification of rank-two Painlevé data.
  Missing are families of pointed complex curves with irregular types, the
  corresponding parabolic meromorphic connection groupoids, ramified local
  descent, and the intrinsic structural polar-degree and local admissibility
  conditions together with their reduced deformation problem.
* Representability, deformation theory and the relative symplectic structure.
  Missing are the stable connection moduli functor, its rigidification and
  relative tangent complex, and the analytic realization of its moduli space.
* Construction and integrability of the isomonodromy splitting.
  Missing are the universal meromorphic connection, admissible deformation base
  and relative tangent sequence on the actual moduli family. A freely supplied
  horizontal distribution would not state the construction theorem.
* Full-stratum irregular Riemann–Hilbert correspondence.
  Missing are Stokes-filtered local systems with ramified descent, their
  parameterized moduli, and the actual Riemann–Hilbert map including resonant and
  reducible strata. The regular-singular and formal connection dictionaries
  alone do not provide these objects.
* Application of continuation to geometric Painlevé dynamics and scalar meromorphy.
  Missing are the actual isomonodromy family and its Riemann–Hilbert comparison,
  together with meromorphic observables on the phase surfaces and the required
  treatment of indeterminacy. Native real integral curves and meromorphic
  functions on Riemann surfaces do not by themselves state this result.
* Intrinsic spaces of initial conditions and their boundary classification.
  Missing are the relevant marked rational surface pairs, their moduli,
  relative anticanonical divisors and the comparison with connection moduli.
* Modifications, symmetries and Riccati loci.
  Missing are elementary modifications on the connection groupoids, the
  induced correspondences between parameter spaces, and the invariant
  geometric loci and their projective-linear reductions. Invariant curves are
  not identified with reducibility without a separate comparison theorem.
* The normalized tau line and its determinant section.
  Missing are holomorphic determinant lines of the relevant index-zero
  Fredholm or Riemann–Hilbert families, the sewing identifications and the
  comparison with the isomonodromic differential. A line bundle or a closed
  differential form without those constructions does not define the target.
* Comparison with the classical scalar equations and ten underlying profiles,
  with all seventeen ordered profiles retained.
  Missing are the intrinsic families above, their phase charts, the scalar
  observables and all normalization maps. Scalar differential equations on
  freely chosen functions would omit the intrinsic comparison theorem.
* Distinguished analytic solutions and the Hastings–McLeod comparison.
  Missing are the intrinsic monodromy/Stokes conditions that select horizontal
  sections and the scalar comparison with the solution owned by RandomMatrices.
  The general scalar existence theorem remains with its existing supplier.
* Controlled confluence of the intrinsic families.
  Missing are the degeneration families, parameter and frame identifications,
  limiting Stokes data and the topology in which horizontal sections converge.

The generic transfer theorem below separates a statable common headline from
these missing application carriers. Its five small definitions use native
manifolds, tangent linear maps, derivatives and continuous trajectories; none of
the missing Painlevé carriers is replaced by an unspecified predicate, an
assumed conclusion or an admitted data definition.
-/

noncomputable section
open Set Bundle
open scoped Manifold Bundle Topology

namespace TauCetiRoadmap.PainleveEquationsAndFunctions

variable {EM EB M B R : Type*}
  [NormedAddCommGroup EM] [NormedSpace ℝ EM] [FiniteDimensional ℝ EM]
  [NormedAddCommGroup EB] [NormedSpace ℝ EB] [FiniteDimensional ℝ EB]
  [TopologicalSpace M] [ChartedSpace EM M] [T2Space M]
  [SecondCountableTopology M] [IsManifold 𝓘(ℝ, EM) ∞ M]
  [TopologicalSpace B] [ChartedSpace EB B] [T2Space B]
  [SecondCountableTopology B] [IsManifold 𝓘(ℝ, EB) ∞ B]
  [TopologicalSpace R]

/-- A finite subdivision, including the empty subdivision of a singleton interval. -/
structure Breaks (a b : ℝ) where
  n : ℕ
  cut : Fin (n + 1) → ℝ
  ordered : StrictMono cut
  first : cut 0 = a
  last : cut (Fin.last n) = b

/-- The right inverse is an actual section of Hom(π*TB,TM). -/
structure HorizontalSplitting
    (π : ContMDiffMap 𝓘(ℝ, EM) 𝓘(ℝ, EB) M B ∞) where
  lift : ∀ x : M, TangentSpace 𝓘(ℝ, EB) (π x) →L[ℝ]
    TangentSpace 𝓘(ℝ, EM) x
  rightInverse : ∀ x,
    (mfderiv 𝓘(ℝ, EM) 𝓘(ℝ, EB) π x).comp (lift x) =
      ContinuousLinearMap.id ℝ (TangentSpace 𝓘(ℝ, EB) (π x))
  regularity : ContMDiff 𝓘(ℝ, EM)
    (𝓘(ℝ, EM).prod 𝓘(ℝ, EB →L[ℝ] EM)) 1
    (fun x ↦ (⟨x, lift x⟩ : Bundle.TotalSpace (EB →L[ℝ] EM)
      (fun x : M ↦ TangentSpace 𝓘(ℝ, EB) (π x) →L[ℝ]
        TangentSpace 𝓘(ℝ, EM) x)))

/-- C¹ on the finitely many closed pieces, continuous on the full interval. -/
def PiecewiseC1On (γ : ℝ → B) (a b : ℝ) : Prop :=
  ContinuousOn γ (Icc a b) ∧ ∃ p : Breaks a b,
    ∀ i : Fin p.n, ContMDiffOn 𝓘(ℝ) 𝓘(ℝ, EB) 1 γ
      (Icc (p.cut i.castSucc) (p.cut i.succ))

/-- Genuine differential horizontality. The equation h(dπ(v))=v avoids casting
vectors along the separately required equality π(η(t))=γ(t). -/
def HorizontalOn
    (π : ContMDiffMap 𝓘(ℝ, EM) 𝓘(ℝ, EB) M B ∞)
    (h : HorizontalSplitting π) (γ : ℝ → B) (η : ℝ → M) (a b : ℝ) : Prop :=
  ContinuousOn η (Icc a b) ∧ EqOn (π ∘ η) γ (Icc a b) ∧
    ∃ p : Breaks a b, ∀ i : Fin p.n,
      let J := Icc (p.cut i.castSucc) (p.cut i.succ)
      ContMDiffOn 𝓘(ℝ) 𝓘(ℝ, EB) 1 γ J ∧
      ContMDiffOn 𝓘(ℝ) 𝓘(ℝ, EM) 1 η J ∧
      ∀ t ∈ J,
        let v := mfderivWithin 𝓘(ℝ) 𝓘(ℝ, EM) η J t 1
        h.lift (η t) (mfderiv 𝓘(ℝ, EM) 𝓘(ℝ, EB) π (η t) v) = v

/-- Actual continuous target trajectories, not a predicate standing for the theorem.
Only paths based at ρ(y) are constrained. Prefix compatibility is stated explicitly
in the transfer theorem; it follows from the usual transport restriction law and
local semiconjugacy in the intended application. -/
structure TargetTransport (ρ : R → B) where
  trajectory : (ℝ → B) → R → ℝ → R
  continuous : ∀ γ y, PiecewiseC1On γ 0 1 → ρ y = γ 0 →
    ContinuousOn (trajectory γ y) (Icc 0 1)
  initial : ∀ γ y, PiecewiseC1On γ 0 1 → ρ y = γ 0 → trajectory γ y 0 = y
  over : ∀ γ y, PiecewiseC1On γ 0 1 → ρ y = γ 0 →
    EqOn (ρ ∘ trajectory γ y) γ (Icc 0 1)

/-- General compact-containment transfer, with uniqueness on the path interval.
The values of the chosen extensions outside [0,1] carry no uniqueness assertion. -/
theorem proper_semiconjugacy_complete_horizontal_lifts
    (π : ContMDiffMap 𝓘(ℝ, EM) 𝓘(ℝ, EB) M B ∞)
    (h : HorizontalSplitting π)
    (ρ : R → B) (T : TargetTransport ρ)
    (F : M → R) (hF : IsProperMap F) (hOver : ρ ∘ F = π)
    (hCompat : ∀ (γ : ℝ → B), PiecewiseC1On γ 0 1 →
      ∀ (x : M), π x = γ 0 → ∀ s ∈ Icc (0 : ℝ) 1,
      ∀ η : ℝ → M, η 0 = x → HorizontalOn π h γ η 0 s →
        EqOn (F ∘ η) (T.trajectory γ (F x)) (Icc 0 s)) :
    ∀ (γ : ℝ → B), PiecewiseC1On γ 0 1 →
      ∀ (x : M), π x = γ 0 → ∃ η : ℝ → M,
        η 0 = x ∧ HorizontalOn π h γ η 0 1 ∧
        ∀ ζ : ℝ → M, ζ 0 = x → HorizontalOn π h γ ζ 0 1 →
          EqOn ζ η (Icc 0 1) := by
  sorry

end TauCetiRoadmap.PainleveEquationsAndFunctions
