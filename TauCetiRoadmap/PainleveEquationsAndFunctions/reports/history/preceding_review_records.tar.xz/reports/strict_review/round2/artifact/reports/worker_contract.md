# Worker contract and dependency audit

Date: 2026-11-05. This is a read-only repository audit for the local PainleveEquationsAndFunctions draft. The Worker service, lanes and CLI have not been run. No repository, pull request, issue, job or merge order has been changed.

## 1. Snapshots and evidence

| Repository or toolchain | Exact revision |
|---|---|
| TauCetiRoadmapWorker main | 46e12afb791b1efab8fd8b3285370d689ba2e7b8 |
| TauCetiRoadmap main | a0ad405e151ff6e42b3c5e372ac3f24e168ad68f |
| TauCeti library pinned by Roadmap | 358314d4ab97483df4fc4cb8adcc02e74a8d9f5a |
| Mathlib pinned by Roadmap | f6090c7095e1e56b3464c1daba5f24631f1290d2 |
| Lean toolchain | leanprover/lean4:v4.35.0-rc3 |
| TauCetiRoadmapJobs tree | 05a0d8708b987c6583704f55a781421ddb139114 |
| Jobs ORDER.txt blob | a7e5a3fd30d7884239694fa2342d34156066f08a |

Repository trees were fetched without truncation. Exact files were read at the revisions above. Full Mathlib and TauCeti source checkouts at their pins are available under _validation/mathlib and _validation/tauceti. They have no compiled dependency cache installed.

Primary evidence:

- [Worker design prompt](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/design.md).
- [Worker package prompt](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/package.md).
- [README shape](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/sections/readme-shape.md).
- [Lean form](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/sections/lean-form.md).
- [Dependency rules](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/sections/dependencies.md).
- [Gap and order rules](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/sections/gaps-and-order.md).
- [Adversarial review rules](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/sections/adversarial.md).
- [Source rules](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/sections/sources-rules.md).
- [Static gates](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/tauceti_roadmap_worker/gates.py), [dependency parser](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/tauceti_roadmap_worker/depgraph.py), [plan validator](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/tauceti_roadmap_worker/lanes/design.py).
- [Source validator](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/tauceti_roadmap_worker/sources.py), [configuration constants](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/tauceti_roadmap_worker/config.py).
- [Roadmap manifest](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/lake-manifest.json), [toolchain](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/lean-toolchain), [AGENTS](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/AGENTS.md).

Exact Worker prompt/gate copies are in _research/worker_contract_sources. Audited main roadmap copies are in _research/roadmap_sources. Proposed roadmap copies are in _research/roadmap_proposed. Pin URLs belong in this audit report; the canonical README gate forbids commit-pinned links into the content repository.

## 2. Required local package

The design-stage outputs are design/README.md, design/plan.json, sources.toml and a design report. The package-stage outputs are README.md, Suggested.lean, metadata.toml, sources.toml and a package report. Design and package reports should record adversarial review, exact suppliers, ownership changes, remaining source limitations and validation results.

There are two different folder contracts:

- The Worker staging package includes sources.toml, design and reports.
- The eventual TauCetiRoadmap content folder normally contains README.md, Suggested.lean and metadata.toml only, plus any deliberately authorized Lean modules or nested roadmaps. The gate's default ROADMAP_FILES is exactly those three names. The staging source manifest and review material should not be copied indiscriminately into a future content-repository change.

The local user draft may retain the complete staging package. Nothing is being published here.

### README structure

1. A title of the form “# Roadmap: painlevé equations and functions”.
2. A bold Summary paragraph.
3. Scope and ownership.
4. Conventions.
5. Exact supplier contracts.
6. How to read the build.
7. Numbered layers, each containing numbered target sections, followed by Examples and Dependencies.
8. Downstream consumers.
9. References.

Every definition or construction needs useful API facts in prose, at least three discriminating Checks, precise hypotheses, source locators and exact prerequisites. Each statement and its proposed proof route must be supplied. A source theorem with narrower hypotheses is not evidence for a stronger target.

README mathematics is Unicode or code-span text, without LaTeX delimiters. Avoid process residue, job identifiers, private filesystem paths and pull-request numbers. Backticked identifiers presented as declarations belonging to this roadmap must exist in Suggested.lean; API facts that have no Lean declaration should be prose. Existing roadmaps keep their ownership: cite their actual target numbers, do not re-plan them.

### plan.json contract

The expected main keys are roadmap, title, parent, summary, baseline, layers, suppliers, consumers and gaps.

Each layer has key, title and targets. Each target has id, kind, name, statement, hypotheses, locator, prerequisites, api and tests. A locator contains source and where. Every target must have a locator or an explicit gap; every definition/construction has at least three tests. Test kinds are computation, degenerate, compatibility, characterisation and non-example.

Allowed prerequisite forms are mathlib:Name, tauceti:Name, roadmap:RoadmapName §section, target:id and gap:slug. The actual validator requires referenced target IDs and gap slugs to exist.

A named supplier gap records slug, needs as one precise sentence, supplier and section, together with neededBy and explanatory detail. The matching README sentence has this form:

    What SupplierName must provide (gap:slug): the precise missing interface.

The mechanical validator permits supplier = "none"; the review rules treat an unowned prerequisite as a design defect. A proposed extension must be called an extension or gap rather than attributed to an existing supplier theorem.

### Source manifest contract

Use schema = "tauceti-roadmap-sources/v1", roadmap = "PainleveEquationsAndFunctions", and singular [[source]] entries.

Required fields are id, authors, title, year, locator_scheme, licence_class and status. Useful optional fields are venue, doi, arxiv, locator, url, fetched_from, fetched_at, sha256, local_name, accessed, version_note, resolution and cited_for.

Allowed locator schemes: theorem, page, section, tag, chapter, equation.

Allowed statuses: certified, uncertified, waived, local. “Verified” and “reviewed” are not statuses.

Allowed licence classes: open-repository, publisher-open, author-page, institutional, operator-local. “none” is reserved for an unread uncertified/waived citation. The validator also supports a precisely formatted answered-by identity.

A certified source's hash is the SHA-256 of the actual fetched bytes, with the exact fetched URL and timestamp. Do not hash a citation string or invent certification. There is one key per work, with a version note if preprint/published numbering differs. Source PDFs and extracted text remain outside the package; manifest entries contain locators and bibliographic facts, not passages.

## 3. Lean outcome and the correct acceptance file

The Worker explicitly allows a Suggested.lean file with zero declarations when no genuine headline is statable on the pinned carriers. Its module docstring must name each missing headline and the specific missing carrier. It explicitly prohibits a weaker substitute, free Prop-valued conditions, admitted data definitions, arbitrary parameter wrappers and padding with generic lemmas.

Required form:

- A single first import Mathlib, followed only by individual TauCeti modules actually used and present at the pin.
- One module docstring, headed with the title followed by “target signatures”.
- Namespace TauCetiRoadmap.PainleveEquationsAndFunctions.
- Only genuine headline theorem signatures, with sorry, and at most the few simple native-carrier definitions needed to state them.
- No set_option, axiom/opaque replacements, admitted example, generic algebraic tautology or README Check copied as a headline.
- When declarations exist, mechanically inspect their full binders with temporary #check commands; unused section variables otherwise silently disappear.
- Default line cap in GateOptions is 5000.

The pinned libraries provide manifolds, vector bundles, real integral curves, smooth distributions, basic schemes, finite-dimensional linear algebra, local meromorphic functions and Fredholm operators. Searches found no actual parameterized parabolic meromorphic connection moduli, analytic Stokes data, full irregular Riemann–Hilbert family, intrinsic Painlevé family, Okamoto pair moduli or holomorphic Fredholm determinant-line family needed for these headlines. A search hit for “Painlevé theorem” in complex-analysis removability files is unrelated to the Painlevé differential equations.

The initial draft used zero declarations under that rule. Strict review C05 found that this analysis had missed the generic proper-semiconjugacy transfer theorem in §5.2, which can be stated on existing manifold/tangent/hom-bundle/derivative/proper-map carriers without Painlevé moduli. The revised Suggested.lean includes five genuine definitions and one admitted headline signature, while retaining the eleven application-carrier omissions. Its semantic statement was reviewed; successful elaboration has not been obtained. This is not a proof of any Painlevé theorem.

### Compilation experiment

Initially neither lean nor lake was on PATH. With the parent's authorization, the official Lean 4.35.0-rc3 Linux distribution was downloaded and extracted locally under _validation/toolchain. No system installation or Worker process was used.

The official archive was:

https://github.com/leanprover/lean4/releases/download/v4.35.0-rc3/lean-4.35.0-rc3-linux.tar.zst

The local Lake executable reported:

    Lake version 5.0.0-src+470d5ce (Lean version 4.35.0-rc3)

The local Lean executable, including direct and PATH-based invocation, reported:

    error: failed to locate application

Lake's environment invocation reported:

    error: could not detect the configuration of the Lake installation

Setting LEAN_SYSROOT did not fix the failure. The official Lean runtime source for this tag locates the application through /proc/<pid>/exe on Linux; that operation failed in this execution environment. No runtime restriction was bypassed. Compilation and elaboration did not occur. The number of sorry warnings is therefore not “zero after compilation”; it is not observed. Source inspection and static checks remain possible.

On a host where this toolchain runs, the least-work genuine elaboration route is a checkout of TauCetiRoadmap at the audited revision, its existing lake-manifest.json and pinned dependencies, and lake env lean on the staged Suggested.lean. This draft does not claim that command succeeded here.

## 4. Actual main-roadmap suppliers

The common prefix for the following evidence is:

https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/

### SmoothBundlesConnections

[README](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/SmoothBundlesConnections/README.md), B1.5:

- Ehresmann connection as a complementary distribution to the kernel of a smooth submersion.
- Restriction/pullback, unique local horizontal lifts, maximal intervals and smooth dependence.
- Completeness for proper surjective submersions through compact inverse images.
- Explicit warning that arbitrary horizontal distributions need not be complete.

Use this generic engine. Painlevé owns construction of the actual isomonodromy splitting and its proper Riemann–Hilbert comparison, not a second generic Ehresmann theory. A proper Riemann–Hilbert map is not the same assertion as properness of the projection to time.

### ComplexManifolds and ComplexKahlerGeometry

[ComplexManifolds](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/ComplexManifolds/README.md) supplies the fixed-model complex manifold construction, realification, gluing, Riemann sphere and holomorphic bundle groundwork.

[ComplexKahlerGeometry](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/ComplexKahlerGeometry/README.md), K3.0 and K4, owns finite-dimensional holomorphic calculus and the holomorphic connection sheaf operator with Leibniz rule, gauge/pullback/tensor/dual/Hom operations and curvature. K4 also owns comparison to smooth flat connections and local systems. Its monodromy convention is transport composed with framing equals framing composed with monodromy. This does not supply irregular Stokes data.

### FormalLaurentPuiseux

[README](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/FormalLaurentPuiseux/README.md), L1–L7, owns scalar Laurent/Puiseux fields, substitution, derivations, residues and ramification/descent. It explicitly excludes formal connection theory and Stokes theory.

### SchemeAndStackFoundations

[README](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/SchemeAndStackFoundations/README.md):

- §1.18: stacks in groupoids, stackification and 2-fibre products.
- §1.19: algebraic and Deligne–Mumford stacks.
- §1.23: fine/coarse moduli and Keel–Mori.
- §§4.2–4.6: Artinian bases, deformation functors, Schlessinger/hulls, elementary obstruction theory and deformations of schemes, line bundles and nodes.
- §4.14: projective Noetherian Quot/Hilbert representability, universal families and base change; projective flat Hom/Isom through open Hilbert loci.

The deformation complex for a parabolic irregular connection and its symplectic trace pairing remain specific construction targets. Do not cite the generic stack roadmap as if that construction already existed.

### AlgebraicVectorBundles and AlgebraicCurves

[AlgebraicVectorBundles](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/AlgebraicVectorBundles/README.md), L0A–L0C and L1A–L1B, owns locally free sheaves, bundle operations/determinants and relative Spec/geometric bundles.

[AlgebraicCurves](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/AlgebraicCurves/README.md), Layers 3–4, 9 and 12, supplies Riemann–Roch, differentials/residues and the curve/function-field dictionary.

### RandomMatrices: exact one-way ownership

[README](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/RandomMatrices/README.md):

- §8.3 owns trace-class integral-operator and Fredholm determinant theory on existing operator-ideal carriers: summability, traces, exterior powers, determinant series, trace-norm continuity and window restrictions.
- §8.4 owns bulk/edge limits, including Airy kernels.
- §8.5 owns Hastings–McLeod existence, uniqueness, the specified Airy asymptotic, absence of real poles and the Fredholm/Painlevé identities, including the F2 and F1 formulas.

Painlevé can consume §8.3–8.5 and own only the comparison of their scalar solution with the intrinsic PII horizontal section. Do not also mark unchanged RandomMatrices as depending on this roadmap; that would create an ownership cycle. No new Hastings–McLeod existence theorem belongs here.

### Determinant-line and operator-family ownership

[OperatorTheory/OperatorIdeals](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/OperatorTheory/OperatorIdeals/README.md) OI-B30 and OI-B23 supplies the trace-class carrier and completeness. It does not supply determinant-line families.

[OperatorTheory/ToeplitzOperators](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/OperatorTheory/ToeplitzOperators/README.md) T3 supplies complex continuous matrix-symbol Fredholmness and index equal to minus winding of the determinant. It uses native ContinuousLinearMap.IsFredholm and family/index APIs. This is a possible supplier for a concrete Riemann–Hilbert boundary operator model, not a universal holomorphic determinant section.

[HeegaardFloer](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/HeegaardFloer/README.md), §2.2 (F0.0), explicitly owns the reusable REAL determinant line det ker(T) tensor det coker(T)* on native Fredholm operators. It builds families by finite-dimensional target stabilization, transition maps, line-bundle cocycle, family/pullback naturality, composition exact-sequence isomorphisms and signs. It also distinguishes orientation transport from linear fibre transport.

The complex holomorphic version is not stated there. A named supplier extension can request complex-scalar holomorphic stabilization and determinant-family gluing. Painlevé then owns the framed index-zero Riemann–Hilbert specialization, canonical determinant section, sewing, divisor, Malgrange/JMU comparison and normalization. An arbitrary closed two-form does not produce these targets, and a real orientation line does not supply a holomorphic tau function.

[CompactOperators](https://github.com/TauCetiProject/TauCetiRoadmap/blob/a0ad405e151ff6e42b3c5e372ac3f24e168ad68f/TauCetiRoadmap/CompactOperators/README.md) concerns nonarchimedean Fredholm determinants and is not the complex analytic supplier for this tau-line construction.

### Other generic suppliers

Completed/UniversalCovers owns covering-space universal lifts/deck transformations. DifferentialGeometry Layers 0–1, 3 and 4 owns forms, flow/distribution/Frobenius infrastructure. SymplecticGeometry has a specific current root roadmap and nested subjects; do not attribute all symplectic geometry to a vague root layer without an exact target.

## 5. Proposed suppliers: heads actually read

These are proposed roadmap targets, not implemented native APIs and not merged main-roadmap guarantees.

| Proposed roadmap | Inspected PR and head | Exact useful scope |
|---|---|---|
| FormalConnectionsOpers | PR 1056; 1aab7da18ead3b687f442771f7786d8f236ce155 | F2.1 sheaf connections/gluing; F2.2 symbols/Atiyah sequence; F2.3 operations; F2.4 fixed-model analytic comparison; F3 formal gauge groupoids |
| ComplexComparisonPartII | PR 848; 84cbfee00308efa17b1f989d7149fa9319140a4d | C−1.1 analytic spaces and analytification; C0.3 holomorphic bundle/locally free sheaf dictionary; C0.4 coherent analytification; C1.9 proper GAGA; C5.6 regular-singular RH |
| AlgebraicModuliForArithmeticGeometry | PR 853; 4f0ad34e58a70d37eaf525cc8cdeb595a3048dfd | §5.1 inertia rigidification; §7.1 Artin criteria/effectivity; §8 framed deformations |
| PadicDifferentialEquationsAndRigidCohomology | PR 1002; 4d3f9ec8043d5d6e4d1fe1f35d9f49555ba01871 | RD.6.52a: formal normal forms and slope decomposition over any characteristic-zero field after finite constants/ramification, ramified descent and good lattice pairs |
| GlobalHolomorphicFunctions | PR 992; 241053b90a2e35ee99d3c4e36a162bf742203581 | One-variable global holomorphic tools, Runge/Mittag–Leffler/Cousin; only needed when an actual target calls for them |

Pinned file evidence:

- [FormalConnectionsOpers](https://github.com/TauCetiProject/TauCetiRoadmap/blob/1aab7da18ead3b687f442771f7786d8f236ce155/TauCetiRoadmap/FormalConnectionsOpers/README.md).
- [ComplexComparisonPartII](https://github.com/TauCetiProject/TauCetiRoadmap/blob/84cbfee00308efa17b1f989d7149fa9319140a4d/TauCetiRoadmap/ComplexComparisonPartII/README.md).
- [AlgebraicModuliForArithmeticGeometry](https://github.com/TauCetiProject/TauCetiRoadmap/blob/4f0ad34e58a70d37eaf525cc8cdeb595a3048dfd/TauCetiRoadmap/AlgebraicModuliForArithmeticGeometry/README.md).
- [PadicDifferentialEquationsAndRigidCohomology](https://github.com/TauCetiProject/TauCetiRoadmap/blob/4d3f9ec8043d5d6e4d1fe1f35d9f49555ba01871/TauCetiRoadmap/PadicDifferentialEquationsAndRigidCohomology/README.md).
- [GlobalHolomorphicFunctions](https://github.com/TauCetiProject/TauCetiRoadmap/blob/241053b90a2e35ee99d3c4e36a162bf742203581/TauCetiRoadmap/GlobalHolomorphicFunctions/README.md).

Important scope qualifications:

1. FormalConnectionsOpers F8 uses an isomorphism-arrow groupoid built from formal local connections/opers. This is not construction of an analytic isomonodromy connection along deformation times.
2. ComplexComparisonPartII C−1.1 retains nilpotent analytic structures and proves gluing/fibre products and scheme analytification. Do not replace it by only a set of complex points.
3. C5.6 is regular-singular, with normalized residue strips and exp(−2πi Res) monodromy. It does not supply irregular Stokes data or proper full-stratum wild RH.
4. RD.6.52a is not confined to a p-adic coefficient field: the formal decomposition statement is characteristic zero. Its rank-two ramified example has slope 1/2 after descent; this is the relevant owner.
5. Existing proposed texts overlap in claiming generic cyclic-vector theory: FormalConnectionsOpers F6.2 and the p-adic roadmap RD.1.2–1.6. This draft should not create a third owner or pretend that this cross-proposal issue has been resolved.

### Merge order evidence

The saved ORDER.txt puts SmoothBundlesConnections at line 8, AlgebraicModuliForArithmeticGeometry at 32, ComplexComparisonPartII at 39, FormalConnectionsOpers at 40 and PadicDifferentialEquationsAndRigidCohomology at 110. The corresponding Part II extensions later in the order must not be silently consumed unless explicitly needed.

For a future package consuming the five relevant proposed suppliers, PainleveEquationsAndFunctions must be placed after all of them. Main-roadmap suppliers are already available and never create an upward edge merely because they appear elsewhere in the board order. This local draft is not in the board order; that fact is a reportable integration condition, not authorization to edit ORDER.txt. No global dependency graph has been claimed to pass merely from inspecting these order positions.

## 6. Native declarations actually verified at the pins

### Mathlib

- Geometry/Manifold/MFDeriv/Defs.lean: MDifferentiableWithinAt, MDifferentiableAt, MDifferentiableOn, MDifferentiable, mfderiv and the native tangent/model carrier.
- Geometry/Manifold/IntegralCurve/Basic.lean: IsMIntegralCurveOn, IsMIntegralCurveAt and IsMIntegralCurve use real time. They do not directly state complex analytic horizontal sections.
- Topology/Maps/Proper/Basic.lean: IsProperMap and IsProperMap.isCompact_preimage. The former is the actual topological proper-map condition, not merely compact fibres.
- Analysis/Meromorphic/Basic.lean: MeromorphicAt is cancellation by a finite power followed by analyticity near a point. It permits arbitrary values assigned at a pole; a scalar chart is not thereby a globally holomorphic map.

The exact prefix for these sources is:

https://github.com/leanprover-community/mathlib4/blob/f6090c7095e1e56b3464c1daba5f24631f1290d2/Mathlib/

### TauCeti

The exact prefix is:

https://github.com/TauCetiProject/TauCeti/blob/358314d4ab97483df4fc4cb8adcc02e74a8d9f5a/TauCeti/

Verified in Geometry/Manifold/IntegralCurve/Maximal.lean, root namespace (with the explicitly qualified method names below):

- maximalIntegralCurveInterval
- maximalIntegralCurve
- zero_mem_maximalIntegralCurveInterval
- IsMIntegralCurveOn.eqOn_maximalIntegralCurve
- isMIntegralCurveOn_maximalIntegralCurve
- not_mapClusterPt_nhdsLT_maximalIntegralCurve
- not_mapClusterPt_nhdsGT_maximalIntegralCurve
- eventually_notMem_nhdsLT_maximalIntegralCurve
- maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo
- maximalIntegralCurveInterval_eq_univ_iff
- isMIntegralCurve_maximalIntegralCurve

These supply real C1 flow extension and compact-escape/completeness facts under the stated Hausdorff, boundaryless-manifold and completeness hypotheses. The chosen maximal curve has a fallback value outside its actual existence interval; no theorem should reason from that value as a solution.

Geometry/Manifold/IntegralCurve/Extension.lean supplies exists_gt_isMIntegralCurveOn_Ioo. Flow.lean supplies maximalIntegralCurve_add, the open flow domain and contMDiffOn_maximalIntegralCurve for the appropriate finite-dimensional smooth setting.

Geometry/Manifold/Distribution.lean defines IsDistributionFrameOn, IsContMDiffDistribution and IsInvolutiveDistribution on native tangent subspaces.

Analysis/ODE/Frobenius.lean defines TauCeti.IsFrobeniusIntegrableAt and proves exists_eventually_hasFDerivAt_of_isFrobeniusIntegrableAt. The useful existence theorem has real finite-dimensional domain and fibre, regularity and local integrability hypotheses. The bare fderiv commutator formula is vacuous at some nondifferentiable functions because fderiv has a default value; do not use it without the regularity hypotheses.

Analysis/Complex/RiemannSurface/Meromorphic.lean supplies TauCeti.RiemannSurface.MeromorphicAt and MeromorphicAt.comp. This is composition between one-complex-dimensional Riemann surfaces. It does not by itself settle a rational phase observable on a complex surface, nor indeterminacy of its restriction to a trajectory. The roadmap must prove the stronger phase-observable comparison on its genuine carriers.

Mathlib and TauCeti have native ContinuousLinearMap.IsFredholm, splitting/index/parameter-family infrastructure. The audited HeegaardFloer supplier is responsible for constructing the determinant-line family on that carrier; no native holomorphic determinant-line family was found.

## 7. Validation that can run without starting the Worker

The following are pure functions in the audited code, not Worker invocations:

- gates.scan_folder(name, readme, lean, GateOptions(...)): README/Lean lexical shape, imports, identifiers, process residue, numbering and optional dependency parsing.
- design.validate_plan(data, name): target IDs, prerequisites, locators, gap records and definition Checks.
- design.supplier_gap_problems(gap): exact named supplier contract fields.
- sources.validate_manifest(data, allow, deny, uncertified_ok): source manifest structure and provenance constraints.
- depgraph.supplier_edges and depgraph.check_order: textual supplier edges and board-order diagnostics.

These functions can be loaded for local read-only checks without running a lane, a service loop, an agent process or a network write. If loading their original module imports would invoke unnecessary Worker facilities, extract only the unchanged pure functions and constants with Python AST and explicitly report this method. Do not report that a whole Worker acceptance gate was passed.

The static checks do not establish that mathematical statements are true, citations cover their full claimed scope, missing carriers have been formalized, or Lean elaboration succeeded. A complete source-defined roadmap is a completed plan with explicit proof obligations; it is not a completed formalization.

### Lean-only static result

Ten audited pure scanners were run on the completed Suggested.lean: set_option, Mathlib subimports, admitted data, admitted examples, Lean residue, missing Mathlib import, private paths, empty Lean sections, import validity and line count. All returned empty findings. The original scanner definitions were loaded through Python AST with only their relative top-level imports omitted; the three exact board constants NAME_RE, TEMP_ROOT and PRIVATE_PATH were supplied from the audited board.py. No Worker entrypoint was executed. The machine-readable result is _research/suggested_lean_static_checks.json. This result covers Lean text rules only, not the final README/plan/source manifest and not elaboration.



## Strict-review refresh of current upstream evidence

At 2026-11-05 the Worker head remains 46e12afb791b1efab8fd8b3285370d689ba2e7b8. Roadmap main advanced to 766fcec2512f250791032b7ad0798ed6415fd398; comparison with the original a0ad405e151ff6e42b3c5e372ac3f24e168ad68f showed no change to any cited main-supplier file, the Mathlib/Tau Ceti pins, or the Lean toolchain. All five proposed supplier heads listed above were refetched and remained unchanged. The current Jobs order is merge-order/ORDER.txt, blob 8732f80c3a88c3cb83516c2de1f1a73e5c538a8d. Its additional DGFloerPartII entry does not change this roadmap's supplier ordering.

The new LocalVariationalFieldTheory roadmap owns general nonlinear bundle jets. The scalar first-jet chart map in §9.1 is a coordinate comparison using the native manifold derivatives, not a second generic jet carrier; adding such a carrier would require reusing that supplier.

The actual Jobs configuration asks for two red-team rounds and separation by agent/model, with review providers from different model families. This manual draft review uses separate fresh-context reviewer sessions and author repairs, with frozen hashes and computed ledgers. It does not claim the distinct-model-family gate, official Worker execution or package acceptance. Lean was retried with its documented sysroot setting and still failed before elaboration with the error recorded above.
