# Strict core review, round 2

## Verdict and scope

**Verdict: `needs_changes` for the frozen round-2 package.** All seven original core findings C01–C07 have individually passed their substantive repair controls. Two current P2 entries remain in this core record: the same-defect omission of the general §11.2 existence/no-exit/convergence headline, and the unanchored native model parameter at the `PiecewiseC1On` / `TargetTransport` call sites. The latter is a source-established elaboration risk; it is not a fabricated observed compiler diagnostic. No P1 false mathematical headline has been established.

This is a fresh manual application of the actual Worker review, whole-document red-team, adversarial, defect-class, lessons, supplier-gap and Lean-form rules, together with `_strict_review/protocol.md`. No Worker entrypoint, external review, push, issue, PR or publication was used. The reviewed artifact was not edited. Later canonical edits reported by the parent are outside this verdict and require their own frozen review.

Coverage is Scope, Conventions, relevant supplier interfaces, all **21 targets in Layers 1–5**, their full README API/checks and plan entries, and the entire `Suggested.lean`. The specifically requested same-defect regression in §11.2 is included; this is not a second general review of Layers 6–13. The assigned primary-source sample was read at 1.1, 1.2, 1.3, 3.1, 3.3, 4.1, 4.3, 5.4 and 5.5, with repaired-source claims also checked. Every core target has a concrete evaluated witness or structural negative control in `core_ledger.json`. Unchanged round-1 calculations are explicitly identified there and were independently rechecked; their previous verdicts were not reused as acceptance.

### Immutable identity

- `README.md`: `bded7b400716d663957a13a462349b688a525cda5889b8f3bac55b8bc8f31316`
- `design/plan.json`: `b68bbe5fa893c3f777ce681d8297c125141e4d7bc4cb3d0acd49bcbf79827738`
- `Suggested.lean`: `eb8d55fa03aba06781bbcd6fe7adc37c679e7aee6f24e1965137149c08c69b29`

Pinned native source: Mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2`; Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`. Pinned Lean source inspected: 4.35.0-rc3.

### Independent gates

| Gate | Status |
| --- | --- |
| Substantive mathematical/design review | Needs the two recorded repairs; seven old core defects closed individually |
| Official Lean elaboration | **Unpassed.** The executable cannot start (`failed to locate application`). No passing build or kernel check is claimed. |
| Reviewers from distinct model families | **Not obtained.** Separate fresh contexts do not certify that gate. |
| Actual Worker run/package acceptance | **Not performed and not claimed.** |

The compiler and reviewer-separation gates remain unpassed even after a later substantive zero-finding review. Conversely, an unavailable compiler is not itself evidence that the intended mathematical theorem is false.

## Current findings

### CORE-R2-01 — P2: 11.2 / Suggested.lean headline selection

**Location.** Suggested.lean:63-65; README.md:1018-1035; design/plan.json target 11.2 formalization_status

**Precise claim.** The missing intrinsic collision/degeneration carriers are used as the reason to omit controlled confluence, but 11.2 explicitly owns a general compact-path parameter-dependent ODE existence/no-exit/uniform-convergence theorem before its application. That common deep headline is already statable on native finite-dimensional normed spaces and is absent from the acceptance-test file.

**Witness.** Take E=R, F_epsilon(t,y)=y^2+epsilon, u0(t)=1/(1-t) on [0,1/2], initial value 1 and tube |y-u0(t)|<=1. On this compact tube 0<=y<=3, so 6 is a common phase-Lipschitz constant; the field error is |epsilon|. The bound (1/2)|epsilon|exp(3)<1/2 for |epsilon|<exp(-3) prevents exit and yields full-segment existence. Native Gronwall assumes both trajectories and their tube membership and therefore does not itself state this conclusion.

**Repair.** Keep the intrinsic-family docstring deferral, but add a real native generic headline for nearby solution existence on the full compact interval/path, no-exit and uniform convergence, with actual derivative/continuity, a positive reference-tube margin, uniform phase-Lipschitz and field-convergence hypotheses, and converging initial points. Use only a few genuine solution/tube definitions. Own the finite chart gluing/adapter. Do not replace the target by an estimate whose hypotheses already assume the compared trajectories exist and remain in the tube.

**Retest.** Inspect that the full nearby-solution existence and trapping are conclusions, not supplied solution operators, arbitrary predicates, or tube-membership hypotheses. Instantiate the nonlinear witness above and a nonconvergent-initial-value rejection. Check the actual pinned Picard-Lindelof/uniqueness and Gronwall premises, then elaborate the full final file once the runtime works.

**Verification limit.** Independently read 11.2 and the native Gronwall/local-existence declarations; the omission is visible in the complete 161-line Suggested.lean. Same-defect regression for C05. No compile-success assertion.

### CORE-R2-02 — P2: Suggested.lean native model arguments

**Location.** Suggested.lean:137,139-140,148,150,154

**Precise claim.** The occurrences PiecewiseC1On gamma and TargetTransport rho do not anchor their implicit model EB to the EB of the smooth projection. The underlying B and function gamma/rho do not determine a chart model, so the frozen file relies on inference of an unconstrained non-output model parameter.

**Witness.** PiecewiseC1On is defined using ContMDiffOn I(R) I(R,EB) at lines 112-115, but its explicit arguments only contain gamma:R->B and real endpoints. TargetTransport similarly only exposes rho:R->B. Native ChartedSpace H M deliberately does not mark H as outParam (ChartedSpace.lean:134-142, including the real-vs-complex multiple-model explanation). Pinned Lean typeclass synthesis uses a new metavariable depth for ordinary input parameters (Lean/Meta/SynthInstance.lean:962-1006). Thus neither the target-transport fields nor the theorem path premises provide the missing model through their explicit terms.

**Repair.** Write PiecewiseC1On (EB := EB) gamma at each of the five uses and TargetTransport (EB := EB) rho in the theorem. Keep the already model-determined HorizontalSplitting pi / HorizontalOn pi h uses. This anchors every path condition and transport to the same native model.

**Retest.** Statically verify the five path occurrences and target-transport type explicitly share the theorem model; then elaborate the complete file and inspect the inferred declaration types. The official runtime is unavailable, so this is a source-established elaboration risk, not a fabricated compiler error or a claimed passing build.

**Verification limit.** Read the actual native class and pinned Lean elaborator sources. This is a concrete input-inference defect/risk rather than a change to the valid mathematical theorem. Parent reports a later canonical defensive edit; that edit is outside this frozen verdict.

### Why the §11.2 missing headline is substantive

The README explicitly separates a **general parameter-dependent ODE theorem** from its application to the collision family. Missing intrinsic moduli, a confluence arrow or limiting Stokes data therefore block the application but do not prevent stating the common theorem. A declaration that assumes two trajectories already exist and stay in a tube, then repeats Grönwall, would not repair this omission.

One concrete mathematical signature uses a finite-dimensional real normed space E, a topological parameter space P with distinguished parameter e₀, vector fields F : P → ℝ → E → E, initial values a : P → E and a reference solution u₀ on [0,1]. Define `SolvesOn` by actual continuity and `HasDerivWithinAt` on the closed interval, and the tube by

T = {(t,y) | 0 ≤ t ≤ 1 and ‖y − u₀(t)‖ ≤ r}, with r > 0.

Require the reference solution equation, continuity of the nearby fields on that actual tube, a common phase Lipschitz constant on each closed tube slice, uniform field convergence on T, and initial-value convergence to u₀(0). The conclusion should choose nearby solutions defined throughout [0,1], satisfying the initial-value and differential equations, staying strictly inside the tube, and converging uniformly to u₀. No nearby solution operator or already-proved tube membership is an input. Compactness of the reference tube, local existence, Grönwall until exit, a strict margin, endpoint extension and uniqueness yield the theorem. The finite chart version then owns subdivision and gluing. This is a statability witness, not a purported compiled Lean file.

The nonlinear test Fε(t,y)=y²+ε on [0,1/2] is useful because the reference solution is explicit while nearby full-interval existence is still a conclusion. The tube with radius 1 is contained in 0 ≤ y ≤ 3, hence L=6 works. The displayed error bound is (1/2)|ε|e³. For |ε|<e⁻³ it stays below 1/2, leaving a positive reserve before the boundary at distance 1. Native `dist_le_of_approx_trajectories_ODE_of_mem` already assumes the compared trajectories and their membership; its hypothesis list proves exactly why that inequality alone is not this headline. See `_validation/mathlib/Mathlib/Analysis/ODE/Gronwall.lean:163` and the local existence source below.

## Individual closure of C01–C07

### C01 — closed

A=0 and g=diag(z,1) produce diag(1,0) dz/z with trace 1; subtracting half its trace gives diag(1/2,-1/2), which is only a local projective representative. The repaired contract globally uses End^0(E) of rank r^2-1/PGL. The gauge discrepancy is scalar and vanishes in the adjoint connection.

### C02 — closed

Fresh integer-cost enumeration gives 17 ordered profiles and 10 underlying unlabelled profiles. Ordered support-size counts are 2,8,6,1, and unlabelled counts are 2,5,2,1. The revised statement retains labels and explicit reindexing.

### C03 — closed

The false rank-zero formal substitution 2 is now outside the stated r>=1 domain. Positive-rank values, including rank one/genus one unfixed 2 and fixed 0, agree with the claimed formula.

### C04 — closed

The early auxiliary unfolding, its finite-flat divisor, simple-connection moduli, local universal object, deformation/trace complexes, two generic logarithmic comparisons, generic closedness and central restriction are now explicitly owned in 2.3. I23 Propositions 8.2-8.3 actually contain the required auxiliary construction. No dependency on later Layer 11 is used.

### C05 — closed_as_missing_declaration_defect; compiler_acceptance_not_claimed

Suggested.lean now has Breaks, HorizontalSplitting, PiecewiseC1On, HorizontalOn, TargetTransport with genuine bodies/native carriers and proper_semiconjugacy_complete_horizontal_lifts with a proof hole only. Prefix compatibility does not assume existence, properness is on F, uniqueness is on [0,1], and no inverse is assumed. CORE-R2-02 separately records an implicit-model elaboration risk.

### C06 — closed

For the universal extension family, the unbalanced stratum pulls back to {0} and balanced locus to A^1 minus {0}. The revised API states locally closed splitting strata with the balanced open locus distinguished.

### C07 — closed

The explicit H=qp/(2t) test now computes one-loop endpoint (-1,-2), two-loop endpoint (1,2), symplectic Jacobian -I and fixed locus {(0,0)}. Always-identity transport fails the new check.

For C05, closing the original absence of a statable generic theorem does not mean its new implementation has passed elaboration. That distinction is the reason for the separate model-argument entry. Likewise, closing C04 means the missing construction now has a concrete owner and noncircular route; it does not mean the future algebraic and analytic proofs have already been carried out.

## Native-carrier and full-signature audit

### Carriers and definitions

`Suggested.lean` now contains five genuine definitions/structures and one theorem, with a single proof `sorry`. Its mathematical content is not represented by freely chosen truth predicates, opaque moduli constants or admitted data definitions. `ContMDiffMap` is the actual smooth-map carrier. The splitting is an actual section of `Hom(π*TB,TM)` with a continuous-linear right inverse for `mfderiv`. The total Hom-bundle model uses Mathlib's native pullback, tangent and continuous-linear-map bundle instances; it is not a secretly trivialized tangent bundle. Relevant checked files include:

- `Mathlib/Geometry/Manifold/ContMDiffMap.lean:38`;
- `Mathlib/Geometry/Manifold/VectorBundle/Basic.lean:82,102`;
- `Mathlib/Geometry/Manifold/VectorBundle/Pullback.lean` and `.../Hom.lean`;
- `Mathlib/Geometry/Manifold/VectorBundle/Tangent.lean:185,188`;
- `Mathlib/Topology/VectorBundle/Constructions.lean:204`;
- `Mathlib/Geometry/Manifold/IsManifold/Basic.lean:1033` for the deliberately non-reducible tangent-space copy.

`Breaks` supplies a finite strictly increasing subdivision with the actual first and last points. Its zero-piece case forces equal endpoints. For a positive-length interval, the pieces are nondegenerate, so the within-derivative formulation has the expected uniqueness at interval endpoints. `HorizontalOn` requires the base equation as well as genuine piecewise differentiability and the tangent equality h(dπ(v))=v. The latter avoids a type cast along a separately stated equality without weakening horizontality: differentiating the base equation on each nondegenerate piece recovers the prescribed base velocity.

`TargetTransport` supplies actual trajectories and their continuity, initial point and base projection. Its field is not the sought source lifting theorem. The prefix-compatibility hypothesis quantifies over **existing** source partial lifts; it does not assume their extension to time 1. The conclusion genuinely asserts source existence through each initial point. No inverse to F, target smoothness, injectivity or surjectivity is needed. Uniqueness is correctly asserted on [0,1], not for arbitrary values of the extension outside the path interval. The singular target is permitted because only its topology is used; native properness supplies a compact inverse image of the compact transported target path (`Mathlib/Topology/Maps/Proper/Basic.lean:210`).

The finite-dimensionality, Hausdorff and second-countability assumptions are materially relevant to compact continuation. A possible false-positive was checked and rejected: it is not correct to conclude that these instance section variables disappear merely because they do not occur textually in the theorem proposition. The pinned Lean elaborator's `withHeaderSecVars` includes relevant instance section variables based on their dependencies; see `Lean/Elab/MutualDef.lean:443–493`, with the theorem paths using that mechanism. This source check is distinct from—and cannot replace—inspection of the elaborated signature when the runtime becomes available.

### The continuous-time ODE route

The real transfer theorem admits every compact piecewise C¹ base path. Such a path has continuous velocity on each piece, but that velocity need not be C¹. The concrete path γ(s)=|s−1/2|^(3/2) is C¹; its derivative has right difference quotients 15, 150 and 1500 at increments 10⁻², 10⁻⁴ and 10⁻⁶. Thus autonomizing the lifted equation cannot in general be fed directly to a theorem requiring a C¹ autonomous tangent field.

Tau Ceti's `maximalIntegralCurveInterval_eq_univ_of_isCompact_of_mapsTo` at `TauCeti/Geometry/Manifold/IntegralCurve/Maximal.lean:364` requires exactly that C¹ autonomous regularity. The valid floor for the pathwise adapter is instead Mathlib's continuous-time, phase-Lipschitz Picard–Lindelöf theory:

- `IsPicardLindelof` in `Mathlib/Analysis/ODE/PicardLindelof.lean:79` requires a uniform phase Lipschitz bound, time continuity, a norm bound and the interval/radius inequality;
- `IsPicardLindelof.exists_eq_forall_mem_Icc_hasDerivWithinAt` in `Mathlib/Analysis/ODE/ExistUnique.lean:56` gives actual local solutions;
- `ODE_solution_unique_of_mem_Icc_right` in the uniqueness source supplies the matching uniqueness floor.

The owned adapter is chart realization of the lifted field, uniform constants on compact subcharts, a finite subdivision, gluing by uniqueness and extension at the endpoint. The frozen README §5.2 already states a finite-subcover alternative, so this is not a new counterexample to its mathematical theorem. Its Needs paragraph should explicitly route that alternative through the continuous-time floor rather than leaving the autonomous citation as the only named runtime source. The parent reports that the later canonical draft does this; that later text was not accepted by this frozen review.

### Required build retest

Once a working Lean runtime is available, elaborate the exact final package, inspect the complete inferred theorem types, and check all native Hom-bundle instances and the explicit model parameters. A source audit cannot certify these steps. In particular, the same model `EB` must appear in all five `PiecewiseC1On` uses and in `TargetTransport` at the theorem binder; the model parameters already occur in the type of π for `HorizontalSplitting` and `HorizontalOn`.

## Scope and supplier interfaces

The scope now states positive rank, structural polar bounds distinct from actual minimal poles, ordered marked points, fixed determinant and its transport, and the classical regular-singular determinant restriction. Scalar irregular twists cannot be hidden by using only projective Katz slopes. The Hamiltonian sign is fixed by ω=dq∧dp and ι_Xω=d_phase H, giving Ω=ω+dH∧dt and q′=H_p, p′=−H_q. A time reparametrization carries the corresponding Jacobian. The package begins with full bundle-valued moduli and geometric horizontal sections; affine charts and scalar observers are subsequent constructions.

The supplier audit preserves the following boundaries:

- **FormalConnectionsOpers** supplies actual sheaf/relative connections, formal algebra and gauge infrastructure. Its cyclic-vector or regular-model comparison statements do not provide full irregular sectorial classification or a canonical global rank-r trace-free bundle.
- **ComplexCurveModuli D2.0 / ComplexComparisonPartII** supply the stated analytic-manifold/analytic-space framework. Regular-singular RH on curves is not the generic irregular, ramified or all-strata family RH theorem.
- **Scheme/stack and algebraic-moduli interfaces** supply the bounded construction, coherent-term and Cech machinery. They do not silently give a global universal object on a coarse space, turn a C-linear connection differential into an O-linear one, or eliminate the ramified degree-two correction.
- **SmoothBundlesConnections** distinguishes ordinary Ehresmann local lifting from completeness. Proper submersion arguments or principal-group-connection completeness cannot replace properness of the semiconjugating F in §5.2. The native autonomous flow regularity issue is handled above.
- **Completed/UniversalCovers** gives topological covering/deck infrastructure. Nonlinear continuation comes from §5.2; descent requires the actual monodromy fixed-point condition.
- **The native meromorphic curve layer** defines meromorphicity and order on one-complex-dimensional charted spaces. Its composition lemmas require the actual holomorphic/meromorphic hypotheses. An arbitrary rational map from a phase surface, or a chosen resolution without a lifted section, is not automatically a scalar observer satisfying them.

The earlier §2.3 auxiliary unfolding is no longer circular with confluence. Its rank and finite-flat equations, smooth moduli and trace comparisons are owned before their use in closedness. The later all-strata RH theorem is also visibly new: the four proof stages in §4.4 are substantive future targets. Neither ownership label is treated as proof, but each now specifies the data and intermediate claims that must be constructed.

## Primary-source scope checks

The sample was checked against the extracted primary text, using binary-safe searches where the I23 extraction contains NULs.

| Target/sample | Read source and result |
| --- | --- |
| 1.1 | I23 Definitions 2.1, 2.2, 2.8 and Remark 2.9: logarithmic, generic unramified and factorized ramified conditions with their stability/leading-term qualifications. |
| 1.2 | HEU10 universality and local-constancy definitions, including the explicit trace-free rank-two/transversality caveats; BOA01 §7 distinguishes pole/irregular-type deformation parameters and fixed exponents. |
| 1.3 and repaired 1.4 | VDPS09 §2.2/Table 1: ten underlying profiles, quotient by curve automorphisms and affine trivial-bundle models; not ten ordered assignments or completeness of that affine locus. |
| Repaired 2.3 | I23 Theorem 7.5, Theorem 8.1 and Propositions 8.2–8.3: auxiliary simple-connection space, etale universal object, smoothness and two generic logarithmic comparison complexes; no license to omit the family construction. |
| 3.1 | I23 Definition 10.1 and Proposition 10.7: dz/z^m and dε/z^(m−1), integrability, central identification and uniqueness after construction. |
| 3.3 | I23 Definition 11.4, Remark 11.5, Theorem 11.6 and Corollary 11.8: constructed projection form, kernel, bracket compatibility and trace/local-product proof of closedness. BOA01 Theorems 7.1/7.3 remain generic-unramified extended-moduli results. STT02 §6 warns that arbitrary global algebraic coordinates need not be Hamiltonian. |
| 4.1 | I23 Theorem 9.7, Remark 9.8, Corollary 9.11: generic local classification, ramified descent and small-sector ambiguity. BY15 Remark 3/Theorem 4 and Theorem 1: exponential covering local systems and twisted Stokes scope. |
| 4.3 and related 4.4 | IS12 Theorem 5.1 proves generic/nonresonant/irreducible analytic isomorphism; Remark 6.3 says the resonant/reducible properness extension is expected. IIS06 Theorems 4.10/4.12 give the full proper PVI map and its exceptional resolution. The roadmap now owns the broader theorem. |
| Repaired 5.2 | IIS06 Lemma 2.12: proper quasiconjugacy plus local flow gives compact trapping; this is not an inverse-map argument. |
| 5.4, 5.5 | IIS06 Theorems 10.6, 10.10 and 10.12: scalar charts on actual loci, Hamiltonian comparison and analytic Painleve property after geometric continuation. Native meromorphic-curve sources retain the chart/domain/nonidentically-infinite hypotheses. |

No source was credited with a future roadmap theorem merely because its terminology or title was similar. In particular the all-strata irregular RH theorem, its whole-family properness and the general §11.2 no-exit theorem remain planned proofs.

## Complete 21-target control ledger

The following entries summarize the reviewed assertions. `core_ledger.json` also carries the exact left/right values, unchanged-witness provenance, plan API/check counts and source locators. `core_compute.py` and `core_computations.json` supply the independent exact/numeric reruns for the repaired counts/dimensions, unfolding, weights, total-form kernel, gauge composition, nonlinear transport, deleted-cover sequence and ODE regularity/no-exit controls. These finite controls test proposed definitions and scope; they are not proofs of the universal future theorems.

### 1.1

**Assessment.** C01 closed. The revised carrier is the induced connection on End^0(E), or equivalently the projective/PGL datum; it is not a rank-r vector bundle obtained by subtracting a local trace.

**Evaluated control/API adequacy.** The object/arrows, determinant, induced-adjoint, ramified descent and arbitrary-base-change APIs are specified. The rank-r trace-free API now distinguishes a local projective representative from the globally rank r^2-1 carrier. Gauge and dual-number checks reject naive local trace subtraction and reduction to complex points.

**Source scope.** I23 Definitions 2.1, 2.2 and 2.8 supply logarithmic, generic-unramified and factorized-ramified input structures on a full vector bundle. FormalConnectionsOpers supplies connection/sheaf infrastructure, not this constructed moduli groupoid. A scalar term disappears only after the actual adjoint/projective construction.

### 1.2

**Assessment.** Pass as a planned deformation construction. Moving poles, auxiliary parameters, exponent lifts and the reduced time direction remain distinct.

**Evaluated control/API adequacy.** Time-base reparametrization and genuine family arrows are explicit. The moving-divisor Kahler differential and q-prime=q^2 under tau=2t exclude implementations that forget base differentials or time Jacobians.

**Source scope.** HEU10 universality/local-constancy results are used with their trace-free rank-two and transversality hypotheses. BOA01 Section 7 has varying irregular types and pole positions with generic hypotheses; it does not automatically produce the whole intrinsic family or a universal chart-independent time quotient.

### 1.3

**Assessment.** Pass. Genus zero, rank two, regular-singular determinant, nonempty stable fibers and the integer structural budget four are actual admission conditions.

**Evaluated control/API adequacy.** The full intrinsic subcategory precedes scalar families. The 3/4/5 logarithmic-point controls distinguish zero-, one- and two-dimensional reduced time bases; the scalar z^-2 I control is rejected by the determinant condition despite projective slope zero.

**Source scope.** VDPS09 Table 1 organizes ten underlying unlabelled formal profiles and only an affine trivial-bundle model. Its exceptional strong-RH cases cannot justify omitting nontrivial bundles. HEU10 reduced time behavior retains its rank-two scope.

### 1.4

**Assessment.** C02 closed. Ten is the number of underlying unlabelled profiles; all seventeen ordered profiles and their reindexing groupoid are now retained.

**Evaluated control/API adequacy.** Fresh enumeration gives ordered counts 2,8,6,1 and unlabelled counts 2,5,2,1 by support size 1,2,3,4. The dimension n+sum(ceil(Katz))-3 equals sum(m)-3=1. The explicit groupoid language prevents a label permutation from becoming an arrow preserving fixed ordered input.

**Source scope.** VDPS09 Table 1 is an underlying-profile classification, not a claim that the ordered groupoid has ten objects. The revised statement now makes exactly that distinction.

### 2.1

**Assessment.** C06 closed. General fixed splitting-type strata are locally closed; balanced loci are identified separately as open.

**Evaluated control/API adequacy.** The extension family O(-1)->E_t->O(1) has balanced fiber O^2 for t nonzero and (1,-1) splitting at t=0. Its inverse images are A^1 minus {0} and {0}; this rejects the original all-open assertion. The mu_2 torsor and infinitesimal-scalar controls still require the stated stack/coarse and etale-universal distinctions.

**Source scope.** I23 Theorem 5.1 constructs quasiprojective stable-connection moduli through parabolic triples, with arbitrary bundles retained. The fixed-determinant central stabilizer and local-universal statements remain explicitly handled; no global universal object is inferred from the coarse space.

### 2.2

**Assessment.** Pass as an owned construction. The full three-term ramified cone, its C-linear differential, Cech comparison and trace pairing have distinct roles.

**Evaluated control/API adequacy.** For u=z E12, d(u)=E12 dz while d(E12)=0, so the differential is not O-linear. A C->C identity in degrees 1,2 has H^1=0; deleting degree 2 creates a spurious C. The forward/reverse trace pairing has opposite signs. These are structural controls rather than a computation of every Painleve tangent space.

**Source scope.** I23 uses the ramified correction and the full complex. Coherent-term suppliers give acyclicity and Cech comparison termwise; they do not turn the connection differential into an O-linear map in D_qc. The roadmap explicitly owns the required C-linear hypercohomology assembly.

### 2.3

**Assessment.** C03 and C04 closed. Positive rank is explicit, and the formerly missing early auxiliary unfolding is now owned in this target rather than borrowed from Layer 11.

**Evaluated control/API adequacy.** Fresh dimension values are 2 for (r,g,d)=(2,0,4), 4 for (2,0,5), 10 unfixed and 8 fixed for (2,1,4), and 2 unfixed/0 fixed for (1,1,4). Rank zero would give the false value 2 and is now excluded. The auxiliary monic family (z-2h^2)(z-h^2) has central divisor z^2, generic distinct roots, and rank-two finite-flat algebra; dual-number h retains z^2.

**Source scope.** I23 Theorem 7.5 gives the nonempty-fiber dimension, and Theorem 8.1 with Propositions 8.2-8.3 constructs auxiliary simple-connection moduli and comparison complexes. The revised target explicitly owns smooth integral H, finite-flat divisor, local conditions, etale universal object, tangent complex, trace form, generic logarithmic comparisons, generic closedness proof and restriction to the central fiber. The source is not treated as a ready-made formal supplier.

### 2.4

**Assessment.** Pass. Stable reducible/resonant points and apparent behavior are retained; generic ramified local irreducibility is a separate mechanism.

**Evaluated control/API adequacy.** With E=O^2, four different invariant parabolic flags and weights (1/5,3/10,2/5,3/5), total parabolic degree is 3/2 and rank-two slope 3/4. Every constant invariant line has degree at most 3/5, and no subset is on the wall. Thus a reducible connection can be stable; ordinary identity monodromy does not erase its flags.

**Source scope.** I23 Definition 2.8 and Remark 2.9 justify the separate generic-ramified irreducibility route. They do not assert every stable connection is irreducible. The claimed all-strata comparison remains a later owned theorem.

### 3.1

**Assessment.** Pass. Strong dual-number extensions retain the actual pole lattice and base differentials; weak monodromy-constant extensions are excluded.

**Evaluated control/API adequacy.** For D=diag(1,0), N=E12, Gamma=D dz/z+N d_epsilon/z has dGamma=-N dz wedge d_epsilon/z^2 and Gamma wedge Gamma=+N dz wedge d_epsilon/z^2. It is flat but has a forbidden logarithmic time pole. The required m=1 lattice allows a regular d_epsilon coefficient, so this wrong extension fails the actual definition.

**Source scope.** I23 Definition 10.1 explicitly uses dz/z^m and d_epsilon/z^(m-1) with the central identification and integrability. Proposition 10.7 supplies the global uniqueness mechanism after the local construction. HEU10 strong-isomonodromy scope supports the resonant distinction.

### 3.2

**Assessment.** Pass as an owned bracket-compatibility theorem; it is not a formal consequence of choosing a right inverse.

**Evaluated control/API adequacy.** The fields h_s=partial_s and h_t=partial_t+s partial_q are both lifts of commuting base fields but have bracket partial_q. The lifted rectangle has q displacement ab. The mixed epsilon_1 epsilon_2 term survives in C[epsilon_1,epsilon_2]/(epsilon_1^2,epsilon_2^2); replacing it by the square-zero maximal-ideal quotient would miss curvature.

**Source scope.** I23 Theorem 11.6 proves bracket compatibility by the two-parameter extension. The target owns that construction and does not infer flatness from the abstract splitting alone.

### 3.3

**Assessment.** Pass with its explicit construction-dependent proof burden. The form defined by vertical projection is not automatically closed for every splitting.

**Evaluated control/API adequacy.** For H=p^2/2 and omega=dq wedge dp, Omega=omega+dH wedge dt has matrix [[0,1,0],[-1,0,p],[0,-p,0]] and kernel (p,0,1). Adding t^2 to H does not change Omega. Conversely h=partial_t+q partial_q gives Omega=dq wedge dp+q dp wedge dt and dOmega=dq wedge dp wedge dt, despite flatness on a one-dimensional base.

**Source scope.** I23 Definition 11.4/Remark 11.5 give the constructed form and kernel; Corollary 11.8 uses the actual trace-complex/local-product construction for closedness. BOA01 Theorems 7.1/7.3 concern generic unramified extended moduli. STT02 Section 6 explicitly cautions that arbitrary global algebraic coordinates need not be Hamiltonian. The roadmap does not use these narrower claims as a universal exact-coordinate assertion.

### 3.4

**Assessment.** Pass. Choice changes and genuine parameter transformations retain the total differential and cocycle law.

**Evaluated control/API adequacy.** For g1=diag(exp(t),exp(-t)) and g2=I+t E12, the composed time-gauge term is [[1,2t+1],[0,-1]] dt. Fresh matrix checks at t=0,1,-1/2 confirm it. Removing g^-1 dg changes the horizontal equation; a fiberwise coordinate agreement is insufficient.

**Source scope.** The formal-gauge supplier and uniqueness of I23 horizontal extensions support naturality after an explicit adapter. The roadmap does not declare arbitrary parameter changes to be identity morphisms.

### 4.1

**Assessment.** Pass as an explicitly owned analytic classification package. Overlap uniqueness must be read relative to the stated sectors and normalization data.

**Evaluated control/API adequacy.** exp(1/z) has ordinary monodromy 1 but nontrivial irregular asymptotics; exp(-2pi i N)=I-2pi i N for N=E12 has eigenvalues 1 but is not I; the pair plus/minus 1/w is exchanged by the quadratic deck map. On a small decay sector, I+c exp(-2/z) E21 has the same asymptotic identity, so naive asymptotic normalization alone is not a uniqueness theorem.

**Source scope.** I23 Theorem 9.7/Corollary 9.11 have a local generic/ramified scope and Remark 9.8 explicitly records the small-sector ambiguity. BY15 exponential local systems and twisted Stokes structures handle ramification. Formal good-lattice/p-adic or regular-singular RH suppliers do not supply complex irregular sectorial existence and gluing.

### 4.2

**Assessment.** Pass. The decorated Betti groupoid, coarse closed-spectral quotient and fixed exponent lift remain different objects.

**Evaluated control/API adequacy.** Exponent lifts 0 and 1 exponentiate to the same monodromy; allowing all integer lifts in one forgotten fiber creates a discrete noncompact ambiguity. The unipotent matrix I+a E12 and I have trace 2 and determinant 1 but different decorated/Jordan information. The quadratic deck exchange squares to I.

**Source scope.** BOA14 untwisted transport is used only for its actual setting. BY15 Theorem 1 and the ramified exponential local system supply the twisted scope to be constructed. Ordinary characters alone cannot retain resonant flags, while nonclosed Jordan-class conditions cannot be silently substituted for the affine closed-spectral quotient.

### 4.3

**Assessment.** Pass as an owned whole-source semiconjugacy theorem. Only the appropriate generic locus has an inverse RH map.

**Evaluated control/API adequacy.** For Bl_0(C^2) times B mapping to C^2 times B, distinct exceptional directions [1:0] and [0:1] have the same image. With constant exceptional directions along time, semiconjugacy remains meaningful and preserves distinct initial points. Any implementation using a global inverse fails this control.

**Source scope.** IS12 Theorem 5.1 gives an analytic isomorphism under its generic, nonresonant and irreducible assumptions. Its Remark 6.3 expects the resonant/reducible extension. IIS06 Theorems 4.10/4.12 prove the PVI full proper map and generic isomorphism/minimal resolution. The roadmap now marks extension to all admitted irregular strata as owned, not as established by IS12.

### 4.4

**Assessment.** Pass as a precisely staged new proof obligation. No cited generic source proves the full asserted all-strata family theorem.

**Evaluated control/API adequacy.** The map (C* minus {1}) times C^2 -> C* times C^2, (z,q,p) mapsto (z^2,q,p), has finite proper fibers over every time. The sequence z=1-1/n maps into compact time interval [1/4,1] and tends to an excluded source point, so the whole map is not proper. This rejects fiberwise properness and compactness assumptions on the wrong projection.

**Source scope.** IIS06 full-family PVI properness is valid. IS12 Remark 6.3 is expected properness in a broader setting, not a proved family theorem. The target owns compact lattice bounds, projective incidence, stable replacement and gluing; proving these stages remains substantive future work.

### 5.1

**Assessment.** Pass. Horizontal sections are genuine sections with a tangent equation; local existence is not global affine-chart continuation.

**Evaluated control/API adequacy.** On B times F a horizontal section is t mapsto (t,x0); a constant map to the total space fails pi composed with s=id. The solution of q-prime=q^2, q(0)=1 is 1/(1-t), with values 2 at 1/2 and 4 at 3/4, and escapes the affine chart at 1.

**Source scope.** IIS06 Definitions 2.1-2.2 and I23 local product (11.5) motivate the holomorphic germ package. The named holomorphic-horizontal-lifts gap owns joint complex analytic dependence; native real smooth flow results alone are not mislabelled as that theorem.

### 5.2

**Assessment.** C05 closed as a missing-headline defect: five genuine native definitions and one substantive theorem are now present. Its elaboration remains unpassed; CORE-R2-02 records the unanchored model argument risk.

**Evaluated control/API adequacy.** Proper compact preimage, genuine derivative horizontality, right inverse, every existing partial lift, and uniqueness only on the interval are encoded. Blowdown with compact exceptional fiber needs no inverse and retains distinct initial points. The deleted-cover and y-prime=y^2 examples reject fiberwise properness or mere compatible projection. The C1 base path abs(s-1/2)^(3/2) rejects direct use of a C1 autonomous extension theorem after autonomization.

**Source scope.** IIS06 Lemma 2.12 supports proper quasiconjugacy. Native IsProperMap.isCompact_preimage works for the possibly singular/arbitrary-topological target. Mathlib Picard-Lindelof supplies continuous-time, phase-Lipschitz local existence and uniqueness; Tau Ceti maximal-extension theorem is for a C1 autonomous tangent field. The frozen README already offers a valid finite-cover route but should state that adapter explicitly.

### 5.3

**Assessment.** C07 closed. The new concrete transport test rejects an always-identity implementation.

**Evaluated control/API adequacy.** For H=qp/(2t) over C*, q=q0 exp(u/2), p=p0 exp(-u/2) on t=exp(u). Fresh evaluation sends initial (1,2) to (-1,-2) after one positive loop and (1,2) after two. The Jacobian is -I, with symplectic multiplier 1; the fixed locus is exactly the origin. Descent therefore fails for (1,2) and holds for (0,0).

**Source scope.** Universal-cover suppliers provide topological lifting and deck/groupoid infrastructure; they do not prove nonlinear continuation. That input is the prior geometric transfer theorem. Flatness, local uniqueness and complete transport are needed for homotopy invariance.

### 5.4

**Assessment.** Pass. Observer admissibility includes domain/resolution plus an actual lifted section, and excludes identically infinite values.

**Evaluated control/API adequacy.** The rational observer [x:y] is undefined at (0,0). Exceptional directions [1:2] and [0:1] evaluate to 1/2 and 0, so resolution alone does not select a lift. For q=1/t the reciprocal is t, giving a simple pole; a constant infinity section has reciprocal identically zero and is excluded from ordinary meromorphic-function claims.

**Source scope.** The native meromorphic layer is for maps out of one-complex-dimensional charted spaces. Composition with an arbitrary phase-space observer still needs the stated analytic chart/observer adapter. IIS06 Section 10 constructs admissible scalar charts only on the relevant phase loci and then uses chart changes.

### 5.5

**Assessment.** Pass in the classical one-complex-dimensional time setting, with a genuinely admissible observer. A higher-dimensional base does not acquire an isolated-pole theorem by citation.

**Evaluated control/API adequacy.** The reciprocal of (t-a)^(-3) vanishes to order 3; q-prime=q^2 crosses the affine pole using u=1/q=1-t. exp(1/(t-a)) has projective limits infinity and 0 along opposite real approaches, excluding a holomorphic projective extension at an interior time. sqrt(t) on C* has a single-valued universal-cover lift with sign-changing deck action, not descent to C*.

**Source scope.** IIS06 Theorem 10.12 derives analytic Painleve property from geometric continuation and algebraic phase/coordinate comparison in PVI. Native meromorphic-order/composition results require the actual meromorphic/holomorphic hypotheses and a curve domain. The roadmap preserves that scope and does not infer real pole-freeness or crossing fixed singularities.

## Retest boundary

The required next review should freeze the repaired README, regenerated plan and complete Suggested.lean together. It should check the new §11.2 declaration against the actual README quantifiers, the explicit EB arguments, and the continuous-time ODE adapter; then run the official elaboration gate when the runtime works. This core report does not approve an unseen later edit. It also does not duplicate the geometry/tau reviewers' separate §11.1 classical-endpoint-domain finding, whose source and target lie outside the assigned core layers.

No optional broad research remains necessary for the core findings recorded here. The remaining work is the concrete repair/retest and the explicitly unpassed acceptance gates.
