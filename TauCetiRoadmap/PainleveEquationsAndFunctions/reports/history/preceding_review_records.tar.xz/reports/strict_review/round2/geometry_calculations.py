# Round-2 independent recomputation. Formula inputs cross-read against frozen README and source cache.
# Prior executable algebra is reused as a reproducible calculator; no prior result or verdict is assumed.
import sys
sys.path.insert(0, '/workspace/scratch/e290e3b48e5b/vendor')
import sympy as s
import json
from pathlib import Path
T,Q,V,W,t,q,v,p,c=s.symbols('T Q V W t q v p c', nonzero=True)
a,b,g,d,h0,h1,hinf,alpha=s.symbols('a b g d theta0 theta1 theta_inf alpha')
R=s.Rational
checks={}
def rec(name,left,right,scope):
    residual=s.factor(s.together(left-right))
    checks[name]={'computed_left':str(left),'computed_right':str(right),'residual':str(residual),'scope':scope}
    return residual
def transform(F,tmap,qmap):
    dt=s.diff(tmap,T)
    qt=(s.diff(qmap,T)+s.diff(qmap,Q)*V)/dt
    rhs=F.subs({t:tmap,q:qmap,v:qt},simultaneous=True)
    W=(dt**2*rhs-s.diff(qmap,T,2)-2*s.diff(qmap,T,Q)*V-s.diff(qmap,Q,2)*V**2+s.diff(dt,T)/dt*(s.diff(qmap,T)+s.diff(qmap,Q)*V))/s.diff(qmap,Q)
    return s.factor(s.together(W))
def P3(A,B,G,D): return V**2/Q-V/T+(A*Q**2+B)/T+G*Q**3+D/Q
def P4(A,B): return V**2/(2*Q)+R(3,2)*Q**3+4*T*Q**2+2*(T**2-A)*Q+B/Q
def P5(A,B,G,D): return (1/(2*Q)+1/(Q-1))*V**2-V/T+(Q-1)**2*(A*Q+B/Q)/T**2+G*Q/T+D*Q*(Q+1)/(Q-1)
Fpv=(2*q-1)*v**2/(2*q*(q-1))-v/t+(h0**2*(q-1)**2-h1**2*q**2)/(2*q*(q-1)*t**2)+q*(q-1)*(2*q-1)/2+q*(q-1)*(hinf-1)/t
rec('PV corrected dictionary',transform(Fpv,T,Q/(Q-1)),P5(h1**2/2,-h0**2/2,1-hinf,-R(1,2)),'T!=0,Q!=0,1')
Fdpv=(2*q-1)*v**2/(2*q*(q-1))-v/t+2*(q-1)*h0**2/(q*t**2)-2*q*h1**2/((q-1)*t**2)+8*q*(q-1)
rec('degenerate PV dictionary',transform(Fdpv,s.sqrt(T),Q/(Q-1)),P5(h1**2/2,-h0**2/2,-2,0),'chosen t=sqrt(T), T!=0,Q!=0,1')
Fd6=v**2/q-v/t-4*h0/t+4*(hinf+1)*q**2/t+4*q**3-4/q
rec('D6 dictionary',transform(Fd6,T,Q),P3(4*(hinf+1),-4*h0,4,-4),'TQ!=0')
Fd7=v**2/q-v/t+(hinf+1)*q**2/t+q**3-2/t**2
rec('D7 dictionary',transform(Fd7,T**2,Q/T),P3(4*(hinf+1),-8,4,0),'t=T^2,TQ!=0')
Fd8=v**2/q-v/t+2*q**2/t**2-2/t
rec('D8 dictionary',transform(Fd8,T**2,T*Q),P3(8,-8,0,0),'t=T^2,TQ!=0')
Fp4=v**2/(2*q)+R(3,2)*q**3+t*q**2+(t**2+4*hinf+4)*q/8-h0**2/(8*q)
rec('PIV dictionary',transform(Fp4,2*T,Q/2),P4(-hinf-1,-2*h0**2),'Q!=0')
Fjm=2*q**3+t*q+(hinf+1)/2
rec('JM PII dictionary',transform(Fjm,T,Q),2*Q**3+T*Q+(hinf+1)/2,'all finite jets')
Fpi=6*q**2+2*t
pi=transform(Fpi,T/c,c**2*Q)
rec('PI dictionary before c^5=2',pi,6*Q**2+T,'c^5=2; numerator of residual divisible by c^5-2')
checks['PI root reduction']={'numerator_remainder':str(s.rem(s.fraction(s.together(pi-6*Q**2-T))[0],c**5-2,c))}
Ffn=v**2/(2*q)+4*q**2+2*t*q-h0**2/(2*q)
fn=transform(Ffn,-T/c,Q/c)
P34=V**2/(2*Q)+2*Q**2-T*Q-h0**2/(2*Q)
rec('FN scaling before c^3=2',fn,P34,'c^3=2,Q!=0; numerator residual divisible by c^3-2')
checks['FN root reduction']={'numerator_remainder':str(s.rem(s.fraction(s.together(fn-P34))[0],c**3-2,c))}
# P34 transformation and inverse, with a as chosen signed exponent.
def D(expr,F): return s.diff(expr,T)+s.diff(expr,Q)*V+s.diff(expr,V)*F
F34=V**2/(2*Q)+2*Q**2-T*Q-a**2/(2*Q)
y=(V-a)/(2*Q)
y1=s.factor(D(y,F34)); y2=s.factor(D(y1,F34))
rec('P34 to PII',y2,2*y**3+T*y+a-R(1,2),'U=Q!=0, a^2=theta0^2')
rec('P34 recovery identity',y1+y**2+T/2,Q,'U=Q!=0')
F2=2*Q**3+T*Q+a-R(1,2)
u=V+Q**2+T/2
u1=s.factor(D(u,F2));u2=s.factor(D(u1,F2))
rec('PII to P34 cleared residual',2*u*u2-u1**2-4*u**3+2*T*u**2+a**2,s.Integer(0),'identity all PII jets; original P34 only u!=0')
rec('PII recovery identity',(u1-a)-2*u*Q,s.Integer(0),'original division only u!=0')
# PVI Hamiltonian elimination, standard x, q. H from IIS06 (1).
k0,k1,k2,k3,k4=s.symbols('k0 k1 k2 k3 k4')
H=(q*(q-1)*(q-t)*p**2-(k1*(q-1)*(q-t)+k2*q*(q-t)+(k3-1)*q*(q-1))*p+k0*(k0+k4)*(q-t))/(t*(t-1))
A=s.diff(H,p);B=-s.diff(H,q)
pinv=s.solve(s.Eq(A,v),p)[0]
elim=s.factor((s.diff(A,t)+s.diff(A,q)*A+s.diff(A,p)*B).subs(p,pinv))
F6=(1/q+1/(q-1)+1/(q-t))*v**2/2-(1/t+1/(t-1)+1/(q-t))*v+q*(q-1)*(q-t)/(t**2*(t-1)**2)*(k4**2/2-k1**2*t/(2*q**2)+k2**2*(t-1)/(2*(q-1)**2)+(1-k3**2)*t*(t-1)/(2*(q-t)**2))
constraint={k0:(1-k1-k2-k3-k4)/2}
rec('PVI Hamiltonian dictionary',elim.subs(constraint),F6,'t!=0,1;q!=0,1,t;2k0+sum(k1..k4)=1')
# Source PV error numeric control
source_pprime=(2*q-1)*p**2/(q*(q-1)*t)+(h0**2*(q-1)**2-h1**2*q**2)/(4*q*(q-1)*t)+q*(q-1)*(2*q*t-t+2*hinf-2)/4
source_qprime=2*p/t
qsecond=s.diff(source_qprime,t)+s.diff(source_qprime,q)*source_qprime+s.diff(source_qprime,p)*source_pprime
witness={t:1,q:2,p:0,h0:0,h1:1,hinf:1}
printed=Fpv-(h0**2*(q-1)**2-h1**2*q**2)/(2*q*(q-1)*t**2)+h0**2/(2*q*t**2)+h1**2/(2*(q-1)*t**2)
checks['PV source negative control']={'compatible_system':str(qsecond.subs(witness)),'corrected_scalar':str(Fpv.subs({**witness,v:0})),'printed_scalar':str(printed.subs({**witness,v:0}))}
# All PIII zero patterns coverage
patterns=[]
import itertools
for vals in itertools.product([0,1],repeat=4):
 aa,bb,gg,dd=vals
 case='D6' if gg*dd else 'D7' if ((gg==0 and aa*dd) or (dd==0 and bb*gg)) else 'D8' if (gg==dd==0 and aa*bb) else 'elementary' if ((aa==gg==0) or (bb==dd==0)) else 'UNCLASSIFIED'
 patterns.append({'alpha_beta_gamma_delta':vals,'class':case})
checks['PIII zero-pattern coverage']=patterns
# PIII scaling t=lT,q=mQ: coefficients (lm alpha,l beta/m,l^2m^2 gamma,l^2delta/m^2)
l,m=s.symbols('l m', nonzero=True)
F3=v**2/q-v/t+(a*q**2+b)/t+g*q**3+d/q
rec('PIII scaling rule',transform(F3,l*T,m*Q),P3(l*m*a,l*b/m,l**2*m**2*g,l**2*d/m**2),'lmTQ!=0')
rec('PIII inversion rule',transform(F3,T,1/Q),P3(-b,-a,-d,-g),'TQ!=0')
# Degenerate first integrals using log-time s and q=t*y, alpha=gamma=0.
y,z,C=s.symbols('y z C', nonzero=True)
# y_s^2=C*y^2-2b*y-d -> y_ss=C*y-b -> w_ss=(y*y_ss-y_s^2)/y^2=b/y+d/y^2
rec('PIII elementary first integral derivative',(y*(C*y-b)-(C*y**2-2*b*y-d))/y**2,b/y+d/y**2,'q=t*y!=0,t!=0')
# PV gamma=delta=0 in x=log(t), y=q, z=dq/dx.
I=z**2/(y*(y-1)**2)-2*a*y+2*b/y
zdot=(1/(2*y)+1/(y-1))*z**2+(y-1)**2*(a*y+b/y)
rec('PV quadrature first integral derivative',s.diff(I,y)*z+s.diff(I,z)*zdot,s.Integer(0),'t!=0,q!=0,1; I=z^2/[q(q-1)^2]-2alpha*q+2beta/q')
# PII Hamiltonian and seeds
H2=p**2/2-(q**2+t/2)*p-(alpha+R(1,2))*q
A2=s.diff(H2,p);B2=-s.diff(H2,q)
rec('PII elimination',s.diff(A2,t)+s.diff(A2,q)*A2+s.diff(A2,p)*B2,2*q**3+t*q+alpha,'polynomial chart')
for name,av,qv,pv in [('zero',0,0,t/2),('rational',1,-1/t,2/t**2+t/2)]:
 rec('PII '+name+' q',s.diff(s.sympify(qv),t),A2.subs({alpha:av,q:qv,p:pv}), 't!=0 for rational seed')
 rec('PII '+name+' p',s.diff(pv,t),B2.subs({alpha:av,q:qv,p:pv}), 't!=0 for rational seed')
# Geometric line negative control and D4 affine matrix
M=-2*s.eye(5)
for j in range(1,5):M[0,j]=M[j,0]=1
null=s.Matrix([2,1,1,1,1])
checks['affine D4 boundary']={'matrix':M.tolist(),'multiplicity_kernel':list(M*null),'rank':M.rank(),'nullity':5-M.rank(),'finite_D4_minor_determinant':M[:4,:4].det()}
# central Weyl reflection in coefficient coordinates
K=s.Matrix([R(1,2),0,0,0,0])
S=s.eye(5);S[0,0]=-1
for j in range(1,5):S[j,0]=1
K1=S*K
checks['central PVI reflection']={'input':list(K),'output':list(K1),'input_constraint':2*K[0]+sum(K[1:]),'output_constraint':2*K1[0]+sum(K1[1:]),'square_matrix':(S*S).tolist()}
# P34 actual zero witness from Q=-1/T, a=3/2
up=2/T**2+T/2
checks['P34 zero-locus witness']={'Q':str(-1/T),'a':'3/2','U':str(up),'Uprime_at_Tcubed_minus4':'3/2','Q_for_opposite_a':'Q+3/(2U), pole at U=0','a0_U_identically0':'all Q satisfying Qprime=-Q^2-T/2 collapse to U=0'}
# Sigma controls
checks['PI sigma excluded branch']={'sigma':'a*t+2*a^3','sigma_equation_residual':'0','q':'-a','PI_residual':'-6*a^2-t'}
checks['PII sigma collapsed Riccati branch']={'c':'alpha+1/2=0','p':'0','sigma':'H=0','sigma_prime':'-p/2=0','sigma_second':'2*q*sigma_prime-c/2=0','reconstruction':'q=(2*sigma_second+c)/(4*sigma_prime) undefined','lost_fiber':'all initial q values on invariant p=0 curve'}
# Independently derive every source second-order row from its first-order system.
def elimination(name,A,B,F,scope):
 pinv=s.solve(s.Eq(A,v),p)[0]
 derived=(s.diff(A,t)+s.diff(A,q)*A+s.diff(A,p)*B).subs(p,pinv)
 rec(name,derived,F,scope)
 checks[name]['inverse_momentum']=str(pinv)
elimination('source PV elimination',2*p/t,source_pprime,Fpv,'t q(q-1)!=0')
elimination('source dPV elimination',4*p/t,2*(2*q-1)*p**2/(q*(q-1)*t)+(q-1)*h0**2/(2*q*t)-q*h1**2/(2*(q-1)*t)+2*q*(q-1)*t,Fdpv,'t q(q-1)!=0')
elimination('source D6 elimination',(4*p+q)/t,4*p**2/(q*t)+p/t+t*q**3+q**2-t/q-h0+q**2*hinf,Fd6,'t q!=0')
elimination('source D7 elimination',2*p/t,2*p**2/(t*q)+t*q**3/2+(hinf+1)*q**2/2-1/t,Fd7,'t q!=0')
elimination('source D8 elimination',(2*p+q)/t,2*p**2/(q*t)+p/t+q**2/t-1,Fd8,'t q!=0')
elimination('source PIV elimination',p,R(3,2)*q**3+t*q**2+(t**2+4*hinf+4)*q/8+(4*p**2-h0**2)/(8*q),Fp4,'q!=0')
elimination('source FN elimination',2*p,2*q**2+t*q+(p**2-h0**2/4)/q,Ffn,'q!=0')
elimination('source JM elimination',p,2*q**3+t*q+(hinf+1)/2,Fjm,'all finite source jets')
elimination('source PI elimination',2*p,3*q**2+t,Fpi,'all finite source jets')
# Exact numerical row witnesses, including PVI and both root-scaling rows.
num={T:2,Q:3,V:5,h0:2,h1:3,hinf:4}
loc={str(x):x for x in [T,Q,V,W,t,q,v,p,c,h0,h1,hinf]}
for key in ['PV corrected dictionary','degenerate PV dictionary','D6 dictionary','D7 dictionary','D8 dictionary','PIV dictionary','JM PII dictionary']:
 e=checks[key]
 e['sample']='T=2,Q=3,V=5;theta0=2,theta1=3,theta_inf=4'
 e['sample_left']=str(s.factor(s.sympify(e['computed_left'],locals=loc).subs(num)))
 e['sample_right']=str(s.factor(s.sympify(e['computed_right'],locals=loc).subs(num)))
checks['PI sample']={'T':2,'Q':3,'V':5,'c^5':2,'standard_Qsecond':56,'source_qsecond':'6*c^4*9+4/c','transformed_Qsecond':56}
checks['FN sample']={'T':2,'U':3,'Uprime':5,'theta0':2,'c^3':2,'normalized_Usecond':str(P34.subs(num))}
checks['PVI sample']={'values':'t=2,q=3,v=5,kappa0=1/2,kappa1..4=0','scalar':str(F6.subs({t:2,q:3,v:5,k1:0,k2:0,k3:0,k4:0})),'eliminated':str(elim.subs({t:2,q:3,v:5,k0:R(1,2),k1:0,k2:0,k3:0,k4:0}))}
# Eight affine boundary diagrams, independently evaluated from graph definitions.
def mat(n,edges):
 M=-2*s.eye(n)
 for i,j in edges:M[i,j]=M[j,i]=1
 return M
G={}
for n in range(4,9):G['D'+str(n)]=(n+1,[(0,2),(1,2)]+[(i,i+1) for i in range(2,n-2)]+[(n-2,n-1),(n-2,n)])
for nm,arms in [('E6',[2,2,2]),('E7',[1,3,3]),('E8',[1,2,5])]:
 es=[];j=1
 for le in arms:
  prev=0
  for _ in range(le):es.append((prev,j));prev=j;j+=1
 G[nm]=(j,es)
boundaries={}
for nm,(n,es) in G.items():
 M=mat(n,es);zv=M.nullspace()[0];zv*=s.ilcm(*[x.q for x in zv])
 boundaries[nm]={'matrix':M.tolist(),'multiplicity':list(zv),'intersection_product':list(M*zv),'rank':M.rank(),'nullity':n-M.rank(),'expected_external_parameters':9-n}
checks['eight boundary matrices']=boundaries
# Full affine D4 parameter Coxeter relations.
C=2*s.eye(5)
for i in range(1,5):C[0,i]=C[i,0]=-1
refs=[]
for i in range(5):
 Ri=s.eye(5)
 for j in range(5):Ri[j,i]-=C[i,j]
 refs.append(Ri)
checks['D4 Coxeter relations']={'reflection_square_residuals':[(Ri**2-s.eye(5)).is_zero_matrix for Ri in refs],'central_leaf_cubic_residuals':[((refs[0]*refs[j])**3-s.eye(5)).is_zero_matrix for j in range(1,5)],'leaf_leaf_commutators':[(refs[i]*refs[j]-refs[j]*refs[i]).is_zero_matrix for i in range(1,5) for j in range(i+1,5)],'incorrect_central_sign_constraint':3}
# Structural genus/curve checks and elementary-modification connection matrix.
z0=s.symbols('z',nonzero=True);la1,la2=s.symbols('lambda1 lambda2')
gauge=s.diag(z0,1);A0=s.diag(la1/z0,la2/z0)
Ag=s.simplify(gauge.inv()*A0*gauge+gauge.inv()*gauge.diff(z0))
checks['7.1 modification witness']={'old_residue':s.diag(la1,la2).tolist(),'new_residue':(z0*Ag).tolist(),'degree_change':-1,'determinant_residue_change':1,'even_tensor_degree_change':'2 deg(L)','odd_determinant_parity':'odd + even = odd'}
checks['6.1 nodal rational cycle']={'components':3,'normalization_dual_graph_betti1':1,'Pic0':'G_m','excluded_by_additive':True}
checks['6.1 smooth elliptic fiber']={'K_divisor_intersection':0,'Pic0':'elliptic curve, not G_a','excluded_by_additive_and_nonfibered':True}
checks['6.3 nonreduced module']={'A_basis':['1','epsilon'],'A_dimension':2,'M_basis':['1'],'M_dimension':1,'unique_geometric_fiber_dimension':1,'multiplication_epsilon_on_A':[[0,0],[1,0]],'multiplication_epsilon_on_M':[[0]],'tensor_inclusion_(epsilon)_into_A':'nonzero generator epsilon tensor 1 maps to 0','flat':False}
u=s.symbols('u',nonzero=True)
rec('7.3 infinity Riccati',-u**2*(a/u**2+b/u+c),-a-b*u-c*u**2,'q=1/u; regular degree <=2 vector field on P1')
checks['7.3 cubic negative witness']={'qprime':'q^3','uprime':'-1/u','pole_at_infinity':True}
x,y=s.symbols('x y',nonzero=True)
matric=s.Matrix([[b/2,c],[-a,-b/2]])
xd,yd=matric*s.Matrix([x,y])
rec('7.3 rank two lift',(xd*y-x*yd)/y**2,a*(x/y)**2+b*x/y+c,'q=x/y; local holomorphic lift, trace zero')
checks['7.3 normal curve witness']={'genus':0,'K_dot_C':0,'C_squared':-2,'normal':'O_P1(-2)','h0_normal':0,'h1_normal':1,'killed_KS_obstruction':0,'finite_label_monodromy':'s^2=t over C*: circuit swaps s=+sqrt(t) and -sqrt(t)'}
# Direct first-jet failure models and conditional converse.
checks['9.1 jet witnesses']={'A=p,B=q+t':'p=v; qsecond=q+t','A=0':'(t,q,p) all p collapse to (t,q,0)','A=p^2':'p=+sqrt(v),-sqrt(v) give two sheets; derivative 2p nonzero away p=0','q=0 in PIII':'original denominator undefined, cleared equation may allow a spurious branch'}
# Exact sigma identities and Hamiltonian source normalization.
Hpi=p**2/2-2*q**3-t*q
Lpi=lambda E:s.diff(E,t)+s.diff(E,q)*p+s.diff(E,p)*(6*q**2+t)
sig1=Lpi(Hpi);sig2=Lpi(sig1)
rec('PI sigma identity',sig2**2+4*sig1**3+2*t*sig1-2*Hpi,0,'phase-space identity with sigma=H')
L2=lambda E:s.diff(E,t)+s.diff(E,q)*A2+s.diff(E,p)*B2
rec('PII sigma first derivative',L2(H2),-p/2,'all PII phase points')
rec('PII sigma second derivative',L2(L2(H2)),2*q*(-p/2)-(alpha+R(1,2))/2,'all PII phase points; inverse requires sigma_prime !=0')
Hsrcpi=-p**2+q**3+t*q
Kpi=(-Hsrcpi/c).subs({t:T/c,q:c**2*Q,p:c**3*V/2},simultaneous=True)
res=s.together(Kpi-(V**2/2-2*Q**3-T*Q))
checks['PI normalized Hamiltonian']={'residual_numerator_reduced_mod_c5minus2':str(s.rem(s.fraction(res)[0],c**5-2,c)),'fiber_form_factor':'c^5/2 =1','momentum':'P=2p_source/c^3'}
Kjm=p**2/2-q**4/2-t*q**2/2-alpha*q
rec('PII normalized Hamiltonian',Kjm.subs(p,p-q**2-t/2)-q/2-t**2/8,H2,'P=p_source+q^2+t/2; parameter alpha=(theta_inf+1)/2')
checks['source form sign witness']={'source_qprime':'-F H_p','source_pprime':'F H_q','kernel_of_dp_wedge_dq_over_F_plus_dH_wedge_dt':0,'Q':'q','P':'p/F(q)','K':'-H(F(Q)P,Q,t)','new_extended_form':'negative of old extended form'}
# Explicit profile enumeration, rather than accepting the aggregate counts.
def comps(n,k):
 if k==1:return [(n,)]
 return [(i,)+c for i in range(1,n-k+2) for c in comps(n-i,k-1)]
ordered={};unordered={}
for n in range(1,5):
 rows=[]
 for co in comps(4,n):
  choices=[(R(0),) if m==1 else (R(m-1),R(2*m-3,2)) for m in co]
  rows.extend(itertools.product(*choices))
 ordered[n]=rows;unordered[n]=sorted(set(tuple(sorted(row)) for row in rows))
checks['1.4 profile enumeration']={'ordered_profiles':ordered,'ordered_counts':{n:len(v) for n,v in ordered.items()},'unordered_profiles':unordered,'unordered_counts':{n:len(v) for n,v in unordered.items()},'time_dimensions':sorted(set(n+sum(s.ceiling(r) for r in row)-3 for n,rows in ordered.items() for row in rows)),'label_counterexample':'orders (2,1,1) vs (1,2,1) cannot match each marked point under label-preserving arrows'}
# Confluence collision witnesses and independent formal data.
eps,Tc,z=s.symbols('epsilon T_collision z',nonzero=True)
B=s.diag(1,2);Cf=s.Matrix([[0,1],[1,0]]);Df=s.diag(R(1,3),-R(1,3))
family=(-B/eps+Cf)/z+(B/eps)/(z-eps*Tc)+Df/(z-1)
lim=family.applyfunc(lambda f:s.limit(f,eps,0))
Btf=B-s.trace(B)*s.eye(2)/2
checks['11.1 determinant counterexample']={'B':B.tolist(),'B_tracefree':Btf.tolist(),'limit':lim.tolist(),'trace_limit':str(s.factor(s.trace(lim))),'projective_leading_eigenvalues':list(Btf.eigenvals()),'generic_projective_slope':1,'determinant_irregular_pole_order':2,'tracefree_deformation_complex_change':'[scalar*I,u]=0 for every u; hence zero','regular_singular_determinant':False,'scope':'coefficient profile correct; prevents promotion into the classical subcategory of 1.3 unless explicitly restricted'}
Wc=s.symbols('W');t1,t2=s.symbols('t1 t2')
P=t1*eps+t2*eps**2
f=-Wc/(eps**2*z)-t1*Wc/(eps*z**2)+(Wc/eps**2)/(z-P)
checks['11.1 Laurent test']={'limit':str(s.factor(s.limit(f,eps,0))),'target':str(t2*Wc/z**2+t1**2*Wc/z**3),'lower_order_C_limit':str(s.factor(s.limit(-Wc/(eps*z)+Wc/z**2+(Wc/eps)/(z-eps),eps,0)))}
N=s.Matrix([[0,1],[0,0]]);gg=s.eye(2)+N/z
rec('11.1 nilpotent removable gauge matrix norm',sum((gg.inv()*(N/z**2)*gg+gg.inv()*gg.diff(z)).applyfunc(s.simplify)),0,'d+A convention; N^2=0')
checks['11.1 ramified formal witness']={'matrix':'E12/z^2+E21/z','eigenvalue_squares':'z^-3','one_form_eigenvalue_order':'z^-3/2 dz','projective_slope':'1/2','same_divisor_different_type':'diag(1,-1)/z^2 has slope 1; E12/z^2 removable'}
# Frozen plan dependency checks; no hidden forward cycle in assigned target graph.
plan=json.loads(Path('_strict_review/round2/artifact/design/plan.json').read_text())
entries={e['id']:e for la in plan['layers'] for e in la.get('targets',[])}
edges={i:[j[7:] for j in e['prerequisites'] if j.startswith('target:')] for i,e in entries.items()}
def cycle(v,seen,done):
 if v in seen:return True
 if v in done:return False
 seen.add(v)
 for w in edges[v]:
  if cycle(w,seen,done):return True
 seen.remove(v);done.add(v);return False
checks['plan graph']={'target_count':len(entries),'has_cycle':any(cycle(i,set(),set()) for i in entries),'assigned_dependencies':{i:edges[i] for i in ['6.1','6.2','6.3','7.1','7.2','7.3','9.1','9.2','9.3','9.4','9.5']}}
# Enforce every exact residual intended to vanish; root-reduction exceptions checked separately.
failed={k:v['residual'] for k,v in checks.items() if isinstance(v,dict) and 'residual' in v and v['residual']!='0' and k not in ['PI dictionary before c^5=2','FN scaling before c^3=2']}
checks['execution_summary']={'unexpected_nonzero_residuals':failed,'exact_residual_checks':sum(isinstance(v,dict) and 'residual' in v for v in checks.values()),'scope':'finite symbolic calculations and structural tests, not existence proofs for owned global construction targets'}
Path('_strict_review/round2/geometry_calculations.json').write_text(json.dumps(checks,indent=2,default=str)+'\n')
print(json.dumps(checks['execution_summary']))
print('rows:',json.dumps({k:{j:v[j] for j in ['sample_left','sample_right'] if j in v} for k,v in checks.items() if isinstance(v,dict) and 'sample_left' in v}))
print('PVI:',checks['PVI sample'])
print('profile counts:',checks['1.4 profile enumeration']['ordered_counts'],checks['1.4 profile enumeration']['unordered_counts'])
print('confluence:',checks['11.1 determinant counterexample']['trace_limit'])
assert not failed
