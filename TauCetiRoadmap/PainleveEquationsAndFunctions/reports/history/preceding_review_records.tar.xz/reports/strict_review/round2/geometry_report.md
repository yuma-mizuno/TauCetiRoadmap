# Independent strict geometry review — round 2

**Verdict: needs_changes.** One established P2 finding concerns the §11.1 classical-domain interface. There are **no actionable substantive findings in the eleven assigned targets** §§6.1–6.3, 7.1–7.3 and 9.1–9.5. The repaired §1.4 classification is consistent with the geometry and presentation tables.

This verdict applies only to the immutable round-2 artifact:

- README SHA-256: `bded7b400716d663957a13a462349b688a525cda5889b8f3bac55b8bc8f31316`.
- Plan SHA-256: `b68bbe5fa893c3f777ce681d8297c125141e4d7bc4cb3d0acd49bcbf79827738`.

The entire assigned README passages, their API/Checks/Needs, their full plan entries and the relevant owned-proof obligations were read. The earlier round's verdict was not treated as evidence. Its executable algebra was reused as a calculator, rerun against source-verified formulas and extended with independent first-order elimination, all ten row values, all eight boundary matrices, the repaired classification and the collision determinant counterexample. No frozen or canonical input was edited.

## R2-GEOM-11.1-CLASSICAL-ENDPOINT (P2): explicitly restrict the primitive collision endpoints

**Location:** README §11.1, the first two paragraphs and the global coefficient check; plan target 11.1, its statement/hypotheses/API and `geometricConfluenceFamilyCheck5`.

**Target claim:** the predicate beginning “The admitted classical domain is the locus where the endpoint formal conditions satisfy…” defines the domain for primitive classical moduli/surface comparisons. Its listed conditions retain formal leading/factorization relations, stability, nonempty fibers and ranks, but do not explicitly require primitive endpoints to be objects of §1.3. In particular “a determinant line connection and its comparison” does not impose a regular-singular determinant.

**Counterexample.** In the displayed global coefficient model take

\[
 B=\operatorname{diag}(1,2),\qquad T\ne0.
\]

Then

\[
\frac{-B/\varepsilon+C}{z}
+\frac{B/\varepsilon}{z-\varepsilon T}
+\frac{D}{z-1}
\longrightarrow
\frac{TB}{z^2}+\frac Cz+\frac D{z-1},
\]

whose trace is

\[
\frac{3T}{z^2}+\frac{\operatorname{tr}C}{z}
+\frac{\operatorname{tr}D}{z-1}.
\]

The determinant is irregular. The trace-free leading coefficient is `diag(−1/2,1/2)`, so the claimed **projective** slope 1 and underlying profile `(0,0,1)` remain correct. This is not an error in that coefficient calculation.

The rank predicate does not repair the omission. Starting with a valid trace-free stable collision family, add the scalar coefficient

\[
\frac32\left(-\frac1{\varepsilon z}
+\frac1{\varepsilon(z-\varepsilon T)}\right)I.
\]

This leaves the projective formal data and invariant subbundles unchanged, and commutators with the scalar term vanish on the trace-free deformation complex. Its ranks and projective stability behavior are therefore unchanged. The limiting determinant acquires the forbidden `3T/z²` term. The scalar term can have a prescribed rank-one strong time lift; that makes it a separate rank-one extension, as §1.3 says, not a primitive classical endpoint.

**Exact repair.** Keep the general collision groupoid if useful, but define its admitted primitive classical domain by requiring both primitive endpoints to satisfy **all of §1.3**, including genus zero, regular-singular determinant with its stipulated residues/transport, and the reduced versal time problem. Record lower-complexity boundary endpoints separately with their actual conditions. Require `tr(B)=0` when promoting the displayed global coefficient test to this primitive classical family. Arbitrary-trace models may remain as explicitly general/projective examples or rank-one extensions.

**Regression test.** `B=diag(1,−1)` passes the determinant leading-term condition. `B=diag(1,2)` is rejected by the primitive-domain predicate despite its correct projective slope and unchanged projective rank calculations. Genus zero should be explicit as part of endpoint membership; this review does not claim a genus-one two-dimensional counterexample.

**Scope qualification.** The last paragraph of §11.1 already withholds a global moduli arrow until exponent, stability and time comparisons are proved. The finding is the missing classical endpoint predicate, not a claim that the coefficient example has already been declared a global moduli arrow. Root subsequently reported an author repair to the canonical files with these restrictions and the negative test. Those edits are outside this frozen snapshot and require their own readback review; they do not erase the finding on the hashes above.

## Verified sound: complete target coverage

The companion ledger has one substantive row for each of the eleven targets and two separate cross-interface rows. Each gives its concrete witness, source evidence, and the exact limit of what the test establishes.

### Geometric carriers and boundary comparison: §§6.1–6.3

The additive/nonfibered/SNC conditions exclude both a smooth elliptic boundary and a multiplicative cycle. They retain affine D8 without adding the older affine-plane-chart hypothesis. STT02 Definitions 1.1/1.3 and Proposition 1.2 support these distinctions. The relative Picard use is conditional on the actual universal-functions and smoothness/base-change hypotheses, including formal smoothness over nonreduced bases; it is not a misuse of a smooth-curve Jacobian theorem.

All eight negative affine boundary matrices were computed. Their ranks are `4,5,6,7,8,6,7,8` for `D4,D5,D6,D7,D8,E6,E7,E8`, respectively, with nullity 1 in every case. The positive primitive multiplicities lie in their kernels. For example D8 has multiplicities `(1,1,2,2,2,2,2,1,1)`; E8 has `(6,3,4,2,5,4,3,2,1)` in the recorded graph order. This verifies the finite intersection calculations, not the existence of every family or a full moduli comparison.

The distinction between identical boundary labels and different input data survives: `(0,0,1/2)` and `(1,1)` are both D6 presentations but have three and two marked poles. AHT17 explicitly warns that its scalar dPV/PIII equivalence does not automatically give an isomonodromy-family comparison. Full coverage of exceptional curves and bundle-jumping charts remains the explicit owned target in §6.2; no circular scalar Painlevé-property premise was found.

The new §6.3 dual-number check is correct. For `A=C[epsilon]/epsilon²`, the module `M=A/(epsilon)` has its sole geometric fiber of dimension 1 but has C-length 1, whereas a free rank-one A-module has length 2. Tensoring `(epsilon)→A` with M kills its nonzero generator, directly showing nonflatness. TER02 proves the one-dimensional first boundary layer and its injection; its equality with all local cohomology has different scope and is not imported. A line also does not select a generator: replacing a normalized time vector by twice itself doubles its Kodaira–Spencer image but preserves the line.

### Transformations and invariant curves: §§7.1–7.3

A logarithmic kernel modification in the frame `diag(z,1)` changes residue `(lambda1,lambda2)` to `(lambda1+1,lambda2)` and bundle degree by −1. This matches the `sum residues=−degree` determinant convention. Tensoring rank two by a line changes determinant by its square and degree by an even integer; it cannot manufacture a square root of an odd-degree determinant. Retaining the flag is essential to the inverse modification.

The new central-reflection sign check is correct. The tuple `(1/2,0,0,0,0)` maps to `(−1/2,1/2,1/2,1/2,1/2)`, retaining affine constraint 1; omitting the central sign gives 3. All five affine D4 reflection squares, four central-leaf cubic relations and six leaf-leaf commutators were computed. IIS06 Remark 7.5(2) confirms that the central reflection is not supplied merely by the listed local gauge moves. The roadmap now owns the extra marked-pair construction and its horizontal extension rather than citing PVI as a theorem for all profiles.

The required fresh §7.3 source sample was checked against ST04 §2.4, Proposition 2.1, Remark 2.4 and Definition 2.3, including the curve-existence hypothesis and the possibility of permutation under continuation. The current target starts from an existing interior rational −2 curve and retains the local/finite/étale nature of its continuation. Adjunction gives `K·C=0`, `C²=−2`, `N_C=O_P1(−2)`, `h0(N_C)=0`, `h1(N_C)=1`. The time Kodaira–Spencer image kills the stated obstruction.

The projective-coordinate test is exact: under `u=1/q`, a quadratic Riccati field becomes `u'=−a−bu−cu²`; a cubic becomes `−1/u` and fails regularity. The matrix `[[b/2,c],[−a,−b/2]]` induces exactly `q'=a q²+bq+c` on `q=x/y`. The double cover `s²=t` supplies an explicit curve-label monodromy model, and the rank-two lift remains local unless its obstruction is resolved. ST04's absence of nodal curves for E8/D7/D8 and its distinction between rational solutions and Riccati curves were retained. No universal “Riccati iff reducible” claim is made.

### Scalar reconstruction and normalization: §§9.1–9.5

The first-jet comparison has the necessary global-image hypothesis. `A=p` reconstructs uniquely; `A=0` collapses all momenta; `A=p²` is locally invertible away from zero but has two global momentum branches. The converse chain rule uses the actual inverse chart and does not infer new original-equation solutions by clearing denominators.

All ten scalar presentation normalizations passed. Nine source first-order systems were differentiated and momentum-eliminated; PVI was independently eliminated from its constrained Hamiltonian. At `T=2,Q=3,V=5,theta0=2,theta1=3,theta_inf=4`, the two sides give:

| Row | Common value of the normalized second derivative |
|---|---:|
| PV | 39/2 |
| dPV | 24 |
| PIII D6 | 397/2 |
| PIII D7 | 1199/6 |
| PIII D8 | 227/6 |
| PIV | 168 |
| JM PII | 125/2 |
| FN P34 | 31/2 |
| PI, with `c⁵=2` | 56 |

PVI at `t=2,q=3,v=5,kappa0=1/2,kappa1=…=kappa4=0` gives `143/12` on both sides. The PI and FN residual numerators reduce to zero modulo `c⁵−2` and `c³−2`, respectively. The P34/PII forward and inverse identities also vanish with the signed exponent retained. Their exceptional `U=0` branch is not silently divided away.

The fresh §9.2 source sample includes VDPS09 Table 1 and all the compatible systems used here, IIS06's PVI chart, and AHT17's dPV time-square and observer substitution. The results validate the dictionary formulas; they do not substitute for the owned moduli-chart and surface construction.

The PIII coefficient cases exhaust all 16 zero/nonzero patterns: 4 D6, 4 D7, 1 D8 and 7 elementary. Scaling and inversion identities have zero residuals. The stated elementary PIII first integral and the PV first integral on `t q(q−1)≠0` differentiate to zero. A general power `C exp(mu log t)` retains its cover/monodromy and nonzero domain.

The source Hamiltonian sign adapter and corrected PV exponent term are correct. The PV negative control gives 2 from the compatible system and 7/2 from the printed scalar source. PI sigma has a real spurious affine branch: `sigma=at+2a³` satisfies the sigma relation while `q=−a` has residual `−6a²−t`. The new PII sigma-collapse test is also correct: at `c=alpha+1/2=0,p=0`, all distinct Riccati trajectories have `sigma=0`. That is loss of phase information, not a spurious phase trajectory. A sigma-only inverse is unavailable there.

Both PII seeds satisfy both Hamilton equations, with derivatives `(0,1/2)` and `(1/t²,−4/t³+1/2)`. The PI source normalization preserves the fiber form with factor `c⁵/2=1`. The time-dependent PII momentum change needs the displayed `−q/2` Hamiltonian correction; recomputation gives exactly the §9.5 Hamiltonian and its §9.2 parameter dictionary.

## Cross-interface checks and supplier/dependency scope

The repaired §1.4 enumeration gives ordered counts `(2,8,6,1)` and underlying counts `(2,5,2,1)` by number of poles. All enumerated time-dimension expressions equal 1. The label-assignment groupoid now transports data between relabeled presentations without adding label-permuting arrows to the original ordered problem. The tuples `(1,0,0)` and `(0,1,0)` remain distinct under original label-preserving arrows.

Beyond the P2 scope issue, §11.1 retains enough coefficient/formal data to distinguish semisimple slope 1, the ramified `E12/z²+E21/z` model of slope 1/2, and removable `E12/z²`. The corrected Laurent example gives `t2 W/z²+t1² W/z³`; lowering the polar scaling of C gives `2W/z²` and no triple pole. Equality of horizontal distributions is a proof target, not built into its regular-domain predicate. This is a noncircular construction target, subject to the missing primitive endpoint restriction.

The 44-node explicit target dependency graph is acyclic. Supplier checks included the actual Picard conditions in ComplexComparisonPartII C3.2d.2/C3.2f.1–2, coherent base-change distinctions in JacobianChallenge Layer C, and Noetherian Hilbert/Quot and intersection/adjunction scopes in SchemeAndStackFoundations. These do not supply the full Painlevé construction automatically; the current plan owns the specific adapters.

The nearby pinned declaration `TauCeti.NumericalType.exists_chain_or_fork_or_exceptional` was read. It concerns connected proper subsets of a numerical type and does not already prove the marked anticanonical-pair classification or the connection-moduli complement theorem. No native headline was replaced by that smaller result. The Suggested.lean module docstring honestly lists the missing geometry/scalar application carriers. Its separate proper-semiconjugacy theorem is outside this assigned mathematical review.

## Reproducible artifacts and limitations

- `geometry_calculations.py` and `geometry_calculations.json`: 68 named records and 39 exact residual checks; no unexpected nonzero residual. The two root-normalization residuals are handled by explicit polynomial remainders.
- `geometry_ledger.json`: all eleven assigned targets, complete witness/scope entries, and the two cross-interface checks.
- `geometry_findings.json`: the one P2 finding, exact repair and regression test.

These are algebraic calculations, source checks and structural adversarial tests. They are not formal proofs of the owned global moduli, compactification, Weyl or analytic extension targets. The known pinned Lean runtime failure prevents an elaboration gate; no successful build is claimed. Distinct-model-family separation was not obtained. This is **not official Worker acceptance**, and no Worker job, push, PR, issue or publication was initiated.

## Source issues

- **Error** in VDPS09 at §4.1 extended two-form, and PI (44), (46), (47): the printed minus-sign form disagrees with its Hamilton equations; the compatible form is `dp∧dq/F+dH∧dt`; affects the displayed Hamiltonian comparison. The roadmap already repairs it.
- **Error** in VDPS09 at §4.3 equation (3): its printed exponent terms disagree with system (2) and Hamiltonian (5); replace them by `[theta0²(q−1)²−theta1²q²]/[2q(q−1)t²]`; affects the displayed scalar equation. The roadmap already repairs it.

The source-only DIL21 coordinate-map defect noted in round 1 is not printed in this roadmap and is not a current finding.
