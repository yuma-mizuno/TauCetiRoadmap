import Mathlib

/-!
# Native finite-chart compact-path convergence: target signature candidate

Source-level candidate for the generic theorem owned by README §11.2.
This file has NOT been elaborated: the pinned Lean runtime cannot start.
The standalone namespace repeats the already-kept finite subdivision only so
that this candidate can be inspected independently. Integration should reuse it.
-/

noncomputable section
open Set Filter
open scoped Manifold Topology NNReal

namespace TauCetiRoadmap.PainleveNativeConfluenceCandidate

/-- A finite subdivision of a real interval. -/
structure Breaks (a b : ℝ) where
  n : ℕ
  cut : Fin (n + 1) → ℝ
  ordered : StrictMono cut
  first : cut 0 = a
  last : cut (Fin.last n) = b

/-- The closed time segment indexed by a subdivision interval. -/
def Breaks.segment {a b : ℝ} (p : Breaks a b) (i : Fin p.n) : Set ℝ :=
  Icc (p.cut i.castSucc) (p.cut i.succ)

/-- Actual nonautonomous tangent equations on the pieces, with a globally
continuous trajectory. Different one-sided velocities at a cut are permitted. -/
def PiecewiseODEOn {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [TopologicalSpace M] [ChartedSpace E M]
    {a b : ℝ} (p : Breaks a b)
    (V : Fin p.n → ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (x : ℝ → M) : Prop :=
  ContinuousOn x (Icc a b) ∧ ∀ i, ∀ t ∈ p.segment i,
    HasMFDerivWithinAt 𝓘(ℝ) 𝓘(ℝ, E) x (p.segment i) t
      ((1 : ℝ →L[ℝ] ℝ).smulRight (V i t (x t)))

/-- The true expression of a time-dependent tangent field in a fixed native
extended chart. The formula agrees with the pinned native curve/chart API. -/
def ChartField {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [TopologicalSpace M] [ChartedSpace E M] [IsManifold 𝓘(ℝ, E) 1 M]
    (c : M) (V : ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (t : ℝ) (z : E) : E :=
  let y := (extChartAt 𝓘(ℝ, E) c).symm z
  tangentCoordChange 𝓘(ℝ, E) y c y (V t y)

/-- A fixed closed tube around the reference graph in one native chart.
Its radius is independent of the approximation index. -/
def ChartTube {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [TopologicalSpace M] [ChartedSpace E M]
    (J : Set ℝ) (c : M) (x₀ : ℝ → M) (r : ℝ) : Set (ℝ × E) :=
  {q | q.1 ∈ J ∧
    q.2 ∈ Metric.closedBall ((extChartAt 𝓘(ℝ, E) c) (x₀ q.1)) r}

/-- A family of nonautonomous tangent fields converging uniformly on finitely
many positive-radius chart tubes has nearby solutions on the entire compact
path interval. Those solutions remain inside the tubes, satisfy the quantitative
segment estimates, and converge uniformly as manifold-valued curves.

The reference trajectory is the only assumed solution. No approximating solution,
its continued existence, or its tube membership is an input. -/
theorem finite_chart_compact_path_no_exit_convergence
    {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [MetricSpace M] [ChartedSpace E M] [IsManifold 𝓘(ℝ, E) 1 M]
    {a b : ℝ} (hab : a < b) (p : Breaks a b)
    (V : ℕ → Fin p.n → ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (V₀ : Fin p.n → ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (x₀ : ℝ → M) (hx₀ : PiecewiseODEOn (E := E) p V₀ x₀)
    (c : Fin p.n → M) (r : ℝ) (hr : 0 < r) (L : ℝ≥0)
    (hchart : ∀ i, ∀ t ∈ p.segment i,
      x₀ t ∈ (extChartAt 𝓘(ℝ, E) (c i)).source)
    (hmargin : ∀ i, ∀ t ∈ p.segment i,
      Metric.closedBall ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) r ⊆
        (extChartAt 𝓘(ℝ, E) (c i)).target)
    (hcont₀ : ∀ i,
      ContinuousOn (fun q : ℝ × E ↦ ChartField (E := E) (c i) (V₀ i) q.1 q.2)
        (ChartTube (E := E) (p.segment i) (c i) x₀ r))
    (hregular : ∀ n i,
      ContinuousOn (fun q : ℝ × E ↦ ChartField (E := E) (c i) (V n i) q.1 q.2)
        (ChartTube (E := E) (p.segment i) (c i) x₀ r) ∧
      ∀ t ∈ p.segment i,
        LipschitzOnWith L (ChartField (E := E) (c i) (V n i) t)
          (Metric.closedBall ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) r))
    (δ : ℕ → ℝ≥0) (hδ : Tendsto (fun n ↦ (δ n : ℝ)) atTop (𝓝 0))
    (herror : ∀ n i, ∀ q ∈ ChartTube (E := E) (p.segment i) (c i) x₀ r,
      dist (ChartField (E := E) (c i) (V n i) q.1 q.2)
        (ChartField (E := E) (c i) (V₀ i) q.1 q.2) ≤ (δ n : ℝ))
    (initial : ℕ → M) (hinitial : Tendsto initial atTop (𝓝 (x₀ a))) :
    ∃ x : ℕ → ℝ → M,
      (∀ᶠ n in atTop,
        x n a = initial n ∧ PiecewiseODEOn (E := E) p (V n) (x n) ∧
        ∀ i, ∀ t ∈ p.segment i,
          x n t ∈ (extChartAt 𝓘(ℝ, E) (c i)).source ∧
          dist ((extChartAt 𝓘(ℝ, E) (c i)) (x n t))
            ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) < r ∧
          dist ((extChartAt 𝓘(ℝ, E) (c i)) (x n t))
            ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) ≤
            (dist ((extChartAt 𝓘(ℝ, E) (c i)) (x n (p.cut i.castSucc)))
              ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ (p.cut i.castSucc))) +
              (t - p.cut i.castSucc) * (δ n : ℝ)) *
                Real.exp ((L : ℝ) * (t - p.cut i.castSucc))) ∧
      TendstoUniformlyOn x x₀ atTop (Icc a b) := by
  sorry

end TauCetiRoadmap.PainleveNativeConfluenceCandidate
