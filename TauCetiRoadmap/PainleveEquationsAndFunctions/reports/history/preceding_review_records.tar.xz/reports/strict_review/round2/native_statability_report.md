# Round 2: narrow native statability audit

## Verdict and scope

**Confirmed actionable P2: the generic §11.2 finite-chart compact-path existence, no-exit and convergence headline is statable on the pinned native carriers and is absent from frozen R2 `Suggested.lean`.** This corroborates **TAU-R2-01**; it is one finding, not a second issue. The docstring's omission of controlled confluence of the *intrinsic families* is justified for that application, but does not explain omission of the separate general theorem explicitly owned by §11.2.

A concrete full-scope signature is in `native_11_2_candidate.lean`. Its final source readback found no correction needed. In particular, `tangentCoordChange I y c y` and the `HasMFDerivWithinAt I I' f s t f'` argument order agree with the native sources. The parent has integrated the candidate into canonical files while preserving frozen R2; that integration does not retroactively change this frozen finding.

This was a source-level review only. **No Lean elaboration, `#check @...` gate, one-tactic probe, or Worker run was performed or passed.** The pinned Lean runtime cannot start, as stipulated by the task. Source-level plausibility is not compiler acceptance.

Inputs were the frozen R2 `README.md`, `Suggested.lean`, and `design/plan.json`, together with the actual `lean-form.md` and `review-lessons.md` rubric. Native source pins inspected were Mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2` and Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`. No canonical or frozen file was edited by this audit.

## Why this is a real missing headline

Frozen `README.md:1018` labels §11.2 “A common compact-path solution-convergence theorem.” The corresponding plan item `11.2` explicitly requires a compact piecewise C¹ time path, finitely many common phase charts, a fixed positive margin, uniform field convergence, a common phase Lipschitz bound, converging initial points, eventual existence and uniform convergence. It owns the first-exit/local-extension/finite-subdivision argument before application to §11.1.

Frozen `Suggested.lean:63` instead lists “Controlled confluence of the intrinsic families” among applications with missing carriers. Those carriers are indeed needed to construct and identify the particular degeneration families. They are not needed to state the general analytic theorem after the prescribed time and phase identifications have been supplied.

The actual rubric requires every statable deep headline, allows a few genuine definitions on native carriers to make it statable, permits `sorry` in theorem proofs, and calls omitted statable headlines a P2 (`lean-form.md`, headline/definition/not-statable rules; `review-lessons.md:12`). The generic theorem is expressly a roadmap target, so it is not an unsolicited scalar substitute for intrinsic geometric confluence.

## Candidate: exact scope and assumptions

The standalone candidate repeats `Breaks` only for independent inspection. Integration reuses the existing subdivision and adds exactly four genuine definitions: `Breaks.segment`, `PiecewiseODEOn`, `ChartField`, and `ChartTube`. The parent reports the resulting canonical total as nine definitions and two admitted theorem signatures. All four new definitions have real bodies; none contains admitted data or an uninterpreted condition standing for a missing interface.

The theorem uses a finite-dimensional real normed model `E`, a native C¹ manifold `M` modelled on `E`, and any compatible `MetricSpace M`. It does not choose a global affine phase chart. It has the following explicit inputs:

1. A nondegenerate compact parameter interval `a < b` and a finite strictly increasing subdivision with those endpoints.
2. Actual nonautonomous tangent fields `V n i t y : TangentSpace 𝓘(ℝ, E) y` and a reference field `V₀ i`. A different time-dependent field is allowed on each segment, accommodating different one-sided velocities of a piecewise C¹ prescribed time path.
3. A continuous reference trajectory `x₀ : ℝ → M` satisfying the actual native manifold differential equation within every closed segment. No approximating trajectory is assumed.
4. One native extended chart `extChartAt ... (c i)` on each segment, containing that segment of the reference trajectory.
5. A fixed radius `r > 0` for which every closed phase ball of radius `r` around the reference chart trajectory is contained in the chart target. This is an explicit positive tube margin, independent of `n`.
6. Joint time/phase continuity of both reference and approximating chart vector fields on these closed tubes; a common `L : ℝ≥0` bounds the phase Lipschitz constants of all approximating fields there. C¹ time dependence is not assumed.
7. Nonnegative field errors `δ n` tending to zero, bounding the chart-field difference on every complete tube, uniformly in time and phase.
8. Initial points `initial n` converging in `M` to `x₀ a`.

The conclusion produces a family of actual manifold-valued trajectories `x n`. Eventually in `n`, each starts at `initial n`, solves the tangent equation on every segment of the *entire* interval `[a,b]`, remains in each prescribed chart source, and has chart distance from the reference strictly less than `r`. The quantitative estimate, for each segment beginning at `tᵢ`, is

\[
 d_i(x_n(t),x_0(t))\leq
 \bigl(d_i(x_n(t_i),x_0(t_i))+(t-t_i)\delta_n\bigr)
 \exp(L(t-t_i)).
\]

Here `d_i` means the norm distance of the two values in that segment's fixed native chart. The conclusion also asserts native `TendstoUniformlyOn x x₀ atTop (Icc a b)` as `M`-valued curves. Segment initial errors are actual values of the same globally continuous trajectory, so the conclusion includes the necessary endpoint gluing. It does not assert a single global coordinate estimate across unrelated charts.

These assumptions match the general theorem after pullback along the prescribed time path and the common identifications. The reference path and the pulled-back vector fields are the data relevant to its ODE argument. The construction of the intrinsic comparison families remains the separate §11.1 application. Complex holomorphic applications pass to the underlying real manifolds, as in §5.2.

The signature is sequential. This matches the parent-requested concrete `δ_n → 0` formulation. An application to a parameter limit must supply the sequential criterion, for example on a first-countable parameter cover, or separately state a filter version. It is not by itself a theorem uniform over compact families of time paths; frozen §11.2 explicitly reserves the extra common-cover/path-family hypotheses for that stronger result.

## Native argument and carrier readback

Paths below are relative to the workspace. All checks in this table are source inspection, not elaborated `#check` output.

| Native declaration | Inspected source | Relevance and result |
| --- | --- | --- |
| `HasMFDerivWithinAt` | `_validation/mathlib/Mathlib/Geometry/Manifold/MFDeriv/Defs.lean:298` | Explicit order is `I I' f s x f'`; derivative type is `TangentSpace I x →L[ℝ] TangentSpace I' (f x)`. The candidate uses precisely this order. |
| `IsMIntegralCurveOn` | `_validation/mathlib/Mathlib/Geometry/Manifold/IntegralCurve/Basic.lean:65` | Native curve equation uses `((1 : ℝ →L[ℝ] ℝ).smulRight (v (γ t)))`. The candidate uses this same derivative shape for time/segment-dependent fields. |
| `tangentCoordChange`, `tangentCoordChange_def` | `_validation/mathlib/Mathlib/Geometry/Manifold/VectorBundle/Tangent.lean:143`, `:146` | First point selects the source chart, second the destination chart, third is the evaluation point. It differentiates `extChartAt I destination ∘ (extChartAt I source).symm`. Thus `I y c y (V t y)` is the correct field in fixed chart `c`. |
| `IsMIntegralCurveAt.of_extChartAt_symm` | `_validation/tauceti/TauCeti/Geometry/Manifold/IntegralCurve/Basic.lean:142` | Uses exactly the candidate formula with `y := (extChartAt I c).symm z`: `tangentCoordChange I y c y (v y)`. This also confirms the native tangent/model argument convention. |
| `IsMIntegralCurveOn.hasDerivAt_extChartAt` | `_validation/tauceti/TauCeti/Geometry/Manifold/IntegralCurve/Basic.lean:189` | Converse derivative is `tangentCoordChange I (γ t) c (γ t) (v (γ t))`, independently confirming direction. Its autonomous statement does not itself supply the new time-dependent theorem. |
| `TangentSpace` | `_validation/mathlib/Mathlib/Geometry/Manifold/IsManifold/Basic.lean:1033` | Native tangent fibers use the model `E` with the library's tangent-space infrastructure. The candidate follows existing native formulas rather than inventing a tangent carrier or cast. |
| `extChartAt` | `_validation/mathlib/Mathlib/Geometry/Manifold/IsManifold/ExtChartAt.lean:437` | Returns a `PartialEquiv M E`; the candidate uses its actual `source`, `target`, and `symm`. It does not mistake it for an arbitrary globally defined diffeomorphism. |
| `TendstoUniformlyOn` | `_validation/mathlib/Mathlib/Topology/UniformSpace/UniformConvergence.lean:90` | Argument order is family, limit function, filter, domain. Candidate order is correct; `MetricSpace M` supplies the uniform structure. |
| `Manifold.metrizableSpace` | `_validation/mathlib/Mathlib/Geometry/Manifold/Metrizable.lean:27` | Native metrization is available for finite-dimensional Hausdorff sigma-compact manifolds. The intended second-countable finite-dimensional manifolds admit the compatible metric used in the conclusion. |

`PiecewiseODEOn` and each `ChartField`/`ChartTube` use explicitly supplied `(E := E)` where inference otherwise depends on the manifold model. This follows the same precaution as the parent's `(EB := EB)` repair in §5.2. `ChartField` has the `IsManifold 𝓘(ℝ, E) 1 M` instance required by native tangent coordinate changes; the other elementary predicates do not require additional smoothness to state their types.

The compatible metric imposes no particular Riemannian or affine geometry. Finite-dimensionality makes the closed graph tubes compact. Inverse charts are uniformly continuous on the relevant compact subsets, so finite-chart convergence yields uniform convergence for any chosen compatible metric. Different compatible metrics need not induce the same global uniformity, but that distinction causes no obstruction on these finitely many compact chart tubes.

## Why the native results do not already supply this headline

`dist_le_of_approx_trajectories_ODE_of_mem` in `_validation/mathlib/Mathlib/Analysis/ODE/Gronwall.lean:162` explicitly assumes both trajectories exist, are differentiable, and remain in the time-dependent sets. Its docstring says it “assumes that the solutions never leave this set.” Restating that estimate with renamed variables would be padding. The candidate instead must construct the compared solutions and prove no exit, extension through the entire compact interval, and finite-chart gluing.

The native local-existence entry point is `IsPicardLindelof.exists_eq_forall_mem_Icc_hasDerivWithinAt` (`Mathlib/Analysis/ODE/ExistUnique.lean:56`). Its structure (`PicardLindelof.lean:79`) requires concrete phase Lipschitz, time continuity, norm, and interval-radius bounds. Those can be obtained on sufficiently small rectangles inside the positive-radius moving tubes, using finite-dimensional compactness and continuity, then combined with the native Grönwall estimate and local uniqueness (`ODE_solution_unique_of_mem_Icc_right`, `ExistUnique.lean:193`). They are not the whole claimed conclusion in a single library invocation.

Tau Ceti's inspected autonomous C¹ manifold extension results (`TauCeti/Geometry/Manifold/IntegralCurve/Extension.lean`) and smooth-parameter local Picard results (`TauCeti/Analysis/ODE/SmoothParameter.lean`) have different hypotheses and do not directly state this compact-tube perturbation theorem. This is a declaration-level distinction, not a claim to have performed an exhaustive automated search or successful one-tactic probe.

There is therefore no identified missing carrier blocking the finite-chart signature. The outstanding time-dependent chart adapter, local rectangle bounds, first-exit argument, compact extension and finite induction are proof obligations of the headline, as allowed by a theorem `sorry`; they do not require a new synthetic moduli or atlas API merely to state it.

## Brief §5.2 semantic review

No additional semantic defect was found in the narrow reading of `proper_semiconjugacy_complete_horizontal_lifts`. It uses an actual native tangent splitting, a C¹ section of the native Hom bundle, the actual projection derivative and an actual proper map. `TargetTransport` gives concrete target trajectories. Its compatibility assumption applies to existing partial horizontal lifts on every prefix, not to an already-assumed global horizontal lift. Properness traps each such lift in the compact preimage of the target trajectory image. The conclusion's uniqueness is correctly limited to the path interval.

Two already-known issues must remain distinguished from this new omission:

- **Model inference:** `ChartedSpace H M` declares `H` as an ordinary parameter (`Mathlib/Geometry/Manifold/ChartedSpace.lean:141`), not an out-parameter. The parent's explicit `PiecewiseC1On (EB := EB)` and `TargetTransport (EB := EB)` repair addresses the identified inference ambiguity. Frozen R2 lacks that repair. This is not a second newly discovered issue here.
- **Regularity of the proof route:** C¹ `γ` need only have continuous `γ′`. Consequently the nonautonomous phase equation along `γ` need not have a C¹ autonomous time extension. The canonical C⁰-time, phase-Lipschitz adapter using the actual native Picard–Lindelöf and uniqueness floor addresses that proof-dependency error at the source/roadmap level. It is necessary to prove the retained general signature; it is not evidence that the proof or Lean type already checks.

The arbitrary topological target `R` does not create a new compactness defect: native `IsProperMap` includes continuity and its `isCompact_preimage` theorem (`Mathlib/Topology/Maps/Proper/Basic.lean:210`) applies without adding a Hausdorff assumption on the target.

## Remaining gate and minimal integration decision

**Recommendation:** keep the full finite-chart candidate, reuse `Breaks`, and distinguish the generic §11.2 signature from the still-unstatable intrinsic confluence application in the module docstring. Match the helper names, sequential scope and theorem name in README/plan. The parent reports this canonical integration completed; frozen R2 remains the reviewed artifact.

Semantic/source confidence is high for the retained scope and the explicitly checked native argument orders. Remaining elaboration risks are ordinary instance/coercion elaboration and retained binder verification, not identified semantic counterexamples. They cannot be closed from source inspection alone. Once the pinned runtime is available, the actual remaining acceptance work is to elaborate the integrated file, inspect `#check @...` for every retained declaration, and perform the rubric's one-tactic probes without substituting any weaker theorem. **The compiler gate remains unpassed.**
