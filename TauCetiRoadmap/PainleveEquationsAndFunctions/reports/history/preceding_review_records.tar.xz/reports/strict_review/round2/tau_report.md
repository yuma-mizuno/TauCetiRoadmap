# Strict Round 2 review: tau functions, analytic selection and confluence

## Verdict and coverage

**Verdict: `needs_changes`.** The six assigned Round 1 findings have been individually retested and closed in their original form. Two P2 issues remain in the frozen Round 2 package: a missing generic ODE headline in `Suggested.lean`, and an incomplete explicit classical endpoint condition in the new collision-domain definition. The latter is an interface defect in the repaired domain, not a failure of the corrected coefficient-limit formula.

This review covers all twelve targets in Layers 8, 10 and 11, **32 API bullets and 41 Checks**, including their relevant supplier and downstream interfaces. Every API and Check has an individual disposition in `tau_ledger.json`. Each target has actual values, formulas or structural countermodels; the review does not count a generic statement of “checked” as evidence. The fresh source sample was §8.4, §10.2, §10.3 and §11.2; all flagged or changed source claims were additionally inspected.

The reviewed package is `_strict_review/round2/artifact`:

- README SHA256: `bded7b400716d663957a13a462349b688a525cda5889b8f3bac55b8bc8f31316`.
- Plan SHA256: `b68bbe5fa893c3f777ce681d8297c125141e4d7bc4cb3d0acd49bcbf79827738`.
- Mathlib checkout: `f6090c7095e1e56b3464c1daba5f24631f1290d2`.
- TauCeti checkout: `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`.

Both artifact hashes were checked, and `git rev-parse HEAD` independently returned both library pins. This is a manual read-only application of the actual Worker review/red-team, adversarial, defect-class, review-lessons, gap/order, dependency, source and Lean-file rubrics. No Worker entrypoint or external write was used. No reviewed artifact was edited. **This is not Worker acceptance:** no successful Lean elaboration or distinct-model-family check was obtained.

## New actionable findings

### TAU-R2-01 — P2: the generic §11.2 headline is statable but absent

**Location:** README §11.2, lines 1018–1034; `Suggested.lean` lines 61–70; plan target 11.2.

Section 11.2 explicitly owns a general compact-path solution-convergence theorem before its intrinsic application. It concludes existence throughout the compact path, using a first-exit/local-extension proof, as well as convergence. `Suggested.lean` omits confluence by citing missing degeneration families, identifications and horizontal-section topology. Those missing objects obstruct the intrinsic application; they do not obstruct the common ODE theorem separately promised in §11.2.

A concrete statement of the common theorem uses a finite-dimensional real normed space E, a compact interval [a,b], a continuous reference solution x₀, a common open neighborhood of its graph, and a fixed positive tube radius r. Continuous fields Fₙ share a phase Lipschitz constant L on that neighborhood, satisfy a uniform tube defect δₙ → 0 relative to F₀, and start from aₙ → x₀(a). The conclusion is eventual existence of solutions xₙ on all of [a,b], remaining in the tube, with

\[
\|x_n(t)-x_0(t)\|
\leq \bigl(\|a_n-x_0(a)\|+(t-a)\delta_n\bigr)e^{L(t-a)},
\]

and hence uniform convergence. The path version pulls back the field by the prescribed piecewise C¹ path and uses its finite-chart overlaps. The native ingredients are normed spaces, derivatives, continuous functions, compact intervals, metric balls, inequalities and uniform convergence. Genuine tube/trajectory definitions suffice; there is no need to invent an opaque Painlevé carrier or a free predicate standing for the conclusion.

This is not a padding request for the existing Grönwall estimate. Mathlib's `dist_le_of_approx_trajectories_ODE_of_mem` explicitly assumes the two trajectories and their membership in the common sets. It does not supply their existence until the final time or prevent the first exit. TauCeti's `UniformTime` gives local existence near a point; `GlobalSolution` treats autonomous globally Lipschitz fields; `SmoothParameter` has a C^(n+1) parameterized field and a special vanishing base-field hypothesis. Those results are useful ingredients, not the §11.2 statement under its stated uniform-field assumptions. See Mathlib `Analysis/ODE/Gronwall.lean`, lines 162–191, and TauCeti `Analysis/ODE/SmoothParameter.lean`, lines 139–157.

**Repair:** add the full generic §11.2 headline signature with concrete native hypotheses and the existence/no-exit conclusion. Retain the intrinsic application as unstatable pending its actual carriers. Do not replace the generic theorem by a Grönwall-only estimate that presupposes its essential conclusion.

**Retest:** the signature must admit Fₙ = 1/n on [0,2], initial value 0, whose error is exactly 2/n; it must exclude zero fields with initial values (−1)ⁿ. Required typeclass and regularity hypotheses must survive elaboration. Compilation remains a separate unpassed gate; the mathematical statability witness is not a claim that a proposed Lean snippet has compiled.

### TAU-R2-02 — P2: the new admitted classical domain needs the §1.3 endpoint restriction

**Location:** README §11.1, lines 989–991 and its final global Check; plan target 11.1.

The collision-data carrier is deliberately broader than the classical subcategory: it permits a smooth projective curve family and a determinant line connection. Its newly advertised admitted-classical-domain predicate lists formal leading/factorization conditions, stable chambers, nonempty stable fibers, flat coherent terms, and constant relation/Kodaira–Spencer ranks. It does not explicitly intersect that broader carrier with the primitive endpoint conditions of §1.3, especially genus zero and a regular-singular determinant with the prescribed transport.

The determinant omission cannot be supplied by the listed rank tests. In the displayed global family, take B = diag(1,2). The limit is

\[
A_0(z)=\frac{TB}{z^2}+\frac C z+\frac D{z-1},
\qquad
\operatorname{tr}A_0(z)=\frac{3T}{z^2}
+\frac{\operatorname{tr}C}{z}
+\frac{\operatorname{tr}D}{z-1}.
\]

The determinant is irregular at zero for T ≠ 0. The trace-free leading part is diag(−1/2,1/2), so the projective slope is still one. More generally, adding a scalar multiple of the identity leaves the adjoint connection, trace-free deformation complex, relation/KS ranks and invariant subbundles unchanged. It therefore preserves the listed projective/rank/stability tests while changing determinant irregularity.

The last sentence of the Check correctly withholds a moduli arrow until further comparisons are verified. Thus this is **not** a finding that the coefficient formula is false or that an unverified coefficient model was already declared an arrow. The defect is the incomplete explicit definition of the claimed classical sublocus. The standing term “classical” points to the intended restriction, but the newly stated predicate should enforce it, rather than rely on its name to recover a condition its tests cannot detect.

**Repair:** require both generic and limiting primitive endpoints to belong to §1.3, including genus zero, regular-singular determinant and compatible fixed-residue/time transport. Keep separately marked lower-complexity boundary endpoints distinct. Use tr(B) = 0 in the classical positive global test, and retain diag(1,2) as an excluded negative test.

**Retest:** B = diag(1,−1) has zero double-pole trace and passes this determinant condition before the remaining comparisons; diag(1,2) has double-pole trace 3T and fails it, despite the same projective slope and unchanged adjoint ranks. A positive-genus primitive endpoint must also fail the explicit §1.3 requirement.

## Closure of the six Round 1 findings

| Old finding | Disposition | Independent retest |
|---|---|---|
| TAU-R1-01, RHP endpoint ghost | Closed | With R = I + C(h), h = R₊ − R₋, identity jump gives h = 0 and R = I. The ghost has squared boundary L² norm e⁻²/2 but a nonzero correction, so it fails the stated Cauchy class. |
| TAU-R1-02, GMR Laurent indices | Closed | The owned corrected lemma uses C of pole order at most r+1, cancels all negative parts of CPʲ, and has top coefficient t₁^(r+1)W. The exact geometric-series remainder proves the claim for every r. |
| TAU-R1-03, undefined confluence arrows | Original defect closed; new endpoint-domain issue separately recorded above | The groupoid now includes labels, determinant comparison, leading orbit, lower coefficients, formal descent and exponent/time maps. It distinguishes the same-divisor slopes 1, 1/2 and 0; convergence is not an input field. |
| TAU-R1-04, negative/positive Poisson mismatch | Closed | Fiber negation sends the source test bracket −1 to the target positive bracket evaluated at −ν, also −1. The identity map would give +1. KKS/moment/reduction transport is explicitly required. |
| TAU-R1-05, unspecified extended JMU/H comparison | Closed | The delivered JMU/H comparison is explicitly generic unramified and logarithmically nonresonant. The slope-1/2 witness is outside it. Broader proved RHP adapters retain determinant/Fredholm identities. Downstream §§9–11 do not reassert the excluded general identity. |
| TAU-R1-06, missing HM sector/arc estimates | Closed | The uniform closed-sector (4.74) bounds are now explicit owned parametrix targets. Their angular integrals give first-arc O(R⁻³ᐟ²), second-arc O(R⁻³ᐟ⁴), and phase +iπ/24. |

### Why the corrected Laurent statement works for all r

Expand the separated pole through order r+1:

\[
\frac{C}{z-P}
=\sum_{j=0}^{r+1}\frac{CP^j}{z^{j+1}}
+\frac{CP^{r+2}}{z^{r+2}(z-P)}.
\]

For j ≤ r, adding Bⱼ = −[CPʲ]₍<0₎ + Dⱼ cancels every negative ε-power. Its limit is Dⱼ(0) + [CPʲ]₀. Since C has leading term Wε^(−r−1) and P = t₁ε + O(ε²), CP^(r+1) tends to t₁^(r+1)W and CP^(r+2) is O(ε). The remainder therefore tends uniformly to zero on compact sets separated from z = 0. At r = 1 the example gives t₂W/z² + t₁²W/z³; at t₁ = 1, t₂ = 0 it is exactly W/[z²(z−ε)]. At ε = 1/4, z = 2, this equals W/7.

The supplement also checks exact rational cancellations for r = 0 through 5, with t₁ = 2 and W = 3; the highest coefficients are 6, 12, 24, 48, 96, 192. These finite checks supplement the all-r remainder argument. They are not its replacement. The matrix pole-order statement is correctly separated from the minimal projective slope.

### Why the new moment and arc conditions suffice

The weighted moment condition in §10.2 is adequate. If h = (I+ν)w with ν ∈ L², then weighted L¹ and L² bounds on w imply weighted L¹ bounds on h by Hölder. After subtracting the first m+1 Cauchy terms, the scaled remainder contains

\[
\int_\Gamma \zeta^m h(\zeta)\frac{\zeta}{\zeta-z}\,d\zeta.
\]

In a closed sector separated from the rays, the ratio is bounded and tends pointwise to zero. Dominated convergence yields the stated o(|z|^(−m−1)) remainder. The roadmap does not claim the same estimate on a ray without its additional local analysis. As an explicit test, h(x) = e^(−x)E₁₂/4 on the positive ray has moments E₁₂/4, E₁₂/4, E₁₂/2, giving Cauchy coefficients iE₁₂/(8π), iE₁₂/(8π), iE₁₂/(4π).

For either HM arc, write u for angular distance from its oscillatory endpoint. On 0 ≤ u ≤ π/3,

\[
\sin(3u/2)\ge 3u/\pi,
\quad
\int_0^{\pi/3}e^{-aR^{3/2}\sin(3u/2)}du
\le\frac{\pi}{3aR^{3/2}}.
\]

Multiplication by the arc length factor R gives O(R^(−3/2)) for the first displayed H bound. For the second bound the largest contributions are R·R^(−1/4)·O(R^(−3/2)) and R·O(R^(−7/4)), both O(R^(−3/4)). This includes the boundary angles, where the exponential alone has modulus one. The regularizing logarithm contributes (1/8)i(π−2π/3) = +iπ/24. The result agrees with ILP18 (4.76), rather than relying only on real-ray asymptotics and pole-freeness.

## Twelve-target evidence map

| Target | Representative concrete evidence | Disposition |
|---|---|---|
| 8.1 | τ(s)=s; τ(s²)=s² has multiplicity 2 but kernel dimension 1; stabilization factors (2/3)(3/5)=2/5. | Survives conditional on precise complex determinant supplier gap. |
| 8.2 | Degree −1 gives χ(E(k))=2k+1; zero-winding diag(z,z⁻¹) has nontrivial kernel/cokernel; a factorization changes scalar determinant by 1/2. | Index, descent and unit-factor scopes survive. |
| 8.3 | K=1−s² gives trace derivative 2ds/s; a three-valent graph has nonzero vertex curvature; the explicit ramified example has slope 1/2. | Repaired generic comparison scope survives. |
| 8.4 | u=2t sends Hdt to (u/4)du for H=t; H_ILP=2Hcanonical+q+t²/4 at α=0. | No false downstream equality or all-strata comparison found. |
| 10.1 | e⁻ᵗ and 2e⁻ᵗ have the same zero formal series; two exceptional lifts have the same coarse RH point; common frame scaling sends constants 2,3 to 10,15. | Selected-lift and normalization contract survives. |
| 10.2 | Ghost norm e⁻²/2; exact Cauchy exclusion; resolvents 2 and 10; jump −I has norm 2 but an explicit normalized solution. | Endpoint and moment repair survives. |
| 10.3 | Nontrivial rational Stokes triple gives η-shift ratio exactly 1; (i,i,0) has undefined literal η; HM arcs and +iπ/24 checked. | Exact source locus and repaired calibration contract survive. |
| 10.4 | a=1,b=2,t₀=0 yields p=3, p′=13/2 and q″=2; real pole-free rational negative control can still have a complex pole. | Bridge consumes existing HM supplier without duplicating it. |
| 11.1 | All-r Laurent cancellation; three slopes 1,1/2,0; negative/positive bracket −1/−1; diag(1,2) yields trace 3T/z². | TAU-R2-02. |
| 11.2 | x′ε=ε gives error 2ε on length 2; x′=x gives exact εe^ℓ; zero fields with alternating initial points do not converge. | Mathematical contract survives; TAU-R2-01 at Suggested.lean interface. |
| 11.3 | Time rescaling changes a jet value 2 to 1; scalar x² identifies ±1; ε/(ε+δ) has iterated limits 0 and 1. | Verified-arrow category fixes old issue; inherits endpoint-domain repair. |
| 11.4 | exp(1/ε) destroys unnormalized convergence; z−ε converges while log derivatives differ by −4/ε at z=ε/2; interval Jacobian changes determinant 3/4 to 1/2. | Separate normalized-form and trace-norm routes survive. |

## Source, supplier and native-API audit

The fresh primary checks used the actual locally held extractions, including `rg -a` for NUL-bearing files. All reused Round 1 source files have unchanged SHA256 hashes, recorded individually in the ledger. Reused computations are explicitly identified; their old verdicts were not imported as authority.

- **BERT10/BERT16/BERT17:** Assumption 3.1, Proposition 5.1, the corrigendum's sign and vertex corrections, the integrable-operator solvability result, derivative formula (3.6), and contour factorization Theorem 3.3 were inspected. These justify the corrected generic scope and actual frame corrections. They do not automatically provide all ramified/resonant RHP adapters. Relevant source windows include BERT10 lines 1588ff/2071ff; BERT16 lines 78–100 and 203–223; BERT17 lines 318–363, 822–869 and 900–949.
- **MAL04:** §5.11–5.12, lines 562–628, is a logarithmic/nonresonant comparison. It is not used to supply an unstated ramified JMU extension. Its determinant construction and finite-rank transition mechanism support the narrower determinant-family discussion.
- **ILP18:** Theorem A and (1.16)–(1.21), Theorem B and (1.24)–(1.28), Lemma 3.3, (4.74), and the phase/calibration passage ending in (4.76) were checked. Exact exclusions, s₃-chart dependence, homogeneous α=0 and τ normalization agree. ILP18 lines 6500–6567 explicitly give the positive phase. FIKN was not independently read; the new uniform sector proof is therefore correctly an owned target.
- **DIK08/HXZ16:** DIK08 Theorem 1 fixes χ = log(2)/24 + ζ′(−1). HXZ16 Theorem 2.1 gives the closed pole-free sectors. Neither is treated as a substitute for the explicit complex-sector H bounds.
- **GMR23:** Theorem 2, lines 470–520, has the printed scaling defect. Definitions 3–4/Theorem 12, lines 3571–3659, give the ordered cascade and negative bracket; Theorem 13 gives the inverse time-matrix formula. Section 5.1, lines 5135–5145, explicitly treats unramified Painlevé cases. Its §4.3 coefficient/Hamiltonian limits are not misreported as a compact-path trajectory theorem.

Supplier interfaces were checked in the supplied current copies. HeegaardFloer F0.0 is real; the complex holomorphic determinant-family extension is a named gap rather than an imaginary supplied theorem. ComplexComparisonPartII's finite-dimensional analytic bundle operations do not by themselves prove that infinite-dimensional family result. OperatorIdeals OI-B23/B30 supplies the trace-class family/completeness contract. ToeplitzOperators T3 explicitly owns the matrix Fredholm index theorem, so scalar Coburn invertibility is not silently applied to matrix jumps. RandomMatrices §8.3 supplies the Fredholm determinant floor and §8.5 owns the real HM solution. AnalyticNumberTheoryPartII §4.3/4.3a fixes Barnes normalization, recurrence domains, zero orders and sector bounds. LieGroupoidsPoisson G4.6A explicitly includes fiber negation; HamiltonianReduction R2–R3 is a real smooth reduction floor, with the complex Takiff family extension owned here.

A final supplier refresh was also inspected independently: `_strict_review/current_sources/HeegaardFloer.current.md`, Git blob `7c171c7f4cb39cef7e2c2d4b054f04dfd150da64` (verified directly from the file bytes), at §2.2 lines 1376–1544. The parent identified this refresh with upstream commit `c9a16a043c3bf2321c63dff75e3f709466373528`. It still works on real Banach models (1378–1386), owns real continuous/smooth determinant-family transitions (1488–1504), and supplies orientation transport while requiring a connection or trivialization for linear fibre transport (1506–1523). It does not supply the complex holomorphic canonical-section package. Thus the named F0.0C gap remains necessary after the refresh; this does not change either Round 2 finding.

No new open-PR ownership search was performed. The supplied main/proposed supplier copies were the review inputs; no claim is made that inaccessible open work was audited. Declared precise supplier gaps remain conditional contracts, not findings merely because their implementations are incomplete.

## Deliverables and remaining gates

The complete machine-readable outputs are `tau_findings.json` and `tau_ledger.json`. The independent exact/rate checks are reproducible with `tau_compute.py`, which writes only `tau_computations.json`; all its assertions passed. It verifies the immutable input hashes before computing.

The substantive conclusion concerns the frozen Round 2 snapshot only. Author repairs made elsewhere do not retroactively change this verdict. A repaired frozen snapshot must retest the two remaining findings and any newly added Lean signatures. The ordinary Worker runtime, successful Lean elaboration and distinct-model-family gate remain separate from this manual review and have not been satisfied here.
