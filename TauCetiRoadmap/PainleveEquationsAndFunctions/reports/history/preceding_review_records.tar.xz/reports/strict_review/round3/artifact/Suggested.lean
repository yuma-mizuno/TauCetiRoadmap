import Mathlib

/-!
# Painlevé equations and functions: target signatures

The roadmap is README.md. This file records the status of its intrinsic headline
theorems against the pinned Mathlib and Tau Ceti APIs; it does not replace that
roadmap.

The general proper-semiconjugacy continuation theorem in Section 5.2 is stated
below on native real manifolds, tangent and hom bundles, derivatives and proper
maps. It uses a C¹ horizontal splitting; complex holomorphic splittings give
the intended application after restriction of scalars. Integrability enters the
later homotopy-invariance theorem, not lifting one prescribed path.

Section 11.2's generic finite-chart compact-path theorem is also stated below.
Its actual tangent fields, positive chart margins, uniform local Lipschitz and
field-error bounds, and convergent initial points imply eventual full-interval
solutions, no exit and uniform convergence. The only assumed solution is the
reference trajectory; the intrinsic collision-family application remains later.

The following intrinsic application headlines still require carriers whose
construction is part of the roadmap or of its named suppliers:

* Intrinsic construction and classification of rank-two Painlevé data.
  Missing are families of pointed complex curves with irregular types, the
  corresponding parabolic meromorphic connection groupoids, ramified local
  descent, and the intrinsic structural polar-degree and local admissibility
  conditions together with their reduced deformation problem.
* Representability, deformation theory and the relative symplectic structure.
  Missing are the stable connection moduli functor, its rigidification and
  relative tangent complex, and the analytic realization of its moduli space.
* Construction and integrability of the isomonodromy splitting.
  Missing are the universal meromorphic connection, admissible deformation base
  and relative tangent sequence on the actual moduli family. A freely supplied
  horizontal distribution would not state the construction theorem.
* Full-stratum irregular Riemann–Hilbert correspondence.
  Missing are Stokes-filtered local systems with ramified descent, their
  parameterized moduli, and the actual Riemann–Hilbert map including resonant and
  reducible strata. The regular-singular and formal connection dictionaries
  alone do not provide these objects.
* Application of continuation to geometric Painlevé dynamics and scalar meromorphy.
  Missing are the actual isomonodromy family and its Riemann–Hilbert comparison,
  together with meromorphic observables on the phase surfaces and the required
  treatment of indeterminacy. Native real integral curves and meromorphic
  functions on Riemann surfaces do not by themselves state this result.
* Intrinsic spaces of initial conditions and their boundary classification.
  Missing are the relevant marked rational surface pairs, their moduli,
  relative anticanonical divisors and the comparison with connection moduli.
* Modifications, symmetries and Riccati loci.
  Missing are elementary modifications on the connection groupoids, the
  induced correspondences between parameter spaces, and the invariant
  geometric loci and their projective-linear reductions. Invariant curves are
  not identified with reducibility without a separate comparison theorem.
* The normalized tau line and its determinant section.
  Missing are holomorphic determinant lines of the relevant index-zero
  Fredholm or Riemann–Hilbert families, the sewing identifications and the
  comparison with the isomonodromic differential. A line bundle or a closed
  differential form without those constructions does not define the target.
* Comparison with the classical scalar equations and ten underlying profiles,
  with all seventeen ordered profiles retained.
  Missing are the intrinsic families above, their phase charts, the scalar
  observables and all normalization maps. Scalar differential equations on
  freely chosen functions would omit the intrinsic comparison theorem.
* Distinguished analytic solutions and the Hastings–McLeod comparison.
  Missing are the intrinsic monodromy/Stokes conditions that select horizontal
  sections and the scalar comparison with the solution owned by RandomMatrices.
  The general scalar existence theorem remains with its existing supplier.
* Controlled confluence of the intrinsic families.
  Missing are the degeneration families, parameter and frame identifications,
  limiting Stokes data and the topology in which horizontal sections converge.

The two generic theorems below separate statable common headlines from
these missing application carriers. Their nine small definitions use native
manifolds, tangent linear maps, derivatives, chart tubes and trajectories; none of
the missing Painlevé carriers is replaced by an unspecified predicate, an
assumed conclusion or an admitted data definition.
-/

noncomputable section
open Set Bundle Filter
open scoped Manifold Bundle Topology NNReal

namespace TauCetiRoadmap.PainleveEquationsAndFunctions

variable {EM EB M B R : Type*}
  [NormedAddCommGroup EM] [NormedSpace ℝ EM] [FiniteDimensional ℝ EM]
  [NormedAddCommGroup EB] [NormedSpace ℝ EB] [FiniteDimensional ℝ EB]
  [TopologicalSpace M] [ChartedSpace EM M] [T2Space M]
  [SecondCountableTopology M] [IsManifold 𝓘(ℝ, EM) ∞ M]
  [TopologicalSpace B] [ChartedSpace EB B] [T2Space B]
  [SecondCountableTopology B] [IsManifold 𝓘(ℝ, EB) ∞ B]
  [TopologicalSpace R]

/-- A finite subdivision, including the empty subdivision of a singleton interval. -/
structure Breaks (a b : ℝ) where
  n : ℕ
  cut : Fin (n + 1) → ℝ
  ordered : StrictMono cut
  first : cut 0 = a
  last : cut (Fin.last n) = b

/-- The right inverse is an actual section of Hom(π*TB,TM). -/
structure HorizontalSplitting
    (π : ContMDiffMap 𝓘(ℝ, EM) 𝓘(ℝ, EB) M B ∞) where
  lift : ∀ x : M, TangentSpace 𝓘(ℝ, EB) (π x) →L[ℝ]
    TangentSpace 𝓘(ℝ, EM) x
  rightInverse : ∀ x,
    (mfderiv 𝓘(ℝ, EM) 𝓘(ℝ, EB) π x).comp (lift x) =
      ContinuousLinearMap.id ℝ (TangentSpace 𝓘(ℝ, EB) (π x))
  regularity : ContMDiff 𝓘(ℝ, EM)
    (𝓘(ℝ, EM).prod 𝓘(ℝ, EB →L[ℝ] EM)) 1
    (fun x ↦ (⟨x, lift x⟩ : Bundle.TotalSpace (EB →L[ℝ] EM)
      (fun x : M ↦ TangentSpace 𝓘(ℝ, EB) (π x) →L[ℝ]
        TangentSpace 𝓘(ℝ, EM) x)))

/-- C¹ on the finitely many closed pieces, continuous on the full interval. -/
def PiecewiseC1On (γ : ℝ → B) (a b : ℝ) : Prop :=
  ContinuousOn γ (Icc a b) ∧ ∃ p : Breaks a b,
    ∀ i : Fin p.n, ContMDiffOn 𝓘(ℝ) 𝓘(ℝ, EB) 1 γ
      (Icc (p.cut i.castSucc) (p.cut i.succ))

/-- Genuine differential horizontality. The equation h(dπ(v))=v avoids casting
vectors along the separately required equality π(η(t))=γ(t). -/
def HorizontalOn
    (π : ContMDiffMap 𝓘(ℝ, EM) 𝓘(ℝ, EB) M B ∞)
    (h : HorizontalSplitting π) (γ : ℝ → B) (η : ℝ → M) (a b : ℝ) : Prop :=
  ContinuousOn η (Icc a b) ∧ EqOn (π ∘ η) γ (Icc a b) ∧
    ∃ p : Breaks a b, ∀ i : Fin p.n,
      let J := Icc (p.cut i.castSucc) (p.cut i.succ)
      ContMDiffOn 𝓘(ℝ) 𝓘(ℝ, EB) 1 γ J ∧
      ContMDiffOn 𝓘(ℝ) 𝓘(ℝ, EM) 1 η J ∧
      ∀ t ∈ J,
        let v := mfderivWithin 𝓘(ℝ) 𝓘(ℝ, EM) η J t 1
        h.lift (η t) (mfderiv 𝓘(ℝ, EM) 𝓘(ℝ, EB) π (η t) v) = v

/-- Actual continuous target trajectories, not a predicate standing for the theorem.
Only paths based at ρ(y) are constrained. Prefix compatibility is stated explicitly
in the transfer theorem; it follows from the usual transport restriction law and
local semiconjugacy in the intended application. -/
structure TargetTransport (ρ : R → B) where
  trajectory : (ℝ → B) → R → ℝ → R
  continuous : ∀ γ y, PiecewiseC1On (EB := EB) γ 0 1 → ρ y = γ 0 →
    ContinuousOn (trajectory γ y) (Icc 0 1)
  initial : ∀ γ y, PiecewiseC1On (EB := EB) γ 0 1 → ρ y = γ 0 → trajectory γ y 0 = y
  over : ∀ γ y, PiecewiseC1On (EB := EB) γ 0 1 → ρ y = γ 0 →
    EqOn (ρ ∘ trajectory γ y) γ (Icc 0 1)

/-- General compact-containment transfer, with uniqueness on the path interval.
The values of the chosen extensions outside [0,1] carry no uniqueness assertion. -/
theorem proper_semiconjugacy_complete_horizontal_lifts
    (π : ContMDiffMap 𝓘(ℝ, EM) 𝓘(ℝ, EB) M B ∞)
    (h : HorizontalSplitting π)
    (ρ : R → B) (T : TargetTransport (EB := EB) ρ)
    (F : M → R) (hF : IsProperMap F) (hOver : ρ ∘ F = π)
    (hCompat : ∀ (γ : ℝ → B), PiecewiseC1On (EB := EB) γ 0 1 →
      ∀ (x : M), π x = γ 0 → ∀ s ∈ Icc (0 : ℝ) 1,
      ∀ η : ℝ → M, η 0 = x → HorizontalOn π h γ η 0 s →
        EqOn (F ∘ η) (T.trajectory γ (F x)) (Icc 0 s)) :
    ∀ (γ : ℝ → B), PiecewiseC1On (EB := EB) γ 0 1 →
      ∀ (x : M), π x = γ 0 → ∃ η : ℝ → M,
        η 0 = x ∧ HorizontalOn π h γ η 0 1 ∧
        ∀ ζ : ℝ → M, ζ 0 = x → HorizontalOn π h γ ζ 0 1 →
          EqOn ζ η (Icc 0 1) := by
  sorry


/-- The closed time segment indexed by a subdivision interval. -/
def Breaks.segment {a b : ℝ} (p : Breaks a b) (i : Fin p.n) : Set ℝ :=
  Icc (p.cut i.castSucc) (p.cut i.succ)

/-- Actual nonautonomous tangent equations on the pieces, with a globally
continuous trajectory. Different one-sided velocities at a cut are permitted. -/
def PiecewiseODEOn {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [TopologicalSpace M] [ChartedSpace E M]
    {a b : ℝ} (p : Breaks a b)
    (V : Fin p.n → ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (x : ℝ → M) : Prop :=
  ContinuousOn x (Icc a b) ∧ ∀ i, ∀ t ∈ p.segment i,
    HasMFDerivWithinAt 𝓘(ℝ) 𝓘(ℝ, E) x (p.segment i) t
      ((1 : ℝ →L[ℝ] ℝ).smulRight (V i t (x t)))

/-- The true expression of a time-dependent tangent field in a fixed native
extended chart. The formula agrees with the pinned native curve/chart API. -/
def ChartField {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [TopologicalSpace M] [ChartedSpace E M] [IsManifold 𝓘(ℝ, E) 1 M]
    (c : M) (V : ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (t : ℝ) (z : E) : E :=
  let y := (extChartAt 𝓘(ℝ, E) c).symm z
  tangentCoordChange 𝓘(ℝ, E) y c y (V t y)

/-- A fixed closed tube around the reference graph in one native chart.
Its radius is independent of the approximation index. -/
def ChartTube {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    [TopologicalSpace M] [ChartedSpace E M]
    (J : Set ℝ) (c : M) (x₀ : ℝ → M) (r : ℝ) : Set (ℝ × E) :=
  {q | q.1 ∈ J ∧
    q.2 ∈ Metric.closedBall ((extChartAt 𝓘(ℝ, E) c) (x₀ q.1)) r}

/-- A family of nonautonomous tangent fields converging uniformly on finitely
many positive-radius chart tubes has nearby solutions on the entire compact
path interval. Those solutions remain inside the tubes, satisfy the quantitative
segment estimates, and converge uniformly as manifold-valued curves.

The reference trajectory is the only assumed solution. No approximating solution,
its continued existence, or its tube membership is an input. -/
theorem finite_chart_compact_path_no_exit_convergence
    {E M : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    [MetricSpace M] [ChartedSpace E M] [IsManifold 𝓘(ℝ, E) 1 M]
    {a b : ℝ} (hab : a < b) (p : Breaks a b)
    (V : ℕ → Fin p.n → ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (V₀ : Fin p.n → ℝ → (x : M) → TangentSpace 𝓘(ℝ, E) x)
    (x₀ : ℝ → M) (hx₀ : PiecewiseODEOn (E := E) p V₀ x₀)
    (c : Fin p.n → M) (r : ℝ) (hr : 0 < r) (L : ℝ≥0)
    (hchart : ∀ i, ∀ t ∈ p.segment i,
      x₀ t ∈ (extChartAt 𝓘(ℝ, E) (c i)).source)
    (hmargin : ∀ i, ∀ t ∈ p.segment i,
      Metric.closedBall ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) r ⊆
        (extChartAt 𝓘(ℝ, E) (c i)).target)
    (hcont₀ : ∀ i,
      ContinuousOn (fun q : ℝ × E ↦ ChartField (E := E) (c i) (V₀ i) q.1 q.2)
        (ChartTube (E := E) (p.segment i) (c i) x₀ r))
    (hregular : ∀ n i,
      ContinuousOn (fun q : ℝ × E ↦ ChartField (E := E) (c i) (V n i) q.1 q.2)
        (ChartTube (E := E) (p.segment i) (c i) x₀ r) ∧
      ∀ t ∈ p.segment i,
        LipschitzOnWith L (ChartField (E := E) (c i) (V n i) t)
          (Metric.closedBall ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) r))
    (δ : ℕ → ℝ≥0) (hδ : Tendsto (fun n ↦ (δ n : ℝ)) atTop (𝓝 0))
    (herror : ∀ n i, ∀ q ∈ ChartTube (E := E) (p.segment i) (c i) x₀ r,
      dist (ChartField (E := E) (c i) (V n i) q.1 q.2)
        (ChartField (E := E) (c i) (V₀ i) q.1 q.2) ≤ (δ n : ℝ))
    (initial : ℕ → M) (hinitial : Tendsto initial atTop (𝓝 (x₀ a))) :
    ∃ x : ℕ → ℝ → M,
      (∀ᶠ n in atTop,
        x n a = initial n ∧ PiecewiseODEOn (E := E) p (V n) (x n) ∧
        ∀ i, ∀ t ∈ p.segment i,
          x n t ∈ (extChartAt 𝓘(ℝ, E) (c i)).source ∧
          dist ((extChartAt 𝓘(ℝ, E) (c i)) (x n t))
            ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) < r ∧
          dist ((extChartAt 𝓘(ℝ, E) (c i)) (x n t))
            ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ t)) ≤
            (dist ((extChartAt 𝓘(ℝ, E) (c i)) (x n (p.cut i.castSucc)))
              ((extChartAt 𝓘(ℝ, E) (c i)) (x₀ (p.cut i.castSucc))) +
              (t - p.cut i.castSucc) * (δ n : ℝ)) *
                Real.exp ((L : ℝ) * (t - p.cut i.castSucc))) ∧
      TendstoUniformlyOn x x₀ atTop (Icc a b) := by
  sorry


end TauCetiRoadmap.PainleveEquationsAndFunctions
