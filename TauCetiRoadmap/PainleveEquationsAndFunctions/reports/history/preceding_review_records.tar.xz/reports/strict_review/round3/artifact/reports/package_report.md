# Package report

## Result and scope

This unpublished draft specifies 11 layers, 44 numbered targets, 115 API laws and 128 diagnostic checks. Its architecture is intrinsic input → actual moduli/deformation construction → horizontal dynamics and common property theorems → classical coordinate comparisons. The previously stated unqualified completion was withdrawn for the strict review. The current substantive verdict is recorded, with exact hashes, in `strict_review_report.md`; this package does not claim official Worker acceptance or completed formalization.

No Worker entrypoint, CLI, lane, provider job, board operation or publication process was started. No push, issue, pull request or other GitHub mutation was performed. The Worker rubrics were inspected and applied manually through frozen snapshots, independent reviewer sessions, concrete counterexamples, author repairs and re-review.

## Contents

| File or directory | Purpose |
|---|---|
| `README.md` | Canonical mathematical specification and precise primary references. |
| `Suggested.lean` | Two general continuation/convergence headlines and nine genuine native-carrier definitions; eleven intrinsic application-carrier omissions. The theorem proofs are intentionally admitted, and elaboration remains unverified. |
| `metadata.toml` | Topic `math.AG`, following the moduli/connection foundation. |
| `sources.toml` | 23 sources, precise versions, locators, scope corrections and retrieved-byte provenance. |
| `design/README.md` | Byte-identical canonical text. |
| `design/plan.json` | Target graph, hypotheses, ownership, supplier contracts and two named gaps. |
| `input/target.draft.toml` | Original draft input retained as history. |
| `reports/design_report.ja.md` | Japanese explanation of the architecture, mathematical decisions, repairs and limits. |
| `reports/strict_review_report.md` and `reports/strict_review/` | Current review protocol, findings, computation ledgers, author resolutions and fixed-version verdicts. |
| `reports/review_*.md` | Historical pre-strict-review records, explicitly superseded. |
| `reports/worker_contract*.md` | Worker/content/native/supplier evidence and current-head refresh. |
| `reports/source_audit.md` | Source hypotheses, corrections, versions and provenance limits. |
| `reports/validate_draft.py` and `validation.json` | Independent static and exact-arithmetic checks, with reproducible outcomes. |
| `SHA256SUMS` | Final package hashes, excluding the checksum file itself. |

The audited repository's normal content folder contains README.md, Suggested.lean and metadata.toml. The source/review material here belongs to this reviewable staging package; it is not a request to publish every staging file.

## Baselines

| Component | Inspected revision |
|---|---|
| Worker contract | `46e12afb791b1efab8fd8b3285370d689ba2e7b8` |
| Current Roadmap main | `c9a16a043c3bf2321c63dff75e3f709466373528` |
| Original Roadmap baseline | `a0ad405e151ff6e42b3c5e372ac3f24e168ad68f` |
| Tau Ceti | `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a` |
| Mathlib | `f6090c7095e1e56b3464c1daba5f24631f1290d2` |
| Lean | `leanprover/lean4:v4.35.0-rc3` |

The second main-repository refresh changed HeegaardFloer. Its complete consumed F0.0 section was reread; it retains the real-family contract and does not close the complex holomorphic gap. The library/toolchain pins did not change. All five proposed supplier heads were refetched and remained unchanged. Roadmap ownership is not evidence that a native theorem has already been implemented.

## Static and arithmetic verification

The graph has 44 vertices and 216 internal edges, with no cycles or forward prerequisites. Layers 1–5 do not depend on the scalar comparison layer. Every definition/construction has API laws and at least three diagnostic checks. README and design README agree; plan targets, supplier/gap sentences, source keys and citations resolve. RandomMatrices remains a one-way supplier.

The independent validator recorded 1113 mechanical assertions and 17 exact-arithmetic diagnostic groups without a failure. These include the original Hamiltonian/PV/sigma/coordinate regressions and the new ordered-profile, gauge, central-reflection, PII-sigma-collapse, corrected Laurent and Poisson-sign witnesses. They are tests of specifications and displayed calculations, not proofs of the general constructions. Independent reviewers' target-by-target evidence is in the review ledgers.

All 22 retrieved primary PDFs were rehashed. DLMF was read through its official rendered text but raw-byte retrieval was denied; it remains explicitly uncertified, with no invented hash. Source provenance is not proof certification. Research PDFs, extracted articles, toolchain binaries and repository checkouts are not included.

Run the independent check from the package directory:

```bash
python3 reports/validate_draft.py
```

The source-cache option can rehash externally retained source bytes; without it, the report explicitly says they were not rehashed. The source cache is not shipped.

## Formal and reviewer gates

The previous zero-declaration rationale missed a general statable headline. The revised Suggested.lean states the complete proper-semiconjugacy transfer theorem on finite-dimensional real smooth manifolds, with an actual C¹ hom-bundle splitting, genuine differential horizontality, continuous target trajectories and properness. The complex holomorphic case is its application. The second native headline gives the finite-chart compact-path existence/no-exit/convergence theorem of §11.2. In total nine genuine definitions make both statements possible without inventing Painlevé moduli or assuming the approximating solutions exist.

The official pinned runtime failed before elaboration with `error: failed to locate application`, including the documented sysroot retry. Lake could not identify its installation configuration. No runtime restriction was bypassed. Both signatures are unelaborated; lexical/source inspection cannot certify its type correctness, and the two `sorry` bodies are admitted future proofs.

The inspected Jobs configuration calls for two red-team rounds and different reviewer model families. Separate fresh-context agents perform this manual review, but a distinct-model-family check was not obtained. Consequently a clean substantive review, if recorded in the current report, is still not official package acceptance.

## Mathematical scope retained

The substantial future proofs remain explicit: auxiliary unfolding and symplectic closedness; full-strata relative proper RH; the full connection-moduli/surface comparison; geometric reflections; resonant/ramified index-zero RHP adapters; precise sectorial calibration estimates; and invariant confluence comparisons. The two generic supplier extensions remain assigned to SmoothBundlesConnectionsPartII and HeegaardFloerPartII.

The determinant/Fredholm variational theory is stated on constructed RHP-adapter loci. The cited JMU/Hamiltonian comparison has its explicit generic unramified/nonresonant scope. A general ramified/resonant identity is not silently promised. No theorem in this roadmap is represented as proved merely because its proof route or owner has been specified.
