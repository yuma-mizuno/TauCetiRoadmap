# Strict Round 3 core closure review

## Verdict and limits

**Zero substantive findings in the frozen R3 source.** All 21 core targets in Layers 1–5 have individual dispositions. The entire `Suggested.lean` was audited, including the mandatory native §11.2 regression. **CORE-R2-01 and CORE-R2-02 are closed at the source/statement level.** This is a strict manual review under the actual Worker review and red-team rubrics, not official Worker acceptance.

The external gates remain **UNPASSED**. The pinned official Lean runtime was previously unable to start; it was not retried or bypassed. No elaboration result is claimed. Fresh reviewer contexts also do not establish distinct model families. The file contains two intentional theorem proof holes, so no theorem implementation or completed proof is asserted. These limits are separate from the mathematical/source-level finding count.

## Frozen inputs and method

| Frozen R3 file | SHA-256 |
|---|---|
| `README.md` | `b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502` |
| `design/plan.json` | `1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10` |
| `Suggested.lean` | `74eeedeeb47cc963f1c2c28382b5fb901a85df34e0f521e7cc7fa4fcccf5afa6` |

The independently checked native pins are Mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2` and Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`. The actual Worker contract revision is `46e12afb791b1efab8fd8b3285370d689ba2e7b8`. The rubric reads covered `review.md`, `redteam.md`, `redteam-section.md`, and the defect-class, Lean-form, gaps/order, source, adversarial, dependency and review-lessons sections under `_research/worker_contract_sources/prompts`, together with `_strict_review/protocol.md`.

An exact R2/R3 target-section comparison finds changes only in **§§5.2, 11.1 and 11.2**. Within the 21 core targets, the other **20 README sections and 20 JSON target objects are equal**. The entire changed §5.2 was checked in README and plan, including its additional test, prerequisites, hypothesis summary and formalization status. The new §11.2 and changed §11.1 endpoint restriction were read in full. The updated roadmap baseline records the current supplier refresh; it does not change the native pins or turn the real geometric supplier floor into a complex one.

Previously computed R2 controls were reused only after independently checking their formulas, hypotheses and applicability to R3. Per-target equality hashes, R2 ledger/computation hashes and the exact provenance are recorded in `core_ledger.json`. No reused R2 computation is represented as a fresh execution. The narrowly targeted fresh calculations below address the changed continuous-time and no-exit claims. This is regression reuse with an independent mathematical audit, not reliance on the old reviewer verdict.

## CORE-R2-01: the full native no-exit theorem

**Closed.** `finite_chart_compact_path_no_exit_convergence`, at `Suggested.lean:215–253`, now states the missing generic full-interval theorem. Its support definitions use actual native objects: finite subdivision segments, manifold tangent equations on the closed pieces, the genuine extended-chart tangent transformation, and positive-radius chart tubes around the reference graph.

The only assumed solution is the reference curve `x₀`. The other inputs are actual time-dependent tangent fields, finitely many reference charts, chart source membership of the reference, a positive closed-ball margin in each chart target, joint continuity on the tubes, a common phase Lipschitz constant, uniform field errors tending to zero, and initial points tending to the reference initial point. For all sufficiently large approximation indices the conclusion **constructs solutions on the entire interval** and proves their tangent equations, source membership, strict tube membership, quantitative segment bounds and metric uniform convergence.

This repairs the omitted headline rather than merely restating a Grönwall estimate. The native estimate assumes both compared trajectories and their domain membership. The new theorem does not assume approximating trajectories, complete solution operators, their continuation, or their tube membership. The collision-family construction still has to supply the common charts and field estimates; this remains expressly separate in §11.2.

### Independent mathematical audit of its hypotheses

1. **The chart field is the actual tangent field in fixed coordinates.** With `y=(extChartAt I c).symm z`, `ChartField` uses `tangentCoordChange I y c y (V t y)`. This direction matches the pinned native integral-curve/chart adapter. The chart-target margin ensures these inverse values lie in the chosen source. `PiecewiseODEOn` uses the continuous linear map sending the time unit to the actual tangent-field value.
2. **The local existence floor has the right regularity.** The reference is continuous on each compact segment. A positive moving tube contains a smaller fixed time-phase cylinder around an interior graph point, with one-sided cylinders at time endpoints. Joint continuity gives bounds on compact cylinders; the common phase Lipschitz estimate supplies uniqueness and the Picard–Lindelöf condition. Finite-dimensional normed `E` supplies completeness. No time derivative of the vector field is required.
3. **No reference-field Lipschitz hypothesis is missing.** The comparison decomposes as `Vₙ(xₙ)−Vₙ(x₀)` plus `Vₙ(x₀)−V₀(x₀)`. The former is controlled by the approximating-field Lipschitz bound, the latter by uniform field convergence. These are exactly the recorded hypotheses.
4. **No exit precedes the continuation conclusion.** Choose the initial coordinate error and field error small enough to make the segment estimate less than half the positive radius. At a first exit the estimate contradicts reaching the tube boundary. The smaller closed coordinate tube over a compact reference segment is compact. Its inverse-chart image lies inside the phase chart, giving compact containment and the local continuation mechanism through the segment endpoint.
5. **Chart transitions are handled by a finite induction.** At each cut the reference lies in both adjacent chart sources. Openness puts sufficiently nearby terminal points in the next source, and continuity of the transition makes the next-chart starting errors tend to zero. The statement correctly restarts each estimate using its own left-endpoint coordinate error. Finitely many segments give a single eventual index and a continuous whole-interval trajectory. Coordinate errors are not assumed invariant under transition maps.
6. **One-sided endpoints and corners are allowed.** Global continuity is required, but derivatives are within each closed piece. Different one-sided velocities at a cut therefore cause no contradiction. `a<b` and the ordered endpoint conditions exclude the empty positive-length subdivision. Values of the chosen total functions outside the interval, and finitely many early approximation indices, are irrelevant.
7. **The metric conclusion follows from compactness.** Inverse charts are uniformly continuous on compact coordinate tube projections. Uniform coordinate convergence consequently gives convergence for the chosen compatible manifold metric on each segment, hence on their finite union. Completeness of the whole manifold is not needed. The metrizable-manifold floor also supports the README statement that the result is independent of a compatible metric on these compact domains.
8. **The parameter and time scopes remain honest.** A first-countable admitted complex parameter cover permits passage through arbitrary sequences, once the geometric family proves the same uniform chart/tube/field and initial-value hypotheses. No conclusion on an unbounded time ray, a whole path family, or through a limiting fixed singularity is asserted.

### Concrete no-exit and gluing regressions

- **Zero-Lipschitz full interval.** On `[0,2]`, `Vₙ=1/(n+1)`, `V₀=0`, and initial point zero yield `xₙ(t)=t/(n+1)` and supremum error `2/(n+1)`. Radius one gives strict trapping for `n≥2`. The freshly evaluated errors at `n=2,9,99` are `2/3,1/5,1/50`. The bound works at `L=0` without dividing by `L`.
- **The original nonlinear R2 witness.** On `[0,1/2]`, take reference `1/(1−t)`, radius one and fields `y²+εₙ`, with `εₙ=e⁻³/(n+2)`. The phase tube is contained in `[0,3]`, so a common Lipschitz constant is six. At the right endpoint the bound is `1/(2(n+2))`. Exact tangent-form solution evaluations give errors approximately `0.0291652,0.0116366,0.00290547` for `n=0,3,18`, compared with bounds `.25,.10,.025`. These are genuine nonlinear trajectories, while the statement still has to construct them rather than assume them.
- **A coordinate transition and a corner.** Use cuts `0,1,2`, triangular reference `t` then `2−t`, and approximating slopes `1+ε` then `−1+ε`. The solution is `x₀(t)+εt`. Use coordinates `y` on the first segment and `2y` on the second. With common field error `2ε` and `L=0`, the second-chart starting error is `2ε`, and the bound is `2ε+2ε(t−1)=2εt`. The metric supremum error is `2ε`; for `ε=1/(n+1)`, radius-one strict chart trapping holds for `n≥4`. This tests both genuine coordinate rescaling and unequal one-sided velocities.
- **A rejected initial-value counterexample.** For identical zero fields and initial points `(-1)ⁿ`, the solutions remain `(-1)ⁿ`. The initial convergence hypothesis correctly excludes this failure. Uncontrolled coefficient convergence without a positive common chart tube likewise does not satisfy the theorem.

## CORE-R2-02: explicit native model anchoring

**Closed at source level.** All five uses of `PiecewiseC1On` explicitly pass `(EB := EB)`. The target-transport theorem binder explicitly uses `TargetTransport (EB := EB) ρ`. The projection in `HorizontalSplitting π` and `HorizontalOn π h` determines their model data, and the new ODE/tube uses explicitly fix `E`.

The repair addresses the actual source-established risk. `ChartedSpace` takes its model as an ordinary input argument, not an `outParam`; its documentation explains that the same topological space can have multiple models. The explicit target space `B` and a function into it therefore do not independently anchor `EB`. The static anchor audit is complete. Elaboration and inspection of inferred declaration types must still wait for a working official runtime; no observed compiler success is invented.

## Complete Suggested.lean and §5.2 audit

The entire 255-line file has one `import Mathlib`, **nine support definitions/structures and two theorem declarations**. The two `sorry` occurrences are theorem proof bodies. The complete declaration inventory appears in the ledger. No admitted carrier data, arbitrary obligation predicate, solution-operator assumption, axiom/opaque stand-in or option change is used to disguise the missing work.

The §5.2 theorem retains a genuine continuous-linear right inverse of the native tangent map, varying C¹ as a Hom-bundle section. A horizontal lift is an actual curve with its base projection and tangent equation. Compatibility quantifies over **each existing partial lift**, without asserting that a complete lift already exists. The proper map is `F`, and the compact set is the preimage of the continuous transported target path. The target itself may be singular or merely topological. No inverse to `F` is required; uniqueness is only on `[0,1]`, so arbitrary outside-interval function values cause no false uniqueness claim.

The new adapter fixes a concrete proof-route issue. For `γ(s)=|s−1/2|^(3/2)`, the path is C¹, but the right difference quotient of its velocity is `1.5/√h`. At `h=10⁻²,10⁻⁴,10⁻⁶` the values are `15,150,1500`. Autonomization therefore need not produce a C¹ vector field. R3 now explicitly owns the continuous-time, phase-Lipschitz chart equation, uniform local intervals on compact neighborhoods, finite-subcover extension and chart gluing. It restricts the existing C¹ autonomous maximal-curve theorem to cases satisfying that stronger hypothesis.

## All 21 core target dispositions

Each entry below has concrete witness inputs, evaluated sides, API/check adequacy, source scope and reuse provenance in `core_ledger.json`. A passing disposition concerns the scoped **planned target**, not an implemented construction.

| Target | Independent adversarial check and disposition |
|---|---|
| 1.1 | **Pass.** Independently rechecked degree/residue compatibility, trace-subtracted gauge discrepancy, adjoint rank, ramified trace residue and dual-number monodromy. The real full-bundle and adjoint/projective carrier survives the controls. |
| 1.2 | **Pass.** Rechecked four-point cross ratio, inverse velocity normalization for tau=2t, and the total moving-log-divisor differential. A true tangent splitting is specified. |
| 1.3 | **Pass.** Rechecked budgets four, five and three and the scalar-irregular determinant exclusion. The classical input class precedes rather than assumes the one-time/two-phase conclusion. |
| 1.4 | **Pass.** Rechecked ordered/unlabelled counts 17/10, with support-size counts (2,8,6,1)/(2,5,2,1). Reindexing is an explicit comparison, not a label-preserving arrow. |
| 2.1 | **Pass.** Rechecked mu_2 stabilizers and the extension family O(-1)+O(1) at zero, O^2 elsewhere. Unbalanced strata are locally closed; the balanced locus is open. Universal-object descent is explicit. |
| 2.2 | **Pass.** Rechecked d(z E12)=E12 dz while z d(E12)=0 and the degree-1-to-2 identity complex. The differential is C-linear first order; deleting degree two changes H1. |
| 2.3 | **Pass.** Rechecked the positive-rank dimension examples and monic finite-flat quadratic unfolding. Rank zero is excluded. Early logarithmic comparison and trace-form closedness are explicitly owned without a Layer-11 cycle. |
| 2.4 | **Pass.** Rechecked four-flag weights: total 1.5, rank-two slope .75, invariant-line weight at most .6. Stable reducible monodromy is allowed; the ramified deck exchange obstructs a naive descended line. |
| 3.1 | **Pass.** Rechecked the flat total form whose derivative and commutator cancel but whose logarithmic time pole violates the allowed order. Strong deformation conditions add real content. |
| 3.2 | **Pass.** Rechecked the nonzero bracket of partial_s and partial_t+s partial_q and the surviving epsilon1 epsilon2 coefficient. Fully square-zero truncation would erase the obstruction. |
| 3.3 | **Pass.** Rechecked the Hamiltonian kernel for H=p^2/2, additive-time invariance, and a flat splitting with nonclosed projected form. Actual symplectic transport is required and explicitly owned. |
| 3.4 | **Pass.** Rechecked the time-dependent gauge logarithmic derivatives, their product cocycle and nonconstant transported coordinates. Pure conjugation cannot replace the connection adapter. |
| 4.1 | **Pass.** Rechecked exp(1/z), unipotent logarithmic monodromy, deck exchange and exponentially small sector ambiguity. Formal/monodromy data do not replace the owned analytic Stokes construction. |
| 4.2 | **Pass.** Rechecked integer-shift exponent fibers, decorated unipotents and ramified deck constraints. The retained theta lift and spectral constraints prevent using the wrong quotient. |
| 4.3 | **Pass.** Rechecked the blowdown exceptional fiber: distinct source points have one image but their own unique lifts. Forward compatibility is required at every stratum; inverse use is generic only. |
| 4.4 | **Pass.** Rechecked the deleted double cover with proper nonempty fixed-time fibers but missing compact-path source limit. Whole-family properness, with four owned construction steps, is the actual requirement. |
| 5.1 | **Pass.** Rechecked q=q0/(1-t q0) and constant-fiber versus constant-total-space points. Actual local section germs are specified, with global continuation still separate. |
| 5.2 | **Pass.** Rechecked proper exceptional-fiber and deleted-cover controls. The new continuous-time, phase-Lipschitz adapter addresses the C1-path regularity gap; the proper map is F. |
| 5.3 | **Pass.** Rechecked q=exp(u/2), p=2 exp(-u/2) over t=exp(u): one loop gives (-1,-2), two give (1,2), and -I fixes only the origin. |
| 5.4 | **Pass.** Rechecked the undefined observer [x:y] on the constant origin curve, distinct resolved lift values, simple pole 1/t and identically-infinity exclusion. A resolution must include a lift. |
| 5.5 | **Pass.** Rechecked a pole of order three, reciprocal continuation for q-prime=q^2, essential-singularity two-path limits and sqrt(t) deck monodromy. Only a defined admissible observer gives the finite-pole conclusion. |

The seven older core repairs remain closed after the listed independent regressions: C01 (adjoint/projective carrier), C02 (labelled counts), C03 (rank-zero exclusion), C04 (early unfolding and closedness ownership), C05 (native §5.2 headline), C06 (splitting strata), and C07 (nontrivial monodromy/descent). The earlier C05 model-inference caveat is now addressed by CORE-R2-02. None of these closures claims a successful build.

## Assigned seeded source review

The assigned fresh core sample is **1.1, 1.3, 3.3 and 5.1–5.5**. The exact cached primary passages were directly read in R3. The seed, primary-source URLs/PDF hashes and text hashes are recorded in the ledger. Source conditions were retained rather than extended silently to the roadmap's broader owned constructions.

| Target | Directly read passages | Scope result |
|---|---|---|
| 1.1 | I23.txt:289–340; I23.txt:810–858 | Definitions 2.1–2.2, 2.8 and Remark 2.9 use full bundles with stated generic logarithmic/unramified/factorized-ramified structures. Stability tests invariant subbundles. No global rank-r trace-subtraction construction is supplied. |
| 1.3 | VDPS09.txt:1148–1238; I23.txt:3950–3988 | VDPS09 section 2.2/Table 1 classifies underlying profiles and constructs reduced times, and distinguishes full bundles from a trivial-bundle open chart. I23 Theorem 7.5 supplies the downstream nonempty-moduli dimension formula, not an input dimension assumption. |
| 3.3 | I23.txt:8445–8494; I23.txt:8747–8795; I23.txt:8907–8948; BOA01.txt:2263–2308,2523–2544 | I23 Definition 11.4 and Corollary 11.8 use the actual strong product comparison to prove total-form closedness. BOA01 Theorems 7.1/7.3 retain their generic diagonal/distinct-pole scope. Arbitrary flat splittings are not automatically symplectic. |
| 5.1 | IIS06.txt:135–185; I23.txt:8747–8795 | IIS06 Definitions 2.1–2.2 and Remark 2.3 distinguish local solution existence from global continuation. I23 (11.5) is an actual analytic product. The local holomorphic-lift supplier gap is precisely stated. |
| 5.2 | IIS06.txt:290–325; Mathlib/Analysis/ODE/PicardLindelof.lean:70–113; Mathlib/Analysis/ODE/ExistUnique.lean:35–88,180–213; Mathlib/Topology/Maps/Proper/Basic.lean:207–213; TauCeti/Geometry/Manifold/IntegralCurve/Maximal.lean:356–381 | IIS06 Lemma 2.12 traps existing lifts above compact target paths, with exceptional-strata compatibility. The real ODE floor permits continuous time; the autonomous compact-extension theorem requires C1. The new adapter owns precisely the missing nonautonomous chart/gluing proof. |
| 5.3 | IIS06.txt:1160–1205; BOA01.txt:2263–2308,2523–2544 | Flat character-family transport gives homotopy dependence. Universal-cover sections and fixed-point descent are distinct claims; the explicit -I test is a genuine nontriviality check. |
| 5.4 | STT02.txt:1407–1482; VDPS09.txt:2315–2360; IIS06.txt:2320–2355 | The sources construct coordinate/Hamiltonian descriptions on actual admitted charts. They do not make rational observers defined at indeterminacy; that comparison and resolution/lift condition remain owned. |
| 5.5 | IIS06.txt:2320–2355; TauCeti/Analysis/Complex/RiemannSurface/Meromorphic.lean:67–90,160–190 | IIS06 Theorem 10.12 supports scalar continuation from geometry and algebraicity. Tau Ceti defines meromorphy and holomorphic composition/order on Riemann surfaces; the higher-dimensional observer bridge and non-identically-infinity condition remain needed. |

The changed native claims were checked in actual files at the stated revisions. `IsPicardLindelof` has time continuity, phase Lipschitzness, a norm bound and an interval-radius condition. `exists_eq_forall_mem_Icc_hasDerivWithinAt` produces local solutions; `ODE_solution_unique_of_mem_Icc_right` requires the actual right-derivative/domain premises used by gluing. The Grönwall declarations estimate existing trajectories. The manifold chart adapter matches `ChartField`, and the autonomous maximal-curve theorem really requires a C¹ tangent section. `IsProperMap.isCompact_preimage` and `Manifold.metrizableSpace` supply the claimed compactness and metric floors. Exact native paths, line windows and file hashes are in the ledger.

For the unselected unchanged core targets, the exact R2 source checks and locator boundaries were retained and independently checked for applicability. No fresh full-source read is claimed for those targets. This distinction is recorded per row, and the R2 numerical witnesses are explicitly attributed.

## Changed §11.1 endpoint consistency

The changed collision input now requires primitive endpoints to satisfy **the full §1.3 restrictions**: genus zero, rank two, structural degree four, admitted local structures, regular-singular determinant with compatible residue/time transport, an actual reduced versal time problem, generic weights and nonempty stable fibers. Matching projective slopes or trace-free deformation ranks cannot replace these conditions. Boundary endpoints record their actual reduced/local conditions and the determinant or leading-term restrictions that fail, and require a separate scalar dictionary/first-jet comparison.

The added counterexample is effective: `B=diag(1,2)` has the same projective slope-one form as its trace-free part, but the limiting determinant contains `3T dz/z²`. The scalar term disappears from the commutator complex without making the determinant regular singular. This input is consequently excluded from the primitive classical domain. The global coefficient test now explicitly imposes `tr(B)=0` and leaves the full endpoint, stability, exponent-map and time-comparison verification as work required before promotion to a moduli arrow. This is consistent with the core §1.3 contract. Detailed confluence-source closure is the separate geometry/tau review's assignment; it is not inferred from the generic ODE theorem.

## Dependency and completion boundary

Substantial future construction and proof work remains: all-strata analytic RH and whole-family properness, ramified comparisons, early deformation/trace-form quasi-isomorphisms, the precisely named holomorphic-horizontal-lift gap, and confluence-family common-chart estimates. These are genuinely owned targets or explicit supplier gaps. In this frozen version they are not represented as implemented native results, assumed complete solution operators, or circular inputs from later layers.

No P1/P2/P3 source-level finding is emitted. The review's zero-finding result remains conditional on the explicit unpassed compiler and different-model-family gates. It does not establish official Worker acceptance, a passing Lean build, or completed proofs.

Only `core_report.md`, `core_findings.json` and `core_ledger.json` were written in Round 3. No canonical/frozen artifact was modified; Worker and GitHub were not used.
