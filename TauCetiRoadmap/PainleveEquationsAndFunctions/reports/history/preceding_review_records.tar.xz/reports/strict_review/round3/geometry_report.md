# Review of PainleveEquationsAndFunctions (geometry and closure, round 3)

**Scoped verdict: no actionable substantive findings.** All eleven assigned targets retain a clean mathematical disposition. The previous P2 finding `R2-GEOM-11.1-CLASSICAL-ENDPOINT` is repaired and closed, including its downstream interface with §11.3. There are no new P1, P2 or P3 findings from this review.

This is a manual application of the actual Worker review and red-team contracts. It is **not official Worker acceptance**: no Worker job was run, no Lean elaboration succeeded in this review, and a distinct-model-family review gate was not obtained. The frozen artifact and canonical roadmap were not edited. Precise owned future proofs and the two named supplier gaps remain obligations, rather than being relabeled as completed theorems or defects merely because they are substantial.

## Identity and evidence provenance

The reviewed artifact is `_strict_review/round3/artifact`. Its exact hashes appear here and in both JSON deliverables.

| Artifact | SHA-256 |
|---|---|
| `README.md` | `b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502` |
| `design/plan.json` | `1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10` |
| `Suggested.lean` | `74eeedeeb47cc963f1c2c28382b5fb901a85df34e0f521e7cc7fa4fcccf5afa6` |
| `sources.toml` | `4672489cf0d2ab9abb4d3a8a5b4b92ac53c4da86861c24c8a71910db4f446ad7` |

The protocol and actual Worker prompts were read, including `review.md`, `redteam.md`, `redteam-section.md`, and the adversarial, defect-class, gap/order and Lean-form rules under `_research/worker_contract_sources`. The Worker revision recorded by the protocol is `46e12afb791b1efab8fd8b3285370d689ba2e7b8`.

The substantive scope is §§6.1–6.3, §§7.1–7.3 and §§9.1–9.5, with the §1.3/1.4 input/classification interface, the repaired §11.1 domain and §11.3 cascade interface. The full internal dependency graph was traversed independently. The additional source sample fixed by Round 3 is **6.2, 6.3, 7.2, 9.4**.

Each of the eleven README sections and its complete plan target object is unchanged from Round 2. Section 11.3 is also unchanged; §11.1 is changed. These are direct equality checks against the frozen snapshots, not an inference from the absence of a reported edit. The ledger records both section hashes and equality results.

Round 2's geometry calculation record contains 68 records and 39 exact residual controls with no unexpected nonzero residuals. They are reused as **earlier recorded computations**, after the formula-bearing sections and target objects were verified unchanged. This review did not run that SymPy script again. Parent-reported portability work encountered a missing old vendor path; it must not be represented as a fresh successful geometry run. Fresh work here consists of source-locator reads, exact hashes/equality checks, a dependency-graph traversal, direct mathematical regression reasoning, and small `fractions.Fraction` calculations on the repaired determinant example.

## Closure of R2-GEOM-11.1-CLASSICAL-ENDPOINT

### What was missing

The previous collision-domain specification did not explicitly reimpose every §1.3 restriction on its primitive endpoints. Projective formal data and trace-free deformation ranks cannot see an irregular central determinant term. A determinant comparison by itself does not require the determinant to be regular singular. This was an interface hypothesis defect, not a claim that the earlier coefficient example already proved a global stable moduli arrow.

### What now closes it

The repaired §11.1 says:

> The admitted primitive classical domain first requires both primitive endpoints to be objects of §1.3

It immediately spells out genus zero, rank two, structural degree four, the admitted formal structures, a regular-singular determinant with compatible fixed-residue time transport, the actual reduced versal time problem, generic weights and nonempty stable fibers. It explicitly rejects substitution of projective slopes or trace-free ranks for this condition. Neither time/phase dimension conclusions nor equality of horizontal distributions becomes a field of the definition. The plan statement and hypotheses contain the same restriction; Checks 5–6 encode the positive determinant restriction and the negative witness.

The separate boundary paragraph records the actual reduced local/structural data, determinant pole order and failed rank or leading-term conditions. It grants an elementary scalar arrow only after the separate §9.3 dictionary and phase/first-jet comparison. A component lacking the verified regular comparison receives no solution-convergence arrow. Thus narrowing the primitive domain has not silently promoted every excluded endpoint into an asserted elementary case.

### Fresh witness and repair test

For the changed global check, the collision part satisfies the exact identity

\[
-\frac{B}{\varepsilon z}+\frac{B}{\varepsilon(z-\varepsilon T)}
=\frac{BT}{z(z-\varepsilon T)}
\longrightarrow \frac{BT}{z^2}.
\]

The fixed simple-pole terms contribute `tr(C)/z + tr(D)/(z−1)`; they cannot cancel the second-order determinant coefficient. At `T=1`, `z=2`, `ε=1/10`, fresh rational arithmetic gives:

| Coefficient B | Separated expression and single-fraction expression | Trace at ε=1/10 | Trace limit | Domain consequence |
|---|---|---:|---:|---|
| diag(1,−1) | diag(5/19,−5/19) on both sides | 0 | 0 | Passes this determinant-leading-term check |
| diag(1,2) | diag(5/19,10/19) on both sides | 15/19 | 3/4 | Rejected as primitive: trace limit is 3T/z² |
| diag(−1/2,1/2) | diag(−5/38,5/38) on both sides | 0 | 0 | The trace-free part of the negative example |

Every exact arithmetic residual in this small retest is zero. The last two matrices differ by `(3/2)I` and have identical trace-free parts. Commutators with this central addition vanish; the invariant-subbundle condition is likewise unchanged by a scalar connection twist. This is precisely why the new determinant endpoint predicate, rather than a rank calculation, is necessary and sufficient to reject this witness.

Passing the determinant test does **not** establish a stable nonempty global collision family. The repaired check correctly requires the other §1.3 conditions, exponent map and time comparison before promotion to a moduli arrow. Genus zero and the reduced versal time problem are now explicit too; no unsupported genus-one dimension counterexample is needed for that part of the closure.

### Downstream §11.3

The generated cascade uses verified §11.1 collision-data arrows on their actual domains. A nonzero lower coefficient can produce a ramified endpoint; a removable or vanishing-leading limit is recorded in its actual new stratum or as a marked lower-complexity boundary. An elementary scalar comparison still requires the proved first-jet dictionary. Composition retains the determinant comparison, labels, parameter covers and time maps, and does not exchange limits without uniformity.

The old domain omission therefore does not survive through §11.3. The retained Round 2 local controls distinguish `E12/z² + E21/z` (projective slope 1/2), the removable `E12/z²`, and semisimple trace-free double-pole data (slope 1). They share the collision divisor but not the endpoint formal condition. Their calculations were reused, not rerun. **Closure disposition: repaired and regression checked.**

## Fresh seeded source checks

Sources were inspected in the actual cached primary text with binary-safe reads; their text and PDF SHA-256 hashes are recorded in the ledger. DLMF was read through its public section URLs, with the returned evidence cached separately. Its cache hash identifies the serialized retrieved response, not a complete raw HTML snapshot.

| Target | Actual locator read | Source scope checked | Result for the roadmap |
|---|---|---|---|
| 6.2 | STT02 Proposition 1.2/Tables 2–3, printed pp. 7–8; VDPS09 introduction and §2.2/Table 1, pp. 18–19; IIS06 §10, especially Theorems 10.6 and 10.10, pp. 49–51 | The pair classification gives the additive SNC boundary diagrams. VDPS09 gives ten formal families and chosen affine charts and explicitly conjectures the general full compactification; its strong RH restrictions in two cases do not cover all bundles. IIS06 provides PVI comparisons on specified opens and transported charts. | The full connection-moduli compactification, exceptional/nontrivial-bundle charts, overlaps and form/distribution comparison remain owned by §6.2. No generic affine chart or conjecture is imported as the global theorem. |
| 6.3 | TER02 Theorem 2.1/Proposition 2.1 and Conjecture 2.1; STT02 Theorem 3.1/Conjecture 3.1 and Proposition 3.2; ST04 Appendix A, printed p. 27 | The first boundary layer has dimension one and injects into supported H1. The connecting map is the intersection matrix in the stated bases. Full supported-cohomology equality is a separate assertion; ST04 Theorem A.2 is generic and excludes D7. | The roadmap claims the first-layer line with its injection, then owns its relative constant-rank, base-change and Kodaira–Spencer comparison. It does not promote the injection or restricted generic theorem to unrestricted H1_D dimension one. |
| 7.2 | IIS06 Theorem 7.4/Remark 7.5(2), printed p. 38; Theorem 10.13, printed p. 52; STT02 pair model | The central PVI reflection is not one of the simple gauge transformations. The source's phase formulas are rational, with denominators and changed parameters. | An additional marked-pair construction is owned. Its effectivity domain, horizontal/symplectic transport, relations and extensions must be proved. The PVI source is not promoted to a construction for every profile. |
| 9.4 | VDPS09 §4.1 and §4.3 equations (2)–(5), printed pp. 31, 34–35; DLMF §§32.6–32.7; IIS06 Theorem 10.13; BERT17 Proposition 2.3 and Theorem 3.3, printed pp. 5 and 10 | Source-form sign and PV elimination must be corrected; sigma inverses and rational transformations need their genuine domains. BERT17's variation and contour-transition formula apply to its specific analytic RHP factorization and contour assumptions. | The roadmap explicitly derives the sign adapter, uses the corrected PV equation, restricts sigma reconstruction, and tracks frame/normalization data. No source gives a universal unqualified converse or an unrestricted time-only tau multiplier. |

The relevant supplier contracts were also read at their actual scope. `ComplexComparisonPartII` C3.2d.2 requires proper flat finite presentation and universal functions for the Picard algebraic space; C3.2f.1–2 retains the full component and distinguishes reduced-base smoothness from the additional formal-smoothness condition over nonreduced bases. `JacobianChallenge` Layer C distinguishes flat base change, coherent cohomology/base change and its reduced-base Grauert criterion. Sections 6.1 and 6.3 require proving the corresponding hypotheses for the actual boundary family. A smooth-curve Jacobian theorem is not substituted for them.

## Adversarial ledger: all eleven targets

The calculations in the following table are explicitly attributed to the earlier Round 2 records unless marked fresh above. Every target also had its current statement, hypotheses, API/check scope and dependencies inspected. Each receives **no actionable substantive findings**. The full JSON ledger retains the earlier concrete witness strings and their provenance.

| Target | Discriminating evidence and computed values | Scope retained |
|---|---|---|
| 6.1 | A smooth elliptic anticanonical curve has elliptic Pic⁰; a rational triangle has dual-graph b1=1 and multiplicative Pic⁰. Both fail the additive condition. All eight affine D/E matrices have a positive kernel of nullity one; D8 uses multiplicities (1,1,2,2,2,2,2,1,1). | The definition keeps D8 and excludes the extra affine-plane axiom. Relative Picard and normalization/unit calculations remain actual constructions. |
| 6.2 | The eight matrix ranks are 4,5,6,7,8,6,7,8 for D4,D5,D6,D7,D8,E6,E7,E8, each with nullity one. Ten formal profiles are not collapsed to eight moduli families. | Intersection matrices and the source table do not construct the full moduli-space complement. Exceptional and nontrivial bundles remain covered by the owned theorem. |
| 6.3 | For affine D4, δ=(2,1,1,1,1) gives Mδ=0 and rank 4. The injection C→C² shows that a one-dimensional source need not exhaust its target. Over A=C[ε]/ε², ker(ε) has length 1 rather than the free module's length 2; its base-change map to the fiber kernel can be zero. | The theorem is about the first layer, with relative constant-rank and KS comparison. Constant geometric fiber dimensions alone do not prove nonreduced-base freeness or arbitrary base change. |
| 7.1 | The invariant-flag negative modification lowers degree by 1 and raises one residue by 1; tensoring by L changes determinant by L². The R1 negative invariant-flag control produces a double pole when the flag is not preserved. | Domain, determinant/exponent, weight and flag changes are retained. A logarithmic example does not prove all ramified strong-extension compatibility. |
| 7.2 | κ=(1/2,0,0,0,0) maps to (−1/2,1/2,1/2,1/2,1/2), preserving 2κ0+Σκj=1. Keeping the old κ0 would instead give 3. The correct parameter reflection squares to the identity. | A lattice calculation does not construct an effective surface map. Rational phase formulas do not assert extension across their denominator divisors. |
| 7.3 | Under u=1/q, a quadratic vector field remains regular, whereas q′=q³ gives u′=−1/u. The projectivization of a rank-two linear system gives q′=a q²+b q+c. A nodal −2 curve has h0(O(−2))=0 and h1(O(−2))=1. | Local curve-family obstructions, base change, descent and rank-two lifting are owned. Riccati is not equated with every reducible or rational solution. |
| 9.1 | For A=p, B=q+t the first-jet elimination gives q″=q+t. A=0 loses momentum; A=p² has two inverse branches even where its derivative is nonzero. | The inverse is on the actual holomorphic image; local derivative nondegeneracy is not global injectivity. Undefined q=0 scalar loci are not added by clearing denominators. |
| 9.2 | All retained equation-comparison residuals vanish, or vanish after the stated c³=2/c⁵=2 root reduction. Recorded nontrivial samples include PV 39/2, dPV 24, D6 397/2, D7 1199/6, D8 227/6, IV 168 and JM-II 125/2 on their specified common sample. | These are identities for explicit dictionaries, not proofs of their geometric construction or global extension. Covers, roots, first-jet images and parameter conventions remain specified. |
| 9.3 | The 16 binary PIII coefficient patterns split 4 D6, 4 D7, 1 D8, 7 elementary. Inversion sends (α,β,γ,δ) to (−β,−α,−δ,−γ). All-zero PIII gives q=C exp(μ log t) locally on t≠0 with C≠0. | Branch choices and original equation domains survive. The scalar boundary partition does not by itself establish a geometric confluence arrow. |
| 9.4 | The corrected PV system gives q″=2 at the stated sample, versus 7/2 from the printed source scalar equation. For PI, σ=at+2a³ satisfies the sigma relation but q=−a has residual −6a²−t. For PII at c=0,p=0, distinct Riccati initial q give the same σ=0. | Forward identities are separated from converses, derivative divisions have genuine domains, and phase information is retained when sigma collapses it. |
| 9.5 | The α=0 seed (q,p)=(0,t/2) has derivatives (0,1/2); the α=1 seed (−1/t,2/t²+t/2) has derivatives (1/t²,−4/t³+1/2), with all four Hamilton residuals zero. At α=−1/2,p=0, q=u′/u reduces to u″=−tu/2. | The second seed needs t≠0 and the logarithmic derivative needs u≠0 or its proved projective interpretation. These controls do not classify all rational solutions. |

### Same-defect regression: noninvertible scalar presentations

The repaired endpoint problem was an example of a coarser invariant failing to retain required input data. I explicitly checked the analogous scalar loss in §9.4 rather than assuming every sigma equation is reversible.

For PI, differentiation of the sigma relation gives

\[
2\sigma''\bigl(\sigma'''+6(\sigma')^2+t\bigr)=0.
\]

On a connected analytic branch where σ″ is not identically zero, the second factor vanishes on an open set and hence identically. This gives PI for q=−σ′. If σ″ is identically zero, the original relation gives σ=at+2a³, whose reconstructed q does not solve PI on an open domain. This is exactly the exclusion in the roadmap.

For PII, with `c=α+1/2`, the Hamiltonian identity gives `σ′=−p/2` and `σ″=2qσ′−c/2`. The printed inverse therefore requires `σ′≠0`. At `c=0,p=0`, all local solutions of `q′=−q²−t/2` have σ=0, despite different initial q. Retaining the phase/initial-point data is necessary; an analytic extension across isolated zeros in a reconstructible branch cannot recover information erased on an entire invariant locus. The current text makes this distinction correctly.

## Dependency and source-facing integration

The fresh graph traversal found **44 targets, 216 internal prerequisite edges, no missing target reference and no cycle**. The plan records **27 supplier contracts and two precise named gaps**. No target in Layers 1–8 has a transitive dependency on Layer 9. Section 11.1 depends on the constructed input/moduli/dynamics and, where used, §6.2; it does not consume a scalar classification to define its collision datum. Section 11.3 receives Layer 9's actual dictionaries only as downstream comparison data.

The README's Needs lines and its build direction agree with that separation. The intrinsic input is decorated connection data with local formal, determinant and deformation conditions; ten unordered profiles, seventeen ordered shapes, dimension conclusions, boundary labels and scalar equations are outputs. `Suggested.lean` also keeps the missing intrinsic carriers explicit in its module documentation rather than inserting a finite classification tag or an assumed comparison into a stand-in definition. Its generic native-manifold statements are handled in the parent/core review; this geometric review is not an elaboration or a proof of those theorems.

The source-facing obligations in §§6.2, 6.3, 7.2 and 11.1 remain precise and assigned: full compactification; relative boundary-line/KS identification; effective marked-pair reflection action and compatibility; collision/reduction/field-comparison construction. Their being future proofs is allowed by the actual Worker contract. They would become defects if replaced by a generic chart, a conjecture, a real-only supplier promoted to a complex theorem, or an equality included among the input fields; none of those substitutions occurs in the inspected interfaces.

The named gaps remain `holomorphic-horizontal-lifts` and `complex-holomorphic-determinant-family`. They are conditional upstream contracts with specified suppliers and downstream users, rather than unowned blanket assumptions. This review checked the full internal graph and relevant source/Picard/base-change scope. The parent integration reviewer owns the complete current-supplier freshness and duplication audit; no claim is made here to have independently refreshed every external roadmap.

## Source issues retained and confirmed

These are source issues already corrected or explicitly restricted by the roadmap, not new roadmap findings.

- **Error** in VDPS09 at §4.1, printed p. 31: the displayed extended form uses the wrong Hamiltonian-term sign for the displayed evolution equations; use `dp∧dq/F + dH∧dt`; affects a stated formula.
- **Error** in VDPS09 at §4.3 equation (3), printed p. 34: its exponent contribution disagrees with the adjacent system and Hamiltonian; use `[θ0²(q−1)²−θ1²q²]/[2q(q−1)t²]`; affects a stated formula.
- **Error** in DLMF at §32.6(ii), converse following 32.6.6: the unrestricted sigma-to-PI converse includes linear spurious branches; require the analytic nonidentically-zero σ″ branch and continuation; affects a stated result.

The GMR23 scaling/sign issues and their corrected adapters are retained from the prior review and read in the current §11.1 interface. This reviewer did not refetch that primary source for the unchanged formulas, and does not present that as a new Round 3 primary-source check.

## Not verifiable and limits

No Lean runtime certificate is available: the reported launcher fails with `failed to locate application`. No distinct-model-family gate was obtained, and no official Worker acceptance is asserted. The frozen mathematical roadmap is a plan: no global compactification, all-profile symmetry, relative base-change theorem, irregular Riemann–Hilbert theorem or collision convergence theorem has thereby been proved. Finite exact controls have their stated scope and do not discharge those constructions.

All eleven assigned targets have a disposition and concrete evidence in `geometry_ledger.json`. `geometry_findings.json` has an empty new-finding list and the complete old-finding closure record. The frozen hashes were checked again on completion.
