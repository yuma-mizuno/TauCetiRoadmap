from pathlib import Path
from fractions import Fraction as Q
import copy, hashlib, json, re, math
ROOT=Path('/workspace/scratch/58443e4fc6da')
OUT=ROOT/'_strict_review/round3'
A=OUT/'artifact'
R2=ROOT/'_strict_review/round2'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
ids=['8.1','8.2','8.3','8.4','10.1','10.2','10.3','10.4','11.1','11.2','11.3','11.4']
expected={'README.md':'b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502','design/plan.json':'1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10','Suggested.lean':'74eeedeeb47cc963f1c2c28382b5fb901a85df34e0f521e7cc7fa4fcccf5afa6'}
assert all(sha(A/k)==v for k,v in expected.items())
plan=json.loads((A/'design/plan.json').read_text())
pt={t['id']:t for l in plan['layers'] for t in l['targets'] if t['id'] in ids}
d=copy.deepcopy(json.loads((R2/'tau_ledger.json').read_text()))
new=(A/'README.md').read_text(); old=(R2/'artifact/README.md').read_text()
def sec(txt,k):
 m=re.search(r'^### '+re.escape(k)+r'\s',txt,re.M); assert m,k
 n=re.search(r'^### \d+\.\d+\s',txt[m.end():],re.M)
 end=m.end()+n.start() if n else len(txt)
 return txt[m.start():end],txt[:m.start()].count('\n')+1
sections={}
for k in ids:
 ns,ln=sec(new,k); os,_=sec(old,k)
 sections[k]={'sha256':hashlib.sha256(ns.encode()).hexdigest(),'byte_identical_to_round2':ns==os,'readme_start_line':ln,'readme_end_line':ln+ns.count('\n')}
source_hashes={k:sha(ROOT/k) for k in d['source_text_sha256']}
assert source_hashes==d['source_text_sha256']
# Only changed mathematical witnesses are evaluated anew. Earlier examples retain their R2 provenance.
comp={'snapshot_hashes':expected,'provenance':'Fresh exact Round 3 checks for repaired 11.1/11.2 only. All unchanged-target calculations are attributed to Round 2 after byte comparison and critical rereading. These examples are not formal proofs.','cases':{}}
for n in [2,3,7]:
 eps=Q(1,n+1); err=2*eps
 assert err==Q(2,n+1)
 comp['cases'][f'constant_field_n{n}']={'epsilon':str(eps),'interval':[0,2],'solution':'t/(n+1)','sup_error':str(err),'bound':str(2*eps),'strict_radius_one':err<1}
eps=Q(1,4)
# Two actual affine coordinate systems u=x, v=2x+5, cuts 0,1,2.
xcut=eps; xend=eps+eps/2
assert 2*xend==2*xcut+eps==Q(3,4)
comp['cases']['two_chart']={'cuts':[0,1,2],'charts':['u=x','v=2x+5'],'intrinsic_fields':['epsilon','epsilon/2'],'coordinate_fields':['epsilon','epsilon'],'epsilon':'1/4','segment1_end_chart_error':'1/4','segment2_start_chart_error':'1/2','segment2_end_chart_error':str(2*xend),'segment2_bound':str(2*xcut+eps),'radius':'1','strictly_inside':2*xend<1,'note':'The second chart estimate starts from its own inherited error; it does not restart from the original error. Different one-sided derivatives at the cut are allowed.'}
comp['cases']['continuous_time']={'reference_field':'abs(t-1/2)','approximate_field':'abs(t-1/2)+epsilon','reference_solution_first_half':'t/2-t^2/2','reference_solution_second_half':'t^2/2-t/2+1/4','initial':'0','L':'0','delta':'epsilon','solution_difference':'epsilon*t','sup_error_on_0_1':'epsilon','hypothesis_check':'The time field is continuous but not C1 at 1/2. The native theorem and 5.2 continuous-time floor permit it.'}
comp['cases']['non_lipschitz_excluded']={'field':'2*sqrt(abs(x))','reference_solution':'0','initial_n':'1/(n+1)^2','approximating_solution':'(1/(n+1)+t)^2','defect':'0','initial_limit':'0','solution_limit':'t^2','failed_hypothesis':'No common phase Lipschitz constant on a positive-radius ball about zero. Difference quotient at h>0 equals 2/sqrt(h), unbounded.'}
comp['cases']['path_velocity']={'geometric_field':'epsilon','path':'gamma(s)=2*s, 0<=s<=1','pulled_back_field':'2*epsilon','delta':'2*epsilon','parameter_interval_duration':'1','sup_error':'2*epsilon','bound':'2*epsilon'}
T=Q(2)
assert T*(1+2)==6 and T*(1-1)==0
comp['cases']['endpoint_domain']={'T':str(T),'positive_B':'diag(1,-1)','positive_double_pole_trace':str(T*(1-1)),'negative_B':'diag(1,2)','negative_double_pole_trace':str(T*(1+2)),'negative_tracefree_part':'diag(-1/2,1/2)','negative_projective_slope':'1','negative_disposition':'Excluded from primitive classical endpoint by regular-singular determinant condition in full 1.3. Adjoint ranks or stability cannot readmit it.','positive_disposition':'Passes only this determinant-pole test; remaining full 1.3 hypotheses must still be checked before a moduli arrow exists.','genus_test':'Any positive-genus endpoint fails the explicit genus-zero condition even with the same local projective profile.'}
(OUT/'tau_computations.json').write_text(json.dumps(comp,ensure_ascii=False,indent=2)+'\n')
closures=[
 {'id':'TAU-R2-01','priority':'P2','status':'closed','targets':['11.2','Suggested.lean'],'repair_quote':'The reference trajectory is the only assumed solution.','location':'Suggested.lean:169–253; README.md §11.2 and §5.2; plan target 11.2','evidence':'The native finite-chart theorem quantifies genuine tangent fields, within-derivative trajectory equations, fixed positive-radius tubes, joint continuity, a common phase Lipschitz constant, uniform field defects tending to zero, and convergent initial values. It concludes eventual full-interval trajectories, initial matching, strict tube containment, segment estimates and TendstoUniformlyOn. The no-exit conclusion is not an input or a wrapper around assumed membership. Exact constant-field, affine-chart and continuous-time witnesses pass. Core reviewer owns elaboration/API details; this closure concerns mathematical correspondence.'},
 {'id':'TAU-R2-02','priority':'P2','status':'closed','targets':['11.1','11.3'],'repair_quote':'both primitive endpoints to be objects of §1.3','location':'README.md §11.1; plan target 11.1, including Check5 and new Check6','evidence':'The carrier now explicitly requires genus zero, rank two, structural degree four, admitted local conditions, regular-singular determinant with fixed-residue compatible transport, actual reduced versal time problem, generic weights and nonempty stable fibers. Boundary endpoints are separately computed and marked. Global positive tests impose tr(B)=0; B=diag(1,2) has determinant term 3T dz/z² and is explicitly excluded, despite unchanged projective slope and adjoint data.'}
]
d.update(snapshot=str(A),readme_sha256=expected['README.md'],plan_sha256=expected['design/plan.json'],suggested_lean_sha256=expected['Suggested.lean'],status='complete',verdict='conditional_mathematical_design_pass',official_worker_acceptance=False,target_count=len(ids),api_count=sum(len(pt[k]['api']) for k in ids),check_count=sum(len(pt[k]['tests']) for k in ids),method='Independent read-only Round 3 strict closure review. All twelve targets critically reread. Ten unchanged README target sections are byte-identical to Round 2; their specifically attributed computed witnesses are reused, not rerun or treated as automatic verdicts. Repaired 11.1/11.2 passages have fresh mathematical correspondence and exact witnesses. All current API and Check texts are mapped individually. Fresh assigned sources 8.3,10.4,11.4 were read at primary locators.',fresh_source_sample=['8.3','10.4','11.4'],computed_supplement=str(OUT/'tau_computations.json'),computation_script=str(OUT/'tau_finalize.py'),source_text_sha256=source_hashes,all_reused_source_hashes_unchanged=True,findings=[],round2_finding_closures=closures,section_byte_comparisons=sections)
d['limitations']=[
 'No Worker entrypoint, lane, board, provider job or GitHub mutation was run by this reviewer.',
 'The required distinct-model-family review gate is unmet; this reviewer cannot supply independent-family provenance.',
 'The pinned Lean runtime could not start in this session; this reviewer did not rerun that failed environment gate and has no successful elaboration evidence. Native API/static checks are separately assigned to the core reviewer.',
 'The admitted future theorem proofs remain future work. This is mathematical design/contract review, not theorem verification or completed formalization.',
 'FIKN was not independently retrieved; the uniform HM closed-sector theorem is an expressly owned local target, not an assertion that the book proves it.',
 'Cached/current supplier files were independently reread. The latest-main identifier c9a16a043c3bf2321c63dff75e3f709466373528 is supplied by the parent; this reviewer made no new remote/open-PR ownership search.'
]
d['acceptance_gates']={'mathematical_contract_review':'pass with zero concrete actionable findings','lean_elaboration':'unmet: pinned runtime startup failure recorded in this session','distinct_model_family':'unmet','official_worker_run':'forbidden and not run','overall_worker_acceptance':False}
d['reused_computation_provenance']={'ledger':str(R2/'tau_ledger.json'),'ledger_sha256':sha(R2/'tau_ledger.json'),'report':str(R2/'tau_report.md'),'computation_script':str(R2/'tau_compute.py'),'computed_results':str(R2/'tau_computations.json'),'results_sha256':sha(R2/'tau_computations.json'),'use':'Exact calculations retained after section byte equality and independent critical rereading; previous verdicts are replaced by this round dispositions. The all-r Laurent/sign calculations remain unchanged within changed 11.1 and were individually cross-read.'}
for x in d['prior_findings']:
 x['status']='closed_regression_maintained'
 if x['id']=='TAU-R1-03':x['evidence']='The collision-data groupoid retains leading orbit, lower coefficients, labels, determinant comparison, exponent/time maps, descent and a rank-defined regular comparison locus; slopes 1,1/2,0 remain distinct. R3 additionally supplies the full primitive endpoint restriction in 1.3, closing the separate TAU-R2-02; unverified components still have no convergence arrow.'
d['current_supplier_refresh'].update(inspection='Independently reread the supplied latest-main F0.0 file and delta in Round 3. Lines 1378–1386 retain real Banach models; 1488–1504 retain real determinant lines and continuous/smooth family transitions; 1506–1523 concern orientation transport, with extra connection/trivialization needed for linear transport. SHA256 independently recomputed and unchanged from the refreshed R2 file.',disposition='Still insufficient for the complex holomorphic determinant line/canonical section needed here. The explicit named F0.0C extension gap remains necessary and is neither silently discharged nor duplicated as a new generic supplier.')
rows={r['id']:r for r in d['rows']}
for k,r in rows.items():
 r['result']='conditional_contract_pass; zero concrete actionable findings'
 r['findings']=[]
 r['section_byte_comparison']=sections[k]
 r['evidence_provenance']={'round':'R3','critical_cross_read':'All frozen target text, its APIs/Checks, dependency contracts and relevant source scopes reread.','calculation_origin':'R2 exact instances/algebra retained after section byte equality; changed passages and altered conclusions separately checked in R3.' if sections[k]['byte_identical_to_round2'] else 'Unchanged formula blocks and exact algebra from R2 individually cross-read; repaired endpoint/native-theorem claims independently checked in R3, with fresh computations.','r2_row_id':k,'r2_ledger_sha256':sha(R2/'tau_ledger.json'),'fresh_source_sample':k in ['8.3','10.4','11.4']}
 r['dependency_contracts']=pt[k]['prerequisites']
 # Preserve individual computed API audits, but identify source prose inherited from R2 honestly.
 r['source_comparison']=[s.replace('Fresh sample:','R2 source comparison, retained after hash equality:') for s in r['source_comparison']]
 for a in r['api_audit']:
  match=[x for x in pt[k]['api'] if x['name']==a['name']]; assert len(match)==1
  a['statement']=match[0]['statement']
 old_checks={x['name']:x for x in r['check_audit']}
 r['check_audit']=[]
 for t in pt[k]['tests']:
  a=copy.deepcopy(old_checks.get(t['name'],{'name':t['name']}));a['statement']=t['statement'];r['check_audit'].append(a)
r=rows['11.1']
r['scope']='Collision-data groupoid with explicit full 1.3 conditions at both primitive classical endpoints, then a relation/KS rank-defined regular comparison locus. Boundary endpoints record actual structural/local conditions, determinant pole order and failed leading/rank conditions, and receive arrows only through separately proved dictionaries and first jets. The corrected all-r Laurent statement is coefficient convergence, not projective slope classification or automatic horizontal convergence. Negative-to-positive Poisson transport acts by fiber negation on every coefficient/exponent.'
r['instances'][9]['input']+=' For the primitive positive coefficient test impose tr(B)=0 and separately verify all 1.3 conditions.'
r['computed_right'][10]='The full 1.3 primitive endpoint condition now rejects this irregular determinant, independently of trace-free ranks/stability. Scalar adjoint invisibility is why the new determinant condition is necessary.'
r['instance_results'][4]='The three slope witnesses remain distinct collision data, and the last is a marked boundary. The primitive endpoint condition is now explicitly full 1.3; both old morphism/domain findings are closed.'
r['instance_results'][9]='The coefficient and infinity-residue computations pass. The positive primitive candidate requires tr(B)=0 and the full 1.3 checks before it is promoted to an arrow.'
r['instance_results'][10]='TAU-R2-02 closed: B=diag(1,2) is an explicit excluded non-example. At T=2 its double-pole determinant coefficient is 6; the trace-free B=diag(1,-1) test gives 0.'
r['api_audit'][0]['audit']='The actual groupoid records all geometric/formal data. The primitive domain now intersects it with both endpoints satisfying every named 1.3 condition, including genus zero and regular-singular determinant transport; then imposes actual relation and KS rank conditions. B=diag(1,2), invisible to adjoint ranks, is explicitly excluded by its determinant double pole. No dimension/distribution conclusion is inserted as an assumption.'
r['api_audit'][0]['disposition']='specified_contract_survives'
r['api_audit'][3]['audit']='Adapters are quantified over verified collision data, not an unstated list of scalar arrows. Leading and lower coefficients distinguish slopes 1,1/2,0. Primitive endpoints obey full 1.3; lower-complexity and scalar-irregular endpoints are separately computed/marked and require their own proved dictionary and phase/first-jet comparison before an arrow is admitted.'
r['api_audit'][3]['disposition']='specified_contract_survives'
r['check_audit'][2]['disposition']='The three identical-divisor coefficient choices retain slopes 1, 1/2 and 0; their formal data are distinct, the last is a marked boundary, and full 1.3 now gates primitive endpoints.'
r['check_audit'][4].update(witness='11.1:10; R3 endpoint_domain computation',disposition='Correct global coefficient and infinity residue. Trace-free B eliminates the determinant double pole; remaining full 1.3 obligations explicitly precede any moduli-arrow promotion.')
r['check_audit'][5].update(witness='11.1:11; R3 endpoint_domain computation',disposition='The determinant term is 3T dz/z², 6 dz/z² at T=2. This scalar-irregular endpoint fails the explicit primitive condition, although projective slope/adjoint ranks do not detect the scalar twist.')
r['fresh_endpoint_audit']={'positive':'diag(1,-1), T=2: determinant double-pole trace 0; not a complete moduli-arrow proof without remaining 1.3 conditions.','negative':'diag(1,2), T=2: determinant double-pole trace 6; excluded.','genus':'Positive genus is expressly excluded at both primitive endpoints.','boundary':'Recorded boundary data do not automatically become primitive classical endpoints or solution-convergence arrows.'}
r=rows['11.2']
r['scope']='The native generic theorem handles a sequence of actual nonautonomous tangent fields on a finite-dimensional real manifold, a finite ordered subdivision and fixed positive-radius closed chart tubes around a reference solution. It assumes joint continuity on those tubes, one common phase Lipschitz constant, uniform defect tending to zero and initial convergence. It constructs eventual full-interval solutions, strict tube containment, the quantitative per-segment estimate and manifold-valued uniform convergence. Complex parameters use arbitrary sequences on the admitted first-countable local cover; pulled fields include path velocity and l is parameter duration. No unbounded-time/singular-endpoint assertion.'
r['instances'][0]['input']='F_n=1/(n+1), F_0=0, initial 0 on [0,2].'
r['computed_left'][0]='x_n=t/(n+1), exact sup error 2/(n+1); n=3 gives 1/2.'
r['computed_right'][0]='(initial error+duration*delta_n)*exp(L*duration)=(0+2/(n+1))*1; strict radius-one containment for n>=2.'
r['instance_results'][0]='The new positive Check1 has exact equality and an eventual trapping threshold.'
r['computed_left'][5]='For gamma(s)=2s on [0,1] and geometric constant defect epsilon, the actual pulled field defect is 2 epsilon; parameter duration is 1.'
r['computed_right'][5]='The exact solution error and displayed bound are both 2 epsilon. Omitting gamma velocity would incorrectly give epsilon.'
r['instance_results'][5]='The R3 wording fixes the parameter-duration convention and incorporates path velocity in F itself; this replaces the earlier R2 arc-length shorthand.'
r['instances'][6]['input']='Native finite_chart_compact_path_no_exit_convergence, Suggested.lean:209–253, with actual fields/derivatives, finite chart tubes and only a reference solution.'
r['computed_left'][6]='No approximating x_n, existence on [a,b], or tube membership is an input. The output existential family has all these eventually, plus the per-segment bound and TendstoUniformlyOn.'
r['computed_right'][6]='Continuity in time and phase Lipschitz regularity give local solutions inside a moving tube. Gronwall plus strict margin rules out first exit, compact tube containment gives continuation, and finite chart transitions propagate cut-point convergence.'
r['instance_results'][6]='TAU-R2-01 closed at mathematical-design level: the theorem is genuinely the generic finite-chart existence/trapping/convergence claim, not a restated approximate-trajectory bound. Elaboration gate remains unmet.'
extra=[
 ('11.2:8','Two charts u=x, v=2x+5 and cuts 0,1,2; fields epsilon then epsilon/2; reference 0; epsilon=1/4.','Both coordinate field defects are epsilon, L=0; chart-2 starting error=1/2, ending error=3/4.','Bound in chart 2 is 1/2+1/4=3/4<1.','Finite-chart estimate uses inherited chart error; it is not reset at cuts.'),
 ('11.2:9','Continuous but non-C1 time field abs(t-1/2), perturbed by epsilon, on [0,1].','Reference solution is t/2-t²/2 before 1/2 and t²/2-t/2+1/4 after; perturbed difference is epsilon*t.','L=0, delta=epsilon, error at1=epsilon=bound.','The explicit 5.2 C0-time floor supports this valid case; C1 autonomization is not required.'),
 ('11.2:10','F_n=F_0=2sqrt(abs(x)), reference0, initial1/(n+1)².','Solutions (1/(n+1)+t)² converge to t², despite defect0 and initial convergence.','At h>0 the phase difference quotient is 2/sqrt(h), unbounded as h->0.','Correctly excluded by common Lipschitz regularity; the hypothesis is substantive.')]
for no,inp,left,right,res in extra:
 r['instances'].append({'case':no,'input':inp});r['computed_left'].append(left);r['computed_right'].append(right);r['instance_results'].append(res)
r['check_audit'][0].update(witness='11.2:1,11.2:3; R3 constant_field_n3',disposition='The positive sequence has exact error 2/(n+1) and eventual strict containment. Alternating initial points violate hinitial, so zero fields alone do not imply convergence.')
r['source_comparison']=[
 'Mathlib Analysis/ODE/Gronwall.lean:162–183 was reread: dist_le_of_approx_trajectories_ODE_of_mem assumes both trajectories and hfs/hgs membership. The new theorem concludes these for the approximation.',
 'TauCeti Analysis/ODE/SmoothParameter.lean:139–165 was reread: its C^(n+1) parameterized field/vanishing-base hypotheses are stronger and different. The 5.2 adapter explicitly owns the continuous-time, phase-Lipschitz local-extension route.',
 'GMR23 coefficient/Hamiltonian source comparisons are reused from the source-hash-identical R2 audit only; they are not asserted to supply the no-exit theorem.'
]
r['native_correspondence']={'definitions':['Breaks.segment','PiecewiseODEOn','ChartField','ChartTube'],'inputs_are_concrete':True,'approximating_solutions_are_assumed':False,'output_constructs_full_interval_solutions':True,'output_strict_trapping':True,'output_uniform_convergence':True,'finite_dimensionality':'Closed chart tubes over compact intervals are compact; inverse charts and finitely many overlap transitions have the needed compact uniform continuity. Global metric completeness/properness of M is not assumed or needed.','time_regularity':'Joint continuity restricted to the closed moving tube supplies local rectangular neighborhoods relative to each time segment. The positive radius and reference continuity give interior phase neighborhoods. Local one-sided extension handles endpoints.','cut_derivatives':'Within derivatives on each closed segment permit different one-sided velocities at a cut and global trajectory continuity.','initial_propagation':'Finite induction transfers convergent cut-point initial data through chart transitions. The segment bound uses the actual chart error at that cut.','metric':'MetricSpace M uses its own compatible topology; uniform convergence is recovered on the compact union of inverse chart tubes.','complex_parameters':'First-countable parameter cover plus arbitrary sequences and uniqueness of local solutions converts the sequential convergence statement to the intended local parameter limit; the quantitative margin argument gives eventual existence.','proof_status':'admitted future proof; not elaborated in this environment'}
r=rows['11.3']
r['scope']='Category generated by verified collision-data comparisons, with actual composition and phase/first-jet maps. Primitive endpoints now inherit the full 1.3 restriction in 11.1. Ramified/lower-complexity and nonzero restrictions remain explicit. No complete finite scalar cascade or commutation of successive limits is inferred from labels.'
if len(r['computed_right'])>3:r['computed_right'][3]='The current collision-data groupoid distinguishes identical-divisor slopes 1,1/2,0 and retains the lower coefficients and rank-regular comparison. Full 1.3 now gates primitive endpoints; only verified comparisons generate arrows.'
# Fresh source locators independently read in this round, distinct from unchanged witness reuse.
fresh={
 '8.3':[
  'BERT17.txt:318–370, Theorem2.2/Proposition2.3: normalized integrable RHP solvability and Fredholm variation; 822–869, formula(3.6) and the explicit factorization correction.',
  'BERT16.txt:78–121, Definition2.1/Theorem2.1, and 203–226, Theorem2.2: corrected vertex curvature and the local monodromy-only theta_V correction; raw/modified forms are not silently closed.',
  'BERT10.txt:1584–1608, Assumption3.1, and 2060–2088, Proposition5.1: generic unramified distinct eigenvalues/logarithmic nonresonance for the JMU restriction.'
 ],
 '10.4':[
  'VDPS09.txt:3524–3596, section4.10: PII scalar chart and Hamiltonian normalization; not used to supply HM analytic existence.',
  'RandomMatrices README:1046–1068, section8.5: real pole-free HM solution of q"=s q+2q³ with q~Ai and its Fredholm identities remain the external supplier.'
 ],
 '11.4':[
  'BERT17.txt:318–370 and 900–950, Theorem2.2/Proposition2.3/Theorem3.3: normalized determinant/frame comparison on the specified invertible contour domain; not arbitrary endpoint asymptotic convergence.',
  'BERT16.txt:203–226, Theorem2.2: dlog tau equals the corrected one-form with theta_V; 11.4 retains actual frame corrections and separately normalized integration.',
  'HeegaardFloer current README:1376–1429,1479–1530 and F0.0.delta.patch: the refreshed determinant family is still real continuous/smooth; complex holomorphic F0.0C remains a named gap.'
 ]}
for k,v in fresh.items():rows[k]['fresh_source_locator_audit']={'seed':json.loads((OUT/'seeded_source_sample.json').read_text())['seed'],'locators':v,'disposition':'Source scope matches the frozen claim; no concrete mismatch identified. The requested analytic/gluing extensions remain explicit owned proof targets where the source does not supply them.'}
d['supplier_contract_audit']=[
 {'supplier':'HeegaardFloer F0.0 / complex extension F0.0C','disposition':'Current real determinant family does not discharge complex holomorphic family/canonical section gap; gap retained.', 'locator':'current_sources/HeegaardFloer.current.md:1376–1429,1479–1530'},
 {'supplier':'OperatorTheory/OperatorIdeals OI-B23/OI-B29/OI-B30','disposition':'General trace-class completeness/norm and family contracts are reused; no positivity is smuggled into arbitrary IIKS kernels.','locator':'README.md:350–354'},
 {'supplier':'RandomMatrices 8.3/8.5','disposition':'General trace-class Fredholm floor precedes DPP specialization. HM real Airy-normalized existence/uniqueness remains external, local phase/chart adapter remains local.','locator':'README.md:984–1029,1046–1068'},
 {'supplier':'ToeplitzOperators matrix-symbol Fredholm theorem','disposition':'Fredholm index=-winding determinant is reused; index zero is not incorrectly made invertibility.','locator':'README.md:156–177'},
 {'supplier':'SchemeAndStackFoundations 1.22/3.3','disposition':'Stack descent and Euler degree statements match use. They do not alone construct holomorphic Fredholm family lines.','locator':'README.md:2989–3006,4713–4727'},
 {'supplier':'ComplexComparisonPartII C-1.1/C0.3','disposition':'Finite-dimensional analytic ring-sheaf/bundle descent supplied; not an infinite-dimensional Fredholm/canonical section theorem.','locator':'README.md:723–741,1018–1047'},
 {'supplier':'AnalyticNumberTheoryPartII 4.3/4.3a','disposition':'Normalized Barnes product, recurrence off Gamma poles, zeros and analytic slit-plane logarithms/sector bounds are stated. Periodic multipliers are excluded by normalization/asymptotics.','locator':'README.md:178–224'},
 {'supplier':'LieGroupoidsPoisson G4.6A / HamiltonianReduction R2–R3','disposition':'Positive Lie–Poisson and KKS conventions with fiber-negation adapter confirmed; complex Takiff/family reduction extension remains owned locally.','locator':'LieGroupoidsPoisson README:1325–1340; HamiltonianReduction README:130–138,187–201'},
 {'supplier':'Mathlib Gronwall and TauCeti smooth-parameter ODE','disposition':'Existing estimates require trajectory hypotheses or stronger smoothness; new native no-exit theorem is substantive. Continuous-time local-extension floor explicitly routed to 5.2.','locator':'Gronwall.lean:162–183; SmoothParameter.lean:139–165; frozen README 5.2'}
]
# Assert complete API/check coverage and synchronized, explicit current text.
assert set(rows)==set(ids)
for k,r in rows.items():
 assert {a['name'] for a in r['api_audit']}=={a['name'] for a in pt[k]['api']},k
 assert {c['name'] for c in r['check_audit']}=={c['name'] for c in pt[k]['tests']},k
 assert all(c.get('witness') and c.get('disposition') for c in r['check_audit']),k
 assert len(r['instances'])==len(r['computed_left'])==len(r['computed_right'])==len(r['instance_results']),k
(OUT/'tau_ledger.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f={'status':'complete','readme_sha256':expected['README.md'],'plan_sha256':expected['design/plan.json'],'suggested_lean_sha256':expected['Suggested.lean'],'verdict':'conditional_mathematical_design_pass','official_worker_acceptance':False,'actionable_finding_count':0,'findings':[],'round2_finding_closures':closures,'prior_regressions':d['prior_findings'],'coverage':{'targets':ids,'target_count':d['target_count'],'api_count':d['api_count'],'check_count':d['check_count'],'fresh_source_sample':['8.3','10.4','11.4']},'acceptance_gates':d['acceptance_gates'],'limitations':d['limitations']}
(OUT/'tau_findings.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'targets':d['target_count'],'apis':d['api_count'],'checks':d['check_count'],'findings':len(d['findings']),'sections_identical':sum(x['byte_identical_to_round2'] for x in sections.values()),'new_computations':len(comp['cases'])}))
