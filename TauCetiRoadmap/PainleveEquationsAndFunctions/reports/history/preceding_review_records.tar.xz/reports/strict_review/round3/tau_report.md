# Strict Round 3 review: tau, RHP and confluence

## Verdict and scope

**Conditional mathematical-design pass: zero concrete actionable findings in the twelve assigned targets.** Both Round 2 findings, TAU-R2-01 and TAU-R2-02, are closed by the frozen Round 3 text. The six earlier tau findings remain closed after a same-defect regression review. This is a judgment about the mathematical contracts and their native-statement correspondence, with expressly owned future proofs and precisely declared supplier gaps. It is not an assertion that those proofs are finished.

**Official Worker acceptance is not established.** No Worker entrypoint, lane, board, provider job or GitHub mutation was run. A successful pinned Lean elaboration and the distinct-model-family review gate are both absent. The pinned runtime startup failure was already established in this session; this reviewer did not rerun that environment failure. Native API/static elaboration audit is assigned separately to the core reviewer. No static check in this report is relabeled as a successful build.

Frozen inputs at `_strict_review/round3/artifact`:

| Input | SHA256 |
|---|---|
| README.md | `b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502` |
| design/plan.json | `1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10` |
| Suggested.lean | `74eeedeeb47cc963f1c2c28382b5fb901a85df34e0f521e7cc7fa4fcccf5afa6` |

The audit covers **12 targets, 32 named APIs and 42 Checks**, with individual witnesses/dispositions in `tau_ledger.json`. All three hashes were checked before the audit and again while recording evidence. The native dependency checkouts resolve to mathlib `f6090c7095e1e56b3464c1daba5f24631f1290d2` and Tau Ceti `358314d4ab97483df4fc4cb8adcc02e74a8d9f5a`.

The controlling review rules were `_strict_review/protocol.md` and the actual Worker review/redteam, adversarial, defect-class, gaps/order, Lean-form, dependencies, review-lessons and source rules cached under `_research/worker_contract_sources` at Worker revision `46e12afb791b1efab8fd8b3285370d689ba2e7b8`. The strict closure standard was applied to changed assertions and repeated defect classes, while precise unfinished proof obligations were not manufactured into defects merely because this is a roadmap.

## Round 2 finding closure

### TAU-R2-02: primitive endpoint conditions — closed

The former domain could preserve projective formal type, adjoint deformation ranks and stability while allowing an irregular scalar determinant. Round 3 now requires **“both primitive endpoints to be objects of §1.3”** and immediately spells out genus zero, rank two, structural degree four, admitted local formal structures, a regular-singular determinant with fixed residues and compatible time transport, the actual reduced versal time problem, generic weights and nonempty stable fibers. The plan statement and prerequisite list agree. This is a carrier/domain condition, followed by the actual relation/Kodaira–Spencer rank tests; the phase/time dimensions and equality of horizontal distributions are still conclusions to prove.

The global coefficient test is now accurately scoped. Its collision part satisfies

\[
-\frac{B}{\varepsilon z}+\frac{B}{\varepsilon(z-\varepsilon T)}
=\frac{TB}{z(z-\varepsilon T)}\longrightarrow\frac{TB}{z^2}.
\]

The finite residues sum to \(C+D\), so the residue at infinity is \(-C-D\). The primitive positive test explicitly imposes \(\operatorname{tr}B=0\). For \(B=\operatorname{diag}(1,-1)\), the new determinant double-pole coefficient is zero. This passes the determinant-pole test only; the text still requires the remaining §1.3, exponent, stability and time comparisons before calling it a moduli arrow.

The new negative Check takes \(B=\operatorname{diag}(1,2)\). Its trace-free part is \(\operatorname{diag}(-1/2,1/2)\), with the same projective slope-one shape, but its determinant connection contains \(3T\,dz/z^2\). At \(T=2\), the coefficient is exactly 6. This endpoint is now excluded explicitly, even though a scalar twist leaves invariant subbundles and the trace-free commutator complex unchanged. A positive-genus endpoint is independently excluded by the now-explicit genus-zero condition; local profiles cannot evade that requirement.

Boundary endpoints are separately computed: actual structural/local data, determinant pole order and the leading/rank failures must be recorded. An elementary scalar arrow requires a separately proved dictionary and phase/first-jet comparison. An unverified comparison component has no solution-convergence arrow. Thus §11.3 no longer inherits the former scope hole.

### TAU-R2-01: generic native no-exit theorem — closed at statement level

`Suggested.lean:169–253` now contains genuine definitions for closed subdivision segments, actual within-derivative tangent equations, coordinate expressions of tangent fields, and moving chart tubes. The headline `finite_chart_compact_path_no_exit_convergence` quantifies:

- A finite-dimensional real model space and a metric manifold with native charts.
- Strictly ordered finite breakpoints covering a nondegenerate compact interval.
- Actual nonautonomous tangent fields for every approximation index and a reference field.
- A continuous reference trajectory solving the equation on every closed segment.
- Fixed positive-radius closed coordinate tubes lying in the chart targets.
- Joint continuity on the tubes and a common phase Lipschitz constant.
- A uniform field-defect bound \(\delta_n\to0\), and convergent initial values.

Its only assumed solution is the reference trajectory. No approximating trajectory, continued existence or tube membership is an input. The conclusion constructs an approximation family and, eventually in its index, asserts the prescribed initial values, actual piecewise differential equations over the whole interval, chart-source membership, **strict** tube containment, the segment estimates, and `TendstoUniformlyOn` as manifold-valued curves.

The per-segment estimate has the correct inherited initial error:

\[
e_{n,i}(t)\leq
\bigl(e_{n,i}(a_i)+(t-a_i)\delta_n\bigr)
\exp\bigl(L(t-a_i)\bigr).
\]

It does not restart the error at zero at a chart transition. The README now says that the fields have already been pulled back by the actual path, including its velocity, and that \(\ell\) is the **parameter interval duration**. For \(\gamma(s)=2s\), \(s\in[0,1]\), and geometric constant field error \(\varepsilon\), the pulled error is \(2\varepsilon\), giving the exact bound \(2\varepsilon\). Dropping the path velocity would give the wrong value \(\varepsilon\).

The mathematical hypotheses support the asserted existence/trapping mechanism. Reference continuity and positive tube radius give local rectangular neighborhoods inside each moving tube, relative to the time segment. Continuous-time, phase-Lipschitz local existence applies there. The new §5.2 floor explicitly owns this nonautonomous adapter and finite-chart continuation; it does not improperly obtain time differentiability by autonomization. Gronwall makes the error smaller than the strict margin for sufficiently large indices, rules out first exit, and permits continuation. Finite-dimensional closed coordinate tubes over compact intervals are compact; inverse charts and a finite number of overlap maps provide the compact continuity needed for gluing and metric uniform convergence. Global completeness or properness of the manifold metric is not required.

Within derivatives on the closed pieces permit different one-sided velocities at a cut, with global continuity of the curve. The finite induction transfers cut-point convergence through overlap maps. Taking arbitrary convergent sequences on the stated first-countable complex parameter cover is appropriate for the local parameter limit, with uniqueness fixing the solution germs; the same quantitative margin argument gives eventual existence. This sequential formulation does not claim a bound uniform over unbounded times or singular endpoints.

Fresh tests of this repaired claim:

| Test | Computed result | Contract consequence |
|---|---|---|
| \(F_n=1/(n+1)\), \(F_0=0\), initial 0, \([0,2]\) | \(x_n(t)=t/(n+1)\), exact error \(2/(n+1)\); at \(n=3\), error \(1/2\) | New positive Check1 and strict radius-one trapping pass. |
| Same field \(F(x)=x\), initial error \(\varepsilon\) | Exact error \(|\varepsilon|e^\ell\) | The exponential factor is substantive. This unchanged R2 calculation was rechecked algebraically. |
| Two charts \(u=x\), \(v=2x+5\); cuts 0,1,2; intrinsic fields \(\varepsilon,\varepsilon/2\) | Both chart-field defects are \(\varepsilon\). At \(\varepsilon=1/4\), second-chart start error \(1/2\), end error \(3/4\), matching its bound | Finite-chart propagation and distinct one-sided velocities are consistent. |
| Reference time field \(|t-1/2|\), perturbed by \(\varepsilon\), on \([0,1]\) | Reference primitive is \(t/2-t^2/2\) then \(t^2/2-t/2+1/4\); difference \(\varepsilon t\), terminal error \(\varepsilon\) | Continuous time, without C1 time regularity, is genuinely admitted and supported by the stated floor. |
| Zero fields, initial values \((-1)^n\) | Constant solutions have subsequences 1 and -1 | Correctly excluded by initial convergence. |
| \(F_n=F_0=2\sqrt{|x|}\), reference zero, initial \(1/(n+1)^2\) | Solutions \((1/(n+1)+t)^2\to t^2\), not zero; phase quotient \(2/\sqrt h\) is unbounded | Correctly excluded by the common Lipschitz hypothesis. |
| \(x_n'=\varepsilon\) on an unbounded ray | Compact error \(\varepsilon T\), but infinite supremum over the ray | The retained compact-interval scope is essential. |

Mathlib `dist_le_of_approx_trajectories_ODE_of_mem` (`Gronwall.lean:162–183`) assumes both trajectories, their derivatives and membership in the common sets. The new theorem concludes those properties for the approximation and is not a one-tactic padding of that estimate. The inspected Tau Ceti smooth-parameter theorem (`SmoothParameter.lean:139–165`) also has different, stronger smoothness and vanishing-base hypotheses. Neither source discharges the owned continuation proof automatically.

This closes the omission at mathematical statement/design level. Its `sorry` is an admitted future proof in the roadmap; the environment has not elaborated the statement successfully.

## All twelve target dispositions

Every row has a current explicit API/Check mapping in `tau_ledger.json`. “Pass” below always means the conditional contract verdict above.

| Target | Concrete audit and counterexample boundary | Disposition |
|---|---|---|
| 8.1 complex determinant-family adapter | Scalar families \(s\) and \(s^2\) distinguish section zero multiplicity from kernel dimension; base change \(s=u^2\) sends \(s^2\) to \(u^4\). Transition factors \((2/3)(3/5)=2/5\) test cocycles. The complex family extension remains an explicit gap. | Pass |
| 8.2 tau line | \(\mathcal O(-1)\oplus\mathcal O\) has \(\chi(E(k))=2k+1\), so no balancing twist exists. \(\operatorname{diag}(z,z^{-1})\) has zero determinant winding but a nontrivial kernel/cokernel. Adding an unrelated two-term complex creates a spurious zero divisor. | Pass; index-zero and descent requirements remain substantive. |
| 8.3 divisor/variation comparison | The finite-rank determinant test gives \(2\,ds/s\); a bundle jump does not disappear because a normalized frame fails. Vertex curvature is nonzero in the triangular three-ray test. The slope-1/2 ramified example is excluded from generic JMU comparison. | Pass; source sample freshly checked. |
| 8.4 Hamiltonian tau normalization | \(H=t\) yields \(\tau=e^{t^2/2}\); adding 3 multiplies by \(e^{3t}\). Under \(u=2t\), the one-form coefficient is \(u/4\). Identical logarithmic derivatives do not fix the factor 7. Nonclosed \(x\,dy\) is not integrable merely on a simply connected space. | Pass; frame, basepoint and convention data remain explicit. |
| 10.1 sectorial boundary specification | \(e^{-t}\) and \(2e^{-t}\) have the same zero formal power series. A blowup boundary may have distinct points over the same scalar coordinate. Common frame rescaling preserves a ratio but changes both constants. | Pass; the full boundary/germ data are retained. |
| 10.2 small-norm RHP | Identity jump has \(h=0\), so the prescribed Cauchy class excludes the endpoint ghost \(I+e^{-1/z}E_{12}/z\). The jump \(-I\) is outside the small-norm regime despite an elementary exact solution. Exponential moment densities give distinct nonzero first three coefficients. | Pass; endpoint/removability and weighted moments are explicit. |
| 10.3 connection formula scopes | Generic PII triple \((i,i,0)\) is still outside a chosen logarithmic coordinate; HM \((-i,0,i)\) is outside the generic formula. The rotated HM triple and normalized constant retain the \(+i\pi/24\) phase. \(e^{-z^2}\) separates real-axis flatness from sector control. | Pass; uniform sector theorem remains owned. |
| 10.4 HM intrinsic bridge | \(q(t_0)=a,q'(t_0)=b\) gives \(p=b+a^2+t_0/2\); \((a,b,t_0)=(1,2,0)\) gives \(p=3\). A factor 2 violates Airy normalization. Real pole-freeness does not imply complex pole-freeness, as \(1/(z-i)\) shows. | Pass; source sample freshly checked. |
| 11.1 geometric collision families | The dual-number specialization, corrected all-r Laurent coefficients, three identical-divisor slopes, negative/positive Poisson adapter, time-matrix determinant and full primitive endpoint tests all retain their proper domains. | Pass; TAU-R2-02 closed. |
| 11.2 compact-path convergence | Fresh constant-field, affine-chart, continuous-time, initial-value and non-Lipschitz tests distinguish every essential input from the existence/trapping output. | Pass at mathematical statement level; TAU-R2-01 closed. |
| 11.3 cascade comparison | \(u=2t\) requires its velocity adapter; \(q=x^2\) loses the distinction between \(x=1\) and \(x=-1\). The two iterated limits of \(\varepsilon/(\varepsilon+\delta)\) differ. | Pass; arrows are verified comparisons and composition is not inferred from labels. |
| 11.4 normalized tau confluence | \(e^{1/\varepsilon}\) has zero time logarithmic derivative but divergent normalization. For \(z-\varepsilon\), determinant zeros converge while logarithmic derivatives diverge near the moving zeros. Interval rescaling changes the constant kernel determinant from \(3/4\) to \(1/2\) when the Jacobian is included. | Pass; source sample freshly checked. |

## Regression tests and source limitations

### JMU scope, RHP class and sector calibration

The §8.3–8.4 JMU/Hamiltonian comparison remains restricted to the BERT10 generic unramified domain: distinct relevant eigenvalues and logarithmic nonresonance. The slope-1/2 local example stays outside it. Broader proved Fredholm/RHP adapters do not silently acquire a JMU equality. The relevant §9.4–9.5 downstream wording and §11.4 were cross-read for the same error class.

For §10.2, normalized reconstruction is in the stated Cauchy class \(R=I+C(h)\), with the actual jump density \(h=R_+-R_-\). The identity-jump endpoint ghost has zero jump density and therefore cannot occur in that class. Endpoint small-circle conditions, determinant removability and weighted moments remain separate hypotheses/owned lemmas. The moment model \(h(x)=e^{-x}E_{12}/4\) gives moments \(1/4,1/4,1/2\); the corresponding coefficients \(i/(8\pi),i/(8\pi),i/(4\pi)\) show that the weighted asymptotic statement is more than bare L2 solvability.

For §10.3, real pole-freeness and a real asymptotic are not substituted for the required closed-sector estimates. The owned RHP-parametrix target supplies uniform bounds including the endpoint behavior needed for arc integration. The R2 calculation

\[
\int \exp(-aR^{3/2}\sin(3\theta/2))\,d\theta
\leq \frac{\pi}{3aR^{3/2}}
\]

and the first/second arc rates \(O(R^{-3/2})\), \(O(R^{-3/4})\) were reused after byte equality and checked against the retained hypotheses. The logarithmic arc calibration remains \(+i\pi/24\). Barnes recurrence is applied away from Gamma poles with normalized analytic logarithms; the product/sector normalization excludes periodic multiplier ambiguity.

### Laurent coefficients and Poisson conventions

The GMR printed Laurent statement remains expressly rejected as a rank-raising lemma. Under its printed \(C=O(\varepsilon^{-r})\), \(P=O(\varepsilon)\), one obtains \(CP^{r+1}=O(\varepsilon)\), so the claimed new highest coefficient vanishes. The Round 2 visual record `_strict_review/source_visual_audit.json` checked the cached original PDF, printed pages 1391–1392, against rendered PDF pages 7–8. That earlier visual verification is attributed here, not represented as a new visual inspection.

The owned repair uses \(C\) of pole order at most \(r+1\) and

\[
B_j=-[CP^j]_{<0}+D_j.
\]

Then the lower limits are \(D_j(0)+[CP^j]_0\), the new highest coefficient is \(t_1^{r+1}W\), and the exact remainder is

\[
\frac{CP^{r+2}}{z^{r+2}(z-P)}=O(\varepsilon)
\]

locally uniformly away from zero. The unchanged all-r algebra and R2 exact tests at \(r=0,\ldots,5\), \(t_1=2,W=3\), give highest coefficients 6,12,24,48,96,192. The \(r=1,\varepsilon=1/4,z=2\) whole-expression test still gives \(W/7\). None of this alone classifies projective slopes or proves horizontal-field convergence; those remain separately owned comparisons on the regular locus.

The source writes \(dY/dz=A_{source}Y\) with negative Lie–Poisson brackets; the roadmap uses \(\nabla=d+A_{ours}\) and a positive supplier convention. The explicit \(A_{ours}=-A_{source}\) acts on all coefficients and exponent/residue parameters. For \(X=E_{12},Y=E_{21},\nu=\operatorname{diag}(1,-1)/2\), the source bracket is -1 and the positive target bracket at \(-\nu\) is also -1; an identity comparison would give +1. KKS, moment-map and reduction transport remain required, and the complex Takiff-family extension is not attributed to the real regular-reduction supplier.

### Fresh sample and supplier refresh

The three assignments from the new seeded 15-target source sample are **8.3, 10.4, 11.4**. The exact seed is retained from `seeded_source_sample.json` in the ledger. Primary cached text was freshly read at these locators:

| Source | Locators | Verified scope |
|---|---|---|
| BERT17 | Theorem2.2/Proposition2.3, cached lines318–370; formula(3.6), lines822–869; Theorem3.3, lines900–950 | Integrable-RHP/Fredholm relation and actual factorization/contour frame corrections on the invertible domain. |
| BERT16 | Definition2.1/Theorem2.1, lines78–121; Theorem2.2, lines203–226 | Corrected vertex curvature and the monodromy-dependent correction; raw forms are not assumed closed. |
| BERT10 | Assumption3.1, lines1584–1608; Proposition5.1, lines2060–2088 | The generic unramified/nonresonant JMU restriction, not a ramified universal identity. |
| VDPS09 | §4.10, lines3524–3596 | PII scalar chart and Hamiltonian normalization; no attribution of HM analytic existence to this chart source. |
| Refreshed HeegaardFloer | §2.2/F0.0, current lines1376–1429 and1479–1530; supplied delta patch | Real Banach determinant-family package, continuous/smooth transitions and orientation transport. |

The latest-main commit identifier `c9a16a043c3bf2321c63dff75e3f709466373528` was supplied by the parent. This reviewer independently read the refreshed local file/delta and recomputed file SHA256 `f7df5b538dc115870d446064a1b6571dc437dcf60451398d17dea86d22651676`; no new remote ownership search is claimed. The F0.0 change does not supply the complex holomorphic determinant line, canonical section and transition package required here. The explicit **F0.0C gap remains necessary**.

The other consumed supplier contracts were checked at their cached declarations: general trace-class family/completeness input in OperatorIdeals, Fredholm determinant continuity before DPP positivity in RandomMatrices8.3, real Airy-normalized HM existence in RandomMatrices8.5, matrix-symbol Fredholm/index in ToeplitzOperators, stack descent/Euler degree in SchemeAndStackFoundations1.22/3.3, finite-dimensional analytic bundle/sheaf descent in ComplexComparisonPartII C-1.1/C0.3, Barnes normalization/sector bounds in AnalyticNumberTheoryPartII4.3/4.3a, and positive Poisson/KKS/free-proper regular reduction in LieGroupoidsPoisson G4.6A and HamiltonianReduction R2–R3. These interfaces are not inflated into the missing infinite-dimensional holomorphic determinant-family, complex Takiff-family or continuous-time continuation proofs.

## Evidence reuse and deliverables

Ten of the twelve complete target sections are byte-identical to Round 2. Sections11.1 and11.2 changed; their repaired claims were audited afresh, while their unchanged exact formula blocks were cross-read before retaining attributed prior calculations. The nine reused primary source texts have identical SHA256 values to the Round 2 records. The full section hashes, source hashes, prior-ledger/result hashes, current API/Check statements, witnesses and per-target dispositions are stored in `tau_ledger.json`.

The report does not rerun unchanged optional numerical tests or copy an old verdict forward. It retains their identified calculations and re-evaluates the current contracts. Fresh exact calculations are in `tau_computations.json`, produced by `tau_finalize.py`. No frozen or canonical artifact was changed.

- `tau_findings.json`: zero actionable findings; two Round 2 closures; six maintained regressions; explicit unmet gates.
- `tau_ledger.json`: all twelve targets, 32 APIs, 42 Checks, source/dependency scopes and byte-equality provenance.
- `tau_computations.json`: repaired endpoint and native-convergence witnesses.
- `tau_finalize.py`: reproducible evidence assembly and structural coverage assertions.

The remaining obstacles to official acceptance are the recorded environment and independent-family gates, not a newly identified mathematical defect in the reviewed scope.
