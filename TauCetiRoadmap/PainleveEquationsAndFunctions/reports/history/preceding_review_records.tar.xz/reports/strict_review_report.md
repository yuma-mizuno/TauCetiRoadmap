# Painlevé ロードマップ：厳格レビュー記録

> 履歴の位置づけ：このファイルは初回3巡の記録を保持する。ユーザーの数学内容への集中という指示を受けた最新の再レビューは `mathematical_review_report.ja.md` と `mathematical_review/` にある。以下の件数・判定・実装状況は、記載された過去の固定版に対するもの。

2026-11-05。対象は未公開の設計ドラフト `PainleveEquationsAndFunctions`。

## 判定の意味

この記録は、TauCetiRoadmapWorker の実際の review / red-team / adversarial / defect-class / dependency / Lean-file の規約を読み、Worker 自体を起動せずに、固定した版へのレビュー、著者による修正、別セッションでの再レビューを行った結果である。初回の無条件な完成宣言は撤回した。

**3巡の厳格レビューを完了し、第3巡の全44項目で未解決の内容上の指摘は0件となった。** 第1巡の13件、第2巡の3件を修正し、それぞれ修正後の固定版で解消を確認した。合計は P2 が15件、P3 が1件である。これを内容レビュー済みの設計ドラフトとして確定する。Lean elaboration と異なるモデル系列によるレビューは未通過であり、公式 Worker の package acceptance や一般定理の証明完成は宣言しない。

Worker、lane、provider job、投稿処理は実行していない。push、issue、PR 作成を含む GitHub への書込みは行っていない。

## 実際に適用した方法

Worker revision は `46e12afb791b1efab8fd8b3285370d689ba2e7b8`。本体の review と red-team の指示、欠陥分類、先行レビューからの教訓、supplier と gap の扱い、native な定理署名の規約を確認した。レビュー対象の README と plan、Suggested.lean などを凍結し、内容の SHA256 を保存した。レビュアーは凍結版を変更せず、著者が canonical 版に修正を加えた。修正がある場合、旧版の合格を新版に流用していない。

全44項目を、Layers 1–5 の21項目、Layers 6・7・9 の11項目、Layers 8・10・11 の12項目に分けた。第1巡・第2巡の各巡で全項目を読み、各 API と検査例、仮定、出典、依存先との境界を点検した。「確認した」という記述だけで済ませず、具体的な値、式、反例または構造的な反例を台帳に記録した。

出典は、README のハッシュを含む seed から選んだ15項目と、指摘のある出典・変更された主張を検査した。seed、選択方法、対象一覧を保存した。各巡の報告書、指摘一覧、計算台帳、著者の処置、凍結版を `strict_review/` に収録する。

## 第1巡：12件の P2 と1件の P3

第1巡は全44項目、114個の API 法則、112個の診断例を対象とした。次の13件を修正し、第2巡の別セッションのレビューで、それぞれ元の欠陥の解消を確認した。ここで「解消」は、ロードマップの対象・仮定・出典・証明の担当箇所が修正されたことを意味し、一般定理の証明完成を意味しない。

| ID | 重大度 | 発見した問題と判別例 | 修正 |
|---|---|---|---|
| C01 | P2 | `A−tr(A)I/r` を大域的な rank-r 接続と扱うことはできない。A=0、g=diag(z,1) で射影化した局所行列は diag(1/2,−1/2)dz/z となる。 | 大域的な対象を End⁰(E) 上の誘導接続と PGLᵣ 接続にした。trace subtraction は局所表示の補題にした。 |
| C02 | P2 | 入力はラベルを保存するのに、ラベルを忘れた10型だけを数えていた。 | ordered profile は17型、underlying profile は10型と区別した。支えの点数ごとの ordered 個数は2,8,6,1。 |
| C03 | P2 | 一般の次元公式に r=0 を入れると2が出るが、零対象の変形次元は0。 | rank r≥1 を明示し、rank 1・genus 1 の unfixed 2 / fixed determinant 0 も検査した。 |
| C04 | P2 | シンプレクティック形式の閉性を示すための極の unfolding が、先に構成されていなかった。 | §2.3 が有限平坦な補助 unfolding とモジュライ族、複体、trace 形式、対数的一般ファイバーとの比較、閉性の特殊化を所有する。Layer 11 への循環を除いた。 |
| C05 | P2 | 未実装の Painlevé carrier を理由に、既存の native carrier 上で述べられる §5.2 の一般継続定理まで省略していた。 | 本物の manifold・tangent/hom bundle・微分・proper map を使う定理署名を追加した。 |
| C06 | P2 | 束の splitting type の locus を一般に open と扱っていた。 | 一般には locally closed とし、balanced な open locus を区別した。O(−1)⊕O(1) から O² への extension family で検査した。 |
| C07 | P3 | 以前の輸送の検査は、常に恒等写像を返す実装でも通過した。 | H=qp/(2t) の周回輸送 (q,p)↦(−q,−p)、二周回で恒等、固定点集合 {(0,0)} を追加した。 |
| TAU-R1-01 | P2 | L² 境界値と無限遠の正規化だけでは RHP の端点に現れる異常項を排除できなかった。 | R=I+C(h)、h=R₊−R₋∈L² という解のクラス、端点小円弧の消失、行列式の可除性、必要な moment 条件を明記した。 |
| TAU-R1-02 | P2 | GMR23 の印刷された rank-raising の添字をそのまま使うと、主張された最高次係数が0になる。 | 実際の Laurent 係数でキャンセルを定義し、最高次と余項を直接計算する訂正補題を §11.1 が所有する。 |
| TAU-R1-03 | P2 | 合流の矢印が形式型の名前だけで指定され、同じ極因子でも異なる形式的極限を区別できなかった。 | leading orbit、次の係数、determinant、時間・指数・ラベル・分岐の写像を保持する collision-data groupoid と、検証済みの矢印から生成する圏を定義した。 |
| TAU-R1-04 | P2 | GMR の負の Lie–Poisson 規約と、supplier の正の規約の同一視に符号が欠けていた。 | A_ours=−A_source を全係数に明示し、pairing、KKS、moment map、reduction まで比較する。 |
| TAU-R1-05 | P2 | 分岐・共鳴した全 strata の JMU/Hamiltonian 公式を、定義・適用範囲なしに約束していた。 | 一般の determinant/Fredholm 変分理論は構成された RHP adapter 上に保ち、JMU/Hamiltonian 同一視は出典が扱う generic unramified/nonresonant locus に限定した。 |
| TAU-R1-06 | P2 | Hastings–McLeod の接続定数の校正に、実軸での情報だけでは足りなかった。 | 複素閉扇形での具体的な一様 Hamiltonian 評価、大円弧積分の消失、位相 +iπ/24 の証明を §10.3 が所有する。 |

このほか、非被約基底 A=ℂ[ε]/ε² 上の A/(ε) が全ファイバー次元1でも局所自由でない例、PVI 中央反射の κ₀ の符号、PII の Riccati 族全体が σ=0 に写る例を検査に加えた。これらは独立した指摘件数を水増しせず、検査の強化として記録している。

## 第2巡：元の13件の解消と、新たな3件の P2

第2巡も全44項目を読み、115個の API 法則と126個の診断例を対象とした。元の13件は個別に再検査して解消した。一方、次の3件が新たに確定した。同じ問題を複数のレビュアーが発見した場合は一件にまとめた。以下の3件も第3巡で解消を確認した。

| 統合 ID | レビュー上の ID | 問題 | 修正と第3巡の判定 |
|---|---|---|---|
| R2-CLASSICAL-ENDPOINT | R2-GEOM-11.1-CLASSICAL-ENDPOINT / TAU-R2-02 | 新しい合流の定義が primitive な始点・終点に §1.3 の全条件を明示していなかった。 | 種数0、rank 2、構造的極次数4、局所条件、regular-singular determinant と固定残差・整合的な時間輸送、reduced time、非空な stable locus を明示した。境界の endpoint は別扱いにした。 |
| R2-NATIVE-COMPACT-PATH | CORE-R2-01 / TAU-R2-01 | §11.2 の一般的な存在・非脱出・収束定理も native carrier で述べられるのに省略されていた。 | 有限チャート、実際の接ベクトル場、共通の正の半径の tube、一様 Lipschitz 評価、誤差と初期値の収束を使う定理署名を追加した。 |
| R2-EXPLICIT-NATIVE-MODEL | CORE-R2-02 | PiecewiseC1On と TargetTransport のモデル EB が、型の入力から決まらない箇所で暗黙の推論に依存していた。 | 5箇所の PiecewiseC1On と TargetTransport の型に `(EB := EB)` を明記した。これはソースから確認された推論上の危険であり、実際のコンパイルエラーを観測したという報告ではない。 |

### 合流の適用領域を狭める必要がある具体例

大域的な係数族

\[
A_\varepsilon(z)=\frac{-B/\varepsilon+C}{z}
 +\frac{B/\varepsilon}{z-\varepsilon T}+\frac D{z-1}
\]

は、z=0 を避けるコンパクト集合上で

\[
A_0(z)=\frac{TB}{z^2}+\frac C z+\frac D{z-1}
\]

に収束する。B=diag(1,2) の場合、trace に 3T/z² が現れる。projective な slope は1でも、determinant は irregular になる。さらに scalar matrix の追加は adjoint connection、trace-free な変形複体、関係式の階数、不変部分束を変えないため、それらの検査だけではこの例を排除できない。修正後は primitive classical domain で明確に除外し、正の検査例には tr(B)=0 を課す。

### 一般定理の署名が前提にしていないもの

§11.2 の定理候補で仮定する解は基準軌道 x₀ だけである。近似軌道 xₙ の存在、最後の時刻までの継続、tube 内への包含は結論に置いた。各パラメータ区間の長さを ℓ、場の誤差を δₙ とすると、局所的な評価

\[
\sup\|x_n-x_0\|
\le (\|x_n(a)-x_0(a)\|+\ell\delta_n)e^{L\ell}
\]

と正の余裕から非脱出を証明し、有限個のチャートを接着する。既存の Grönwall の評価は、比較する二本の軌道が存在し tube に入っていることを仮定するので、それだけではこの主定理を置き換えない。

また C¹ の経路 γ(s)=|s−1/2|^(3/2) の速度は C¹ ではない。従って、時間を追加した場に C¹ 自律系の定理を無条件に適用できない。時間方向には連続、位相変数方向には局所 Lipschitz という実際の Mathlib の Picard–Lindelöf / uniqueness API を使うチャート上の構成を §5.2 が所有し、§11.2 が利用する。この修正は証明経路の明確化であり、§5.2 の主張自体の反例ではない。

## 出典に対して行った追加検査

GMR23 の該当箇所は、テキスト抽出だけでなく元の PDF の印刷頁1391–1392、式(12)–(15)を画像として確認した。C=O(ε^(−r))、P=O(ε) では CP^(r+1)=O(ε) であり、新しい最高次係数は残らない。これは OCR の誤読ではない。

訂正した補題では C の極次数を r+1 以下とし、Bⱼ=−[CPʲ]₍<0₎+Dⱼ で負の Laurent 係数を消す。C の最高係数を W、P=t₁ε+O(ε²) とすると、最高次係数は t₁^(r+1)W である。恒等式

\[
\frac{C}{z-P}=\sum_{j=0}^{r+1}\frac{CP^j}{z^{j+1}}
 +\frac{CP^{r+2}}{z^{r+2}(z-P)}
\]

の最後の項が、z=0 を避けるコンパクト集合上で O(ε) となることを証明する。この式は行列係数の極次数についての補題であり、最小の projective Katz slope との一致は別の局所形式比較を必要とする。

BERT の変分公式は corrigendum も読み、符号、頂点補正、フレーム変化、非共鳴・非分岐の仮定を照合した。ILP の接続公式はパラメータの除外、正規化、対数の枝、絶対定数の校正を確認した。第一・第二の大円弧について、それぞれ O(R^(−3/2)) と O(R^(−3/4)) の評価を計算し、振動する境界角まで含めた。出典の定理を、その仮定を超える ramified/resonant な主張の証拠にはしていない。

22本の取得済み一次 PDF はハッシュを再計算した。DLMF は公式ページの表示を読み、原データの取得に失敗したため `uncertified` のままとし、架空の hash は付けていない。`certified` はこのファイルの取得 provenance の意味であり、数学的証明の認証ではない。

## 依存先の更新確認

作業開始時の Roadmap main は `a0ad405e151ff6e42b3c5e372ac3f24e168ad68f`。第1回の更新確認で `766fcec2512f250791032b7ad0798ed6415fd398`、第2回で `c9a16a043c3bf2321c63dff75e3f709466373528` となった。第2回には direct supplier の HeegaardFloer の変更があり、現在の §2.2 を全て読み直した。実 determinant family と orientation transport という供給範囲は維持され、複素正則な determinant family と canonical section は依然として明示的な F0.0C の拡張契約を必要とする。

5件の proposed supplier PR の head は再取得して変化がないことを確認した。Mathlib、Tau Ceti、Lean の pin は変わっていない。supplier のロードマップに所有者が記載されていることを、native な実装が存在するという意味には使っていない。

## 未通過の独立した gate

1. **Lean elaboration。** pinned Lean `v4.35.0-rc3` の公式実行ファイルは、elaboration の前に `error: failed to locate application` で失敗した。明示的な sysroot を使った再試行も成功しなかった。環境の制限を迂回していない。Suggested.lean の2つの定理署名と9つの補助定義は、ソース上の型・数学的な意味を検査したが、型検査済みとは表示しない。2つの theorem body の `sorry` は roadmap の目標署名としての意図的な未証明部分であり、データ定義は admitted にしていない。
2. **異なるモデル系列でのレビュー。** セッションと役割を分離したレビュアーを使用したが、Worker の設定にある異なるモデル系列によるレビューは得ていない。この条件を満たしたと表示しない。
3. **一般定理の実装・証明。** これは実装ロードマップである。全 strata の relative proper RH、moduli と表面の比較、ramified/resonant RHP adapter、複素扇形の解析評価、合流比較などは、精密な仮定・依存関係・担当項目を持つ今後の証明対象である。

従って、内容のレビューが問題なしとなっても、公式 Worker の package acceptance や Lean による形式化完成とは別である。

## 最終判定：第3巡

| 担当範囲 | 項目数 | 最終判定 | 個別の解消確認 |
|---|---:|---|---|
| Layers 1–5、Suggested.lean 全文、§11.2 の一般定理 | 21 | 未解決の内容上の指摘0件 | CORE-R2-01 / CORE-R2-02 を source・statement の水準で解消。 |
| Layers 6・7・9、合流の入口と後続比較、全依存図 | 11 | 未解決の内容上の指摘0件 | R2-GEOM-11.1-CLASSICAL-ENDPOINT を解消。 |
| Layers 8・10・11、τ・RHP・接続公式・合流 | 12 | 未解決の内容上の指摘0件 | TAU-R2-01 / TAU-R2-02 を解消。 |

第3巡の本文は11層・44項目、API 法則115件、診断例128件を持つ。内部依存は216本で、欠けた参照や循環はなく、Layers 1–8 から Layer 9 への推移的な依存もない。27件の supplier contract と2件の精密な named gap を保持する。静的・機械的な検査は1113件（17組の計算診断を含む）が通過した。

第3巡では変更された §§5.2、11.1、11.2 と Suggested.lean を新たに検査した。変更されていない節では、本文と plan の対象項目の一致を実際に確認し、以前の計算を明示的に帰属させて再利用した。全44項目の再評価と、新しい seed による15項目の出典検査は行っている。「以前の結果を読んだ」ことを「今回同じ計算を再実行した」ことにはしていない。

新たな有限チャート上の検査には、座標を y から 2y に替える場合の誤差の引継ぎ、一方微分の異なる折れ点、時間依存性が連続だが C¹ でない場、Lipschitz 条件を失った平方根の場の反例を用いた。したがって、新しい定理を単一の恒等チャートや既存解への評価だけで検査したわけではない。

### 確定した内容の同一性

| ファイル | 第3巡と納品版に共通の SHA256 |
|---|---|
| README.md | `b74672aa2bd4cbbb7b9d6991758a9e31f76560d1842a65508971d630ddd89502` |
| Suggested.lean | `74eeedeeb47cc963f1c2c28382b5fb901a85df34e0f521e7cc7fa4fcccf5afa6` |
| design/plan.json | `1aa9109b2b041ba25a84ba3a3cc95ea0004d01c2843f828a6533ee9081449e10` |

metadata.toml、sources.toml、design/README.md も含む6ファイルは、最終レビュー後に変更していない。最終判定はこの内容に対するものである。全ての凍結版は各巡の snapshot.json で検証でき、納品版の6ファイルとの結び付けは final_review.json と verify_review_snapshots.py で確認できる。

内容レビューを終了した後に加えたのは、判定・解消記録・再現方法・パッケージの検証情報である。本文の数学的主張や定理署名を、レビュー後に差し替えてはいない。

## 主な一次資料と照合箇所

- [Inaba, Moduli Space of Factorized Ramified Connections and Generalized Isomonodromic Deformation](https://sigma-journal.com/2023/013/) — §2、(6.9)、Propositions 8.2–8.3、Definition 10.1、Propositions 10.7/10.10、§11。
- [van der Put–Saito, Moduli spaces for linear differential equations and the Painlevé equations, v5](https://arxiv.org/abs/0902.1702v5) — §2.2 と Table 1、§4 の座標表示。原文の符号・係数の検査は別途 `VDPS09_sign_audit.md` に記録。
- [Gaiur–Mazzocco–Rubtsov, Isomonodromic Deformations: Confluence, Reduction and Quantisation](https://link.springer.com/content/pdf/10.1007/s00220-023-04650-8.pdf) — Theorem 2、印刷頁1391–1392、式(12)–(15)、Definitions 3–4、Theorems 12–13、§5.1。
- [Bertola, The Malgrange Form and Fredholm Determinants](https://arxiv.org/abs/1703.00046v4) — Theorem 2.2、Proposition 2.3、(3.6)、Theorem 3.3。2010年の論文と2016年の corrigendum も source manifest に別記。
- [Its–Lisovyy–Prokhorov, Monodromy dependence and connection formulae for isomonodromic tau functions, v4](https://arxiv.org/abs/1604.03082v4) — Theorems A/B、§3.9、(4.74)–(4.76)。
- [Worker の review 指示（検査した revision）](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/prompts/review.md)、[review evidence 規約](https://github.com/TauCetiProject/TauCetiRoadmapWorker/blob/46e12afb791b1efab8fd8b3285370d689ba2e7b8/docs/REVIEW-EVIDENCE.md)。
