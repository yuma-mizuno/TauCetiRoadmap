#!/usr/bin/env python3
"""Verify archived review bytes and the final canonical-file binding, not mathematical truth."""
from pathlib import Path
import hashlib,json,sys
base=Path(__file__).resolve().parent/'strict_review'
package=base.parent.parent
failures=[];counts={}
for directory in sorted(p for p in base.glob('round[0-9]*') if p.is_dir()):
    manifest=json.loads((directory/'snapshot.json').read_text())
    counts[directory.name]=len(manifest['files'])
    for rel,expected in manifest['files'].items():
        path=directory/'artifact'/rel
        actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual!=expected:failures.append(f'{directory.name}/artifact/{rel}')
current_math_path=package/'reports/mathematical_review/final_review.json'
final_path=base/'final_review.json'
if final_path.is_file():
    final=json.loads(final_path.read_text())
    for rel,expected in final['canonical_files'].items():
        # Once a later mathematical review exists, the old verdict binds its
        # historical final snapshot, not newly revised canonical mathematics.
        path=(base/f"round{final['final_round']}"/'artifact'/rel) if current_math_path.is_file() else package/rel
        actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual!=expected:failures.append(f'prior-final-binding/{rel}')
else:failures.append('missing final_review.json')
if current_math_path.is_file():
    current=json.loads(current_math_path.read_text())
    for rel,expected in current['canonical_files'].items():
        path=package/rel
        actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual!=expected:failures.append(f'current-mathematical-canonical/{rel}')
print(json.dumps({'archived_files':counts,'failures':failures,'scope':'Byte integrity and final-version binding only; not Lean elaboration or a proof certificate.'},indent=2))
sys.exit(bool(failures))
